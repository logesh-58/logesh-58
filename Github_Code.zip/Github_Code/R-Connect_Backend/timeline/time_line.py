from mouldmanagement.models import Mouldmodel
# from productiontable.views import name
from django.shortcuts import render
from workflow.models import Tickets
from machinemanagement.models import AddMachine
import datetime
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import badpart, breakdown, timeline
from .serializers import RejectionPartsSerializers, breakdownSerializers, timelineSerializers
import json
from productiontable.models import ProductionTable
from shiftmanagement.models import ShiftTimings
from celery.schedules import crontab
# from celery.task import periodic_task
from analysis.views import machineArray
from usermanagement.models import AddUser
from django.db.models import Q

def shiftStarttime(Plantname):
    shiftstarttime = datetime.datetime.now().time()
    for i in (ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')):    shiftstarttime = i['shift1start']
    return shiftstarttime

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------- Breakdown --------------------------------

def breakdownReason(reasonnumber):
    reasonarray = ['Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
    return reasonarray[reasonnumber - 1]

def diffTime(i, previoustime, currenttime, down_time):
    dict = {
        'id'            : i['id'], 
        'date'          : i['date'], 
        'difftime'      : str(down_time), 
        'Machinename'   : i['Machinename'], 
        'Mouldname'      : i['Mouldname'],  
        'MachineState'  : i['MachineState'], 
        'primaryreason' : breakdownReason(i['primaryreason']),
        'rootcause'     : i['rootcause'],
        'starttime'     : (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')).time(),
        'endtime'       : (datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')).time()
    }
    return dict

def fetchDowntimeData(today,nextDate, daystart, machinename, Plantname):
    breakdowndata           = breakdown.objects.filter(Q(date = today, time__gte = daystart, Machinename = machinename, Plantname = Plantname) | Q (date = nextDate, time__lte = daystart, Machinename = machinename, Plantname = Plantname)).all().order_by('id')
    # print(type(breakdowndata))
    breakdown_serialdata    = breakdownSerializers(breakdowndata, many=True)
    # print(type(breakdown_serialdata))
    # print(type(breakdown_serialdata.data))
    previousstate = -1; previoustime = ''
    currentstate = -1; currenttime = ''
    flag = 0
    DataArray = []; dict = None
    for i in (breakdown_serialdata.data):
        # print(i)
        currentstate = i['MachineState']
        currenttime  = i['date'] + " " + i['time'] 
        Mouldname_data = Mouldmodel.objects.filter(id = i['Mouldname']).values('Mouldname')
        # print(i['Mouldname'])
        for molddata in Mouldname_data:
            i['Mouldname'] = molddata['Mouldname']
        if(flag == 0):
            previousstate = currentstate
            previoustime  = currenttime
            flag = 1
        # print(previoustime, previousstate, currentstate, currenttime)
        if(previousstate == 0 and currentstate == 1):
            # if((previousstate != currentstate) and (previousstate < currentstate)):
            difftime = ((datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')) - (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')))
            if int(difftime.total_seconds()) >= 300:
               dict = diffTime(i, previoustime, currenttime, difftime)
               DataArray.append(dict)
        previousstate = currentstate
        previoustime  = currenttime
        # break
    return DataArray