from django.urls import path
from .import views, new_timeline

urlpatterns = [

    path('breakdown/', views.breakdowndata,name="timeline"),
    path('badpart/', views.RejectionPartsdata,name="timeline"),

    path('timelines/', new_timeline.data,name="timeline"),
]
