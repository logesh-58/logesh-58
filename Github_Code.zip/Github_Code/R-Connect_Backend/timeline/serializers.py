from django.db.models import fields
from .models import badpart, breakdown, timeline
from rest_framework import serializers

class timelineSerializers(serializers.ModelSerializer):
    class Meta:
        model = timeline
        fields = ('Machinename', 'productionhour', 'nonproductionhour', 'time', 'status', 'reason', 'Mouldname', 
                    'name', 'value', 'cause', 'operation', 'selectedmachine')

class RejectionPartsSerializers(serializers.ModelSerializer):
    class Meta:
        model = badpart
        # fields = ('date', 'time', 'Machinename', 'Mouldname', 'partcount', 'reason')
        fields = '__all__'

class breakdownSerializers(serializers.ModelSerializer):
    class Meta:
        model = breakdown
        fields = ('id', 'date', 'time', 'Machinename', 'Mouldname',  'MachineState', 'primaryreason', 'rootcause')