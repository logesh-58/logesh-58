from django.urls import path
from workflow import views, reportfile


urlpatterns=[
    path('workflow/',            views.ReportEvent,  name="workflow event"),
    path('ticket/',              views.TicketEvent,  name="ticket"), # get event name list 
    path('ticketdatas/',         views.Ticketdatas,  name="ticketdatas"), # get particular event data
    # path('id/(?P<tid>[0-9])/',   views.profile,      name="html"), # get particular event data
    # path('shiftwisereport/',     views.shiftreport,  name="shiftreport"), # get particular event data
    path('dailyreport/',        reportfile.report,         name="productiondata"), # get particular event data
]
