from django.db.models.base import Model
from rest_framework import serializers
from workflow.models import WorkflowData, Tickets

class WorkflowDbSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowData
        fields = ['eventtype',
                  'wfeventcode',
                  'wfeventname',
                  'wfeventgroup',
                  'wfresetinterval',
                  'wfpriority',
                  'wfactive',
                  'wfdescription',
                  'wfalertmessage',
                  'wfcorrectmessage',
                  'wfcreatedon',
                  'wfcreatedby',
                  'wfmodifiedon',
                  'wfmodifiedby',
                  'atoemail',
                  'accemail',
                  'asubject',
                  'apriority',
                  'amessage',
                  'stime',
                  'sschedule_days',
                  'saMouldname',
                  'sanextmaintenance',
                  'samoldalertinterval']

class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tickets
        fields = '__all__'