import datetime
from email.mime.base import MIMEBase

from analysis.views import machineArray
from .models import Tickets, WorkflowData
from .serializers import WorkflowDbSerializer, TicketSerializer
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
from django_celery_beat.models import PeriodicTask, CrontabSchedule
import json
from django.core.mail import EmailMessage
import smtplib
import math
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from django.db.models.aggregates import Sum
from datetime import timedelta

import os   
from RConnect.settings import BASE_DIR
from shiftmanagement.models import ShiftTimings
import xlwt
from timeline.models import badpart, timeline
from productiontable.serializers import ProductionTableSerializers
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from django.db.models import Q
from mouldmanagement.models import Mouldmodel


@csrf_exempt
def ReportEvent(request):
    global code
    code = ''
    if request.method=="GET":
        Plantname = request.GET['Plantname']
        workflowdata = WorkflowData.objects.filter(wfPlantname = Plantname).all().order_by('wfid')
        wfserializeddata = WorkflowDbSerializer(workflowdata,many=True)
        return JsonResponse(wfserializeddata.data,safe=False)
    
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        event           = httpdata["eventname"]
        code            = httpdata["wfeventcode"]
        eventname       = httpdata["wfeventname"]
        eventgroup      = httpdata["wfeventgroup"]
        resetinterval   = httpdata["wfresetinterval"]
        eventpriority   = httpdata["wfpriority"]
        eventstatus     = httpdata["wfactive"]
        description     = httpdata["wfdescription"]
        alertmsg        = httpdata["wfalertmessage"]
        correctmsg      = httpdata["wfcorrectmessage"]
        createdon       = httpdata["wfcreatedon"]
        createdby       = httpdata["wfcreatedby"]
        modifiedon      = httpdata["wfmodifiedon"]
        modifiedby      = httpdata["wfmodifiedby"]
        toemail         = httpdata["atoemail"]
        ccemail         = httpdata["accmail"]
        subject         = httpdata["asubject"]
        mailpriority    = httpdata["apriority"]
        message         = httpdata["amessage"]
        time            = httpdata["stime"]
        days            = httpdata["schedule_days"]
        # Mouldname        = httpdata["saMouldname"]
        # moldnextmaintenancedate = httpdata["sanextmaintenance"]
        # moldalertinterval       = httpdata["samoldalertinterval"]

        eventcodeall = WorkflowData.objects.values('wfeventcode')
        available_count = 0
        for i in eventcodeall:
            if(code == i['wfeventcode']):
                available_count = 1
                return JsonResponse('Data already exist..', safe=False)
        if (available_count == 0):
            ins = WorkflowData(
                wfeventcode         = code,
                wfPlantname         = Plantname,
                wfeventname         = eventname,
                wfeventgroup        = eventgroup,
                wfresetinterval     = resetinterval,
                wfpriority          = eventpriority,
                wfactive            = eventstatus,
                wfdescription       = description,
                wfalertmessage      = alertmsg,
                wfcorrectmessage    = correctmsg,
                wfcreatedon         = createdon,
                wfcreatedby         = createdby,
                wfmodifiedon        = modifiedon,
                wfmodifiedby        = modifiedby,
                atoemail            = toemail,
                accemail            = ccemail,
                asubject            = subject,
                apriority           = mailpriority,
                amessage            = message,
                stime               = time,
                sschedule_days      = days,
                # saMouldname          = Mouldname,
                # sanextmaintenance   = moldnextmaintenancedate,
                # samoldalertinterval = moldalertinterval,
                # eventtype           = event
            )
            ins.save()
            #-----------------Ticket event---------------
            if(event == 'preventive maintenance'):
                ticketcodeall = Tickets.objects.values('tcode')
                max_code = 0
                for i in ticketcodeall:
                    print(i)
                    lastcode = i['tcode']
                    lastcode_ = lastcode.split('_')
                    lastcode_num = int(lastcode_[1])
                    if(max_code < lastcode_num):
                        max_code = lastcode_num
                # print(lastcode_num)
                ticketcode = 'TICKET_'+str(max_code + 1)
                print('Createdon = ', createdon)
                closingon = '1990-01-01'
                closingtime = '00:00:00'
                tdescription = '' 
                closedby = '' 
                reportingmail = ''
                ticketstatus = 'opened'
                ticketinstance = Tickets(tcode = ticketcode, teventname = eventname, tcreatedon = createdon, 
                                            traisedby = createdby, tPlantname = Plantname, 
                                            tclosingon = closingon, tclosingtime = closingtime, tclosedby = closedby,
                                                                tdescription = tdescription, treportingmail = reportingmail, tticketstatus = ticketstatus)
                print(ticketinstance)
                ticketinstance.save()
            #---------------------End of ticket event-----------
            try:
                nextmaintenance = datetime.datetime.strptime(moldnextmaintenancedate, '%Y-%m-%d')
                nextmaintenancedate = nextmaintenance.day
                alertstrtdate = nextmaintenancedate - moldalertinterval
                print(alertstrtdate, nextmaintenancedate)
            except:
                alertstrtdate = 0
                nextmaintenancedate = 0
            
            tmesplt = time.split(":")
            print('Time split = ', tmesplt) 
            strday=""
            for i in days:
                print('i = ', i)
                strday=i+","+strday
            print('strday = ', strday)
            chngd=""
            for i in range(len(strday)-1):
                chngd=chngd+strday[i]
            print('changed = ', chngd)
            
            if(event=='last report'):
                schedule, _ = CrontabSchedule.objects.get_or_create(
                    minute=tmesplt[1],
                    hour=tmesplt[0],
                    day_of_week=chngd,
                    day_of_month='*',
                    month_of_year='*',
                )  
                PeriodicTask.objects.create(
                crontab=schedule,
                name=code,
                task='workflow.tasks.gensendmail',
                kwargs=json.dumps({"wfeventcode":code})
                )              
            elif(event=='preventive maintenance'):
                schedule, _ = CrontabSchedule.objects.get_or_create(
                    minute=tmesplt[1],
                    # minute='*/1',
                    hour=tmesplt[0],
                    # hour='*',
                    day_of_week= '*',
                    day_of_month= str(alertstrtdate)+"-"+str(nextmaintenancedate) ,
                    month_of_year='*',
                )
                # print(schedule)
                PeriodicTask.objects.create(
                    crontab=schedule,
                    name=code,
                    task='workflow.tasks.alertsendmail',
                    kwargs=json.dumps({"wfeventcode":code})
                )
            elif(event=='Machine stop alert'):
                schedule, _ = CrontabSchedule.objects.get_or_create( minute='*/1' )
                # print(schedule)
                PeriodicTask.objects.create(
                    crontab=schedule,
                    name=code,
                    task='workflow.tasks.stopalertsendmail',
                    kwargs=json.dumps({"wfeventcode":code})
                )
            return JsonResponse('Data saved successfully.', safe=False)
        else:
            return JsonResponse("Failed to save data.",safe=False)
    
    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        event           = httpdata["eventname"]
        code            = httpdata["wfeventcode"]
        eventname       = httpdata["wfeventname"]
        eventgroup      = httpdata["wfeventgroup"]
        resetinterval   = httpdata["wfresetinterval"]
        eventpriority   = httpdata["wfpriority"]
        eventstatus     = httpdata["wfactive"]
        description     = httpdata["wfdescription"]
        alertmsg        = httpdata["wfalertmessage"]
        correctmsg      = httpdata["wfcorrectmessage"]
        createdon       = httpdata["wfcreatedon"]
        createdby       = httpdata["wfcreatedby"]
        modifiedon      = httpdata["wfmodifiedon"]
        modifiedby      = httpdata["wfmodifiedby"]
        toemail         = httpdata["atoemail"]
        ccemail         = httpdata["accmail"]
        subject         = httpdata["asubject"]
        mailpriority    = httpdata["apriority"]
        message         = httpdata["amessage"]
        time            = httpdata["stime"]
        days            = httpdata["schedule_days"]
        Mouldname        = httpdata["saMouldname"]
        # moldnextmaintenancedate = httpdata["sanextmaintenance"]
        # moldalertinterval       = httpdata["samoldalertinterval"]

        if(WorkflowData.objects.filter(wfeventcode = code).exists()):
            WorkflowData.objects.filter(wfeventcode = code).update(wfeventname          = eventname,
                                                                    wfPlantname         = Plantname,
                                                                    wfeventgroup        = eventgroup,
                                                                    wfresetinterval     = resetinterval,
                                                                    wfpriority          = eventpriority,
                                                                    wfactive            = eventstatus,
                                                                    wfdescription       = description,
                                                                    wfalertmessage      = alertmsg,
                                                                    wfcorrectmessage    = correctmsg,
                                                                    wfcreatedon         = createdon,
                                                                    wfcreatedby         = createdby,
                                                                    wfmodifiedon        = modifiedon,
                                                                    wfmodifiedby        = modifiedby,
                                                                    atoemail            = toemail,
                                                                    accemail            = ccemail,
                                                                    asubject            = subject,
                                                                    apriority           = mailpriority,
                                                                    amessage            = message,
                                                                    stime               = time,
                                                                    sschedule_days      = days,
                                                                    eventtype           = event,
                                                                    # saMouldname          = Mouldname,
                                                                    # sanextmaintenance   = moldnextmaintenancedate,
                                                                    # samoldalertinterval = moldalertinterval,
                                                            )
            try:
                nextmaintenance = datetime.datetime.strptime(moldnextmaintenancedate, '%Y-%m-%d')
                nextmaintenancedate = nextmaintenance.day
                alertstrtdate = nextmaintenancedate - moldalertinterval
                print(alertstrtdate, nextmaintenancedate)
            except:
                alertstrtdate = 0
                nextmaintenancedate = 0
            tmesplt = time.split(":")
            print('Time split = ', tmesplt)
            strday=""
            for i in days:
                print('i = ', i)
                strday=i+","+strday
            print('strday = ', strday)
            chngd=""
            for i in range(len(strday)-1):
                chngd=chngd+strday[i]
            print('changed = ', chngd)
            if(event=='last report'):
                schedule, _ = CrontabSchedule.objects.get_or_create(
                    minute=tmesplt[1],
                    hour=tmesplt[0],
                    day_of_week=chngd,
                    day_of_month='*',
                    month_of_year='*',
                )
                PeriodicTask.objects.filter(name = eventname).update(
                    crontab=schedule,
                    name=code,
                    task='workflow.tasks.gensendmail',
                    kwargs=json.dumps({"wfeventcode":code})
                )
            elif(event=='preventive maintenance'):
                schedule, _ = CrontabSchedule.objects.get_or_create(
                    minute=tmesplt[1],
                    # minute='*/1',
                    hour=tmesplt[0],
                    # hour='*',
                    day_of_week= '*',
                    day_of_month= str(alertstrtdate)+"-"+str(nextmaintenancedate) ,
                    month_of_year='*',
                )
                PeriodicTask.objects.filter(name = eventname).update(
                    crontab=schedule,
                    name=code,
                    task='workflow.tasks.alertsendmail',
                    kwargs=json.dumps({"wfeventcode":code})
                )
            return JsonResponse('Data updated successfully.', safe=False)
        else:
            return JsonResponse("Failed to save data.",safe=False) 
    
    if request.method == 'DELETE':
        global event_name
        data = request.body
        httpdata = json.loads(data)
        code = httpdata["wfeventcode"]
        # print("code : ",code)
        if(WorkflowData.objects.filter(wfeventcode = code).exists()):
            eventname = WorkflowData.objects.filter(wfeventcode = code).values("wfeventname")
            # print(eventname)
            for i in eventname:
                event_name = i['wfeventname']
                # print('Event name : ',event_name)
            WorkflowData.objects.filter(wfeventcode = code).delete()
            if PeriodicTask.objects.filter(name=event_name).exists():
                PeriodicTask.objects.filter(name=event_name).delete()
                print('Data deleted successfully')
            return JsonResponse("Data deleted successfully", safe=False)
        else:
            return JsonResponse("Failed to delete data.", safe=False)

@csrf_exempt
def TicketEvent(request):
    if(request.method == 'GET'):
        Plantname = request.GET['Plantname']
        mydict = {}
        Array = []
        gettickets = Tickets.objects.filter(tPlantname=Plantname)
        ticketdataserializer = TicketSerializer(gettickets, many = True)
        # for i in gettickets:
        #     eventname = i['teventname']
        #     mydict = {'teventname' : eventname}
        #     Array.append(mydict)
        # return JsonResponse(Array, safe = False)
        return JsonResponse(ticketdataserializer.data, safe = False)
    if(request.method == 'POST'):
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        ticketstatus = ''
        id              = httpdata['tid']
        code            = httpdata["tcode"]
        eventname       = httpdata["teventname"]
        createdon       = httpdata["tcreatedon"]
        closingon       = httpdata["tclosingon"]
        closingtime     = httpdata["tclosingtime"]
        raisedby        = httpdata["traisedby"]
        closedby        = httpdata["tclosedby"]
        description     = httpdata["tdescription"]
        reportingmail   = httpdata["treportingmail"]
        if(Tickets.objects.filter(tcode = code).exists()):
            ticketstatus = 'closed'
            approvalstatus = 'pending'

            receivers= reportingmail

            subject='Ticket closed - reg'
            body = '''Dear user,<br>
                Ticket ID (''' + code + ''') has been closed by ''' + closedby + ''' on ''' +  closingon + ''' at ''' + closingtime + ''' .<br>
            <br>
            <br>
            Ticket description: ''' + description + '''<br>
            Click <a href="http://127.0.0.1:8001/id/''' + str(id) + '''/">here </a> to approve the ticket.<br>   
            <br>
            <br>
            Regards,<br>
            R-Connect team.<br>
            <br>
            Note: This is a system generated mail.'''

            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = "robis.development@matec.motherson.com"
            msg['To'] = reportingmail
            part2 = MIMEText(body, 'html')
            msg.attach(part2)
            message = """From: R-Connect Team
                        To: """+ receivers +""";
                        Subject: """+ subject +"""

                        """+ body +""".
                        """
            smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
            smtpObj.sendmail('ntpdpmt1@int.motherson.com',reportingmail,msg.as_string())    
            smtpObj.quit()     
            print('Mail send successfully')
            Tickets.objects.filter(tcode = code).update(tclosingon = closingon, tclosingtime = closingtime, tclosedby = closedby,
                                                            tdescription = description, treportingmail = reportingmail, 
                                                            tticketstatus = ticketstatus, tapprovalstatus = approvalstatus)   
            ticketresponse = eventname
        else:
            ticketresponse = 'Ticket not found'
        return JsonResponse(ticketresponse, safe=False)

@csrf_exempt
def Ticketdatas(request):
    if(request.method == 'GET'):
        Plantname = request.GET['Plantname']
        eventname = request.GET['eventname']
        ticketstatus = ''
        approvalstatus = ''
        getstatus = Tickets.objects.filter(tPlantname=Plantname, teventname=eventname).values('tticketstatus', 'tapprovalstatus')
        for i in getstatus:
            ticketstatus = i['tticketstatus']
            approvalstatus = i['tapprovalstatus']
        if(ticketstatus == 'opened'):
            ticketdata = Tickets.objects.filter(tPlantname=Plantname, teventname=eventname)
            ticketdataserializer = TicketSerializer(ticketdata, many = True)
            return JsonResponse(ticketdataserializer.data, safe=False)
        elif(ticketstatus == 'closed' and approvalstatus == 'pending'):
            return JsonResponse('Ticket submitted and waiting for approval', safe=False)
        elif(approvalstatus == 'approved'):
            return JsonResponse('Ticket closed', safe=False)

def profile(request, tid):
    if(Tickets.objects.filter(tid = tid ).exists()):
        Tickets.objects.filter(tid = tid ).update(tapprovalstatus = 'approved')
    return HttpResponse('Approved')


@csrf_exempt
def data(request):
    if request.method == 'POST':
        Plantname = (json.loads(request.body))['plantname']
        date = (json.loads(request.body))['date']
        #Set average of production data
        # now = datetime.datetime.now()
        # date = (now.date()).strftime('%Y-%m-%d')
        yesterday = date
        currentdate = (datetime.datetime.strptime(date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        print(yesterday, currentdate)
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        for i in shift_starttime:
            shift_starttime = i['shift1start']
        dateArray = []
        timeArray = []
        myarray   = []
        MachinenamesArray = machineArray(Plantname)
        distinctArray =  []
        for machine in MachinenamesArray:
            flag = 0; count = 0; prevcount = 0; firstid = 0; lastid = 0; prevmold = ''
            try:
                dateArray = [yesterday, currentdate]
                # print(machine, dateArray)
                timeArray = [str(shift_starttime), '23:59:00', '00:00:01', str(shift_starttime)]
                for i in range(0, len(dateArray)):
                    ind = (i*i)+ i
                    date_ = dateArray[i]
                    fromtime = timeArray[ind]
                    totime   = timeArray[ind + 1]
                    # print('Time = ',machine, date_, fromtime, totime)
                    getdatas = ProductionTable.objects.filter(date = date_, time__range = (fromtime, totime), Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0).values('id', 'ProductionCountActual', 'Machinename', 'Mouldname_id').order_by('id')
                    for i in getdatas:
                        id = i['id']; count = int(i['ProductionCountActual']); Mouldname_id =  i['Mouldname_id']; Machinename = i['Machinename']
                        
                        if(flag == 0): prevcount = count; firstid = id; flag = 1
                        # if(prevcount <= count): lastid = id
                        if(prevcount > count or (prevmold != Mouldname_id and (prevmold != '' and Mouldname_id != ''))):
                            distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold }; distinctArray.append(distinctDict); lastid = id; firstid = id
                        prevcount = count; prevmold = Mouldname_id; lastid = id
                if(Machinename and Mouldname_id != ''):
                    distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold }; distinctArray.append(distinctDict)
                Machinename = ''; Mouldname_id = ''
            except: 
                continue
            # print(distinctArray)

        for i in distinctArray:
            shift = ''; fidcount = 0
            Machinename = i['Machinename']; Mouldname = i['Mouldname']; fid = i['fid']; lid = i['lid']
            # print('Machinename, id =', Machinename, fid, lid)
            # ---------------- Get the running time of the mold-----------------------------------------
            flag = 0; firsttime = '00:00:00'; lasttime = '00:00:00'; prevmold = ''; currmold = ''; runningtime = 0; actualcount = 0; cycletime = 0.00
            firsttime = (list(ProductionTable.objects.filter(id = fid).values('time'))[0])['time']
            lasttime = (list(ProductionTable.objects.filter(id = lid).values('time'))[0])['time']
            # print('Firsttime = ', firsttime, 'Lasttime = ',lasttime)
            if(int(firsttime.split(":")[0]) >= 6 and int(firsttime.split(":")[0]) <= 13):
                shift = 'A' 
            elif(int(firsttime.split(":")[0]) >= 14 and int(firsttime.split(":")[0]) <= 21):
                shift = 'B'
            else:
                shift = 'C'

            # -- Get the actual count value --
            try: 
                countnumbers = ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).count()
            except: countnumbers = 0
            # print('Count Numbers = ', countnumbers)

            try: 
                actualcount = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('ProductionCountActual').last())['ProductionCountActual']
            except Exception as e: 
                print(Machinename, e)
                actualcount = 0
            
            fidcount = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
            # print('fidcount = ', fidcount)
            fidtime = (datetime.datetime.strptime(((list(ProductionTable.objects.filter(id=fid).values('time'))[0])['time']), '%H:%M:%S')).hour
            # print('fidtime = ', Machinename, Mouldname, fidtime)

            # print('ActualCount = ', actualcount)
            if(fidtime == shift_starttime.hour):
                # print('start time hour same')
                if(fidcount > 1 and fidcount <= actualcount):
                    actualcount = (actualcount - fidcount) + 1
                # print('sub count = ', actualcount)
            # print(actualcount, Machinename)

            if(firsttime < lasttime): runningtime = (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')).total_seconds()
            elif(firsttime == lasttime): runningtime = 0
            else: runningtime = ((datetime.datetime.strptime('23:59:59', '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')) + (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime('00:00:01', '%H:%M:%S'))).total_seconds()
            # print('Running time (sec)', runningtime)
                        
            cycletime      = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('CycletimeSet').last())["CycletimeSet"]
            pcycletimeSumval    = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).aggregate(Sum('CycletimeActual')))["CycletimeActual__sum"]
            # ------------------------Cycle time set -------------------------------------
            # try: cycletime = round((cycletimevalue['CycletimeSet'] / 1000000), 1)
            # except: cycletime = 0
            # print('cyceltime = ', cycletime)

            # ------------------------previous Cycle time (Actual Cycle time) -------------------------------------
            # print(Machinename, cycletime, pcycletimeSumval, actualcount, countnumbers)
            
            try: 
                firstval = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
                # print('Fistval = ', firstval)
                if(firstval == 1 and (countnumbers == actualcount)):
                    CycletimeActual = round((pcycletimeSumval/actualcount), 1) 
                else:
                    CycletimeActual = round((pcycletimeSumval/countnumbers), 1) 
            except Exception as e: 
                # print('Cycletime exception error = ', e)
                CycletimeActual = 0

            # # print('CycletimeActual = ', CycletimeActual)
            
            RejectionParts = (list(ProductionTable.objects.filter(id = lid, Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname).values('RejectionParts'))[0])['RejectionParts']
            # print(RejectionParts)
            # ------------------------ Set or Target count calculation -------------------------------------
            try: totalpart = int(float(runningtime)/float(cycletime))
            except:  totalpart = 0
            # ------------------------ productiontime set and actual calculation -------------------------------------
            actualruntime   = float(round(runningtime/60, 1))
            totaltime = round((((actualruntime * 10)/100) + actualruntime), 1)
            # ------------------------ OEE parameters calculation -------------------------------------
            idletime = float(round((actualruntime - float((CycletimeActual * actualcount)/60)),1))
            if(idletime < 0):
                idletime = 0
            ##--Availability--
            try: Availability = float(round(((actualruntime/totaltime)*100),1))
            except: Availability = 0
            ##--Performance--
            try: Performance = float(round(((actualcount / totalpart)*100), 1))
            except: Performance = 0
            ##--Quality--
            try: Quality = float(round(((actualcount / actualcount)*100), 1))
            except: Quality = 0
            ##--OEE--
            try: oee = float(round(((Availability * Performance * Quality)/10000),1))
            except: oee = 0

            #-------------------- Recommended Calculations----------------------------------------
            num = CycletimeActual
            if (num%10)< 5 and (num%10)> 0:
                num = num + (5- (num%10))
            elif int(num%10)<= 9 and (num%10)> 5:
                num = num + (10- (num%10))

            try: totalpart_recommended = round(float(runningtime)/float(num))
            except: totalpart_recommended = 0

            try: performance_recommended = float(round(((actualcount / totalpart_recommended)*100), 1))
            except: performance_recommended = 0
            
            try: OEE_recommended = float(round(((Availability * performance_recommended * Quality)/10000),1))
            except: OEE_recommended = 0
            Mouldname_data = Mouldmodel.objects.filter(id = Mouldname).values('Mouldname')
            for i in Mouldname_data:
                Mouldname = i['Mouldname']                  
            #--------------------Append With Dictionary ---------------------------------------
            mydict = {  'Machinename'                   : Machinename, 
                        'Mouldname'                      : Mouldname, 
                        'Shift'                         : shift,
                        'Starttime'                    : firsttime,
                        'Endtime'                      : lasttime,
                        'Cycletime_Set'           : cycletime,
                        'Cycletime_Actual'       : CycletimeActual,
                        'Recommended_cycleTime'         : num,
                        'Productiontime_Set'      : round(totaltime, 1),
                        'Productiontime_Actual'   : round(actualruntime, 1),
                        'ProductionCount_Set'           : totalpart_recommended,
                        'ProductionCount_Actual'        : int(actualcount),
                        'RejectionParts'                      : RejectionParts,
                        'MachineIdletime'         : round(idletime, 1),
                        'Actual_runtime'          : round(actualruntime, 1),
                        'Total_runtime'           : round(totaltime, 1),
                        'ae'                        : Availability,
                        'Target_production'             : totalpart_recommended,
                        'Actual_production'             : actualcount,
                        'pe'                        : performance_recommended,
                        'Good_parts'                    : actualcount,
                        'Produced_parts'                : actualcount,
                        'qe'                        : Quality,
                        # 'OEE (%)'                       : round(oee, 1),
                        'oee'                       : OEE_recommended
                        }
            myarray.append(mydict)
        print(myarray)
        return JsonResponse(myarray, safe=False)