from django.db import models

# Create your models here.
class AddUser(models.Model):
    udid            = models.AutoField(primary_key=True)
    udusercode      = models.CharField(max_length=255,default=False,null=True)
    udPlantname     = models.CharField(max_length=255, default=False, null=True)
    udusername      = models.CharField(max_length=255,default=False,null=True)
    udtype          = models.CharField(max_length=255,default=False,null=True)
    udfirstName     = models.CharField(max_length=255,default=False,null=True)
    udlastName      = models.CharField(max_length=255,default=False,null=True)
    udemail         = models.EmailField(default=False,null=True)
    udpassword      = models.CharField(max_length=255,default=False,null=True)
    udconfirmpassword = models.CharField(max_length=255,default=False,null=True)
    udlocation      = models.CharField(max_length=255,default=False,null=True)
    udsession_id    = models.CharField(max_length=255, default=False, null=True)

