from django.urls import path
from meter_data import views, meter_report, peak_offpeak

urlpatterns=[
    path('meterdata/',views.meterdata,name='meter_data'), 
    path('metereport/',meter_report.meterhealth,name='meter_data'),
    path('meterhealth/',meter_report.healthhours, name = 'meterhealth_hours'),
    path('peakoffpeak/',peak_offpeak.PeakOffPeak, name = 'energy consumption for peak vs off peak')
    # path('data/',views.ewoncheck,name='ewon_data') 
]