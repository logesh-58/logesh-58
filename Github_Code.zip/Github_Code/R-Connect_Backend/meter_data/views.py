import json
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Meterdata,Masterdatatable,Dailydatacache
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from meter_data.serializers import MeterDatabaseSerializer,DailydatacacheDbSerializer,MasterTableDbSerializer
from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
import datetime
from datetime import timedelta
from general_settings.models import Timingtable
from meter_data.master_data_algo.task import Datacachethread
from rest_framework.decorators import authentication_classes, permission_classes, api_view
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

# @api_view(['GET', 'POST', 'PUT', 'DELETE'])
# @authentication_classes([TokenAuthentication])
# @permission_classes([IsAuthenticated])
@csrf_exempt
def meterdata(request):
    if request.method == 'GET':
        plntname = request.GET['plantname']
        meterdata=Meterdata.objects.filter(meter_plantname = plntname).all()
        meterDatabaseSerializer = MeterDatabaseSerializer(meterdata,many=True)
        return JsonResponse(meterDatabaseSerializer.data, safe=False)
    
    elif request.method == 'POST':
        meterDatabase_data =  JSONParser().parse(request)
        print(meterDatabase_data)
        Datacachethread(meterDatabase_data).start()
        valid = 0
        timingtblrow = Timingtable.objects.get(ttid=1)
        dailyreporttime = timingtblrow.ttdaystarttime
        s1time = timingtblrow.tts1time
        s2time = timingtblrow.tts2time
        s3time = timingtblrow.tts3time
        s1string = s1time.strftime('%H')
        s1hrint = int(s1string)
        current_time = datetime.datetime.now()
        # Subtract 2 hours from datetime object containing current time
        past_time = current_time - timedelta(hours=s1hrint)
        # Convert datetime object to string in specific format 
        past_time_str = past_time.strftime('%Y-%m-%d')
        for meterDatabase_data_dict in meterDatabase_data:
            meterDatabaseSerializer = MeterDatabaseSerializer(data=meterDatabase_data_dict, partial=True)
            # print('Data: ', meterDatabase_data_dict["metername"])
            if meterDatabaseSerializer.is_valid():
                # print('Valid Data: ', meterDatabase_data_dict["metername"])
                try:
                    matchrow = Meterdata.objects.get(metername=meterDatabase_data_dict["metername"],crntdate=past_time_str)
                except Meterdata.DoesNotExist:
                    matchrow = None
                if matchrow != None:
                    dbdate=matchrow.crntdate
                    strdate = dbdate.strftime('%Y-%m-%d')
                else:
                    strdate = None
                if past_time_str == strdate:
                    Meterdata.objects.filter(metername=meterDatabase_data_dict["metername"],
                                                crntdate=past_time_str).update(crntdate=past_time_str,
                                                                                metername=meterDatabase_data_dict["metername"],
                                                                                actualenergy=meterDatabase_data_dict["actualenergy"],
                                                                                power=meterDatabase_data_dict["actualpower"],
                                                                                linevoltage=meterDatabase_data_dict["linevoltage"],
                                                                                avgcurrent=meterDatabase_data_dict["avgcurrent"],
                                                                                runninghours=0,
                                                                                powerfactor=meterDatabase_data_dict["powerfactor"],
                                                                                actualpower=meterDatabase_data_dict["actualpower"],
                                                                                reactivepower=0,
                                                                                frequency=meterDatabase_data_dict["frequency"],
                                                                                meterstatus=meterDatabase_data_dict["meterstatus"],
                                                                                meter_plantname = meterDatabase_data_dict['plantname'])           
                else:
                    meterDatabaseSerializer.save()
            # else:
            #     print('Data: ', meterDatabase_data_dict)

            valid = valid + 1

        if valid > 0:
            return JsonResponse("The Following data saved to the DB:", status=200,safe=False)
        else:
            return JsonResponse(meterDatabaseSerializer.errors, status=400)

def datacache(request):
    plntname = request.GET['plantname']
    if request.method == 'GET':
        dailydata=Dailydatacache.objects.filter(dcplantname = plntname).all()
        cacheDbSerializer = DailydatacacheDbSerializer(dailydata,many=True)
        return JsonResponse(cacheDbSerializer.data, safe=False)

def mastertable(request):
    plntname = request.GET['plantname']
    if request.method == 'GET':
        masterdata=Masterdatatable.objects.filter(mtplntlctn = plntname).all()
        masterDbSerializer = MasterTableDbSerializer(masterdata,many=True)
        return JsonResponse(masterDbSerializer.data, safe=False)

@csrf_exempt
def ewoncheck(request):
    if request.method=='POST':
        ewondata =  JSONParser().parse(request)
        return HttpResponse("The Following data has been received from ewon", status=200,safe=False)

