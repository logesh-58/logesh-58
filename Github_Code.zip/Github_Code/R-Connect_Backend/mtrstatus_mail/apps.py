from django.apps import AppConfig


class MtrstatusMailConfig(AppConfig):
    name = 'mtrstatus_mail'
