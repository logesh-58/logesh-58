from django.db import models
from mouldmanagement.models import Mouldmodel

# Create your models here.
class ShiftTimings(models.Model):
    id                  = models.AutoField(primary_key=True)
    Plantname           = models.CharField(max_length=255, default=False, null=True)
    shift1start         = models.TimeField(default=False,null=True)
    shift1end           = models.TimeField(default=False,null=True)
    shift2start         = models.TimeField(default=False,null=True)
    shift2end           = models.TimeField(default=False,null=True)
    shift3start         = models.TimeField(default=False,null=True)
    shift3end           = models.TimeField(default=False,null=True)