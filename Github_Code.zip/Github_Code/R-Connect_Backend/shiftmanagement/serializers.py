from django.db.models import fields
from rest_framework import serializers
from .models import ShiftTimings

class ShiftTimingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftTimings
        fields = ('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end')