from django.shortcuts import render
from .models import ShiftTimings
from .serializers import ShiftTimingSerializer
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from analysis.views import machineArray
from datetime import datetime, timedelta, time
from mouldmanagement.models import Mouldmodel
from machinemanagement.models import AddMachine
from hourly_production.dailyenrgyhrs_report import schedule_sendmail
from hourly_production.tasks import shift_schedule_sendmail

# Create your views here.
@csrf_exempt
def timings(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        timingdata = ShiftTimings.objects.filter(Plantname = Plantname).all()
        serialized_time = ShiftTimingSerializer(timingdata, many=True)
        return JsonResponse(serialized_time.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        httpdata = json.loads(request.body)
        s1starttime = httpdata['s1starttime']
        s1endtime   = httpdata['s1endtime']
        s2starttime = httpdata['s2starttime']
        s2endtime   = httpdata['s2endtime']
        s3starttime = httpdata['s3starttime']
        s3endtime   = httpdata['s3endtime']

        instance = ShiftTimings(Plantname = Plantname, shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
        if(ShiftTimings.objects.filter(Plantname = Plantname).exists()):
            ShiftTimings.objects.filter(Plantname = Plantname).update(shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
            shift_schedule_sendmail()
            schedule_sendmail()
        else:
            instance.save()
            shift_schedule_sendmail()
            schedule_sendmail()
        return JsonResponse('Data saved successfully', safe=False)