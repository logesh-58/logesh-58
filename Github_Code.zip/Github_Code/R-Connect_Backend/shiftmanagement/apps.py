from django.apps import AppConfig


class ShiftmanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shiftmanagement'
