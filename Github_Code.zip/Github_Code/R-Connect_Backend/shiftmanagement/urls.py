from django.urls import path
from .import views

urlpatterns = [
    path('shifttime/', views.timings,name="Shifttiming"),
]

