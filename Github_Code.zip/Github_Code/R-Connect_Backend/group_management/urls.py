from django.conf.urls import url 
from group_management import views

urlpatterns=[
    url('groupmanagement/',views.addgroup,name='group_management'),
    url('groupmanagement/<str:aggroupcode>',views.delete,name='group_management')
]