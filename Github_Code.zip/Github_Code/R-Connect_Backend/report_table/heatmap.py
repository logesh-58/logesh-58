from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from meter_data.models import Masterdatatable
from meter_management.models import AddMeter
from django.db.models.aggregates import Sum

@csrf_exempt
def HeatMap(request):
    
    if request.method == 'POST':
        
        request_data = json.loads(request.body)['Date']
        
        heatmap_array = []
        meternames = AddMeter.objects.values('ammetername').order_by('ammetername')
        for data1 in meternames:
            # print(data1['ammetername'])
            energy_cons = Masterdatatable.objects.filter(mtdate = request_data, mtmtrname = data1['ammetername']).values('mth1ec', 'mth2ec', 'mth3ec', 'mth4ec', 'mth5ec', 'mth6ec', 'mth7ec', 'mth8ec', 'mth9ec', 'mth10ec', 'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec', 'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec', 'mth21ec', 'mth22ec', 'mth23ec', 'mth24ec', )
            data_array = []
            for data2 in energy_cons:
                # print(data2)
                try:
                    h1 = round(data2['mth1ec'], 2)
                except:
                    h1 = 0
                data_array.append(h1)
                try:
                    h2 = round(data2['mth2ec'], 2)
                except:
                    h2 = 0
                data_array.append(h2)
                try:
                    h3 = round(data2['mth3ec'], 2)
                except:
                    h3 = 0
                data_array.append(h3)
                try:
                    h4 = round(data2['mth4ec'], 2)
                except:
                    h4 = 0
                data_array.append(h4)
                try:
                    h5 = round(data2['mth5ec'], 2)
                except:
                    h5 = 0
                data_array.append(h5)
                try:
                    h6 = round(data2['mth6ec'], 2)
                except:
                    h6 = 0
                data_array.append(h6)
                try:
                    h7 = round(data2['mth7ec'], 2)
                except:
                    h7 = 0
                data_array.append(h7)
                try:
                    h8 = round(data2['mth8ec'], 2)
                except:
                    h8 = 0
                data_array.append(h8)
                try:
                    h9 = round(data2['mth9ec'], 2)
                except:
                    h9 = 0
                data_array.append(h9)
                try:
                    h10 = round(data2['mth10ec'], 2)
                except:
                    h10 = 0
                data_array.append(h10)
                try:
                    h11 = round(data2['mth11ec'], 2)
                except:
                    h11 = 0
                data_array.append(h11)
                try:
                    h12 = round(data2['mth12ec'], 2)
                except:
                    h12 = 0
                data_array.append(h12)
                try:
                    h13 = round(data2['mth13ec'], 2)
                except:
                    h13 = 0
                data_array.append(h13)
                try:
                    h14 = round(data2['mth14ec'], 2)
                except:
                    h14 = 0
                data_array.append(h14)
                try:
                    h15 = round(data2['mth15ec'], 2)
                except:
                    h15 = 0
                data_array.append(h15)
                try:
                    h16 = round(data2['mth16ec'], 2)
                except:
                    h16 = 0
                data_array.append(h16)
                try:
                    h17 = round(data2['mth17ec'], 2)
                except:
                    h17 = 0
                data_array.append(h17)
                try:
                    h18 = round(data2['mth18ec'], 2)
                except:
                    h18 = 0
                data_array.append(h18)
                try:
                    h19 = round(data2['mth19ec'], 2)
                except:
                    h19 = 0
                data_array.append(h19)
                try:
                    h20 = round(data2['mth20ec'], 2)
                except:
                    h20 = 0
                data_array.append(h20)
                try:
                    h21 = round(data2['mth21ec'], 2)
                except:
                    h21 = 0
                data_array.append(h21)
                try:
                    h22 = round(data2['mth22ec'], 2)
                except:
                    h22 = 0
                data_array.append(h22)
                try:
                    h23 = round(data2['mth23ec'], 2)
                except:
                    h23 = 0
                data_array.append(h23)
                try:
                    h24 = round(data2['mth24ec'], 2)
                except:
                    h24 = 0
                data_array.append(h24)
            if data_array != []:
                heatmap = {
                    "name": data1['ammetername'],
                    "data": data_array
                }
                heatmap_array.append(heatmap)
    
    return JsonResponse({"heat_map": heatmap_array}, safe=False)