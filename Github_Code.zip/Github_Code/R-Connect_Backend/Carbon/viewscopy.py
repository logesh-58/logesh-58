import json
import os
from click import style
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from REnergy.settings import BASE_DIR
from source_management.models import AddSource
from meter_data.models import Masterdatatable
from costestimator.models import Cost_DG, Cost_Petrol, Cost_CNG, Cost_LPG, Cost_Wind
from django.db.models.aggregates import Sum
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta

@csrf_exempt
def EnergyConsumption(request):
    if request.method == 'POST':
        current_date = datetime.now()
        current_month = current_date.month
        current_year = current_date.year

        start_month = 4

        Carbonlist = []
        Total = []
        source1total = []
        # source2total = []
        source3total = []
        source4total = []
        source5total = []
        source6total = []
        source7total = []
        if current_month >= start_month:
            while start_month <= current_month:
                start_date = datetime(current_year, start_month, 1).strftime("%Y-%m-%d")
                # print(start_date)
                if start_month == 12:
                    end_date = datetime(current_year, start_month, 31).strftime("%Y-%m-%d")
                    # print(end_date)
                else:
                    end_date = (datetime(current_year, start_month + 1, 1) + timedelta(days=-1)).strftime("%Y-%m-%d")
                    # print(end_date)

                # emission_list = []
                addsource = AddSource.objects.values('assourcename')
                for i in addsource:
                    if i['assourcename'] == 'Transformer1':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Transformer :",month)
                        except:
                            month = 0
                        emission = round(month * 0.7132)
                        # print("Transformer :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.7132"
                        no = "1"
                        # emission_list.append(emission)
                        source1total.append(emission)

                    # if i['assourcename'] == 'Wind':
                    #     Edata = Cost_Wind.objects.values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                    #     try:
                    #         month = round(Edata['Wind_percentage__sum'])
                    #         # print("Wind :",month)
                    #     except:
                    #         month = 0
                    #     emission = round(month * 0.59)
                    #     # print("Wind :",emission)
                    #     unit = "kWh"
                    #     greenhouse = "CO2 equ"
                    #     conversion = "Kg CO2/kL"
                    #     nam_ghg = "0.59"
                    #     no = "2"
                    #     # emission_list.append(emission)
                    #     source2total.append(emission)

                    if i['assourcename'] == 'Solar Energy':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Solar Energy', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Solar :",month)
                        except:
                            month = 0
                        emission = round(month * 0.041)
                        # print("solar :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.041"
                        no = "3"
                        # emission_list.append(emission)
                        source3total.append(emission)

                    if i['assourcename'] == 'DG':
                        Edata = Cost_DG.objects.filter(dg_date__range =(start_date, end_date)).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                        try:
                            month = round(Edata['dg_lit_cons__sum'])
                            # print("DG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.6)
                        # print("DG :",emission)
                        greenhouse = "CO2"
                        nam_ghg = "2.6"
                        conversion = "Kg CO2/L"
                        unit = "Liters"
                        no = "4"
                        # emission_list.append(emission)
                        source4total.append(emission)

                    if i['assourcename'] == 'Petrol':
                        Edata = Cost_Petrol.objects.filter(pt_date__range =(start_date, end_date)).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                        try:
                            month = round(Edata['pt_lit_cons__sum'])
                            # print("Petrol :",month)
                        except:
                            month = 0
                        emission = round(month * 2.32)
                        # print("petrol :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.32"
                        no = "5"
                        # emission_list.append(emission)
                        source5total.append(emission)

                    if i['assourcename'] == 'LPG':
                        Edata = Cost_LPG.objects.filter(LPG_date__range =(start_date, end_date)).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                        try:
                            month = round(Edata['LPG_kg_cons__sum'])
                            # print("LPG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.19)
                        # print("lpg :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.19"
                        no = "6"
                        # emission_list.append(emission)
                        source6total.append(emission)

                    if i['assourcename'] == 'CNG':
                        Edata = Cost_CNG.objects.filter(CNG_date__range =(start_date, end_date)).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                        try:
                            month = round(Edata['CNG_kg_cons__sum'])
                            # print("CNG :",month)
                        except:
                            month = 0
                        emission = round(month * 0.614)
                        # print("cng :",emission)
                        unit = "Kg"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/Kg"
                        nam_ghg = "0.614"
                        no = "7"
                        # emission_list.append(emission)
                        source7total.append(emission)

                    rcarbon = {
                        'description': i['assourcename'],
                        'units': unit,
                        'month': month,
                        'ghg': greenhouse,
                        'Namghg': nam_ghg,
                        'unitcon': conversion,
                        'emission': emission,
                        'no' : no
                    }

                    Carbonlist.append(rcarbon)
                    
                start_month += 1

        else:
            while start_month <= 12:
                start_date = datetime(current_year - 1, start_month, 1).strftime("%Y-%m-%d")
                # print(start_date)
                if start_month == 12:
                    end_date = datetime(current_year - 1, start_month, 31).strftime("%Y-%m-%d")
                    # print(end_date)
                else:
                    end_date = (datetime(current_year - 1, start_month + 1, 1) + timedelta(days=-1)).strftime("%Y-%m-%d")
                    # print(end_date)
                
                # emission_list = []
                addsource = AddSource.objects.values('assourcename')
                for i in addsource:
                    if i['assourcename'] == 'Transformer1':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Transformer :",month)
                        except:
                            month = 0
                        emission = round(month * 0.7132)
                        # print("Transformer :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.7132"
                        no = "1"
                        # emission_list.append(emission)
                        source1total.append(emission)

                    # if i['assourcename'] == 'Wind':
                    #     Edata = Cost_Wind.objects.values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                    #     try:
                    #         month = round(Edata['Wind_percentage__sum'])
                    #         # print("Wind :",month)
                    #     except:
                    #         month = 0
                    #     emission = round(month * 0.59)
                    #     # print("Wind :",emission)
                    #     unit = "kWh"
                    #     greenhouse = "CO2 equ"
                    #     conversion = "Kg CO2/kL"
                    #     nam_ghg = "0.59"
                    #     no = "2"
                    #     # emission_list.append(emission)
                    #     source2total.append(emission)

                    if i['assourcename'] == 'Solar Energy':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Solar Energy', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Solar :",month)
                        except:
                            month = 0
                        emission = round(month * 0.041)
                        # print("solar :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.041"
                        no = "3"
                        # emission_list.append(emission)
                        source3total.append(emission)

                    if i['assourcename'] == 'DG':
                        Edata = Cost_DG.objects.filter(dg_date__range =(start_date, end_date)).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                        try:
                            month = round(Edata['dg_lit_cons__sum'])
                            # print("DG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.6)
                        # print("DG :",emission)
                        greenhouse = "CO2"
                        nam_ghg = "2.6"
                        conversion = "Kg CO2/L"
                        unit = "Liters"
                        no = "4"
                        # emission_list.append(emission)
                        source4total.append(emission)

                    if i['assourcename'] == 'Petrol':
                        Edata = Cost_Petrol.objects.filter(pt_date__range =(start_date, end_date)).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                        try:
                            month = round(Edata['pt_lit_cons__sum'])
                            # print("Petrol :",month)
                        except:
                            month = 0
                        emission = round(month * 2.32)
                        # print("petrol :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.32"
                        no = "5"
                        # emission_list.append(emission)
                        source5total.append(emission)

                    if i['assourcename'] == 'LPG':
                        Edata = Cost_LPG.objects.filter(LPG_date__range =(start_date, end_date)).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                        try:
                            month = round(Edata['LPG_kg_cons__sum'])
                            # print("LPG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.19)
                        # print("lpg :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.19"
                        no = "6"
                        # emission_list.append(emission)
                        source6total.append(emission)

                    if i['assourcename'] == 'CNG':
                        Edata = Cost_CNG.objects.filter(CNG_date__range =(start_date, end_date)).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                        try:
                            month = round(Edata['CNG_kg_cons__sum'])
                            # print("CNG :",month)
                        except:
                            month = 0
                        emission = round(month * 0.614)
                        # print("cng :",emission)
                        unit = "Kg"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/Kg"
                        nam_ghg = "0.614"
                        no = "7"
                        # emission_list.append(emission)
                        source7total.append(emission)

                    rcarbon = {
                        'description': i['assourcename'],
                        'units': unit,
                        'month': month,
                        'ghg': greenhouse,
                        'Namghg': nam_ghg,
                        'unitcon': conversion,
                        'emission': emission,
                        'no' : no
                    }

                    Carbonlist.append(rcarbon)

                start_month += 1

            start_month = 1

            while start_month <= current_month:
                start_date = datetime(current_year, start_month, 1).strftime("%Y-%m-%d")
                # print(start_date)
                if start_month == 12:
                    end_date = datetime(current_year, start_month, 31).strftime("%Y-%m-%d")
                    # print(end_date)
                else:
                    end_date = (datetime(current_year, start_month + 1, 1) + timedelta(days=-1)).strftime("%Y-%m-%d")
                    # print(end_date)

                # emission_list = []
                addsource = AddSource.objects.values('assourcename')
                for i in addsource:
                    if i['assourcename'] == 'Transformer1':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Transformer :",month)
                        except:
                            month = 0
                        emission = round(month * 0.7132)
                        # print("Transformer :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.7132"
                        no = "1"
                        # emission_list.append(emission)
                        source1total.append(emission)

                    # if i['assourcename'] == 'Wind':
                    #     Edata = Cost_Wind.objects.values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                    #     try:
                    #         month = round(Edata['Wind_percentage__sum'])
                    #         # print("Wind :",month)
                    #     except:
                    #         month = 0
                    #     emission = round(month * 0.59)
                    #     # print("Wind :",emission)
                    #     unit = "kWh"
                    #     greenhouse = "CO2 equ"
                    #     conversion = "Kg CO2/kL"
                    #     nam_ghg = "0.59"
                    #     no = "2"
                    #     # emission_list.append(emission)
                    #     source2total.append(emission)

                    if i['assourcename'] == 'Solar Energy':
                        Edata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Solar Energy', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            month = round(Edata['mtenergycons__sum'])
                            # print("Solar :",month)
                        except:
                            month = 0
                        emission = round(month * 0.041)
                        # print("solar :",emission)
                        unit = "kWh"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/kWh"
                        nam_ghg = "0.041"
                        no = "3"
                        # emission_list.append(emission)
                        source3total.append(emission)

                    if i['assourcename'] == 'DG':
                        Edata = Cost_DG.objects.filter(dg_date__range =(start_date, end_date)).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                        try:
                            month = round(Edata['dg_lit_cons__sum'])
                            # print("DG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.6)
                        # print("DG :",emission)
                        greenhouse = "CO2"
                        nam_ghg = "2.6"
                        conversion = "Kg CO2/L"
                        unit = "Liters"
                        no = "4"
                        # emission_list.append(emission)
                        source4total.append(emission)

                    if i['assourcename'] == 'Petrol':
                        Edata = Cost_Petrol.objects.filter(pt_date__range =(start_date, end_date)).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                        try:
                            month = round(Edata['pt_lit_cons__sum'])
                            # print("Petrol :",month)
                        except:
                            month = 0
                        emission = round(month * 2.32)
                        # print("petrol :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.32"
                        no = "5"
                        # emission_list.append(emission)
                        source5total.append(emission)

                    if i['assourcename'] == 'LPG':
                        Edata = Cost_LPG.objects.filter(LPG_date__range =(start_date, end_date)).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                        try:
                            month = round(Edata['LPG_kg_cons__sum'])
                            # print("LPG :",month)
                        except:
                            month = 0
                        emission = round(month * 2.19)
                        # print("lpg :",emission)
                        unit = "Liters"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/L"
                        nam_ghg = "2.19"
                        no = "6"
                        # emission_list.append(emission)
                        source6total.append(emission)

                    if i['assourcename'] == 'CNG':
                        Edata = Cost_CNG.objects.filter(CNG_date__range =(start_date, end_date)).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                        try:
                            month = round(Edata['CNG_kg_cons__sum'])
                            # print("CNG :",month)
                        except:
                            month = 0
                        emission = round(month * 0.614)
                        # print("cng :",emission)
                        unit = "Kg"
                        greenhouse = "CO2"
                        conversion = "Kg CO2/Kg"
                        nam_ghg = "0.614"
                        no = "7"
                        # emission_list.append(emission)
                        source7total.append(emission)

                    rcarbon = {
                        'description': i['assourcename'],
                        'units': unit,
                        'month': month,
                        'ghg': greenhouse,
                        'Namghg': nam_ghg,
                        'unitcon': conversion,
                        'emission': emission,
                        'no' : no
                    }

                    Carbonlist.append(rcarbon)
                start_month += 1

        Source1 = sum(source1total)
        Total.append(Source1)
        # Source2 = sum(source2total)
        # Total.append(Source2)
        Source3 = sum(source3total)
        Total.append(Source3)
        Source4 = sum(source4total)
        Total.append(Source4)
        Source5 = sum(source5total)
        Total.append(Source5)
        Source6 = sum(source6total)
        Total.append(Source6)
        Source7 = sum(source7total)
        Total.append(Source7)
        print("Total :",Total)
        # print(Carbonlist)


    return JsonResponse( {'rcarbon': Carbonlist}, safe=True)