from django.apps import AppConfig


class CarbonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Carbon'
