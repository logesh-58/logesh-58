from machinemanagement.views import machine
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from .models import ProductionTable
from timeline.models import timeline
from dashboard.models import Dashboard
from productionviewmaster.models import productionviewmaster
from .serializers import ProductionTableSerializers, MachinenameSerialzers
from mouldmanagement.models import Mouldmodel
from django.db.models.aggregates import Sum
import json
from datetime import datetime, timedelta, time
from machinemanagement.models import AddMachine
from shiftmanagement.models import ShiftTimings
from rest_framework import viewsets
from rest_framework.decorators import api_view
from django.db.models import Q

class ProductionTableViewset(viewsets.ModelViewSet):
    serializer_class = ProductionTableSerializers

    def create(self,request,*args,**kwargs):
        Plantname = request.GET['Plantname']
        httpdata = request.data

        Machinename = httpdata['Mname']
        mldname = httpdata['mldname']

        fromdate = httpdata['start']
        todate =  httpdata['end']

        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        if shift_times:
            # Directly assign time values without using strptime
            first_shift_start = shift_times['shift1start']
            first_shift_end = shift_times['shift1end']
            second_shift_start = shift_times['shift2start']
            second_shift_end = shift_times['shift2end']
            third_shift_start = shift_times['shift3start']
            third_shift_end = shift_times['shift3end']
            
        else:
            print("No shift times available for the specified Plantname.")

        # Convert the date strings to datetime objects
        startdate_dt = datetime.strptime(fromdate, "%Y-%m-%d")
        enddate_dt = datetime.strptime(todate, "%Y-%m-%d")

        # Calculate the total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        nex_enddate_dt = enddate_dt + timedelta(days=1)

        seconddate_dt = startdate_dt + timedelta(days=1)

        # Convert to string only for querying
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        enddate_str = enddate_dt.strftime('%Y-%m-%d')
        seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

        # Retrieve and store all data for the date range
        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=first_shift_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=third_shift_end),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values().order_by('id')

        if(mldname != ''):
            Mouldname_data = Mouldmodel.objects.filter(Mouldname=mldname).values('id')

            if Mouldname_data.exists():  # Check if data is present
                Mouldname_id = Mouldname_data[0]['id']  # Access the first item
                
                # ---------------------------------------------------------------------------------
                # Filter `all_dashboard_value` for entries with the matching `Mouldname_id`
                date_data = [p for p in all_dashboard_value if p['Mouldname_id'] == Mouldname_id]
                
                if date_data:  # Check if date_data is not empty
                    date_data_serializers = ProductionTableSerializers(date_data, many=True)
                    data_ = list(date_data_serializers.data)
                    columns = list(data_[0].keys()) if data_ else []
                    ds = date_data_serializers.data

                    for record in ds:
                        record["Mouldname"] = mldname

                    my_dict = {'display': columns, 'values': ds}

                    return JsonResponse(my_dict, safe=False)
                else:
                    return JsonResponse('No data available', safe=False)
            else:
                return JsonResponse('No matching Mouldname found', safe=False)
            
        else:
            distinctMould = list(set(p['Mouldname_id'] for p in all_dashboard_value))

            MouldArray = []
            for ind in distinctMould:

                mouldname = Mouldmodel.objects.get(id = ind).Mouldname
                MouldArray.append(mouldname)

            return JsonResponse(MouldArray, safe = False)
        
        
@csrf_exempt
def name(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        names = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
        nameserializer = MachinenameSerialzers(names, many = True)
        return JsonResponse(nameserializer.data, safe=False)
