from django.urls import path, include 
from .import new_views
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('',new_views.ProductionTableViewset,basename="ProductionTable")

urlpatterns = [
    path('data/',include(router.urls)),
    path('Machinenames/', new_views.name, name="ProductionTable"),     
]