from django.db.models import fields
from rest_framework import serializers
from .models import ProductionTable
from machinemanagement.models import AddMachine

class ProductionTableSerializers(serializers.ModelSerializer):
    class Meta:
        model = ProductionTable
        fields = "__all__"

class MachinenameSerialzers(serializers.ModelSerializer):
    class Meta:
        model = AddMachine
        fields = ['amMachinename']