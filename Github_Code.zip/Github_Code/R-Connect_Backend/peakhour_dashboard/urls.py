from django.urls import path
from peakhour_dashboard import views

urlpatterns = [
    path('analytics/',views.peakhour,name='peakhour_dashboard'),
    path('peakhourconfig/',views.peakhourconfig,name='peakhour_management'),
    path('incomerconfig/',views.incomerdata,name='incomer_analytics'),
    path('demanddata/', views.demands, name="demands_consumptions")
]