from django.db.models.base import Model
from rest_framework import serializers
from peakhour_dashboard.models import PeakConfig

class PeakHourSerializer(serializers.ModelSerializer):
    class Meta:
        model = PeakConfig
        fields =['pkid',
                 'pkcode',
                 'pkplantname',
                 'pkstatus',
                 'pkstart',
                 'pkend'
                ]

