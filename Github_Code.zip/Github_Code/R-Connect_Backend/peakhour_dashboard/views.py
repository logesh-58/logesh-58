from functools import partial
from django.http.response import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from peakhour_dashboard.models import PeakConfig
from peakhour_dashboard.serializers import PeakHourSerializer
from rest_framework.parsers import JSONParser
from general_settings.models import Timingtable
from datetime import datetime, time
import calendar
from datetime import timedelta
from meter_data.models import Masterdatatable, Meterdata
from source_management.models import AddSource
import json
import pandas as pd
from django.db.models.aggregates import Sum
from group_management.models import AddGroup
from meter_management.models import AddMeter
# Create your views here.
@csrf_exempt
def peakhour(request):
    if request.method == "POST":
        analyticreq=JSONParser().parse(request)
        sdate = analyticreq["sessiondate"]
        plntname=request.GET['plantname']
        sessiondataArray = []  
        timing = list(Timingtable.objects.values('ttdaystarttime'))[0]['ttdaystarttime']
        groupname = list(AddGroup.objects.values('aggroupname').distinct())
        metername = list(AddMeter.objects.values('ammetername', 'ammetergroup').distinct())
        # print(metername)
        peakcongig = list(PeakConfig.objects.values('pkstatus').distinct())
        dict = {}
        for data1 in peakcongig:
            sessionwise = []
            # print(data1['pkstatus'])
            peakstatus = list(PeakConfig.objects.filter(pkstatus = data1['pkstatus']).values('pkstart', 'pkend'))
            for data2 in peakstatus:
                if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) >= int(timing.strftime("%H"))):
                    pkstart = int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H")) + 1
                    pkend = int(data2['pkend'].strftime("%H")) - int(timing.strftime("%H"))
                    
                if (int(data2['pkstart'].strftime("%H")) > int(data2['pkend'].strftime("%H"))) and (int(data2['pkend'].strftime("%H")) <= int(timing.strftime("%H"))):
                    pkstart = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1
                    pkend = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1 + int(data2['pkend'].strftime("%H")) + 1
                    
                if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) < int(timing.strftime("%H"))):
                    endtime_count = int(timing.strftime("%H")) - int(data2['pkstart'].strftime("%H"))
                    starttime_count = 24 - endtime_count
                    pkstart = starttime_count + 1
                    pkend = 24

                for i in range(pkstart, pkend + 1):
                    hours = "mth" + str(i) + "ec"
                    session_data = Masterdatatable.objects.filter(mtdate = sdate).values(hours).aggregate(Sum(hours))
                    try:
                        sessionwise.append(session_data[hours + '__sum'])
                    except:
                        sessionwise.append(0)
            dict[data1['pkstatus']] = round(sum(sessionwise)) 
        sessiondataArray.append(dict)
        
        groupSessionArray = []  
        for grpnames in groupname:
            group_dict = {}
            group_dict["groupname"] = grpnames['aggroupname']
            for data1 in peakcongig:
                groupwise = []
                # print(data1['pkstatus'])
                peakstatus = list(PeakConfig.objects.filter(pkstatus = data1['pkstatus']).values('pkstart', 'pkend'))
                for data2 in peakstatus:
                    if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) >= int(timing.strftime("%H"))):
                        pkstart = int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H")) + 1
                        pkend = int(data2['pkend'].strftime("%H")) - int(timing.strftime("%H"))
                        
                    if (int(data2['pkstart'].strftime("%H")) > int(data2['pkend'].strftime("%H"))) and (int(data2['pkend'].strftime("%H")) <= int(timing.strftime("%H"))):
                        pkstart = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1
                        pkend = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1 + int(data2['pkend'].strftime("%H")) + 1
                        
                    if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) < int(timing.strftime("%H"))):
                        endtime_count = int(timing.strftime("%H")) - int(data2['pkstart'].strftime("%H"))
                        starttime_count = 24 - endtime_count
                        pkstart = starttime_count + 1
                        pkend = 24
                        
                    for i in range(pkstart, pkend + 1):
                        hours = "mth" + str(i) + "ec"
                        
                        group_data = Masterdatatable.objects.filter(mtdate = sdate, mtgrpname = grpnames['aggroupname']).values(hours).aggregate(Sum(hours))
                        try:
                            groupwise.append(group_data[hours + '__sum'])
                        except:
                            groupwise.append(0)
                group_dict[data1['pkstatus']] = round(sum(groupwise))
            groupSessionArray.append(group_dict)
        
        metersessionArray = []
        for mtrname in metername:   
            meter_dict = {}
            meter_dict['mtrname'] = mtrname['ammetername']
            meter_dict['group'] = mtrname['ammetergroup']
            for data1 in peakcongig:
                meterwise = []
                # print(data1['pkstatus'])
                peakstatus = list(PeakConfig.objects.filter(pkstatus = data1['pkstatus']).values('pkstart', 'pkend'))
                for data2 in peakstatus:
                    if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) >= int(timing.strftime("%H"))):
                        pkstart = int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H")) + 1
                        pkend = int(data2['pkend'].strftime("%H")) - int(timing.strftime("%H"))
                        
                    if (int(data2['pkstart'].strftime("%H")) > int(data2['pkend'].strftime("%H"))) and (int(data2['pkend'].strftime("%H")) <= int(timing.strftime("%H"))):
                        pkstart = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1
                        pkend = (int(data2['pkstart'].strftime("%H")) - int(timing.strftime("%H"))) + 1 + int(data2['pkend'].strftime("%H")) + 1
                        
                    if (int(data2['pkstart'].strftime("%H")) < int(data2['pkend'].strftime("%H"))) and (int(data2['pkstart'].strftime("%H")) < int(timing.strftime("%H"))):
                        endtime_count = int(timing.strftime("%H")) - int(data2['pkstart'].strftime("%H"))
                        starttime_count = 24 - endtime_count
                        pkstart = starttime_count + 1
                        pkend = 24
                        
                    for i in range(pkstart, pkend + 1):
                        hours = "mth" + str(i) + "ec"
                        meter_data = Masterdatatable.objects.filter(mtdate = sdate, mtmtrname = mtrname['ammetername']).values(hours).aggregate(Sum(hours))
                        try:
                            meterwise.append(round(meter_data[hours + '__sum']))
                        except:
                            meterwise.append(0)
                meter_dict[data1['pkstatus']] = round(sum(meterwise))
            metersessionArray.append(meter_dict)
        my_dict = {
            "overall": sessiondataArray,
            "groupwise": groupSessionArray,
            "meterdata": metersessionArray
        }
            
    return JsonResponse(my_dict, safe=False)

#------------Old code for Session data -----------------
#         timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
#         # print(timingtblrow)
#         for s in timingtblrow:
#             dailyreporttime = s["ttdaystarttime"]
#             s1time = s["tts1time"]
#             s2time = s["tts2time"]
#             s3time = s["tts3time"]
#         s1string = s1time.strftime('%H')
#         s1hrint = int(s1string)
#         current_time = datetime.now()
#         # Subtract 2 hours from datetime object containing current time
#         past_time = current_time - timedelta(hours=s1hrint)
#         # Convert datetime object to string in specific format 
#         past_time_str = past_time.strftime('%Y-%m-%d')
#         h1time = int(s1string)
#         h2time = ((h1time-24) + 1) if h1time>=23 else (h1time + 1)
#         h3time = ((h2time-24) + 1) if h2time>=23 else (h2time + 1)
#         h4time = ((h3time-24) + 1) if h3time>=23 else (h3time + 1)
#         h5time = ((h4time-24) + 1) if h4time>=23 else (h4time + 1)
#         h6time = ((h5time-24) + 1) if h5time>=23 else (h5time + 1)
#         h7time = ((h6time-24) + 1) if h6time>=23 else (h6time + 1)
#         h8time = ((h7time-24) + 1) if h7time>=23 else (h7time + 1)
#         h9time = ((h8time-24) + 1) if h8time>=23 else (h8time + 1)
#         h10time = ((h9time-24) + 1) if h9time>=23 else (h9time + 1)
#         h11time = ((h10time-24) + 1) if h10time>=23 else (h10time + 1)
#         h12time = ((h11time-24) + 1) if h11time>=23 else (h11time + 1)
#         h13time = ((h12time-24) + 1) if h12time>=23 else (h12time + 1)
#         h14time = ((h13time-24) + 1) if h13time>=23 else (h13time + 1)
#         h15time = ((h14time-24) + 1) if h14time>=23 else (h14time + 1)
#         h16time = ((h15time-24) + 1) if h15time>=23 else (h15time + 1)
#         h17time = ((h16time-24) + 1) if h16time>=23 else (h16time + 1)
#         h18time = ((h17time-24) + 1) if h17time>=23 else (h17time + 1)
#         h19time = ((h18time-24) + 1) if h18time>=23 else (h18time + 1)
#         h20time = ((h19time-24) + 1) if h19time>=23 else (h19time + 1)
#         h21time = ((h20time-24) + 1) if h20time>=23 else (h20time + 1)
#         h22time = ((h21time-24) + 1) if h21time>=23 else (h21time + 1)
#         h23time = ((h22time-24) + 1) if h22time>=23 else (h22time + 1)
#         h24time = ((h23time-24) + 1) if h23time>=23 else (h23time + 1)
#         metrdata=Masterdatatable.objects.filter(mtdate=sdate,mtcategory="Secondary",mtplntlctn=plntname).values("mtmtrname","mtgrpname")
#         peakrows = PeakConfig.objects.filter(pkplantname=plntname).values()
#         pkhrs=[]
#         nonpkhrs=[]
#         stndrdhrs=[]
#         # for meter in metrdata:
#         for data in peakrows:
#             a = int((data["pkstart"]).strftime("%H"))
#             b = int((data["pkend"]).strftime("%H"))
#             if b==0:
#                 b=24
#             if data["pkstatus"] == "Peak":
#                 for i in range(a,b):
#                     pkhrs.append(i)
#                     # for j in range(1,25):
#                     #     # print(eval("h"+str(i)+"time"))
#                     #     if i == eval("h"+str(j)+"time"):
#                     #         print("PeakHour:",j)
#                     #         c = "mth"+str(j)+"ec"
#                     #         metrdata=Masterdatatable.objects.filter(mtdate="2021-06-25",mtmtrname=meter).values("mtmtrname",c,"mtgrpname")
                            
#                             # for val in metrdata:
#                             #     print(val.mtrname)
                                
#             elif data["pkstatus"] == "Non Peak":
#                 for i in range(a,b):
#                     nonpkhrs.append(i)
#                     # for j in range(1,25):
#                     #     # print(eval("h"+str(i)+"time"))
#                     #     if i == eval("h"+str(j)+"time"):
#                     #         print("NonPeakHour:",j)
#             elif data["pkstatus"] == "Standard":
#                 for i in range(a,b):
#                     stndrdhrs.append(i)
#                     # for j in range(1,25):
#                     #     # print(eval("h"+str(i)+"time"))
#                     #     if i == eval("h"+str(j)+"time"):
#                     #         print("StandardHour:",j)
#         # print("Peak Hours:",pkhrs)
#         # print("Non Peak Hours:",nonpkhrs)
#         # print("Standard Hours",stndrdhrs)
#         # for val in pkhrs:
# #LOGIC TO CALCULTE THE PEAK HOUR, NON PEAK HOUR AND STANDARD HOUR ENERGY
#         meterdata_list=[]
#         for meter in metrdata:
#             metnme = meter["mtmtrname"]
#             grpnme = meter["mtgrpname"]
#             peakeng = 0.00
#             nonpkeng = 0.00
#             stdeng = 0.00
#             # shreng = 0.00
#             # print(metnme)
#             # print(grpnme)
#     #LOGIC TO GET THE NON PEAK HOUR ENERGY
#             for hr in pkhrs:
#                 # shreng=0.00
#                 # print(hr)
#                 for j in range(1,25):
#                     # print(eval("h"+str(i)+"time"))
#                     if hr == eval("h"+str(j)+"time"):
#                         # print("PeakHour:",j)
#                         c = "mth"+str(j)+"ec"
#                         # print(c)
#                         slctdata=Masterdatatable.objects.filter(mtdate=sdate,mtmtrname=metnme,mtcategory="Secondary",mtplntlctn=plntname).values("mtmtrname","mtgrpname",c)
#                         for val in slctdata:
#                             # mnme = val.mtmtrname
#                             # gnme = val.mtgrpname
#                             # print(type(val))
#                             shreng = val[c]
#                             # print(val[c])
#                             if shreng==None:
#                                 shreng=0.00
#                             # print(shreng)
#                 try:
#                     peakeng =float(shreng)+float(peakeng)
#                 except:
#                     peakeng =0.00+float(peakeng)
#             # print(peakeng)
#     #LOGIC TO GET THE NON PEAK HOUR ENERGY
#             for hr in nonpkhrs:
#                 # shreng=0.00
#                 # print(hr)
#                 for j in range(1,25):
#                     # print(eval("h"+str(i)+"time"))
#                     if hr == eval("h"+str(j)+"time"):
#                         # print("PeakHour:",j)
#                         c = "mth"+str(j)+"ec"
#                         # print(c)
#                         slctdata=Masterdatatable.objects.filter(mtdate=sdate,mtmtrname=metnme,mtplntlctn=plntname).values("mtmtrname","mtgrpname",c)
#                         for val in slctdata:
#                             # mnme = val.mtmtrname
#                             # gnme = val.mtgrpname
#                             # print(type(val))
#                             shreng = val[c]
#                             # print(val[c])
#                             if shreng==None:
#                                 shreng=0.00
#                             # print(shreng)
#                 try:
#                     nonpkeng =float(shreng)+float(nonpkeng)
#                 except:
#                     nonpkeng =0.00+float(nonpkeng)
#             # print(nonpkeng)
#     #LOGIC TO GET THE STANDARD HOUR ENERGY
#             for hr in stndrdhrs:
#                 # shreng=0.00
#                 # print(hr)
#                 for j in range(1,25):
#                     # print(eval("h"+str(i)+"time"))
#                     if hr == eval("h"+str(j)+"time"):
#                         # print("PeakHour:",j)
#                         c = "mth"+str(j)+"ec"
#                         # print(c)
#                         slctdata=Masterdatatable.objects.filter(mtdate=sdate,mtmtrname=metnme,mtplntlctn=plntname).values("mtmtrname","mtgrpname",c)
#                         for val in slctdata:
#                             # mnme = val.mtmtrname
#                             # gnme = val.mtgrpname
#                             # print(type(val))
#                             shreng = val[c]
#                             # print(val[c])
#                             if shreng==None:
#                                 shreng=0.00
#                             # print(shreng)
#                 try:
#                     stdeng =float(shreng)+float(stdeng)
#                 except:
#                     stdeng =0.00+float(stdeng)
#             # print(stdeng)
#             meterdata_list.append({"mtrname":metnme,"group":grpnme,"peak":peakeng,
#                                     "nonpeak":nonpkeng,"standard":stdeng})
                                
#         # print(meterdata_list) 
# # LOGIC TO CALCULATE THE GROUPWISE PEAK HOUR ENERGY CONSUMPTION
#         groupwise_list=[]
#         grpdata = Masterdatatable.objects.filter(mtdate=sdate,mtcategory="Secondary",mtplntlctn=plntname).values("mtgrpname").distinct()
#         grp_name=[]
#         for grp in grpdata:
#             grp_name.append(grp["mtgrpname"])
#         # print(grp_name)
#         grpkeng = 0.0
#         grpnonpkeng = 0.0
#         grpstdeng = 0.0
#         for name in grp_name:
#             for data in meterdata_list:
#                 datagrp = data["group"]
#                 datapk = data["peak"]
#                 datanonpk = data["nonpeak"]
#                 datastd = data["standard"]
#                 if (name==datagrp):
#                     # print(name)
#                     grpkeng = float(datapk) + grpkeng
#                     grpnonpkeng = float(datanonpk) + grpnonpkeng
#                     grpstdeng = float(datastd) + grpstdeng
#             groupwise_list.append({"groupname":name,"peak":grpkeng,"nonpeak":grpnonpkeng, "standard":grpstdeng})
#         # print(groupwise_list)

# #LOGIC TO CALCULATE THE OVERALL ENERGY CONSUMPTION
#         overall_list=[]
#         overpk=0.0
#         overnonpk=0.0
#         overstd=0.0
#         for grpdata in groupwise_list:
#             grppk = grpdata["peak"]
#             grpnonpk = grpdata["nonpeak"]
#             grpstd = grpdata["standard"]
#             overpk = float(grppk) + overpk
#             overnonpk = float(grpnonpk) + overnonpk
#             overstd = float(grpstd) + overstd
#         overall_list.append({"peak":overpk,"nonpeak":overnonpk,"standard":overstd})
#         # print(overall_list)
  
#     my_dict = {"overall":overall_list,"groupwise":groupwise_list,"meterdata":meterdata_list}
#     # print(my_dict)
#     return JsonResponse(my_dict,safe=False)

@csrf_exempt
def peakhourconfig(request):
    plntname=request.GET['plantname']
    if request.method == "GET":
        peakconfig = PeakConfig.objects.filter(pkplantname=plntname).values()
        peakserailizer = PeakHourSerializer(peakconfig,many=True)
        return JsonResponse(peakserailizer.data,safe=False)

    elif request.method == "POST":
        peakconfig_DbData = JSONParser().parse(request)
        # print("peakhour config")
        pkdatacode = peakconfig_DbData["pkcode"]
        pkconfigdata = PeakConfig.objects.all()
        count=0
        for s in pkconfigdata:
            if s.pkcode == pkdatacode:
                count+=1
        if count==0:
            peakSerializerData = PeakHourSerializer(data=peakconfig_DbData,partial=True)
            if peakSerializerData.is_valid():
                peakSerializerData.save()
                PeakConfig.objects.filter(pkcode=peakconfig_DbData["pkcode"]).update(pkplantname = plntname)
                return JsonResponse("Peak Hour Configuration data saved to the Database",safe=False)
            else:
                return JsonResponse("Peak Hour Configuratin data already exist",safe=False)

    elif request.method == "PUT":
        peakconfigdata = JSONParser().parse(request)
        print(peakconfigdata)
        PeakConfig.objects.filter(pkcode=peakconfigdata["pkcode"]).update(pkstatus = peakconfigdata["pkstatus"],
                                                                          pkstart = peakconfigdata["pkstart"],
                                                                          pkend = peakconfigdata["pkend"],
                                                                          pkcode=peakconfigdata["pkcode"])
        return JsonResponse("Data updated successfully",safe=False)

    elif request.method == "DELETE":
        Dbdata= JSONParser().parse(request)
            # print(Dbdata["sccode"])
        PeakConfig.objects.filter(pkcode=Dbdata["code"]).delete()

        return JsonResponse("Session Record Deleted Successfully",safe=False)


@csrf_exempt
def incomerdata(request):
    if request.method == "GET":
        plntname=request.GET['plantname']
        timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
        # print(timingtblrow)
        for s in timingtblrow:
            dailyreporttime = s["ttdaystarttime"]
            s1time = s["tts1time"]
            s2time = s["tts2time"]
            s3time = s["tts3time"]
        s1string = s1time.strftime('%H')
        s1hrint = int(s1string)
        current_time = datetime.now()
        # Subtract 2 hours from datetime object containing current time
        past_time = current_time - timedelta(hours=s1hrint)
        # Convert datetime object to string in specific format 
        past_time_str = past_time.strftime('%Y-%m-%d')
        #LOGIC TO SEND DATA TO THE SOURCE CARD
        incomerdata = Masterdatatable.objects.filter(mtdate=past_time_str,mtcategory="Primary",mtplntlctn=plntname).all()
        icomer_name=[]
        for data in incomerdata:
            icomer_name.append(data.mtmtrname)
        incomer_list=[]
        for data in incomerdata:
            incomer_list.append({"name":data.mtmtrname,
                                 "energy":data.mtenergycons,
                                  "frequency":data.mtavgfreq,
                                  "voltage":data.mtpeakvolt,
                                  "current":data.mtpeakcrnt,
                                  "powerfactor":data.mtpwrfctr})
            # print(data.mtmtrname)
        #LOGIC TO SEDN DATA TO THE SOURCE CHARTER
        yearval = past_time.strftime('%Y')
        monthval = past_time.strftime('%m')
        # print(monthval,yearval)
        dtmnth = calendar.monthrange(int(yearval),int(monthval))
        # print(dtmnth[0])
        # print(dtmnth[1])
        strtdate = yearval+"-"+monthval+"-01"
        enddate = yearval+"-"+monthval+"-"+str(dtmnth[1])
        # incomerchart = Masterdatatable.objects.filter(date__range=[strtdate,enddate])
        inc_grdata=[]
        for mtr in icomer_name:
            mtrnme = "(mtmtrname='"+mtr+"')"
            catgryqry="(mtcategory='"+"Primary"+"')"
            datequery="(mtdate BETWEEN '"+strtdate+"' AND '"+enddate+"')"
            plantquery="(mtplntlctn='MATE U-I')"
            sql="SELECT * FROM meter_data_masterdatatable WHERE "+datequery+" AND "+catgryqry+" AND "+plantquery+" AND "+mtrnme+" ORDER BY mtdate"
            mthpwrfctr=[]
            mthdate=[]
            for data in Masterdatatable.objects.raw(sql):
                mthpwrfctr.append(data.mtpwrfctr)
                mthdate.append(data.mtdate)
            inc_grdata.append({"name":mtr,"data":mthpwrfctr,"date":mthdate})
        my_dict={"incomer":incomer_list,"monthly":inc_grdata}
        return JsonResponse(my_dict,safe=False)


@csrf_exempt
def demands(request):
    if request.method == 'GET':
        from_date = request.GET['from_date'] ; to_date   = request.GET['to_date']
        print(from_date, to_date)
        list_demands = []
        src_name = Masterdatatable.objects.filter(mtsrcname='Transformer1',mtgrpname='Incomer',mtcategory="Secondary").values()
        for s in src_name:
            sourcename = s['mtsrcname']
            # print(sourcename)
            max_demands = AddSource.objects.get(assourcename = sourcename)
            add_srcname = max_demands.assourcename ; max_capacity = max_demands.assourcecapacity
        srt_date = datetime.strptime(from_date , "%Y-%m-%d").date() ; end_date = datetime.strptime(to_date , "%Y-%m-%d").date()
        dly_date = pd.date_range(start=srt_date, end=end_date)
        for date in dly_date:
            dte = (date.date())
            # print(dte)
            try:
                maxdemands_reached = Masterdatatable.objects.get(mtcategory = 'Secondary', mtsrcname='Transformer1',mtgrpname='Incomer', mtdate = dte)
                mtmaxdemands =  maxdemands_reached.mtmaxdemands
                list_demands.append({"max_demands":max_capacity,"Actual_demands":mtmaxdemands , "date":dte})
            except:
                list_demands.append({"max_demands":max_capacity,"Actual_demands":0 , "date":dte})
        print(list_demands)
        return JsonResponse(list_demands,safe=False)