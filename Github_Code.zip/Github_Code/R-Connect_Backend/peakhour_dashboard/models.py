from django.db import models

# Create your models here.
class PeakConfig(models.Model):
    pkid = models.AutoField(primary_key=True)
    pkcode = models.CharField(max_length=255,default=False,null=True)
    pkplantname = models.CharField(max_length=255,default=False,null=True)
    pkstatus = models.CharField(max_length=255,default=False,null=True)
    pkstart = models.TimeField(default=False,null=True)
    pkend = models.TimeField(default=False,null=True)
