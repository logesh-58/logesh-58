from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from maintenance.models import maintenance_module
import json
from machinemanagement.models import AddMachine
from datetime import datetime, timedelta, time
import pandas
import calendar
from shiftmanagement.models import ShiftTimings
from django.db.models import Q
# mail packages
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders

# Create your views here.

def getmachinename(plantname):
    """Fetch machine names and images for the given plant."""
    return list(AddMachine.objects.filter(amPlantname=plantname)
                .values('amMachinename', 'ammachineimage')
                .order_by('amid'))

@csrf_exempt
def maintenance_func(request):
    if request.method == 'GET':
        plantname = request.GET.get('Plantname')

        current_date = datetime.today().date()
        current_date_str = current_date.strftime("%Y-%m-%d")
        nextdate_str = (current_date + timedelta(days=1)).strftime("%Y-%m-%d")

        # Get shift start time
        shift_data = ShiftTimings.objects.filter(Plantname=plantname).values('shift1start', 'shift3end').last()
        shift_data_str = shift_data['shift1start'].strftime('%H:%M:%S') if shift_data['shift1start'] else None
        shift_data_end = shift_data['shift3end'].strftime('%H:%M:%S') if shift_data['shift3end'] else None
        # Get machine names
        machine_list = getmachinename(plantname)
        machine_names = [machine['amMachinename'] for machine in machine_list]

        # Fetch maintenance data for the required machines and time range
        all_data = maintenance_module.objects.filter(
            Q(mnt_date=current_date_str, mnt_time__gte=shift_data_str) |
            Q(mnt_date=nextdate_str, mnt_time__lte=shift_data_end),
            mnt_machinename__in=machine_names
        ).values(
            'mnt_machinename', 'mnt_oilfilter_clogge', 'mnt_hydraulic',
            'mnt_pumpstatus', 'mnt_lubrication', 'mnt_FRdoor', 'mnt_RRdoor',
            'mnt_moldleakage', 'mnt_cooling', 'mnt_injection', 'mnt_oilfilter_motor'
        ).order_by('mnt_id')

        response_list = []

        for machine in machine_list:
            machine_name = machine['amMachinename']
            machine_image = machine['ammachineimage']

            # Get maintenance data for this machine
            machine_data = [entry for entry in all_data if entry['mnt_machinename'] == machine_name]

            if machine_data:
                latest_data = machine_data[-1]  # Safely get the last entry
            else:
                latest_data = {}  # Empty dict if no data found

            response_list.append({
                "machinename": machine_name,
                "Machineimage": machine_image,
                "oilfilter_condition": latest_data.get('mnt_oilfilter_clogge', "No Data Found!"),
                "lubricationoil_monitoring": latest_data.get('mnt_lubrication', "No Data Found!"),
                "hydraulicoil_monitoring": latest_data.get('mnt_hydraulic', "No Data Found!"),
                "pumpstatus_monitoring": latest_data.get('mnt_pumpstatus', "No Data Found!"),
                "frdoor_monitoring": latest_data.get('mnt_FRdoor', "No Data Found!"),
                "rrdoor_monitoring": latest_data.get('mnt_RRdoor', "No Data Found!"),
                "moldleakage_monitoring": latest_data.get('mnt_moldleakage', "No Data Found!"),
                "cooling_monitoring": latest_data.get('mnt_cooling', "No Data Found!"),
                "injection_monitoring": latest_data.get('mnt_injection', "No Data Found!"),
                "oilfilter_motor": latest_data.get('mnt_oilfilter_motor', "No Data Found!")
            })

        return JsonResponse(response_list, safe=False)

    

@csrf_exempt
def Analytics(request):
    if request.method == 'POST':
        request_data     = json.loads(request.body)
        start_date       = request_data['start_date']
        end_date         = request_data['end_date']
        machinename      = request_data['machinename']

        plantname = request.GET['Plantname']
        # Retrieve the shift start time
        shift_data = ShiftTimings.objects.filter(Plantname=plantname).values('shift1start', 'shift3end').last()
        shift_data_str = shift_data['shift1start']
        shift_data_end = shift_data['shift3end']

        # Convert start and end dates to datetime objects
        startdate_dt = datetime.strptime(start_date, "%Y-%m-%d")
        enddate_dt = datetime.strptime(end_date, "%Y-%m-%d")

        # Calculate total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        # Query all relevant maintenance data
        all_data = maintenance_module.objects.filter(
            Q(mnt_date=start_date, mnt_time__gte=shift_data_str) |
            Q(mnt_date__range=[(startdate_dt + timedelta(days=1)).strftime('%Y-%m-%d'), end_date]) |
            Q(mnt_date=(enddate_dt + timedelta(days=1)).strftime('%Y-%m-%d'), mnt_time__lte=shift_data_end),
            mnt_machinename=machinename
        ).values(
            'mnt_date', 'mnt_time', 'mnt_oilfilter_clogge', 'mnt_hydraulic', 'mnt_pumpstatus',
            'mnt_lubrication', 'mnt_FRdoor', 'mnt_RRdoor', 'mnt_moldleakage',
            'mnt_cooling', 'mnt_injection', 'mnt_oilfilter_motor'
        ).order_by('mnt_id')


        analytics_list = []
        
        for day_offset in range(total_days):
            current_date = startdate_dt + timedelta(days=day_offset)
            next_date = current_date + timedelta(days=1)

            current_date_str = current_date.strftime('%Y-%m-%d')

            day_data = [
                entry for entry in all_data
                if (entry['mnt_date'] == current_date.date() and time.fromisoformat(entry['mnt_time']) >= shift_data_str) or
                   (entry['mnt_date'] == next_date.date() and time.fromisoformat(entry['mnt_time']) <= shift_data_end)
            ]

            # Count occurrences for each maintenance parameter
            oilfilterclogging = sum(1 for entry in day_data if entry['mnt_oilfilter_clogge'] is not None and entry['mnt_oilfilter_clogge'] > 0)
            lubricationoil = sum(1 for entry in day_data if entry['mnt_lubrication'] is not None and entry['mnt_lubrication'] > 0)
            hydraulicoil = sum(1 for entry in day_data if entry['mnt_hydraulic'] is not None and entry['mnt_hydraulic'] > 0)
            pumpstatus = sum(1 for entry in day_data if entry['mnt_pumpstatus'] is not None and entry['mnt_pumpstatus'] > 0)
            frdoor = sum(1 for entry in day_data if entry['mnt_FRdoor'] is not None and entry['mnt_FRdoor'] > 0)
            rrdoor = sum(1 for entry in day_data if entry['mnt_RRdoor'] is not None and entry['mnt_RRdoor'] > 0)
            moldleakage = sum(1 for entry in day_data if entry['mnt_moldleakage'] is not None and entry['mnt_moldleakage'] > 0)
            cooling = sum(1 for entry in day_data if entry['mnt_cooling'] is not None and entry['mnt_cooling'] > 0)
            injection = sum(1 for entry in day_data if entry['mnt_injection'] is not None and entry['mnt_injection'] > 0)
            oilfiltermotor = sum(1 for entry in day_data if entry['mnt_oilfilter_motor'] is not None and entry['mnt_oilfilter_motor'] > 0)

            analytics_list.append({
                "date": current_date_str,
                "oilfilter_clogging": oilfilterclogging,
                "lubrication_oillevel": lubricationoil,
                "hydraulic_oillevel": hydraulicoil,
                "pump_status": pumpstatus,
                "frdoor_monitoring": frdoor,
                "rrdoor_monitoring": rrdoor,
                "mold_leakge": moldleakage,
                "cooling_monitoring": cooling,
                "injection_monitoring": injection,
                "oilfiltermotor": oilfiltermotor
            })

        return JsonResponse(analytics_list, safe=False)


@csrf_exempt
def Historical(request):
    if request.method == 'POST':
        request_data = json.loads(request.body)
        start_date = request_data['start_date']
        end_date = request_data['end_date']
        machinename = request_data['machinename']

        plantname = request.GET['Plantname']
        # Retrieve the shift start time
        shift_data = ShiftTimings.objects.filter(Plantname=plantname).values('shift1start', 'shift3end').last()
        shift_data_str = shift_data['shift1start']
        shift_data_end = shift_data['shift3end']

        # Convert start and end dates to datetime objects
        startdate_dt = datetime.strptime(start_date, "%Y-%m-%d")
        enddate_dt = datetime.strptime(end_date, "%Y-%m-%d")

        # Calculate total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        # Query all relevant maintenance data
        all_data = maintenance_module.objects.filter(
            Q(mnt_date=start_date, mnt_time__gte=shift_data_str) |
            Q(mnt_date__range=[(startdate_dt + timedelta(days=1)).strftime('%Y-%m-%d'), end_date]) |
            Q(mnt_date=(enddate_dt + timedelta(days=1)).strftime('%Y-%m-%d'), mnt_time__lte=shift_data_end),
            mnt_machinename=machinename
        ).values(
            'mnt_date', 'mnt_time', 'mnt_oilfilter_clogge', 'mnt_hydraulic', 'mnt_pumpstatus',
            'mnt_lubrication', 'mnt_FRdoor', 'mnt_RRdoor', 'mnt_moldleakage',
            'mnt_cooling', 'mnt_injection', 'mnt_oilfilter_motor'
        ).order_by('mnt_id')


        # Initialize response
        historical_response = []

        # Process data day by day
        for day_offset in range(total_days):
            current_date = startdate_dt + timedelta(days=day_offset)
            next_date = current_date + timedelta(days=1)

            current_date_str = current_date.strftime('%Y-%m-%d')

            day_data = [
                entry for entry in all_data
                if (entry['mnt_date'] == current_date.date() and time.fromisoformat(entry['mnt_time']) >= shift_data_str) or
                   (entry['mnt_date'] == next_date.date() and time.fromisoformat(entry['mnt_time']) <= shift_data_end)
            ]

            # Check if conditions exist and are greater than or equal to 0, with None handling
            if sum(1 for entry in day_data if entry['mnt_oilfilter_clogge'] is not None and entry['mnt_oilfilter_clogge'] > 0):
                historical_response.append({
                    "date": current_date_str,    # entry['mnt_date'].strftime('%Y-%m-%d'),
                    "machinename": machinename,
                    "condition": 'Oilfilter is clogged'
                })
            if sum(1 for entry in day_data if entry['mnt_lubrication'] is not None and entry['mnt_lubrication'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Lubrication Oil Level is Dropped'
                })
            if sum(1 for entry in day_data if entry['mnt_hydraulic'] is not None and entry['mnt_hydraulic'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Hydraulic Oil Level is Dropped'
                })
            if sum(1 for entry in day_data if entry['mnt_pumpstatus'] is not None and entry['mnt_pumpstatus'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Main Motor is Powered Off'
                })
            if sum(1 for entry in day_data if entry['mnt_FRdoor'] is not None and entry['mnt_FRdoor'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'FR Safety Door is Opened'
                })
            if sum(1 for entry in day_data if entry['mnt_RRdoor'] is not None and entry['mnt_RRdoor'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'RR Safety Door is Opened'
                })
            if sum(1 for entry in day_data if entry['mnt_moldleakage'] is not None and entry['mnt_moldleakage'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Mold is Leaking'
                })
            if sum(1 for entry in day_data if entry['mnt_cooling'] is not None and entry['mnt_cooling'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Cooling Monitoring'
                })
            if sum(1 for entry in day_data if entry['mnt_injection'] is not None and entry['mnt_injection'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Injection Monitoring'
                })
            if sum(1 for entry in day_data if entry['mnt_oilfilter_motor'] is not None and entry['mnt_oilfilter_motor'] > 0):
                historical_response.append({
                    "date": current_date_str,
                    "machinename": machinename,
                    "condition": 'Oil Filter Motor is Powered Off'
                })

        return JsonResponse(historical_response, safe=False)