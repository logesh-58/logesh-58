from django.apps import AppConfig


class HourlyVirtualreportConfig(AppConfig):
    name = 'hourly_virtualreport'
