from django.db import models

# Create your models here.
class AddCategory(models.Model):
    acid = models.AutoField(primary_key=True)
    accategoryname = models.CharField(max_length=255,default=False,null=True)
    acplantname = models.CharField(max_length=255,default=False,null=True)
    accategorycode= models.CharField(max_length=255,default=False,null=True)