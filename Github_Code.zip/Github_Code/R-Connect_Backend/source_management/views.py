import source_management
from django.shortcuts import render
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from source_management.serializers import SourceManagementDbSerializer
from source_management.models import AddSource

# Create your views here.
@csrf_exempt
def addsource(request):
    plntname=request.GET['plantname']
    if request.method=="GET":
        sourcemanagement = AddSource.objects.filter(asplantname=plntname).values()
        smdbserializer = SourceManagementDbSerializer(sourcemanagement,many=True)
        return JsonResponse(smdbserializer.data,safe=False)

    elif request.method=="POST":
        sourcemanagement_Dbdata =  JSONParser().parse(request)
        srcname = sourcemanagement_Dbdata["assourcecode"]
        
        getrow = AddSource.objects.all()
        count=0
        for s in getrow:
            # print(s.assourcecode)
            if srcname == s.assourcecode:
                count=count+1

        if count == 0:        
            sourcemanagementSerializer = SourceManagementDbSerializer(data=sourcemanagement_Dbdata, partial=True)
            if sourcemanagementSerializer.is_valid():
                sourcemanagementSerializer.save()
                AddSource.objects.filter(assourcecode=sourcemanagement_Dbdata["assourcecode"]).update(asplantname=plntname)

            return JsonResponse("Source Management data saved to the db successfully",safe=False)
        else:
            return JsonResponse("Source Code Already exist",safe=False)

    elif request.method=="PUT":
        sourcemanagement_Dbdata =  JSONParser().parse(request)
        print(sourcemanagement_Dbdata)
        AddSource.objects.filter(assourcecode=sourcemanagement_Dbdata["assourcecode"]).update(assourcename=sourcemanagement_Dbdata["assourcename"],
        asplantname=sourcemanagement_Dbdata["asplantname"],
        assourcecapacity=sourcemanagement_Dbdata["assourcecapacity"],
        assourcecode=sourcemanagement_Dbdata["assourcecode"])

        return JsonResponse("Source Management data updated to the db successfully",safe=False)

    elif request.method=="DELETE":
        Dbdata= JSONParser().parse(request)
        # print(request)
        print("Delete running within add meter")
        AddSource.objects.filter(assourcecode=Dbdata["code"]).delete()

        return JsonResponse("Source Management Record Deleted Successfully",safe=False)

# @csrf_exempt
# def delete(request):
#     Dbdata= JSONParser().parse(request)
#     print(Dbdata["code"])
#     AddSource.objects.filter(assourcecode=Dbdata["code"]).delete()
#     return JsonResponse("Source Record Deleted Successfully",safe=False)

   