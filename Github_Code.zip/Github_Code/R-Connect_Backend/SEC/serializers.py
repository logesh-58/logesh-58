from django.db.models.base import Model
from rest_framework import serializers
from SEC.models import secmodel

class secserializer(serializers.ModelSerializer):
    class Meta:
        model = secmodel
        fields =[
                'sec_id',
                'sec_date',
                'sec_energy',
                'sec_material',
                'sec_value',
                'sec_conform'
                ]