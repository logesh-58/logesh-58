from SEC.models import secmodel
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from datetime import datetime, timedelta
from django.db.models.aggregates import Sum

@csrf_exempt
def SECchart(request):
    if request.method == 'POST':
        request_data = json.loads(request.body)
        year_data = int(request_data['Year'])
        month_data = int(request_data['Month'])
        
        current_date = datetime.now()
        # present_date = current_date.strftime("%d")
        # current_month = current_date.month
        # current_year = current_date.year
        
        start_date = datetime(year_data, month_data, 1)
        end_date = (datetime(year_data, month_data + 1, 1) - timedelta(days = 1))
        
        date_array = []
        
        while start_date <= end_date:
            date_array.append(start_date.strftime("%Y-%m-%d"))
            start_date += timedelta(days = 1)
            
        secvalue_array = []
        for dates in date_array:
            secvalue = secmodel.objects.filter(sec_date = dates).values('sec_value').aggregate(Sum('sec_value'))
            try:
                secvalue_array.append(round(secvalue['sec_value__sum'], 2))
            except:
                secvalue_array.append(0)
                
        my_dict = {
            "Date": date_array,
            "SEC_value": secvalue_array
        }
        
    return JsonResponse(my_dict, safe=False)