from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from SEC.models import secmodel
from SEC.serializers import secserializer
from rest_framework.parsers import JSONParser
from meter_data.models import Masterdatatable
from django.http import HttpResponse
from django.db.models.aggregates import Sum
from datetime import date, timedelta
# from celery.schedules import crontab
# from celery.task import periodic_task


# Create your views here.
@csrf_exempt
def secreport(request):
    # plntname=request.GET['plantname']
    if request.method == "GET":
        sec_data = secmodel.objects.values().order_by('sec_date')
        secserailizer = secserializer(sec_data,many=True)
        return JsonResponse(secserailizer.data,safe=False)

    elif request.method == "POST":
        data = JSONParser().parse(request)
        secconfig = secmodel.objects.values('sec_id')
        # print(secconfig)
        count = 0
        for i in secconfig:
            if i['sec_id'] == data['sec_id']:
                count+=1
        # print(data)
        if count > 0:
            secmodel.objects.filter(sec_date = data['sec_date']).update(sec_material = data['sec_material'] , sec_value = data['sec_value'], sec_conform = 1)
            return JsonResponse("Data updated successfully",safe=False)
        else:
            return JsonResponse("Data not existed", safe=False)

# @csrf_exempt
# @periodic_task(run_every=(crontab(day_of_week="0-6", hour=6, minute=1)))
# def sec_energy(request):
#     # if request.method=='GET':
#     Previous_date = date.today() - timedelta(days = 1)
#     groupArray = ["IMG", "IMGAuxilliary"]
#     Total_energy = 0
#     for group in groupArray:
#         IMG_energy  = Masterdatatable.objects.filter(mtdate = Previous_date, mtgrpname = group).values('mtenergycons')
#         for img in IMG_energy:
#             Total_energy = img['mtenergycons'] + Total_energy
#     if (secmodel.objects.filter(sec_date = Previous_date, sec_conform=1).exists()):
#         print('SEC Data exists')
#     else:
#         secmodel.objects.create(sec_date = Previous_date, sec_energy = round(Total_energy), sec_conform=0) 
#     return 1