from django.db.models import fields
from rest_framework import serializers
from .models import productionviewmaster

class pvmasterserializer(serializers.ModelSerializer):
    class Meta:
        model = productionviewmaster
        fields = ('date', 'Machinename', 'Mouldname', 'shift1actual', 'shift1target', 'shift2actual', 'shift2target', 'shift3actual', 'shift3target')

# class MoldcountSerializers(serializers.ModelSerializer):
#     class Meta:
#         model = Moldcount
#         fields = ('Mouldname', 'moldcount')

# class shiftstatusSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = shiftstatus
#         fields = ('Machinename',  'shift1total', 'shift2total', 'shift3total', 'shift1target', 'shift2target', 'shift3target')