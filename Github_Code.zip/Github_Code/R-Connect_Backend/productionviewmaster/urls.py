from django.urls import path
from .import views

urlpatterns = [
    path('productionviewdata/', views.data, name="productionviewmaster"),
    # path('chartdata/', views.chart, name="molddata"),
    path('shiftwisechart/', views.chart, name="molddata"),
    # path('overallchart/', views.overallchart, name="molddata"),
]