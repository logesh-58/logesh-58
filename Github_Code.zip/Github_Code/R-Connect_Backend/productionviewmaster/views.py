from productiontable.models import ProductionTable
from django.db.models.aggregates import Sum
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from .models import productionviewmaster, Moldcount
from shiftmanagement.models import ShiftTimings
from .serializers import pvmasterserializer
import json
import datetime
from datetime import timedelta
from machinemanagement.models import AddMachine
from celery.schedules import crontab
from  celery import shared_task
#from celery.decorators import periodic_task
from mouldmanagement.models import Mouldmodel

# Create your views here.
# @periodic_task(run_every=(crontab(minute='*/1')))
def productionview():
    Plantname = 'ROBIS'
    today = datetime.datetime.now()
    prev7day = today.date() - datetime.timedelta(weeks=1)
    today_date = today.strftime('%Y-%m-%d')
    time_now = today.strftime('%H:%M:%S')
    time_now = datetime.datetime.strptime(time_now, '%H:%M:%S')
    time_now = str(((time_now) - datetime.timedelta(seconds = time_now.second)).time())
    prevdate = today.date() - datetime.timedelta(days=1)
    prev_date = prevdate.strftime('%Y-%m-%d')   
    nextdate = today + datetime.timedelta(days=1)
    nxtdt = nextdate.strftime('%Y-%m-%d')
    updated_date = ''
    # -------------------------------------------------------------------------------------
    shift1starttime = datetime.datetime.now()
    shift2starttime = datetime.datetime.now()
    shift3starttime = datetime.datetime.now()

    shiftstarttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift2start', 'shift3start', 'shift1end', 'shift2end', 'shift3end')

    for i in shiftstarttime:
        shift1starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift1start']) + datetime.timedelta(seconds = 1)).time() 
        shift2starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift2start']) + datetime.timedelta(seconds = 1)).time() 
        shift3starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift3start']) + datetime.timedelta(seconds = 1)).time() 
        shift1endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift1end']) - datetime.timedelta(seconds = 1)).time()
        shift2endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift2end']) - datetime.timedelta(seconds = 1)).time()
        shift3endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), i['shift3end']) - datetime.timedelta(seconds = 1)).time()
 
    # -------------------------------------------------------------------------------------
    getmasterdatamachines = ProductionTable.objects.filter(date=today_date, Plantname = Plantname, ProductionCountActual__gte = 1,).values('Machinename', 'Mouldname_id').distinct()
    # print(getmasterdatamachines)
    MachineState = -1
    for i in getmasterdatamachines:
        Machinename = i['Machinename']
        Mouldname_id = i['Mouldname_id']
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
        Mouldname = ''
        for i in Mouldname_data:
            Mouldname = i['Mouldname']
            print(mouldname)       
        
        
        if(today.hour >= shift1starttime.hour):
            updated_date = today_date
        else:
            updated_date = prev_date
        getlasttime = ''
        if(productionviewmaster.objects.filter(date=updated_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).exists()):
            getlasttime = productionviewmaster.objects.filter(date=updated_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('time') 
            for i in getlasttime:
                getlasttime = i['time']
                #print(getlasttime)
                getlasttime = datetime.datetime.strptime(getlasttime, '%H:%M:%S')
                getlasttime = ((getlasttime) - datetime.timedelta(seconds = getlasttime.second)).time()
        else:
            getlasttime = str(shift1starttime)
            getlasttime = datetime.datetime.strptime(getlasttime, '%H:%M:%S')
            getlasttime = ((getlasttime) - datetime.timedelta(seconds = getlasttime.second)).time()
        # print('Last time & Now time = ', getlasttime, time_now)

        if(Machinename=='FM660T' or Machinename=='KM3200T'):
            MachineState = 0
        else:
            MachineState = 1
        getalldatas = ProductionTable.objects.filter(date=today_date, time__range = (getlasttime, time_now), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = MachineState).values('time')
        getalldatascount = ProductionTable.objects.filter(date=today_date, time__range = (getlasttime, time_now), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = MachineState).count()
        # print('All datas count =', getalldatascount)
        
        for j in getalldatas:
            time = j['time']
            try:
                time = datetime.datetime.strptime(time, '%H:%M:%S').time()
            except:
                continue
            #check if data is logged in shift1
            if(str(time) >= str(shift1starttime) and str(time) <= str(shift1endtime)):
                shift1actual = 0
                s1actual = 0
                getdata = productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('shift1actual')
                for i in getdata:
                    s1actual = i['shift1actual']
                shift1actual = s1actual + 1
                ps1s = 0
                # gettargetcount = ProductionTable.objects.filter(date=today_date, time__range = (shift1starttime, shift1endtime), Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname).values('ProductionCountSet').distinct()
                # for i in gettargetcount:
                #     ps1s = ps1s + i['ProductionCountSet']
                setvalue = ShiftProductiondata.objects.filter(Plantname = Plantname, sdate = today_date, sMachinename = Machinename).values('sMouldname', 's1set')
                for value in setvalue:
                    sMouldname = value['sMouldname']
                    ssetvalue = value['s1set']
                    if(sMouldname == Mouldname):
                        ps1s = ssetvalue
                if(productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).exists()):
                    productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename,
                                Mouldname = Mouldname).update(shift1actual = shift1actual, shift1target = int(ps1s), time = time_now)
                else:
                    shift1actual = 1
                    shift_input = 'Shift-I'
                    instance = productionviewmaster(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname, shift1actual = shift1actual, shift2actual= 0, shift3actual= 0, 
                                                    shift1target = int(ps1s), shift2target = 0, shift3target = 0, shift = shift_input, time = time_now)
                    instance.save()
            #check if data is logged in shift2
            elif(str(time) >= str(shift2starttime) and str(time) <= str(shift2endtime)):
                shift2actual = 0; s2actual = 0
                getdata = productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('shift2actual')
                for i in getdata:
                    s2actual = i['shift2actual']
                shift2actual = s2actual + 1
                ps2s = 0
                # gettargetcount = ProductionTable.objects.filter(date=today_date, time__range = (shift2starttime, shift2endtime), Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname).values('ProductionCountSet').distinct()
                # for i in gettargetcount:
                #     ps2s = ps2s + i['ProductionCountSet']
                setvalue = ShiftProductiondata.objects.filter(Plantname = Plantname, sdate = today_date, sMachinename = Machinename).values('sMouldname', 's2set')
                for value in setvalue:
                    sMouldname = value['sMouldname']
                    ssetvalue = value['s2set']
                    if(sMouldname == Mouldname):
                        ps2s = ssetvalue
                if(productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).exists()):
                    productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename,
                        Mouldname = Mouldname).update(shift2actual = shift2actual, shift2target = int(ps2s), time = time_now)
                else:
                    shift2actual = 1
                    shift_input = 'Shift-II'
                    instance = productionviewmaster(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname, shift1actual = 0, shift2actual= shift2actual, shift3actual= 0, 
                                                    shift1target = 0, shift2target = int(ps2s), shift3target = 0, shift = shift_input, time = time_now)
                    instance.save()
            #check if data is logged in shift3   
            elif(str(time) >= str(shift3starttime)):
                shift3actual = 0
                s3actual = 0
                getdata = productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('shift3actual')
                for i in getdata:
                    s3actual = i['shift3actual']
                shift3actual = s3actual + 1
                ps3s = 0
                # gettargetcount = ProductionTable.objects.filter(date=today_date, time__gte = (shift3starttime), Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname).values('ProductionCountSet').distinct()
                # for i in gettargetcount:
                #     ps3s = ps3s + i['ProductionCountSet']
                setvalue = ShiftProductiondata.objects.filter(Plantname = Plantname, sdate = today_date, sMachinename = Machinename).values('sMouldname', 's3set')
                for value in setvalue:
                    sMouldname = value['sMouldname']
                    ssetvalue = value['s3set']
                    if(sMouldname == Mouldname):
                        ps3s = ssetvalue
                if(productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).exists()):
                    productionviewmaster.objects.filter(date=today_date, Plantname = Plantname, Machinename = Machinename,
                                                Mouldname = Mouldname).update(shift3actual = shift3actual, shift3target = int(ps3s), time = time_now)
                else:
                    shift3actual = 1
                    shift_input = 'Shift-III'
                    instance = productionviewmaster(date=today_date, Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname, shift1actual = 0, shift2actual= 0, shift3actual= shift3actual, 
                                                    shift1target = 0, shift2target = 0, shift3target = int(ps3s), shift = shift_input, time = time_now)
                    instance.save()
            #check if data is logged in previous day shift3   
            else:
                ps3s = 0
                s3actual = 0
                shift3actual = 0
                # gettargetcount = ProductionTable.objects.filter(date=today_date, time__lte = (shift3endtime), Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname).values('ProductionCountSet').distinct()
                # for i in gettargetcount:
                #     ps3s = ps3s + i['ProductionCountSet']
                setvalue = ShiftProductiondata.objects.filter(Plantname = Plantname, sdate = prev_date, sMachinename = Machinename).values('sMouldname', 's3set')
                for value in setvalue:
                    sMouldname = value['sMouldname']
                    ssetvalue = value['s3set']
                    if(sMouldname == Mouldname):
                        ps3s = ssetvalue
                if(productionviewmaster.objects.filter(date=prev_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).exists()):
                    getdata = productionviewmaster.objects.filter(date=prev_date, Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('shift3actual')
                    for i in getdata:
                        s3actual = i['shift3actual']
                    shift3actual = s3actual + 1
                    # getmachines = ProductionTable.objects.filter(date=today_date, time__lte = (shift3endtime), Plantname = Plantname).values('Machinename', 'Mouldname').distinct()
                    # pds3s = 0
                    # for i in getmachines:
                    #     Machinename = i['Machinename']
                    #     Mouldname = i['Mouldname']
                    #     getpdtargetcount = ProductionTable.objects.filter(date=today_date, time__lte = (shift3endtime), Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname).values('ProductionCountSet').distinct()
                    #     for i in getpdtargetcount:
                    #         pds3s = pds3s + i['ProductionCountSet']
                    # targetcount=  pds3s + ps3s
                    productionviewmaster.objects.filter(date=prev_date, Plantname = Plantname, 
                                            Machinename = Machinename, Mouldname = Mouldname).update(shift3actual = shift3actual, shift3target = int(ps3s), time = time_now)
                else:       
                    shift3actual = 1                 
                    shift_input = 'Shift-III'
                    instance = productionviewmaster(date=prev_date, Plantname = Plantname, Machinename = Machinename, Mouldname= Mouldname, shift1actual = 0, shift2actual= 0, shift3actual= shift3actual, 
                                                    shift1target = 0, shift2target = 0, shift3target = int(ps3s), shift = shift_input, time = time_now)
                    instance.save()
    # -------------------------------------------------------------------------------------
    #Get mold count for cards
    MachineState = -1
    if(today.hour >= shift1starttime.hour):
        updated_date = today_date
    else:
        updated_date = prev_date
    #print('COunting mold ...')
    allmachines = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
    getmolds = ProductionTable.objects.filter(date=updated_date, Plantname = Plantname, ProductionCountActual__gte = 1, MachineState__gt = MachineState).values('Mouldname_id').distinct()
    #print(getmolds)
    moldarray = []
    for i in getmolds:
        Mouldname_id = i['Mouldname_id']
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
        mouldname = ''
        for i in Mouldname_data:
            Mouldname = i['Mouldname']
            print(mouldname)
                
        getcount = 0
        for i in allmachines:
            machine = i['amMachinename']
            if(machine=='FM660T' or machine=='KM3200T'):
                MachineState = 0
            else:
                MachineState = 1
            getcount = getcount + (ProductionTable.objects.filter(date = updated_date,  time__range = (shift1starttime, time_now), Mouldname=Mouldname, Plantname = Plantname, Machinename = machine, MachineState__gt = MachineState, ProductionCountActual__gte = 1).count())
            if(Moldcount.objects.filter(date = updated_date, Mouldname = Mouldname, Plantname = Plantname).exists()):
                Moldcount.objects.filter(date = updated_date, Mouldname = Mouldname, Plantname = Plantname).update(moldcount = getcount)
            else:
                # getcount = 1
                moldinstance = Moldcount(date = updated_date, Mouldname = Mouldname, Plantname = Plantname, moldcount = getcount)
                moldinstance.save()
        mydict = {'Mouldname':Mouldname, 'moldcount':getcount}
        #print(mydict)
        # moldarray.append(mydict)

#Create your views here.
@csrf_exempt
def data(request):
    if request.method == 'GET':
        # productionview()
        Plantname = request.GET['Plantname']
        print(Plantname)
        today = datetime.datetime.now()
        prev7day = today.date() - datetime.timedelta(weeks=1)
        today_date = today.strftime('%Y-%m-%d')
        time_now = today.strftime('%H:%M:%S')
        time_now = datetime.datetime.strptime(time_now, '%H:%M:%S')
        time_now = str(((time_now) - datetime.timedelta(seconds = time_now.second)).time())
        prevdate = today.date() - datetime.timedelta(days=1)
        prev_date = prevdate.strftime('%Y-%m-%d')   
        nextdate = today + datetime.timedelta(days=1)
        nxtdt = nextdate.strftime('%Y-%m-%d')
        # -------------------------------------------------------------------------------------
        shift1_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        shift2_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift2start')
        shift3_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift3start') 
        
        for i in shift1_starttime:
            shift1starttime = i['shift1start']
        for i in shift2_starttime:
            shift2starttime = i['shift2start']
        for i in shift3_starttime:
            shift3starttime = i['shift3start']

        shift1endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift1starttime) + datetime.timedelta(hours = 7, minutes=59, seconds = 59)).time() 
        shift2endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift2starttime) + datetime.timedelta(hours = 7, minutes=59, seconds = 59)).time() 
        shift3endtime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift3starttime) + datetime.timedelta(hours = 7, minutes=59, seconds = 59)).time() 

        shift1starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift1starttime) + datetime.timedelta(seconds = 1)).time() 
        shift2starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift2starttime) + datetime.timedelta(seconds = 1)).time() 
        shift3starttime = (datetime.datetime.combine(datetime.date(1, 1, 1), shift3starttime) + datetime.timedelta(seconds = 1)).time() 

        # print('Start time2 = ', shift1starttime, shift2starttime, shift3starttime)
        # print('End time2 = ', shift1endtime, shift2endtime, shift3endtime)  
        
        #table data
        # print('Updated date = ', updated_date)
        if(today.hour >= shift1starttime.hour):
            updated_date = today_date
        else:
            updated_date = prev_date
        prev7day = (datetime.datetime.strftime(prev7day, '%Y-%m-%d'))
        today    = (datetime.datetime.strftime(today, '%Y-%m-%d'))
        # print(prev7day, today)
        pvdata = productionviewmaster.objects.filter(date__range = (prev7day, today), Plantname=Plantname).all().order_by('date')
        pvdataserial = pvmasterserializer(pvdata, many=True)
        #chartdata
        pvdatachart = productionviewmaster.objects.filter(date=updated_date, Plantname=Plantname).all().order_by('Machinename')
        pvdataserialchart = pvmasterserializer(pvdatachart, many=True)
        # print(pvdataserialchart.data)
        #get key vlaues from chart data
        data_ = (list(pvdataserialchart.data))
        try:
            columns = list(data_[0].keys())
            for i in range(len(columns)):
                columns[i] = columns[i].upper()
        except:
            columns = []
        #overallchartdata
        getmachines = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
        # print(getmachines)
        data = []
        molddict = {}
        for i in getmachines:
            machine = i['amMachinename']
            if(productionviewmaster.objects.filter(Plantname = Plantname, Machinename = machine).exists()):
                getmold = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine).values('Mouldname_id').distinct()
                # print(machine, getmold)
                molddata_array = []                
                for i in getmold:
                    Mouldname_id = i['Mouldname_id']
                    Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
                    mouldname = ''
                    for i in Mouldname_data:
                        Mouldname = i['Mouldname']    
                    
                    
                    s1sum = 0; s2sum = 0; s3sum = 0; s1set = 0; s2set = 0; s3set = 0; 
                    gets1act = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift1actual'))
                    gets2act = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift2actual'))
                    gets3act = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift3actual'))
                    s1sum = gets1act['shift1actual__sum']
                    s2sum = gets2act['shift2actual__sum']
                    s3sum = gets3act['shift3actual__sum']
                    actualcount = (int(s1sum) + int(s2sum) + int(s3sum))
                    gets1set = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift1target'))
                    gets2set = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift2target'))
                    gets3set = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = machine, Mouldname = mold).aggregate(Sum('shift3target'))
                    s1set = gets1set['shift1target__sum']
                    s2set = gets2set['shift2target__sum']
                    s3set = gets3set['shift3target__sum']
                    actualcount = (int(s1sum) + int(s2sum) + int(s3sum))
                    targetcount = (int(s1set) + int(s2set) + int(s3set))
                    molddict = {'Mouldname':mold, 'actualcount':actualcount, 'targetcount': targetcount}
                    # print(molddict)
                    molddata_array.append(molddict)
                mydictall = {'Machinename': machine, 'molddata':molddata_array}
                data.append(mydictall)
        # print(data)
        #Get mold count for cards

        getmolds = Moldcount.objects.filter(date = updated_date, Plantname = Plantname).values('Mouldname_id', 'moldcount')
        moldarray = []
        for i in getmolds:
            Mouldname = i['Mouldname']
            Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values(Mouldname)
            Mouldname = ''
            for i in  Mouldname_data:
                Mouldname = i['mouldname']
                print(Mouldname)
            getcount = i['moldcount']
            if(getcount):
                mydict = {'Mouldname':Mouldname, 'moldcount':getcount}
                # print(mydict)
                moldarray.append(mydict)
        # print(pvdataserialallchart.data)
        
        #append moldcount, table, chart and overall chart data's into custom dictionary
        data_dict = {'molddata' : moldarray, 'tabledata': pvdataserial.data, 'columns':columns, 'overallchart': data}
        # print(data_dict)
        return JsonResponse(data_dict, safe=False)

@csrf_exempt
def chart(request):
    if request.method == 'POST':
        # print(request.body);
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        Machinename = httpdata['Machinename']
        # print(httpdata, Machinename)
        today = datetime.datetime.now()
        predate = today - datetime.timedelta(days=1)
        today_date = today.strftime('%Y-%m-%d')
        predate = predate.strftime('%Y-%m-%d')
        if(today.hour >= 6):
            updated_date = today_date
        else:
            updated_date = predate
        #chartdata
        pvdatachart = productionviewmaster.objects.filter(date=updated_date, Plantname=Plantname, Machinename = Machinename)
        pvdataserialchart = pvmasterserializer(pvdatachart, many=True)
        # print(pvdataserialchart.data)
        #get key vlaues from chart data
        data_ = (list(pvdataserialchart.data))
        # print(data_)
        getmolddata = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, Machinename = Machinename).values('Mouldname_id')
        # print(getmolddata)
        data = []
        dataArray = []
        for i in getmolddata:
            Mouldname_id = i['Mouldname_id']
            Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
            moldname = ''
            for i in Mouldname_data:
                Mouldname = i['Mouldname']            
            getdata = productionviewmaster.objects.filter(date = updated_date, Plantname = Plantname, 
                                        Machinename = Machinename, Mouldname= Mouldname).values('shift1actual','shift1target','shift2actual','shift2target','shift3actual','shift3target')
            print(getdata)
            for i in getdata:
                shift1actual = i['shift1actual']
                shift2actual = i['shift2actual']
                shift3actual = i['shift3actual']
                shift1target = i['shift1target']
                shift2target = i['shift2target']
                shift3target = i['shift3target']
                dict = {'Mouldname':Mouldname, 'shift1actual': shift1actual, 'shift2actual': shift2actual, 'shift3actual': shift3actual, 
                                'shift1target': shift1target, 'shift2target': shift2target, 'shift3target': shift3target}
                dataArray.append(dict)
        print(dataArray)
        mydict = {'Machinename': Machinename, 'molddata': dataArray}
        print(mydict)
        data.append(mydict)
        print(data)
        return JsonResponse(data, safe=False)