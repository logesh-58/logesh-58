from django.urls import path
from dailyreport import new_views

urlpatterns=[
    path('dalilyreport/', new_views.data, name="productiondata"), # get particular event data
]
