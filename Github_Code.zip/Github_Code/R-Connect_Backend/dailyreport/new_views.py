from django.shortcuts import render
from email.mime.base import MIMEBase
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
from django_celery_beat.models import PeriodicTask, CrontabSchedule
import json
from django.core.mail import EmailMessage
import smtplib
import math
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from django.db.models.aggregates import Sum
from datetime import datetime, time, timedelta, date

import os   
from RConnect.settings import BASE_DIR
from shiftmanagement.models import ShiftTimings
import xlwt
from timeline.models import breakdown, badpart, timeline
from productiontable.serializers import ProductionTableSerializers
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from django.db.models import Q
from mouldmanagement.models import Mouldmodel
# Create your views here.

@csrf_exempt
def data(request):
    if(request.method == 'POST'):
        Plantname = request.GET['Plantname']
        
        currentdate = datetime.strptime(json.loads(request.body)['date'], "%Y-%m-%d").date()

        # Calculate the next date using timedelta
        nextdate = (currentdate + timedelta(days=1)).strftime('%Y-%m-%d')

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()

        # Extracting shift timings as strings (converted from time objects)
        shift_starttime_str = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        shift_endtime_str = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        MachinenamesArray = machineArray(Plantname)

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=currentdate, time__gte=shift_starttime_str) |
                    Q(date=nextdate, time__lte=shift_endtime_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename', 'time', 'date', 'ProductionCountActual', 'Mouldname_id','CycletimeSet', 'CycletimeActual', 'Cavity', 'ProductionTimeTotal', 'ProductionCountSet').order_by('id')

        all_RejectionParts_cal = badpart.objects.filter(
            Q(date=currentdate, time__gte=shift_starttime_str) |
            Q(date=nextdate, time__lte=shift_endtime_str),
            Plantname=Plantname,
            partcount__gt=0,
            Machinename__in=MachinenamesArray
        ).values('Machinename', 'date', 'time', 'Cavity', 'Mouldname_id').order_by('id')

        all_breakdown_data = breakdown.objects.filter(
            Q(date=currentdate, time__gte=shift_starttime_str) |
            Q(date=nextdate, time__lte=shift_endtime_str),
            Machinename__in=MachinenamesArray,
            Plantname=Plantname
        ).values('Machinename', 'MachineState', 'time', 'date', 'Mouldname_id').order_by('id')

        # Directly assign time values without using strptime
        first_shift_start = shift_starttime['shift1start']
        first_shift_end = shift_starttime['shift1end']
        second_shift_start = shift_starttime['shift2start']
        second_shift_end = shift_starttime['shift2end']
        third_shift_start = shift_starttime['shift3start']
        third_shift_end = shift_starttime['shift3end']

        myarray   = []

        for machine in MachinenamesArray:

            distinctArray = list(set(p['Mouldname_id'] for p in all_dashboard_value if p['Machinename'] == machine))

            for mould in distinctArray:
                
                mouldname = Mouldmodel.objects.get(id = mould).Mouldname

                tracktime = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            p['Mouldname_id'] == mould
                        ]
                
                first_record = tracktime[0]
                last_record = tracktime[-1]

                mfirst_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                mlast_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                ProductionTimeActual_minute = ((datetime.combine(last_date, mlast_time) - datetime.combine(first_date, mfirst_time)).total_seconds()) / 60

    ##################################################################
                # List to store shifts
                shifts = []
                
                for time in (mfirst_time, mlast_time):
                    # Determine the company shift
                    if first_shift_start <= time <= first_shift_end:
                        shift = 'A'
                    elif second_shift_start <= time <= second_shift_end:
                        shift = 'B'
                    elif time >= third_shift_start or time <= third_shift_end:
                        shift = 'C'
                    else:
                        shift = 0  # Set to 0 if it doesn’t match any shift

                    # Append shift to the list
                    shifts.append(shift)

                if shifts == ['A', 'C']:
                    shifts = ['A', 'B', 'C']
                else:
                    shifts = shifts

    ##################################################################

                Cycletime_Set = first_record['CycletimeSet']

                total_cycle_time = sum(p['CycletimeActual'] for p in tracktime) if tracktime else 0

                lengthavg = sum(p['Cavity'] for p in tracktime) if tracktime else 0

                avg_cycle = total_cycle_time/lengthavg

                recommanded_cycle = math.ceil(avg_cycle / 5) * 5

                mac_counts = first_record['ProductionCountSet']

                mac_minutes = first_record['ProductionTimeTotal']

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == machine and
                            e['Mouldname_id'] == mould
                        ]
                RejectionParts = sum(p['Cavity'] for p in RejectionParts_cal) if RejectionParts_cal else 0

                saw = [k for k in all_breakdown_data if
                            k['Machinename'] == machine and
                            k['Mouldname_id'] == mould
                            and mfirst_time <= datetime.strptime(k['time'], "%H:%M:%S").time() <= mlast_time
                        ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None

                total_idle_minutes = total_idle_time / 60

                good_parts = lengthavg - RejectionParts

                total_ProductionTimeActual_minutes = ProductionTimeActual_minute - total_idle_minutes
                availability = (float(total_ProductionTimeActual_minutes) / float(mac_minutes)) * 100 if mac_minutes != 0 else 0
                quality = (abs(lengthavg - RejectionParts) / lengthavg) * 100 if lengthavg != 0 else 0
                performance = (lengthavg / mac_counts) * 100 if mac_counts != 0 else 0
                oee = (availability / 100) * (performance / 100) * (quality / 100) * 100

                #--------------------Append With Dictionary ---------------------------------------
                mydict = {  
                            'Machinename'                   : machine, 
                            'Mouldname'                     : mouldname,
                            'Shift'                         : shifts,
                            'Starttime'                    : mfirst_time,
                            'Endtime'                      : mlast_time, 
                            'Cycletime_Set'           : Cycletime_Set,
                            'Cycletime_Actual'       : round(avg_cycle,2),
                            'Recommended_cycleTime'         : recommanded_cycle,
                            'Productiontime_Set'      : round(mac_minutes, 1),
                            'Productiontime_Actual'   : round(ProductionTimeActual_minute, 1),
                            'ProductionCount_Set'           : mac_counts,
                            'ProductionCount_Actual'        : int(lengthavg),
                            'RejectionParts'                      : RejectionParts,
                            'MachineIdletime'         : round(total_idle_minutes, 1),
                            'Actual_runtime'          : round(total_ProductionTimeActual_minutes, 1),
                            'Total_runtime'           : round(mac_minutes, 1),
                            'ae'                        : round(availability,2),
                            'Target_production'             : mac_counts,
                            'Actual_production'             : lengthavg,
                            'pe'                        : round(performance,2),
                            'Good_parts'                    : good_parts,
                            'Produced_parts'                : lengthavg,
                            'qe'                        : round(quality,2),
                            'oee'                       : round(oee,2)
                            }
                myarray.append(mydict)

        if(myarray != []):
            return JsonResponse(myarray, safe=False)
        else:
            return JsonResponse('No data available', safe=False)
