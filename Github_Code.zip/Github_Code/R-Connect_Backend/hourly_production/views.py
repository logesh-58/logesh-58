# from celery import shared_task
from django.http import HttpResponse
import xlwt
from RConnect.settings import BASE_DIR
import os
from datetime import datetime , timedelta
from django.views.decorators.csrf import csrf_exempt
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from celery.schedules import crontab
# from celery.task import periodic_task
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
from celery.schedules import crontab
# from celery.task import periodic_task
from timeline.models import badpart 
from mouldmanagement.models import Mouldmodel 
from timeline.models import breakdown

@csrf_exempt
def report(request):
    now = datetime.now()
    work_book = xlwt.Workbook(encoding='utf-8')
    machinename_data = AddMachine.objects.values('amMachinename')
    for machine in machinename_data:
        work_sheet = work_book.add_sheet(machine['amMachinename'])
        work_sheet.show_grid = False
        style  = xlwt.XFStyle()
        style1 = xlwt.XFStyle()
        style2 = xlwt.XFStyle()
        style3 = xlwt.XFStyle()
        style_bold = xlwt.XFStyle()
        style_header = xlwt.XFStyle()
        style_bold2 = xlwt.XFStyle()
        #set alignment
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap      = 1
        style.alignment     = alignment
        style1.alignment    = alignment
        style2.alignment    = alignment
        style3.alignment    = alignment
        ######
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        style_bold.alignment = alignment
        style_header.alignment = alignment
        ######
        alignment_1       = xlwt.Alignment()
        alignment_1.horz  = xlwt.Alignment.HORZ_LEFT
        alignment_1.vert  = xlwt.Alignment.VERT_CENTER
        alignment_1.wrap      = 1
        style_bold2.alignment = alignment_1
        #Set Border
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style2.borders  = border
        style3.borders  = border
        ######
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style_bold.borders = border
        style_header.borders = border
        style_bold2.borders  = border
        #pattern
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
        style.pattern = pattern
        #Set Font Color
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['red']
        font.name = 'Times New Roman'
        font.bold = True
        font.height = 250
        style3.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'Times New Roman'
        font.bold = False
        font.height = 200
        style.font = font
        style1.font = font
        style2.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'Times New Roman'
        font.bold = True
        font.height = 200
        style_bold.font = font 
        style_bold2.font = font
        #############################  GETTING THE SHIFT_WISE DATA ############################
        shift_list = []; shift_int = []; shift_datetime = []
        current_date = datetime.now()
        nextday_date = current_date + timedelta(days=1)
        shift_data = ShiftTimings.objects.values().last() 
        shift1start = shift_data['shift1start']; shift1end   = shift_data['shift1end'] 
        shift2start = shift_data['shift2start']; shift2end   = shift_data['shift2end']
        shift3start = shift_data['shift3start']; shift3end   = shift_data['shift3end'] 
        ### STORED THE SHIFT DATETIME.TIME DATA'S INTO THE SHIFT_LIST
        shift_list.append(shift1start); shift_list.append(shift1end)
        shift_list.append(shift2start); shift_list.append(shift2end)
        shift_list.append(shift3start); shift_list.append(shift3end)
        ### CONVERT THE DATETIME.TIME TO INTEGER VALUE
        for string in shift_list:
            dttme_obj = datetime.strptime(str(string), "%H:%M:%S") 
            shift_int.append(int(dttme_obj.hour))
                    
        def Dummy():
            i = 0
            # print(len(shift_list))
            while i<len(shift_list):
                if shift_int[i] <= shift_int[i+1]:
                    datetime_objects_from = datetime.combine(current_date , shift_list[i])
                    datetime_objects_to   = datetime.combine(current_date , shift_list[i+1])
                    shift_datetime.append(datetime_objects_from)
                    shift_datetime.append(datetime_objects_to)
                else:
                    datetime_objects_from = datetime.combine(current_date , shift_list[i])
                    datetime_objects_to   = datetime.combine(nextday_date , shift_list[i+1])
                    shift_datetime.append(datetime_objects_from)
                    shift_datetime.append(datetime_objects_to)
                i+=2
        Dummy() 

        excel_map = []
        # Current Day
        date = current_date.date
        now_data = now.replace(second=0, microsecond= 0)
        #################### Hourly Reports ###################
        def hourly_report(shift_start, shift_end):
            ############################### HOURLY PRODUCTION REPORT ####################################
            for col_width in range(1, 13+1):
                work_sheet.col(col_width).width = 5000
            r=1
            c=1
            work_sheet.write_merge(r, r+1, c, c+11,('HOURLY PRODUCTION REPORT-INJECTION MOULDING-IMG'),style3)

            r=3
            c=1
            work_sheet.write_merge(r, r, c, c+1, ('DATE & SHIFT'),style_bold)

            r=4
            c=3
            work_sheet.write_merge(r+1, r+1, c+5, c+7,'DOWNTIME', style_bold)

            r=4
            c=1
            work_sheet.write_merge(r, r, c, c+1, ('PART NAME:'),style_bold)

            r=4
            c=7
            work_sheet.write_merge(r, r, c, c, ('TOOL NO'),style_bold)

            r=3
            c=9
            work_sheet.write_merge(r, r, c, c+1, ('CYCLE TIME'),style_bold)

            r=4
            c=9
            work_sheet.write_merge(r, r+0, c, c+1, ('TARGET/HOUR:'),style_bold)

            r=5
            c=1
            work_sheet.write_merge(r, r, c, c+1, ('TIME'),style_bold)

            r=6
            c=1
            work_sheet.write_merge(r, r, c, c, ('FROM'),style_bold)

            r=6
            c=2
            work_sheet.write_merge(r, r, c, c, ('TO'),style_bold)

            r=5
            c=3
            work_sheet.write_merge(r, r+1, c, c, ('COUNTER START'),style_bold)

            r=5
            c=4
            work_sheet.write_merge(r, r+1, c, c, ('COUNTER END'),style_bold)

            r=5
            c=5
            work_sheet.write_merge(r, r+1, c, c, ('TOTAL SHOTS'),style_bold)

            r=5
            c=6
            work_sheet.write_merge(r, r+1, c, c, ('GOOD PARTS'),style_bold)

            r=5
            c=7
            work_sheet.write_merge(r, r+1, c, c, ('REJECTION PARTS'),style_bold)

            r=5
            c=11
            work_sheet.write_merge(r, r+1, c, c+1, ('Er./SETTER SIGN'),style_bold)

            r=6
            c=8
            work_sheet.write_merge(r, r+0, c, c+0, ('FROM'),style_bold)

            r=6
            c=9
            work_sheet.write_merge(r, r+0, c, c, ('TO'),style_bold)

            r=6
            c=10
            work_sheet.write_merge(r, r+0, c, c, ('REASON'),style_bold) 

            work_sheet.write_merge(3, 3, 7, 8, None, style_bold)
            work_sheet.write(4, 8, None,style_bold)
            work_sheet.write_merge(4, 4, 11, 12, None, style_bold)
            mould_name = []; cycle_time = []; mould_cycle = []; break_down = []
            shift_to = shift_start 
            date = shift_to.date()
            while shift_to < shift_end:
                shift_from = shift_to  
                # print('shift_from :', shift_from)
                shift_to += timedelta(hours=1) 
                # print('shift_to :', shift_to)
                str_shift_from = datetime.strftime(shift_from, "%H:%M:%S") 
                str_shift_to   = datetime.strftime((shift_to - timedelta(seconds=1)), "%H:%M:%S") 
                if date == datetime.today().date and str_shift_from == '06:00:00':
                    str_shift_from = "06:00:01"
                if str_shift_from  == '00:00:00':
                    date = (datetime.today() + timedelta(days=1)).date
                if date == (datetime.today() + timedelta(days=1) ).date and str_shift_to == '05:59:59':
                    str_shift_to = "06:00:00"
                # print(date, str_shift_from, str_shift_to)
                shift_data  = ProductionTable.objects.filter(date = date , Machinename = machine['amMachinename'], 
                                                            time__range = [str_shift_from, str_shift_to]).values('date', 'time', 'ProductionCountActual','RejectionParts', 'Mouldname_id', 'CycletimeSet').order_by('id')
                break_down_shift = breakdown.objects.filter(date = date, Machinename = machine['amMachinename'], time__range = [str_shift_from, str_shift_to]).values('time', 'MachineState', 'primaryreason').order_by('id')
                for break_data in break_down_shift:
                    break_down.append(break_data)
                if shift_data != []:
                    for mould_data in shift_data:
                        if mould_name != [] and cycle_time != [] and mould_cycle != []:
                            if  mould_data['Mouldname_id'] in mould_name and mould_data['CycletimeSet'] in cycle_time:
                                pass
                            else:
                                mould_name.append(mould_data['Mouldname_id'])
                                cycle_time.append(round(mould_data['CycletimeSet'], 0)) 
                                mould_cycle.append({"mould_id":mould_data['Mouldname_id'], "cycle_time":round(mould_data['CycletimeSet'], 0)})
                        else:
                            mould_name.append(mould_data['Mouldname_id']) 
                            cycle_time.append(round(mould_data['CycletimeSet'], 0)) 
                            mould_cycle.append({"mould_id":mould_data['Mouldname_id'], "cycle_time":round(mould_data['CycletimeSet'], 0)})
                    for x in range(0, len(shift_data),1):
                        if x == 0:
                            excel_map.append({"from_time":shift_data[x]['time'], "count_start":shift_data[x]['ProductionCountActual'], "rejection":shift_data[x]['RejectionParts']})
                        try:
                            val_1 = shift_data[x]['ProductionCountActual'] ; val_2 = shift_data[x+1]['ProductionCountActual']
                            if val_2 >= val_1:
                                pass 
                            else:
                                excel_map.append({"to_time":shift_data[x]['time'], "count_end":shift_data[x]['ProductionCountActual'] , "rejection":shift_data[x]['RejectionParts']})
                                excel_map.append({"from_time":shift_data[x+1]['time'], "count_start":shift_data[x+1]['ProductionCountActual'], "rejection":shift_data[x+1]['RejectionParts']})
                        except:
                            pass
                        if x == len(shift_data)-1:
                            excel_map.append({"to_time":shift_data[x]['time'] , "count_end":shift_data[x]['ProductionCountActual'], "rejection":shift_data[x]['RejectionParts']})
            # print(machine['amMachinename'], mould_name, cycle_time)
        
            mould_name_ = []
            for mn in mould_cycle:
                mould_name_.append(Mouldmodel.objects.get(id = mn['mould_id'] ).Mouldname) 
            cycle_time_ = []
            for mn in mould_cycle:
                cycle_time_.append( str(mn['cycle_time'])) 
            work_sheet.write_merge(4,4,3,6,'  ,  '.join(mould_name_), style_bold)  
            work_sheet.write_merge(3,3,11,12,'  ,  '.join(cycle_time_), style_bold)
            row = 7
            col = 1
            rejection_count = 0; total_count_start = 0; total_count_end = 0; total_count_shots = 0; total_good_parts = 0; total_rejection_count = 0
            for map in range(0, len(excel_map), 2):
                # print(excel_map[map], excel_map[map+1], excel_map[map+2])
                for keys_1,keys_2 in zip(excel_map[map],excel_map[map+1]):
                    if keys_1 == 'from_time':
                        # print("data_get_it")
                        work_sheet.write(row, col, excel_map[map]['from_time'], style1) 
                    if keys_1 == 'count_start':
                        total_count_start = excel_map[map]['count_start'] + total_count_start
                        work_sheet.write(row, col+2, excel_map[map]['count_start'], style1) 
                    #    total_cs = excel_map[map]['count_start']
                # for keys in excel_map[map+1]:
                    if keys_2 == 'to_time':
                        work_sheet.write(row, col+1, excel_map[map+1]['to_time'], style1)
                    if keys_2 == 'count_end':
                        total_count_end = excel_map[map+1]['count_end'] + total_count_end
                        work_sheet.write(row, col+3, excel_map[map+1]['count_end'], style1) 
                    #    total_ce = excel_map[map]['count_end']
                        rejection_end = excel_map[map+1]['rejection']
                        global total_rejection
                        total_rejection = abs(rejection_end - rejection_count)
                    #    work_sheet.write(row, col+5, total_rejection, style1)
                        rejection_count = total_rejection
                total_count = excel_map[map+1]['count_end'] - excel_map[map]['count_start'] 
                total_count_shots = total_count_shots + total_count
                total_rejection_count = total_rejection + total_rejection_count
                work_sheet.write(row, col+6, total_rejection, style1)
                good_parts = total_count - total_rejection 
                total_good_parts = good_parts + total_good_parts
                work_sheet.write(row, col+4, total_count, style1)
                work_sheet.write(row, col+5, good_parts, style1)
                row += 1 
            work_sheet.write(row, col+2, total_count_start, style_bold)
            work_sheet.write(row, col+3, total_count_end, style_bold)
            work_sheet.write(row, col+4, total_count_shots, style_bold)
            work_sheet.write(row, col+5, total_good_parts, style_bold)
            work_sheet.write(row, col+6, total_rejection_count, style_bold)
            ################### Values are Not there ###############################
            r_none = row +1
            for r in range(r_none, r_none+3):
                for c in range(3,7):
                    work_sheet.write(r, c, None, style_bold)
            for c in range(1,7):
                work_sheet.write(r_none+3, c, None, style_bold)
            for r in range(r_none+4, row+8):
                for c in range(3,9):
                    work_sheet.write(r, c, None, style_bold)
            r_none = row
            for r in range(7,r_none+1):
                for c in range(8,13):
                    work_sheet.write(r, c, None, style_bold)
            for r in range(r_none+1, r_none+5):
                for c in range(12,13):
                    work_sheet.write(r, c, None, style_bold)
            for r in range(r_none+5, r_none+8):
                for c in range(11,13):
                    work_sheet.write(r, c, None, style_bold)
            for r in range(r_none+1, r_none+5):
                for c in range(9,12):
                    work_sheet.write(r, c, None, style_bold)        
            ##############################################################################################################################
            r = row
            c = 1
            for data in ['TOTAL', 'PART WT.', 'RUNNER WT.', 'SHOT WT.','Raw Material Name','Grade','Batch No','LUMPS WT.','TOTAL RUNNER WT','TOTAL RUN HOURS','TOTAL DOWN HOURS']:
                if data != 'Raw Material Name' and data != 'Grade' and data != 'Batch No' and data != 'TOTAL RUNNER WT' and data != 'LUMPS WT.' and data != 'TOTAL RUN HOURS' and data != 'TOTAL DOWN HOURS':
                    work_sheet.write_merge(r, r, c, c+1, data , style_bold2)
                elif data != 'TOTAL' and data != 'PART WT.' and data != 'SHOT WT.'and data != 'RUNNER WT.' and data != 'TOTAL RUNNER WT' and data != 'LUMPS WT.' and data != 'TOTAL RUN HOURS' and data != 'TOTAL DOWN HOURS':
                    work_sheet.write_merge(r+1, r+1, c, c+1, data, style_bold2)
                elif data != 'TOTAL'and data != 'PART WT.'and data != 'RUNNER WT.' and data != 'SHOT WT.' and data != 'Raw Material Name' and data!= 'Grade' and data != 'Batch No':
                    c=7
                    work_sheet.write_merge(r-6, r-6, c, c+1, data, style_bold2)  
                    # work_sheet.write(r, c, None, style_bold)
                r += 1
            r = row + 5
            c = 9
            for data in ['Operator Name/Id No', 'Signature', 'Shift. Engr., Sign']:
                work_sheet.write_merge(r, r, c, c+1, data, style_bold2)
                r += 1
            # row length
            for row_width in range(1, r):
                work_sheet.row(row_width).height_mismatch = True
                work_sheet.row(row_width).height = 380
            return r, break_down
        ########################################## REJECTION REPORTS ###########################################
        def rejection_report(row_value, break_down, start, end):
            style  = xlwt.XFStyle()
            style1 = xlwt.XFStyle()
            style2 = xlwt.XFStyle()
            style3 = xlwt.XFStyle()
            # set alignment
            alignment       = xlwt.Alignment()
            alignment.horz  = xlwt.Alignment.HORZ_CENTER
            alignment.vert  = xlwt.Alignment.VERT_CENTER
            alignment.wrap      = 1
            style.alignment     = alignment
            style1.alignment    = alignment
            style2.alignment    = alignment
            style3.alignment    = alignment
            #Set Border
            border          = xlwt.Borders()
            border.left     = xlwt.Borders.THIN 
            border.right    = xlwt.Borders.THIN 
            border.top      = xlwt.Borders.THIN 
            border.bottom   = xlwt.Borders.THIN
            style1.borders  = border
            style2.borders  = border
            style3.borders  = border
            #style1
            pattern = xlwt.Pattern()
            pattern.pattern = xlwt.Pattern.SOLID_PATTERN
            pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
            style.pattern = pattern
            #Set Font Color
            font = xlwt.Font()
            font.colour_index=xlwt.Style.colour_map['red']
            font.name = 'Times New Roman'
            font.bold = True
            font.height = 250
            style3.font = font

            font = xlwt.Font()
            font.colour_index=xlwt.Style.colour_map['black']
            font.name = 'Times New Roman'
            font.bold = False
            font.height = 200
            style.font = font
            style1.font = font
            style2.font = font
            
            r= row_value + 1
            c=1
            work_sheet.row(r).height_mismatch = True
            work_sheet.row(r).height = 550
            work_sheet.write_merge(r, r, c, c+18,('REJECTION DETAILS'), style3)
            # Set Heading border
            header = ['DATE', 'TIME','SET UP','FLASH','SINK MARK','SILVER STREAKS','PIN MARK','SHORT FILL','BURN MARK','SCORING','BLACK MARK','WHITE MARK','JETTING\FLOW MARK','WELD LINES','SCRATCHES','SHINING','COLOUR MISMATCHING','OIL MARK','OTHERS']
            r=r+1
            c=1
            for i in header:
                work_sheet.row(r).height_mismatch = True
                work_sheet.row(r).height = 550
                if i == 'JETTING\FLOW MARK' or i == 'COLOUR MISMATCHING':
                   work_sheet.col(c).width = 6500
                else:
                    work_sheet.col(c).width = 5000
                work_sheet.write_merge(r, r+1, c, c, i,style_bold)
                c+=1
            # print(badpart.objects.values()) shift_start, shift_end
            rejectionparts = []
            hours = int(datetime.strftime(start, "%H")) 
            rejstart_time = datetime.strftime(start, '%H:%M:%S')  
            rejend_time   = datetime.strftime(end, '%H:%M:%S') 
            rejend_date = datetime.strftime(end, '%Y:%m:%d')  
            rejectionparts = badpart.objects.filter(date = rejend_date , time__gte = rejstart_time, time__lte = rejend_time, Machinename = machine['amMachinename']).values('date','time','reason').order_by('id')
            # print(rejectionparts)
            r = r+2
            c = 1
            count = 0
            count_1 = 0
            count_2 = 0
            count_3 = 0
            count_4 = 0
            count_5 = 0
            count_6 = 0
            count_7 = 0
            count_8 = 0
            count_9 = 0
            count_10 = 0
            count_11 = 0
            count_12 = 0
            count_13 = 0
            count_14 = 0
            count_15 = 0
            count_16 = 0
            count_17 = 0
            count_18 = 0
            
            if rejectionparts!= []:
                for rej in rejectionparts:
                    date = rej['date']
                    time = rej['time'] 
                    reason = rej['reason'] 
                    if reason == 1:
                        count = count +1
                        # work_sheet.write(r, reason+2,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+2,'-', style1)
                    if reason == 2:
                        count_1 = count_1 +1
                        # work_sheet.write(r, reason+3,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+3,'-', style1)
                    if reason == 3:
                        count_2 = count_2 +1
                        # work_sheet.write(r, reason+4,'1', style1)
                    # else:
                    #    work_sheet.write(r, reason+4,'-', style1)
                    if reason == 4:
                        count_3 = count_3 +1
                        # work_sheet.write(r, reason+5,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+5,'-', style1)
                    if reason == 5:
                        count_4 = count_4 +1
                        # work_sheet.write(r, reason+6,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+6,'-', style1)
                    if reason == 6:
                        count_5 = count_5 +1
                        # work_sheet.write(r, reason+7,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+7,'-', style1)    
                    if reason == 7:
                        count_6 = count_6 +1
                        # work_sheet.write(r, reason+8,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+8,'-', style1) 
                    if reason == 8:
                        count_7 = count_7 +1
                        # work_sheet.write(r, reason+9,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+9,'-', style1) 
                    if reason == 9:
                        count_8 = count_8 +1
                        # work_sheet.write(r, reason+10,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+10,'-', style1) 
                    if reason == 10:
                        count_9 = count_9 +1
                        # work_sheet.write(r, reason+11,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+11,'-', style1) 
                    if reason == 11:
                        count_10 = count_10 +1
                        # work_sheet.write(r, reason+12,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+12,'-', style1) 
                    if reason == 12:
                        count_11 = count_11 +1
                        # work_sheet.write(r, reason+13,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+13,'-', style1) 
                    if reason == 13:
                        count_12 = count_12 +1
                        # work_sheet.write(r, reason+14,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+14,'-', style1) 
                    if reason == 14:
                        count_13 = count_13 +1
                        # work_sheet.write(r, reason+15,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+15,'-', style1) 
                    if reason == 15:
                        count_14 = count_14 +1
                        # work_sheet.write(r, reason+16,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+16,'-', style1) 
                    if reason == 16:
                        count_15 = count_15 +1
                        # work_sheet.write(r, reason+17,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+17,'-', style1) 
                    if reason == 17:
                        count_16 = count_16 +1
                        # work_sheet.write(r, reason+2,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+18,'-', style1) 
                    if reason == 18:
                        count_17 = count_17 +1
                        # work_sheet.write(r, reason+2,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+19,'-', style1) 
                    if reason == 19:
                        count_18 = count_18 +1
                        # work_sheet.write(r, reason+2,'1', style1)
                    # else:
                        # work_sheet.write(r, reason+20,'-', style1) 
                    #    work_sheet.write(r,c,'1',style1)
                    work_sheet.write(r, c, (date), style1)
                    work_sheet.write(r, c+1, (time), style1)
                    # work_sheet.write(r, c+1, (time), style1)
                    for column in range(3, 20):
                        if(column == (reason+2)):
                            work_sheet.row(r).height_mismatch = True
                            work_sheet.row(r).height = 550
                            work_sheet.write(r, column, '1', style1)
                        else:
                            work_sheet.write(r, column, '-', style1)
                        column+=1
                    r = r+1
            work_sheet.row(r).height_mismatch = True
            work_sheet.row(r).height = 550
            work_sheet.write_merge(r, r, c, c+1, 'Total', style_bold)
            work_sheet.write(r,c+2, count, style_bold)
            work_sheet.write(r,c+3, count_1, style_bold)
            work_sheet.write(r,c+4, count_2, style_bold)
            work_sheet.write(r,c+5, count_3, style_bold)
            work_sheet.write(r,c+6, count_4, style_bold)
            work_sheet.write(r,c+7, count_5, style_bold)
            work_sheet.write(r,c+8, count_7, style_bold)
            work_sheet.write(r,c+9, count_8, style_bold)
            work_sheet.write(r,c+10, count_9, style_bold)
            work_sheet.write(r,c+11, count_10, style_bold)
            work_sheet.write(r,c+12, count_11, style_bold)
            work_sheet.write(r,c+13, count_12, style_bold)
            work_sheet.write(r,c+14, count_13, style_bold)
            work_sheet.write(r,c+15, count_14, style_bold)
            work_sheet.write(r,c+16, count_15, style_bold)
            work_sheet.write(r,c+17, count_16, style_bold)
            work_sheet.write(r,c+18, count_17, style_bold)
            row_ = r + 3 ; col = 1
            work_sheet.row(row_).height_mismatch = True
            work_sheet.row(row_).height = 550
            work_sheet.row(row_+1).height_mismatch = True
            work_sheet.row(row_+1).height = 550
            work_sheet.col(col).width   = 5000
            work_sheet.col(col+1).width = 5000
            work_sheet.col(col+2).width = 5000
            work_sheet.write_merge(row_, row_, col, col+2,'DOWNTIME', style_bold)
            work_sheet.write(row_+1, col, ('FROM'),style_bold)
            work_sheet.write(row_+1, col+1, ('TO'),style_bold)
            work_sheet.write(row_+1, col+2, ('REASON'),style_bold)
            # print(break_down)
            reasons_list = ['Maintenance', 'Robot Problem', 'Power Issue', 'Mould Change', 'Material Change', 'Tool Problem']
            for dat0 in range(0, len(break_down)):
                if break_down[dat0]['MachineState'] == 0:
                    if break_down[dat0-1]['MachineState'] !=0:
                        for dat1 in range(dat0, len(break_down)):
                            if break_down[dat1]['MachineState'] == 1:
                                work_sheet.row(row_+2).height_mismatch = True
                                work_sheet.row(row_+2).height = 550
                                work_sheet.col(col).width   = 5000
                                work_sheet.col(col+1).width = 5000
                                work_sheet.col(col+2).width = 7000
                                # print(break_down[dat0]['time'], break_down[dat1]['time']) 
                                work_sheet.write(row_+2, col, break_down[dat0]['time'], style1)
                                work_sheet.write(row_+2, col+1, break_down[dat1]['time'], style1)
                                work_sheet.write(row_+2,  col+2, reasons_list[break_down[dat1]['primaryreason']], style1)
                                row_ += 1
                                break
        # if 1 == 1:
        #     row_SHIFT = 3; col_SHIFT = 3
        #     shift_start = shift_datetime[0]
        #     shift_end   = shift_datetime[1]
        #     date_shift_time = datetime.strftime(datetime.today(), '%Y-%m-%d')  + '  &  ' + ("Shift_A")
        #     work_sheet.write_merge(row_SHIFT, row_SHIFT, col_SHIFT, col_SHIFT+3, date_shift_time, style_bold)
        #     row_value , break_down = hourly_report(shift_start, shift_end)
        #     rejection_report(row_value, break_down, shift_start, shift_end)
            
        if now_data == shift_datetime[0]:
            row_SHIFT = 3; col_SHIFT = 3
            shift_start = shift_datetime[0]
            shift_end   = shift_datetime[1]
            date_shift_time = datetime.strftime(datetime.today(), '%Y-%m-%d')  + '  &  ' + ("Shift_A")
            work_sheet.write_merge(row_SHIFT, row_SHIFT, col_SHIFT, col_SHIFT+3, date_shift_time, style_bold)
            row_value , break_down = hourly_report(shift_start, shift_end)
            rejection_report(row_value, break_down, shift_start, shift_end)

        if now_data == shift_datetime[3]:
            row_SHIFT = 3; col_SHIFT = 3
            # global shift_start , shift_end
            shift_start = shift_datetime[2]
            shift_end   = shift_datetime[3]
            date_shift_time = datetime.strftime(datetime.today(), '%Y-%m-%d') + '  &  ' + ("Shift_B")
            work_sheet.write_merge(row_SHIFT, row_SHIFT, col_SHIFT, col_SHIFT+3, date_shift_time, style_bold)
            row_value , break_down = hourly_report(shift_start, shift_end)
            rejection_report(row_value, break_down, shift_start, shift_end)

        if now_data == shift_datetime[5]:
            row_SHIFT = 3; col_SHIFT = 3
            # global shift_start , shift_end
            shift_start = shift_datetime[4] 
            shift_end   = shift_datetime[5] 
            date_shift_time = datetime.strftime(datetime.today(), '%Y-%m-%d') + '  &  ' + ("Shift_C")
            work_sheet.write_merge(row_SHIFT, row_SHIFT, col_SHIFT, col_SHIFT+3, date_shift_time, style_bold)
            row_value , break_down = hourly_report(shift_start, shift_end)
            rejection_report(row_value, break_down, shift_start, shift_end)

    savepath = os.path.join(BASE_DIR,'Report','ProductionReport.xls')
    work_book.save(savepath)    
    # return savepath    
    return HttpResponse("Report Generated")


