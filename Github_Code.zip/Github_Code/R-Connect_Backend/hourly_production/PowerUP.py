from meter_data.models import Masterdatatable
from django.http.response import JsonResponse
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
import json
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from usermanagement.models import AddUser

# Write Your Code Buddy!
@csrf_exempt
def mould_name(request):
    if request.method == 'POST':
        client_data = json.loads(request.body)
        inputDate = client_data['date']
        nextdate  = str((datetime.strptime(inputDate, "%Y-%m-%d") + timedelta(days = 1)).date())
        Plantname = request.GET['Plantname']
        
        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        machinename = client_data['machinename']

        Mould_id = ProductionTable.objects.filter(Q(date = inputDate, time__gte = firstday_start, Machinename = machinename) |
                                       Q (date = nextdate, time__lte = secondday_end, Machinename = machinename)).distinct('Mouldname_id').values('Mouldname_id')

        Mould_Name = [ Mouldmodel.objects.get(id = x['Mouldname_id']).Mouldname for x in Mould_id]
        return JsonResponse(Mould_Name, safe = False)