from productiontable.models import ProductionTable
import xlwt
from RConnect.settings import BASE_DIR
import os
from datetime import datetime , timedelta , date
from django.views.decorators.csrf import csrf_exempt
from machinemanagement.models import AddMachine
from django.http import HttpResponse
from mouldmanagement.models import Mouldmodel
# from celery.task import periodic_task
from celery.schedules import crontab

#Create your code here
def shotwise():
    work_book=xlwt.Workbook(encoding='utf-8')
    style1 = xlwt.XFStyle()
    style_bold = xlwt.XFStyle()
    style_header = xlwt.XFStyle()
    # Set alignment
    alignment       = xlwt.Alignment()
    alignment.horz  = xlwt.Alignment.HORZ_CENTER
    alignment.vert  = xlwt.Alignment.VERT_CENTER
    alignment.wrap      = 1
    style1.alignment    = alignment
    style_bold.alignment = alignment
    style_header.alignment = alignment
    # Set border
    border          = xlwt.Borders()
    border.left     = xlwt.Borders.THIN 
    border.right    = xlwt.Borders.THIN 
    border.top      = xlwt.Borders.THIN 
    border.bottom   = xlwt.Borders.THIN
    style1.borders  = border
    style_bold.borders = border
    style_header.borders = border
    # Set Font
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'calibari'
    font.bold = False
    font.height = 200
    style1.font = font 

    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'calibari'
    font.bold = True
    font.height = 200
    style_bold.font = font 
    
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'calibari'
    font.bold = True
    font.height = 220
    style_header.font = font 
    
    # Create the sheet name
    for machine_name in AddMachine.objects.values('amMachinename'):
        shot_wise = work_book.add_sheet(machine_name['amMachinename'])
        row = 4
        col = 1
        # Adding the headers to the particular sheet
        for heading_data in ['DATE', 'TIME', 'PLANT NAME','MACHINE', 'MOULDNAME', 'MACHINESTATE', 'PRODUCTION  COUNT SET', 'PRODUCTION COUNT ACTUAL', 
                             'CYCLETIME SET', 'CYCLETIME ACTUAL', 'ALARM', 'PRODUCTION TIME ACTUAL', 'PRODUCTION TIME TOTAL', 'CAVITY', 'REJECTION COUNT']:
            shot_wise.col(col).width = 4700
            shot_wise.row(row).height_mismatch = True
            shot_wise.row(row).height = 1100
            shot_wise.write(row, col, heading_data, style_bold)     
            col+=1 
        row_header = 1; col_header = 1
        shot_wise.write_merge(row_header, row_header+2, col_header, col-1, 'PRODUCTION DATA - SHOT WISE', style_header)
        # Fetch the data to the tables
        current_date = date.today()
        # print(current_date)
        next_date = current_date + timedelta(days = 1)
        # print(next_date)
        Production_table = []
        Production_table_current = ProductionTable.objects.filter(date = str(current_date), time__range = ['06:00:00', '23:59:59'] , Machinename = machine_name['amMachinename']).values().order_by('id')
        Production_table_next = ProductionTable.objects.filter(date = str(next_date), time__range = ['00:00:00', '05:59:59'] , Machinename = machine_name['amMachinename']).values().order_by('id')
        for data in Production_table_current:
            Production_table.append(data)
        for data in Production_table_next:
            Production_table.append(data)
        if Production_table != []:
            row = 5; col = 1
            for production_data in Production_table:
                shot_wise.row(row).height_mismatch = True
                shot_wise.row(row).height = 400
                shot_wise.write(row, col, production_data['date'], style1)
                shot_wise.write(row, col+1, production_data['time'], style1)
                shot_wise.write(row, col+2, production_data['Plantname'], style1)
                shot_wise.write(row, col+3, production_data['Machinename'], style1)
                mould_name = Mouldmodel.objects.get(id = production_data['Mouldname_id']).Mouldname
                shot_wise.write(row, col+4, mould_name, style1)
                shot_wise.write(row, col+5, production_data['MachineState'], style1)
                shot_wise.write(row, col+6, production_data['ProductionCountSet'], style1)
                shot_wise.write(row, col+7, production_data['ProductionCountActual'], style1)
                shot_wise.write(row, col+8, production_data['CycletimeSet'], style1)
                shot_wise.write(row, col+9, production_data['CycletimeActual'], style1)
                shot_wise.write(row, col+10, production_data['Alarm'], style1)
                shot_wise.write(row, col+11, production_data['ProductionTimeActual'], style1)
                shot_wise.write(row, col+12, production_data['ProductionTimeTotal'], style1)
                shot_wise.write(row, col+13, production_data['Cavity'], style1)
                shot_wise.write(row, col+14, production_data['RejectionParts'], style1)
                row+=1
    savepath = os.path.join(BASE_DIR,'Report','ShortWise_Report.xls')
    work_book.save(savepath) 
    return savepath
