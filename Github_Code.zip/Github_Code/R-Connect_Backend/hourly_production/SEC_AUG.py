from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import pandas as pd
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
from datetime import datetime, timedelta
from django.db.models import Q
import os

########################################################### New Update ##########################################################

@csrf_exempt
def sec_value_data(request):
    if request.method == 'POST':
        Plantname = request.GET.get('Plantname')
        request_data = json.loads(request.body)
        start_date = request_data['start']
        end_date = request_data['end']
        machine_name = request_data['Mname']
        mouldname = request_data['mldname']

        mould_management = Mouldmodel.objects.get(Mouldname=mouldname)
        weight = mould_management.weight
        mouldid = mould_management.id

        # Convert the date strings to datetime objects
        startdate_dt = datetime.strptime(start_date, "%Y-%m-%d")
        enddate_dt = datetime.strptime(end_date, "%Y-%m-%d")

        # Calculate the total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        nex_enddate_dt = enddate_dt + timedelta(days=1)

        seconddate_dt = startdate_dt + timedelta(days=1)

        # Convert to string only for querying
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        enddate_str = enddate_dt.strftime('%Y-%m-%d')
        seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        all_production_data = ProductionTable.objects.filter(
            Q(date=startdate_str, time__gte=firstday_start) |
            Q(date__range=[seconddate_str, enddate_str]) |
            Q(date=nex_enddate_str, time__lte=secondday_end),
            Plantname=Plantname,
            Machinename=machine_name,
            ProductionCountActual__gt=0,
            Mouldname_id=mouldid,
            MachineState=1
        ).values('Machinename', 'time', 'date', 'Mouldname_id', 'Cavity').order_by('id')

        sec_value = []
        sec_hrs = []
        sec_table = []

        for day_offset in range(total_days):
            current_date = startdate_dt + timedelta(days=day_offset)
            current_date_str = current_date.strftime('%Y-%m-%d')

            next_day = current_date + timedelta(days=1)
            next_day_str = next_day.strftime('%Y-%m-%d')

            for i in range(1, 25):  # Looping over 24 hours

                base_hour = int(firstday_start[:2])
                base_minute = int(firstday_start[3:5])

                adj_hour = (base_hour + i - 1) % 24
                next_hour = (adj_hour + 1) % 24

                # Ensure minutes do not go negative
                if base_minute > 0:
                    time_end_minute = base_minute - 1
                else:
                    time_end_minute = 59  # Handle case where base_minute is 00
                    next_hour = (next_hour - 1) % 24  # Adjust next hour accordingly

                time_start = f"{str(adj_hour).zfill(2)}:{str(base_minute).zfill(2)}:00"
                time_end = f"{str(next_hour).zfill(2)}:{str(time_end_minute).zfill(2)}:59"

                # print(time_start, time_end)

                # if "00:00:00" < time_start < secondday_end:
                if time_start < secondday_end:

                    # print("time1:", time_start, time_end)
                        
                    try:
                        parent_dir = "Machines"
                        sub_dir1 = machine_name
                        sub_dir2 = current_date_str
                        try:
                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        time_start_ = datetime.strptime(time_start, "%H:%M:%S").time()
                                        time_end_ = datetime.strptime(time_end, "%H:%M:%S").time()

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if time_start_ <= time_obj <= time_end_:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")

                                        # if output_data:
                                        if output_data > 0:
                                            hourdata = round(output_data,1)
                                        else:
                                            hourdata = 0   # "No data in time range"
                                except FileNotFoundError:
                                    hourdata = 0  # "File not found"
                            else:
                                hourdata = 0   # "Path does not exist"
                        except:
                            hourdata = 0
                    except KeyError:
                        hourdata = 0
                    # print("time1:", time_start, time_end, "hourdata:", hourdata)

                    Product_Count = [p for p in all_production_data if
                                    p['date'] == next_day_str and
                                    p['time'] >= time_start and p['time'] <= time_end]

                    production_data = (sum(p['Cavity'] for p in Product_Count) * weight) if Product_Count else 0

                    try:
                        SEC = round(hourdata / (production_data / 1000), 2) if production_data else 0
                    except ZeroDivisionError:
                        SEC = 0

                    sec_value.append(float(SEC))
                    sec_hrs.append(f"{current_date_str}_{time_start}-{time_end}")
                    sec_table.append({"date": current_date_str, "hour": time_start+'_'+time_end, "value": float(SEC)})

                # elif "00:00:00" < time_end < secondday_end:
                elif time_end < secondday_end:

                    # print("time2:", time_start, time_end)
                    try:
                        parent_dir = "Machines"
                        sub_dir1 = machine_name
                        sub_dir2 = current_date_str
                        try:
                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        time_start_ = datetime.strptime(time_start, "%H:%M:%S").time()
                                        time_end_ = datetime.strptime(time_end, "%H:%M:%S").time()

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if time_start_ <= time_obj <= time_end_:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")

                                        # if output_data:
                                        if output_data > 0:
                                            hourdata = round(output_data,1)
                                        else:
                                            hourdata = 0   # "No data in time range"
                                except FileNotFoundError:
                                    hourdata = 0  # "File not found"
                            else:
                                hourdata = 0   # "Path does not exist"
                        except:
                            hourdata = 0
                    except KeyError:
                        hourdata = 0
                    # print("time2:", time_start, time_end, "hourdata:", hourdata)
                    
                    Product_Count = [k for k in all_production_data if
                            ((k['date'] == current_date_str and time_start <= k['time']) or
                            (k['date'] == next_day_str and k['time'] <= time_end))
                                ]

                    production_data = (sum(p['Cavity'] for p in Product_Count) * weight) if Product_Count else 0

                    try:
                        SEC = round(hourdata / (production_data / 1000), 2) if production_data else 0
                    except ZeroDivisionError:
                        SEC = 0

                    sec_value.append(float(SEC))
                    sec_hrs.append(f"{current_date_str}_{time_start}-{time_end}")
                    sec_table.append({"date": current_date_str, "hour": time_start+'_'+time_end, "value": float(SEC)})

                else:
                    # print("time3:", time_start, time_end)
                    try:
                        parent_dir = "Machines"
                        sub_dir1 = machine_name
                        sub_dir2 = current_date_str
                        try:
                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        time_start_ = datetime.strptime(time_start, "%H:%M:%S").time()
                                        time_end_ = datetime.strptime(time_end, "%H:%M:%S").time()

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if time_start_ <= time_obj <= time_end_:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")

                                        # if output_data:
                                        if output_data > 0:
                                            hourdata = round(output_data,1)
                                        else:
                                            hourdata = 0   # "No data in time range"
                                except FileNotFoundError:
                                    hourdata = 0  # "File not found"
                            else:
                                hourdata = 0   # "Path does not exist"
                        except:
                            hourdata = 0
                    except KeyError:
                        hourdata = 0
                    # print("time3:", time_start, time_end, "hourdata:", hourdata)

                    Product_Count = [p for p in all_production_data if
                                    p['date'] == current_date_str and
                                    p['time'] >= time_start and p['time'] <= time_end]

                    production_data = (sum(p['Cavity'] for p in Product_Count) * weight) if Product_Count else 0

                    try:
                        SEC = round(hourdata / (production_data / 1000), 2) if production_data else 0
                    except ZeroDivisionError:
                        SEC = 0

                    sec_value.append(float(SEC))
                    sec_hrs.append(f"{current_date_str}_{time_start}-{time_end}")
                    sec_table.append({"date": current_date_str, "hour": time_start+'_'+time_end, "value": float(SEC)})
                # print("----------------------------------------------------------------------")
        average_total = round(sum(sec_value) / len(sec_hrs), 2) if sec_hrs else 0

        return JsonResponse(
            {
                "average_value": average_total,
                "sec_date_hour": sec_hrs,
                "sec_value": sec_value,
                "sec_table": sec_table
            },
            safe=False
        )