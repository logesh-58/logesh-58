from django.urls import path
from .import views, analysis

urlpatterns = [

    path('daywise/', analysis.daywise,name="daywise"),
    path('weekwise/', analysis.weekwise,name="daywise"),
    path('weekdaychart/', analysis.weekdaychart,name="daywise"),

]
