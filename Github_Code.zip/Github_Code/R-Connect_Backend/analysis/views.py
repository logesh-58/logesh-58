from timeline.models import timeline
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from productiontable.models import ProductionTable
import json
import datetime
import time
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from django.db.models import Sum as add
import pandas as pd

from django.utils.dateparse import parse_datetime

#------------------------------------------START of production analytics--------------------------------------------------

def machineArray(Plantname):
    # Use values_list to fetch a list of machine names directly
    mastermachineArray = AddMachine.objects.filter(
        amPlantname=Plantname
    ).order_by('amid').values_list('amMachinename', flat=True)
    
    # Convert to list if necessary (depends on Django version)
    return list(mastermachineArray)