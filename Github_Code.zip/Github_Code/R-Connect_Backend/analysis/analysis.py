from timeline.models import timeline
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from productiontable.models import ProductionTable
import json
from datetime import datetime, timedelta
import time
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from django.db.models import Sum as add
import pandas as pd

from django.utils.dateparse import parse_datetime

#------------------------------------------START of production analytics--------------------------------------------------

def machineArray(Plantname):
    # Use values_list to fetch a list of machine names directly
    mastermachineArray = AddMachine.objects.filter(
        amPlantname=Plantname
    ).order_by('amid').values_list('amMachinename', flat=True)
    
    # Convert to list if necessary (depends on Django version)
    return list(mastermachineArray)

@csrf_exempt
def daywise(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']        
        httpdata = json.loads(request.body)
        date = httpdata['date']
        Machinename = httpdata['Machinename']
        Current_Date = datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.%fZ").date()

        Next_Date = Current_Date + timedelta(days = 1)
        #--------------------------------------------------------------------------------
        shift_time = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift3end').last()
        shiftstarttime = shift_time['shift1start']
        shiftendtime   = shift_time['shift3end']
        #-------------------------------------------------------------------------------- 

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=Current_Date, time__gte=shiftstarttime) |
                    Q(date=Next_Date, time__lte=shiftendtime),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Mouldname_id', 'Cavity').order_by('id')

        data = []

        distinctArray = list(set(p['Mouldname_id'] for p in all_dashboard_value))

        for mould in distinctArray:

            actual_count_cal = [e for e in all_dashboard_value if
                            e['Mouldname_id'] == mould
                        ]
            actual_count = sum(p['Cavity'] for p in actual_count_cal) if actual_count_cal else 0
            
            mac_counts = 300

            MouldName = Mouldmodel.objects.get(id = mould).Mouldname

            mydict = {'date':Current_Date, 'Machinename':Machinename, 'Mouldname': MouldName, 'ProductionCountActual':actual_count, 'ProductionCountSet':mac_counts}
            data.append(mydict)

        return JsonResponse(data, safe=False)

@csrf_exempt
def weekwise(request):
    # def weekwise(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        week = httpdata['week']
        Machinename = httpdata['Machinename']
        #--------------------------------------------------------------------------------
        shift_time = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        shiftstarttime = shift_time['shift1start']
        shiftendtime   = shift_time['shift3end']
        #--------------------------------------------------------------------------------
    
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_time['shift1start'].strftime('%H:%M:%S') if shift_time['shift1start'] else None
        secondday_end = shift_time['shift3end'].strftime('%H:%M:%S') if shift_time['shift3end'] else None

        data = []

        if(int(week) == 1): # this week
            #--------------------------------------------------------------------------------

            today_date = datetime.today().date()

            # Get the start date of the current week (Monday)
            startdate = today_date - timedelta(days=today_date.weekday())

            seconddate = startdate + timedelta(days=1)

            # Get the end date of the current week (Sunday)
            enddate = startdate + timedelta(days=6)

            nextdate = enddate + timedelta(days=1)

            startdate_str = startdate.strftime("%Y-%m-%d")
            seconddate_str = seconddate.strftime("%Y-%m-%d")
            enddate_str = enddate.strftime("%Y-%m-%d")
            nex_enddate_str = nextdate.strftime("%Y-%m-%d")

            total_days = (enddate - startdate).days + 1
            #--------------------------------------------------------------------------------

            all_dashboard_value = ProductionTable.objects.filter(
                            Q(date=startdate_str, time__gte=shiftstarttime) |
                            Q(date__range=[seconddate_str, enddate_str]) |
                            Q(date=nex_enddate_str, time__lte=shiftendtime),
                            Plantname=Plantname,
                            Machinename=Machinename,
                            ProductionCountActual__gt=0,
                            MachineState=1
                        ).values('Machinename', 'time', 'date', 'Mouldname_id', 'Cavity').order_by('id')

            for day_offset in range(total_days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                moldrow = list(set(p['Mouldname_id'] for p in all_dashboard_value if
                                ((p['date'] == current_date_str and firstday_start <= p['time']) or
                            (p['date'] == next_day_str and p['time'] <= secondday_end))
                                         ))
                
                if moldrow != []:
                    for mould in moldrow:
                        mould_name = Mouldmodel.objects.get(id = mould).Mouldname

                        actual_count_cal = [e for e in all_dashboard_value if
                        ((e['date'] == current_date_str and e['Mouldname_id'] == mould and firstday_start <= e['time']) or
                            (e['date'] == next_day_str and e['Mouldname_id'] == mould and e['time'] <= secondday_end))
                        ]
                        actual_count = sum(p['Cavity'] for p in actual_count_cal) if actual_count_cal else 0

                        mydict = {'date':current_date_str, 'Machinename':Machinename, 'Mouldname':mould_name, 'ProductionCountActual':actual_count}
                        data.append(mydict)
                
            return JsonResponse(data, safe=False)
        
        elif(int(week) == 0): # last week
            #--------------------------------------------------------------------------------
            today_date = datetime.today().date()

            # Start date of the last week (Monday)
            startdate = today_date - timedelta(days=today_date.weekday() + 7)
            # End date of the last week (Sunday)
            enddate = startdate + timedelta(days=6)

            seconddate = startdate + timedelta(days=1)

            nextdate = enddate + timedelta(days=1)

            startdate_str = startdate.strftime("%Y-%m-%d")
            seconddate_str = seconddate.strftime("%Y-%m-%d")
            enddate_str = enddate.strftime("%Y-%m-%d")
            nex_enddate_str = nextdate.strftime("%Y-%m-%d")

            total_days = (enddate - startdate).days + 1
            #--------------------------------------------------------------------------------

            
            all_dashboard_value = ProductionTable.objects.filter(
                            Q(date=startdate_str, time__gte=shiftstarttime) |
                            Q(date__range=[seconddate_str, enddate_str]) |
                            Q(date=nex_enddate_str, time__lte=shiftendtime),
                            Plantname=Plantname,
                            Machinename=Machinename,
                            ProductionCountActual__gt=0,
                            MachineState=1
                        ).values('Machinename', 'time', 'date', 'Mouldname_id', 'Cavity').order_by('id')

            for day_offset in range(total_days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                moldrow = list(set(p['Mouldname_id'] for p in all_dashboard_value if
                                ((p['date'] == current_date_str and firstday_start <= p['time']) or
                            (p['date'] == next_day_str and p['time'] <= secondday_end))
                                         ))
                
                if moldrow != []:
                    for mould in moldrow:
                        mould_name = Mouldmodel.objects.get(id = mould).Mouldname

                        actual_count_cal = [e for e in all_dashboard_value if
                        ((e['date'] == current_date_str and e['Mouldname_id'] == mould and firstday_start <= e['time']) or
                            (e['date'] == next_day_str and e['Mouldname_id'] == mould and e['time'] <= secondday_end))
                        ]
                        actual_count = sum(p['Cavity'] for p in actual_count_cal) if actual_count_cal else 0

                        mydict = {'date':current_date_str, 'Machinename':Machinename, 'Mouldname':mould_name, 'ProductionCountActual':actual_count}
                        data.append(mydict)
                
            return JsonResponse(data, safe=False)
        

@csrf_exempt
def weekdaychart(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        machinedatas = httpdata['datemachine']
        iDay = httpdata['daydata']
        iweek = machinedatas['week']
        Machinename = machinedatas['Machinename']
        
        Day = time.strptime(iDay, "%A").tm_wday
        x = datetime.now()
        currentday = x.weekday()

        # Current date and weekday
        today = datetime.now().date()
        today_day = datetime.now().weekday()

        # Calculate week start and end dates
        currentweekstart = today - timedelta(days=today_day)
        lastweekstart = currentweekstart - timedelta(weeks=1)

        #--------------------------------------------------------------------------------
        shift_time = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift3end').last()
        shiftstarttime = shift_time['shift1start']
        shiftendtime   = shift_time['shift3end']
        #--------------------------------------------------------------------------------
        if (int(iweek) == 0): #lastweek

            Current_Date = datetime.strftime(lastweekstart + timedelta(days=Day), '%Y-%m-%d')
            Next_Date = datetime.strftime(lastweekstart + timedelta(days=Day+1), '%Y-%m-%d')

            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=Current_Date, time__gte=shiftstarttime) |
                    Q(date=Next_Date, time__lte=shiftendtime),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Mouldname_id', 'Cavity').order_by('id')

            data = []

            distinctArray = list(set(p['Mouldname_id'] for p in all_dashboard_value))

            for mould in distinctArray:

                actual_count_cal = [e for e in all_dashboard_value if
                                e['Mouldname_id'] == mould
                            ]
                actual_count = sum(p['Cavity'] for p in actual_count_cal) if actual_count_cal else 0

                aggregated_data = 300
                
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                MouldName = Mouldmodel.objects.get(id = mould).Mouldname

                mydict = {'date':Current_Date, 'Machinename':Machinename, 'Mouldname': MouldName, 'ProductionCountActual':actual_count, 'ProductionCountSet':mac_counts}
                data.append(mydict)

            return JsonResponse(data, safe=False)     
                                                                             
        if (int(iweek) == 1): #currentweek

            Current_Date = datetime.strftime(currentweekstart + timedelta(days=Day), '%Y-%m-%d')
            Next_Date = datetime.strftime(currentweekstart + timedelta(days=Day+1), '%Y-%m-%d')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=Current_Date, time__gte=shiftstarttime) |
                    Q(date=Next_Date, time__lte=shiftendtime),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Mouldname_id', 'Cavity').order_by('id')

            data = []

            distinctArray = list(set(p['Mouldname_id'] for p in all_dashboard_value))

            for mould in distinctArray:

                actual_count_cal = [e for e in all_dashboard_value if
                                e['Mouldname_id'] == mould
                            ]
                actual_count = sum(p['Cavity'] for p in actual_count_cal) if actual_count_cal else 0

                aggregated_data = 300
                
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                MouldName = Mouldmodel.objects.get(id = mould).Mouldname

                mydict = {'date':Current_Date, 'Machinename':Machinename, 'Mouldname': MouldName, 'ProductionCountActual':actual_count, 'ProductionCountSet':mac_counts}
                data.append(mydict)

            return JsonResponse(data, safe=False)  
 