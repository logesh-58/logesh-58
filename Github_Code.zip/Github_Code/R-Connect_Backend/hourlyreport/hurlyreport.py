from datetime import datetime , timedelta, date
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from meter_data.models import Masterdatatable
from mouldmanagement.models import Mouldmodel
from timeline.models import breakdown, badpart
from django.db.models import Sum as add
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from django.db.models import Q
import os

@csrf_exempt
def hurlyproduction(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        client_data = json.loads(request.body)
        Machinename = client_data['machinename']
        dan = (datetime.strptime(client_data['date'], '%Y-%m-%d')).date()
        law = dan + timedelta(days = 1)

        today = dan.strftime("%Y-%m-%d")
        nextdate = law.strftime("%Y-%m-%d")

        API = []

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        shift_data = shift_starttime['shift1start']

        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=today, time__gte=firstday_start) |
                    Q(date=nextdate, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename', 'time', 'date', 'MachineState', 'CycletimeActual', 'Mouldname_id', 'Cavity').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=today, time__gte=firstday_start) |
                    Q(date=nextdate, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename=Machinename
                ).values('Machinename', 'date', 'time', 'Cavity', 'Mouldname_id').order_by('id')
        
        all_breakdown_data = breakdown.objects.filter(
                    Q(date=today, time__gte=firstday_start) |
                    Q(date=nextdate, time__lte=secondday_end),
                    Machinename=Machinename,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date', 'primaryreason', 'Mouldname_id').order_by('id')
        
        # **Fix: Extract Hours & Minutes in Decimal Format**
        starttime = shift_data.hour + (shift_data.minute / 60)  # Convert to decimal hours

        hrsArray = []

        for i in range(0, 24):  # Loop for 24 hours
            hour_index = (starttime + i) % 24  # Ensuring hours stay within 0-23 range
            date_value = nextdate if hour_index < starttime else today

            fromtime = f"{int(hour_index):02d}:{int((hour_index % 1) * 60):02d}:00"

            # Calculate `totime` by subtracting 1 second
            to_hour = int((hour_index + 1) % 24)
            to_minute = int(((hour_index + 1) % 1) * 60) - 1

            if to_minute < 0:  # If minute is negative, adjust hour and set minute to 59
                to_hour = (to_hour - 1) % 24
                to_minute = 59

            totime = f"{to_hour:02d}:{to_minute:02d}:59"

            hrsArray.append({
                "date": date_value,
                "fromtime": fromtime,
                "totime": totime
            })

        ############################## HOURLY PRODUCTION REPORT ####################################
        reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
        
        API_dict = {}  # Dictionary to store hourly grouped data

        for hour in hrsArray:

            date = hour['date']
            fromTime = hour['fromtime']
            toTime = hour['totime']

            # print("fromTime:", fromTime, "toTime:", toTime)

            if (fromTime < secondday_end) or ((fromTime and toTime) > secondday_end):
            # elif toTime < secondday_end:

                # print("date:", date, "fromTime:", fromTime, "toTime:", toTime)
            
                main_data = [p for p in all_dashboard_value if (p['date'] == date and fromTime <= p['time'] <= toTime)]

                seen = set()
                distinctMould = [p['Mouldname_id'] for p in main_data if not (p['Mouldname_id'] in seen or seen.add(p['Mouldname_id']))]
                
                mould_list = []

                for mould_id in distinctMould:
                    mould_obj = Mouldmodel.objects.get(id=mould_id)
                    mould_name = mould_obj.Mouldname
                    mld_weight = mould_obj.weight

                    mld_data = [p for p in main_data if (p['Mouldname_id'] == mould_id)]

                    totalshots = sum(p['Cavity'] for p in mld_data)

                    badparts = sum(p['Cavity'] for p in all_RejectionParts_cal if (p['date'] == date and fromTime <= p['time'] <= toTime
                            and p['Mouldname_id'] == mould_id))
                    
                    goodparts = totalshots - badparts

                    totalweight = totalshots * mld_weight

                    if mld_data:

                        first_record = mld_data[0]
                        last_record = mld_data[-1]

                        mould_start_time = first_record['time'] # Start time
                        mould_end_time = last_record['time']  # End time
                        
                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                        try:
                            runhour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        except:
                            runhour = 0

                        #####################################
                        parent_dir = "Machines"
                        sub_dir1 = Machinename
                        sub_dir2 = today             
                        try:
                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if first_time <= time_obj <= last_time:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")
                                        # Format the output data in the desired list format
                                        
                                        # if output_data:
                                        if output_data > 0:
                                            output_data_str = round(output_data,1)
                                        else:
                                            output_data_str = 0   # "No data in time range"
                                except FileNotFoundError:
                                    output_data_str = 0  # "File not found"
                            else:
                                output_data_str = 0   # "Path does not exist"
                        except:
                            output_data_str = 0
                        #####################################

                        try:
                            energy_index = output_data_str     
                        except:
                            energy_index = 0

                        try:
                            sec_value = round(float(energy_index)/(float(totalweight)/1000), 2)  
                        except:
                            sec_value = 0

                        reason_list = []

                        break_down = [k for k in all_breakdown_data if
                                    (k['date'] == date and mould_start_time <= k['time'] <= mould_end_time and k['Mouldname_id'] == mould_id)]
                
                        reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
                        
                        #  .total_seconds()     # .seconds
                        total_idle_time = 0  # Initialize the sum

                        last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                        # Iterate through the breakdown data and calculate time differences
                        for last, bd in zip(break_down, break_down[1:]):
                            # If `MachineState = 0` for last, store its time but don't calculate yet
                            if last['MachineState'] == 0:
                                # Capture the first occurrence of MachineState = 0
                                if last_time_str is None:
                                    last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
                            # Only calculate the time difference when transitioning from 0 to 1
                            if last_time_str and bd['MachineState'] == 1:
                                # Combine date and time for `bd`
                                bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                                # Parse the combined date and time
                                last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                                bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                                # Calculate the time difference in seconds
                                time_difference = (bd_time - last_time).total_seconds()

                                if last['primaryreason'] == bd['primaryreason']:

                                    if last['primaryreason'] != 0:
                                        reason_list.append(reasons[last['primaryreason']])

                                # Accumulate the total time in seconds
                                total_idle_time += time_difference

                                # Reset last_time_str to None after calculating for this transition
                                last_time_str = None

                        idlehours = total_idle_time / 3600  # Convert seconds to hours

                        total_runhour = float(runhour) - idlehours

                        total_seconds = int(total_runhour * 3600)
                        time_formatted = str(timedelta(seconds=total_seconds))

                        if reason_list == []:
                            reason_list = '_'

                        mould_list.append({
                            "mould_name": mould_name,
                            "mould_start_time": mould_start_time,
                            "mould_end_time": mould_end_time,
                            "Run_Hour": time_formatted,
                            "total_shots": totalshots,
                            "Goodparts": goodparts,
                            "part_weight": totalweight,
                            "energy": energy_index,
                            "SEC": sec_value,
                            "stop_reason": reason_list
                        })

                # Store the grouped data in the dictionary
                if mould_list:
                    API_dict[f"{fromTime}-{toTime}"] = {
                        "from_time": fromTime,
                        "to_time": toTime,
                        "mould_data": mould_list
                    }

            else:
                # print("date:", "rrrrrrrrrrrrrrrrr", "fromTime:", fromTime, "toTime:", toTime)

                main_data = [k for k in all_dashboard_value if
                            ((k['date'] == today and fromTime <= k['time']) or
                            (k['date'] == nextdate and k['time'] <= toTime))
                                ]

                seen = set()
                distinctMould = [p['Mouldname_id'] for p in main_data if not (p['Mouldname_id'] in seen or seen.add(p['Mouldname_id']))]
                
                mould_list = []

                for mould_id in distinctMould:
                    mould_obj = Mouldmodel.objects.get(id=mould_id)
                    mould_name = mould_obj.Mouldname
                    mld_weight = mould_obj.weight

                    mld_data = [p for p in main_data if (p['Mouldname_id'] == mould_id)]

                    totalshots = sum(p['Cavity'] for p in mld_data)
                    
                    badparts = sum(k['Cavity'] for k in all_RejectionParts_cal if
                            ((k['date'] == today and fromTime <= k['time']) or
                                (k['date'] == nextdate and k['time'] <= toTime))
                            and k['Mouldname_id'] == mould_id)
                    
                    goodparts = totalshots - badparts

                    totalweight = totalshots * mld_weight

                    if mld_data:

                        first_record = mld_data[0]
                        last_record = mld_data[-1]

                        mould_start_time = first_record['time'] # Start time
                        mould_end_time = last_record['time']  # End time

                        mould_start_date = first_record['date'] # Start date
                        mould_end_date = last_record['date']  # End date
                        
                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                        try:
                            runhour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        except:
                            runhour = 0

                        #####################################
                        parent_dir = "Machines"
                        sub_dir1 = Machinename
                        sub_dir2 = today             
                        try:
                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if first_time <= time_obj <= last_time:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")
                                        # Format the output data in the desired list format
                                        
                                        # if output_data:
                                        if output_data > 0:
                                            output_data_str = round(output_data,1)
                                        else:
                                            output_data_str = 0   # "No data in time range"
                                except FileNotFoundError:
                                    output_data_str = 0  # "File not found"
                            else:
                                output_data_str = 0   # "Path does not exist"
                        except:
                            output_data_str = 0
                        #####################################

                        try:
                            energy_index = output_data_str     
                        except:
                            energy_index = 0

                        try:
                            sec_value = round(float(energy_index)/(float(totalweight)/1000), 2)  
                        except:
                            sec_value = 0

                        reason_list = []

                        if mould_start_date == mould_end_date:
                            break_down = [k for k in all_breakdown_data if
                                        (k['date'] == mould_start_date and mould_start_time <= k['time'] <= mould_end_time and k['Mouldname_id'] == mould_id)]

                        else:
                            break_down = [k for k in all_breakdown_data if 
                                        ((k['date'] == today and mould_start_time <= k['time']) or 
                                        (k['date'] == nextdate and k['time'] <= mould_end_time)) and 
                                        k['Mouldname_id'] == mould_id]

                        reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
                        
                        #  .total_seconds()     # .seconds
                        total_idle_time = 0  # Initialize the sum

                        last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                        # Iterate through the breakdown data and calculate time differences
                        for last, bd in zip(break_down, break_down[1:]):
                            # If `MachineState = 0` for last, store its time but don't calculate yet
                            if last['MachineState'] == 0:
                                # Capture the first occurrence of MachineState = 0
                                if last_time_str is None:
                                    last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
                            # Only calculate the time difference when transitioning from 0 to 1
                            if last_time_str and bd['MachineState'] == 1:
                                # Combine date and time for `bd`
                                bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                                # Parse the combined date and time
                                last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                                bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                                # Calculate the time difference in seconds
                                time_difference = (bd_time - last_time).total_seconds()

                                if last['primaryreason'] == bd['primaryreason']:

                                    if last['primaryreason'] != 0:
                                        reason_list.append(reasons[last['primaryreason']])

                                # Accumulate the total time in seconds
                                total_idle_time += time_difference

                                # Reset last_time_str to None after calculating for this transition
                                last_time_str = None

                        idlehours = total_idle_time / 3600  # Convert seconds to hours

                        total_runhour = float(runhour) - idlehours

                        total_seconds = int(total_runhour * 3600)
                        time_formatted = str(timedelta(seconds=total_seconds))

                        if reason_list == []:
                            reason_list = '_'

                        mould_list.append({
                            "mould_name": mould_name,
                            "mould_start_time": mould_start_time,
                            "mould_end_time": mould_end_time,
                            "Run_Hour": time_formatted,
                            "total_shots": totalshots,
                            "Goodparts": goodparts,
                            "part_weight": totalweight,
                            "energy": energy_index,
                            "SEC": sec_value,
                            "stop_reason": reason_list
                        })

                # Store the grouped data in the dictionary
                if mould_list:
                    API_dict[f"{fromTime}-{toTime}"] = {
                        "from_time": fromTime,
                        "to_time": toTime,
                        "mould_data": mould_list
                    }


        # Convert API_dict values to a list for JSON response
        API = list(API_dict.values())

        return JsonResponse(API, safe=False)