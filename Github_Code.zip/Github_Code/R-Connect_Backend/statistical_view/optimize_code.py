import datetime
from timeline.models import breakdown
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
import json
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
import pandas as pd
from dateutil import relativedelta
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.db.models import Q, Sum, F, ExpressionWrapper, fields, DurationField, FloatField, Q, Min, Max, F, Func, Count, Prefetch
from datetime import datetime, timedelta
from django.utils.dateparse import parse_time
from decimal import Decimal
###################################################################################################

@csrf_exempt
def historical_fun(request):
    Plantname = request.GET.get('Plantname')

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')
    select_machine = DateReq.get('machinename')

    # Convert the date strings to datetime objects
    startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

    # Calculate the total days in the range
    total_days = (enddate_dt - startdate_dt).days + 1

    nex_enddate_dt = enddate_dt + timedelta(days=1)

    seconddate_dt = startdate_dt + timedelta(days=1)

    # Convert to string only for querying
    nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
    startdate_str = startdate_dt.strftime('%Y-%m-%d')
    enddate_str = enddate_dt.strftime('%Y-%m-%d')
    seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

    shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
    # Extracting shift timings as strings (converted from time objects)
    firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
    secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

    # Retrieve and store all data for the date range
    all_dashboard_value = ProductionTable.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Plantname=Plantname,
                Machinename=select_machine,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'CycletimeActual', 'time', 'date').order_by('id')

    all_breakdown_data = breakdown.objects.filter(
        Q(date=startdate_str, time__gte=firstday_start) |
        Q(date__range=[seconddate_str, enddate_str]) |
        Q(date=nex_enddate_str, time__lte=secondday_end),
        Machinename=select_machine,
        Plantname=Plantname
    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

    ################################
    #last
    response_data = []

    for day_offset in range(total_days):
        current_date = startdate_dt + timedelta(days=day_offset)
        current_date_str = current_date.strftime('%Y-%m-%d')
        
        # Define next day for range
        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

        total_seconds = 1 * 24 * 60 * 60

        # Query the ProductionTable for entries for the current date
        dayresult = [p for p in all_dashboard_value if
                            ((p['date'] == current_date_str and firstday_start <= p['time']) or
                                (p['date'] == next_day_str and p['time'] <= secondday_end))
                        ]

        total_cycle_time = sum(p['CycletimeActual'] for p in dayresult) if dayresult else 0


        # Append data for each machine
        utilization = [
            round((total_cycle_time / total_seconds) * 100),  # Utilization
            0,  # Idle time (to be calculated below)
            0   # Nonproductive time (to be calculated below)
        ]

        # Calculate total idle time for current date
        saw = [k for k in all_breakdown_data if
                            ((k['date'] == current_date_str and firstday_start <= k['time']) or
                                (k['date'] == next_day_str and k['time'] <= secondday_end))
                        ]

        #  .total_seconds()     # .seconds
        total_idle_time = 0  # Initialize the sum

        last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

        # Iterate through the breakdown data and calculate time differences
        for last, bd in zip(saw, saw[1:]):
            # If `MachineState = 0` for last, store its time but don't calculate yet
            if last['MachineState'] == 0:
                # Capture the first occurrence of MachineState = 0
                if last_time_str is None:
                    last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
            
            # Only calculate the time difference when transitioning from 0 to 1
            if last_time_str and bd['MachineState'] == 1:
                # Combine date and time for `bd`
                bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                # Parse the combined date and time
                last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                # Calculate the time difference in seconds
                time_difference = (bd_time - last_time).total_seconds()

                # Print the intermediate values
                # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                # Accumulate the total time in seconds
                total_idle_time += time_difference

                # Reset last_time_str to None after calculating for this transition
                last_time_str = None


        val1 = Decimal(total_seconds) - (Decimal(total_cycle_time) + Decimal(total_idle_time))
        val2 = round((val1/total_seconds)*100)

        utilization[1] = round((total_idle_time / total_seconds) * 100)  # Idle time in percentage
        utilization[2] = round(val2)  # Nonproductive time

        # Construct the response for the current date
        response_data.append({
            "date": current_date_str,
            "Machine": select_machine,
            "Utilization": utilization
        })

    return JsonResponse(response_data, safe=False)

##########################################################################################################################################

@csrf_exempt
def statistical_fun(request):
    Plantname = request.GET.get('Plantname')
    MachinenamesArray = machineArray(Plantname)

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')

    # Convert the date strings to datetime objects
    startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

    # Calculate the total days in the range
    total_days = (enddate_dt - startdate_dt).days + 1

    nex_enddate_dt = enddate_dt + timedelta(days=1)

    seconddate_dt = startdate_dt + timedelta(days=1)

    # Convert to string only for querying
    nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
    startdate_str = startdate_dt.strftime('%Y-%m-%d')
    enddate_str = enddate_dt.strftime('%Y-%m-%d')
    seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

    shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
    # Extracting shift timings as strings (converted from time objects)
    firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
    secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

    # Fetch production data directly with aggregation
    production_data = ProductionTable.objects.filter(
        Q(date=startdate_str, time__gte=firstday_start) |
        Q(date__range=[seconddate_str, enddate_str]) |
        Q(date=nex_enddate_str, time__lte=secondday_end),
        Plantname=Plantname,
        Machinename__in=MachinenamesArray,
        ProductionCountActual__gt=0,
        MachineState=1
    ).values('Machinename').annotate(production_time=Sum('CycletimeActual'))

    # Convert production data to dictionary with float conversion
    machine_production = {entry['Machinename']: float(entry['production_time']) for entry in production_data}

    all_breakdown_data = breakdown.objects.filter(
        Q(date=startdate_str, time__gte=firstday_start) |
        Q(date__range=[seconddate_str, enddate_str]) |
        Q(date=nex_enddate_str, time__lte=secondday_end),
        Machinename__in=MachinenamesArray,
        Plantname=Plantname
    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

    total_seconds = total_days * 24 * 60 * 60


    response_data = []

    for select_machine in MachinenamesArray:

        stat_total_cycle_time = machine_production.get(select_machine, 0)


        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine
                        ]

        #  .total_seconds()     # .seconds
        stat_total_idle_time = 0  # Initialize the sum

        last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

        # Iterate through the breakdown data and calculate time differences
        for last, bd in zip(saw, saw[1:]):
            # If `MachineState = 0` for last, store its time but don't calculate yet
            if last['MachineState'] == 0:
                # Capture the first occurrence of MachineState = 0
                if last_time_str is None:
                    last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
            
            # Only calculate the time difference when transitioning from 0 to 1
            if last_time_str and bd['MachineState'] == 1:
                # Combine date and time for `bd`
                bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                # Parse the combined date and time
                last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                # Calculate the time difference in seconds
                time_difference = (bd_time - last_time).total_seconds()

                # Accumulate the total time in seconds
                stat_total_idle_time += time_difference

                # Reset last_time_str to None after calculating for this transition
                last_time_str = None

        val1 = Decimal(total_seconds) - (Decimal(stat_total_cycle_time) + Decimal(stat_total_idle_time))
        val2 = round((val1 / total_seconds) * 100)

        machine_data = {
            "Machine": select_machine,
            "Utilization": [
                round((stat_total_cycle_time / total_seconds) * 100),  # TotalCycleTimeActual
                round((stat_total_idle_time / total_seconds) * 100),   # TotalIdleTime
                val2  # Nonprod
            ]
        }
        response_data.append(machine_data)

    return JsonResponse(response_data, safe=False)