from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dashboard
from productiontable.models import ProductionTable
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from datetime import datetime, time, timedelta
import pytz
from django.db.models import Q, Min, Max, Count, F, Sum
from analysis.views import machineArray
from shiftmanagement.models import ShiftTimings
from timeline.models import breakdown, badpart
import json
from maintenance.models import maintenance_module


@csrf_exempt
def datar_w(request):
    if request.method=="POST":
        DateReq = json.loads(request.body)
        
        Name = DateReq.get("Name")

        if Name == "Production data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            MachineState = DateReq.get("MachineState")
            Alarm = DateReq.get("Alarm")
            ProductionCountActual = DateReq.get("ProductionCountActual")
            ProductionCountSet = DateReq.get("ProductionCountSet")
            CycletimeActual = DateReq.get("CycletimeActual")
            CycletimeSet = DateReq.get("CycletimeSet")
            ProductionTimeActual = DateReq.get("ProductionTimeActual")
            ProductionTimeTotal = DateReq.get("ProductionTimeTotal")
            RejectionParts = DateReq.get("RejectionParts")
            Cavity = DateReq.get("Cavity")
            date =  DateReq.get("date")
            time =  DateReq.get("time")
            machinestatus = DateReq.get("machinestatus")


            if date and time:
                datetime_str = f"{date} {time}"
                datetime_obj = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
            else:
                return JsonResponse({"error": "Invalid date or time format"}, status=400)

            try:
                all_dashboard_value = ProductionTable.objects.filter(
                        Plantname=Plantname,
                        Machinename=Machinename
                    ).values("ProductionCountActual", "Mouldname_id").order_by('id').last()
                
                last_production_count = all_dashboard_value["ProductionCountActual"]
                last_mould_id = all_dashboard_value["Mouldname_id"]

                if last_production_count != ProductionCountActual or last_mould_id != Mouldname_id:
                    maxs = CycletimeSet * 2
                    if CycletimeActual <= maxs:
                        item = Dashboard(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            datetime=datetime_obj,
                            machinestatus=machinestatus
                        )
                        item.save()

                        item = ProductionTable(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            date =  date,
                            time =  time
                        )
                        item.save()
            except:

                if Mouldname_id != 0:
                    maxs = CycletimeSet * 2
                    if CycletimeActual <= maxs:
                        item = Dashboard(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            datetime=datetime_obj,
                            machinestatus=machinestatus
                        )
                        item.save()

                        item = ProductionTable(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            date =  date,
                            time =  time
                        )
                        item.save()

        if Name == "Breakdown data":
            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            MachineState = DateReq.get("MachineState")
            primaryreason = DateReq.get("primaryreason")
            date =  DateReq.get("date")
            time =  DateReq.get("time")
            try:
                all_breakdown_data = breakdown.objects.filter(
                        Machinename=Machinename,
                        Plantname=Plantname
                    ).values('primaryreason', 'MachineState').order_by('id').last()
                
                last_primaryreason = all_breakdown_data["primaryreason"]
                last_MachineState = all_breakdown_data["MachineState"]

                if last_primaryreason == primaryreason and last_MachineState == MachineState:
                    pass
                else:
            
                    item = breakdown(
                                    Plantname=Plantname,
                                    Machinename=Machinename,
                                    Mouldname_id=Mouldname_id,
                                    MachineState=MachineState,
                                    primaryreason=primaryreason,
                                    date =  date,
                                    time =  time
                                )
                    item.save()
            except:
                if Mouldname_id != 0:
                    item = breakdown(
                                        Plantname=Plantname,
                                        Machinename=Machinename,
                                        Mouldname_id=Mouldname_id,
                                        MachineState=MachineState,
                                        primaryreason=primaryreason,
                                        date =  date,
                                        time =  time
                                    )
                    item.save()

        if Name == "Maintenance data":
            mnt_oilfilter_clogge = DateReq.get("mnt_oilfilter_clogge")
            mnt_machinename = DateReq.get("mnt_machinename")
            mnt_lubrication = DateReq.get("mnt_lubrication")
            mnt_hydraulic = DateReq.get("mnt_hydraulic")
            mnt_pumpstatus = DateReq.get("mnt_pumpstatus")
            mnt_date =  DateReq.get("mnt_date")
            mnt_time =  DateReq.get("mnt_time")
            mnt_oilfilter_motor = DateReq.get("mnt_oilfilter_motor")

            if maintenance_module.objects.filter(mnt_date = mnt_date, mnt_machinename = mnt_machinename).exists():
                maintenance_module.objects.filter(mnt_date = mnt_date, mnt_machinename = mnt_machinename).update(
                    mnt_oilfilter_clogge=mnt_oilfilter_clogge,
                    mnt_lubrication=mnt_lubrication,
                    mnt_hydraulic=mnt_hydraulic,
                    mnt_pumpstatus=mnt_pumpstatus,
                    mnt_time=mnt_time,
                    mnt_oilfilter_motor=mnt_oilfilter_motor)
                
            else:
                item = maintenance_module(
                                mnt_date=mnt_date,
                                mnt_machinename=mnt_machinename,
                                mnt_oilfilter_clogge=mnt_oilfilter_clogge,
                                mnt_lubrication=mnt_lubrication,
                                mnt_hydraulic=mnt_hydraulic,
                                mnt_pumpstatus=mnt_pumpstatus,
                                mnt_time=mnt_time,
                                mnt_oilfilter_motor=mnt_oilfilter_motor
                                    )
                item.save()

        if Name == "Badpart data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            partcount = DateReq.get("partcount")
            Cavity = DateReq.get("Cavity")
            reason = DateReq.get("reason")
            date =  DateReq.get("date")
            time =  DateReq.get("time")

            try:

                all_RejectionParts_cal = badpart.objects.filter(
                        Plantname=Plantname,
                        Machinename=Machinename
                    ).values('Mouldname_id', 'partcount').order_by('id').last()
                
                last_Mouldname_id = all_RejectionParts_cal["Mouldname_id"]
                last_partcount = all_RejectionParts_cal["partcount"]

                if last_partcount != partcount or last_Mouldname_id != Mouldname_id:
                    item = badpart(
                                Plantname=Plantname,
                                Machinename=Machinename,
                                Mouldname_id=Mouldname_id,
                                partcount=partcount,
                                Cavity=Cavity,
                                reason=reason,
                                time=time,
                                date=date
                            )
                    item.save()

            except:
                if Mouldname_id != 0:
                    item = badpart(
                                    Plantname=Plantname,
                                    Machinename=Machinename,
                                    Mouldname_id=Mouldname_id,
                                    partcount=partcount,
                                    Cavity=Cavity,
                                    reason=reason,
                                    time=time,
                                    date=date
                                )
                    item.save()

        if Name == "Update Dashboard data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            machinestatus = DateReq.get("machinestatus")
            
            if Dashboard.objects.filter(Plantname = Plantname, Machinename = Machinename).exists():
                Dashboard.objects.filter(Plantname = Plantname, Machinename = Machinename).update(
                    machinestatus=machinestatus)

    return JsonResponse("Data Received Successfully", safe=False)