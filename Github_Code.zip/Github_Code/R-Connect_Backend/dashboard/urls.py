from django.urls import path
from .prefetch_dash import production_dashboards
from .datawrite import datar_w

urlpatterns = [
    path('production_dashboards', production_dashboards),
    path('datamaster/', datar_w),
]
