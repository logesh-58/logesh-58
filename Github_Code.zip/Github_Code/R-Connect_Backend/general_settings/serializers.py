from rest_framework import serializers
from general_settings.models import Timingtable

class TimingTableDbSerializer(serializers.ModelSerializer):
    class Meta:
        model = Timingtable
        fields = ['ttid','ttcode','ttplntname','ttdaystarttime','tts1time',
                  'tts2time','tts3time','ttlastupdate','ttcreatedby',       
                  'ttmodifiedby']