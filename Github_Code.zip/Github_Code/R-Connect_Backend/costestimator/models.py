from django.db import models
# Create your models here.
# class CostEstimationModel(models.Model):
#     ce_id=models.AutoField(primary_key=True)
#     ce_srcname = models.CharField(max_length=255, blank=True, null=True, default=False)
#     ce_unitcost = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
#     ce_plantname = models.CharField(max_length=255, blank=True, null=True, default=False)

class Cost_DG(models.Model):
    dg_id = models.AutoField(primary_key=True)
    dg_date = models.DateField()
    dg_desc = models.CharField(max_length=255, blank=True, null=True, default=False)
    dg_lit_cons = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    dg_lit_cpl = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)

class Cost_Solar(models.Model):
    solar_id = models.AutoField(primary_key=True)
    solar_installedCap = models.DecimalField(max_digits=20,decimal_places=2, blank=True)
    solar_cst = models.DecimalField(max_digits=20,decimal_places=2, blank=True)

class Cost_EB(models.Model):
    EB_id = models.AutoField(primary_key=True)
    EB_date = models.DateField()
    EB_Session = models.CharField(max_length=255, default=False, null=True)
    EB_SessionCost = models.DecimalField(max_digits=20, decimal_places=2, blank=True)   

class Cost_Wind(models.Model):
    Wind_id = models.AutoField(primary_key=True)
    Wind_month = models.CharField(max_length=255, default=False, null=True)
    Wind_percentage = models.DecimalField(max_digits=20, decimal_places=2, blank=True)
    Wind_cost = models.DecimalField(max_digits=20, decimal_places=2, blank=True, default=0)

class Cost_Petrol(models.Model):
    pt_id = models.AutoField(primary_key=True)
    pt_date = models.DateField()
    pt_lit_cons = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    pt_cpl = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)

class Cost_LPG(models.Model):
    LPG_id = models.AutoField(primary_key=True)
    LPG_date = models.DateField()
    LPG_kg_cons = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    LPG_cpkg = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)

class Cost_CNG(models.Model):
    CNG_id = models.AutoField(primary_key=True)
    CNG_date = models.DateField()
    CNG_kg_cons = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=False, default=False)
    CNG_cpkg = models.DecimalField(max_digits=20,decimal_places=2, blank=False, null=True, default=False)

class Cost_PNG(models.Model):
    PNG_id = models.AutoField(primary_key=True)
    PNG_date = models.DateField()
    PNG_kg_cons = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    PNG_cpkg = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    
# class cost_water(models.Model):
#     id = models.AutoField(primary_key = True)
#     wt_date = models.DateField()
#     wt_purpose = models.CharField(max_length=255, default=False, null=True)
#     wt_source = models.CharField(max_length=255, default=False, null=True)
#     wt_consumption = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
#     wt_cost = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)

class cost_water(models.Model):
    wt_id = models.AutoField(primary_key = True)
    wt_date = models.DateField()
    wt_source = models.CharField(max_length=255, default=False, null=True)
    wt_type = models.CharField(max_length=255, default=False, null=True)
    wt_consume = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
    wt_state = models.BooleanField(default=False, null=True)
    wt_cost = models.DecimalField(max_digits=20,decimal_places=2, blank=True, null=True, default=False)
