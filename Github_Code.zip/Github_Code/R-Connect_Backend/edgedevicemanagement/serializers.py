from edgedevicemanagement.models import AddEdgeDevice
from rest_framework import serializers

class EdgedeviceManagementSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddEdgeDevice
        fields = [
                  'aeedgedevicename',
                  'aedevicecode',
                  'aeapikey',
                  'aestatus',
                  'aelocation'
                  ]