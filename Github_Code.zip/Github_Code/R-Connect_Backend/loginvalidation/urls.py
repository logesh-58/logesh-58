from django.urls import path 
from loginvalidation import views

urlpatterns=[
    path('loginvalidation/',views.validateuser,name='login_validation')
]