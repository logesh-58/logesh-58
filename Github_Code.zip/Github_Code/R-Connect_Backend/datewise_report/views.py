from django.db import connection
from django.shortcuts import render
from django.http import HttpResponse
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from meter_data.models import Masterdatatable
# Create your views here.

@csrf_exempt
def reportgraph(request):
    plntname=request.GET['plantname']
    if request.method == 'POST':
        rcvd =  JSONParser().parse(request)  
        rtrntype = rcvd["type"]
        strttime = rcvd["starttime"]
        endtime = rcvd["endtime"]
        plntnme = rcvd["plantname"]
        mtrname = rcvd["mtrname"]
    #   print(rtrntype,strttime,endtime,plntnme)
        # sortedrow = Masterdatatable.objects.filter(mtdate=[str(strttime),str(endtime)],mtplntlctn=str(plntnme))
        # print(sortedrow)
        # data = Masterdatatable.objects.raw("SELECT*From meter_data_masterdatatable WHERE id=1")
        #Getting Hourly Energy Consumption data from the Database
        # print(rtrntype)
        hourlyec_list=[]
        group_list=[]
        ec_sumlist=[]
        meter_list=[]
        mtrngrp_list=[]
        date_list=[]
        allmtrdict=[]
        allmtrdictcmp1=[]
        allmtrdictcmp2=[]
        #LOGIC TO GET THE TODAY AND LAST 24 HOURS ENERGY CONSUMPTION
        # if (rtrntype=='Today' or rtrntype=='Last 24Hours') and (mtrname != ""):
        #     print((rtrntype=='Today' or rtrntype=='Last 24Hours') and (mtrname != ""))
        #     plantquery="(mtplntlctn='"+plntnme+"')"
        #     datequery="(mtdate BETWEEN '"+strttime+"' AND '"+endtime+"')"
        #     mtrnmequry="(mtmtrname='"+mtrname+"')"
        #     # print(plantquery)
        #     # print(datequery)
        #     sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+plantquery+" AND "+mtrnmequry
        #     # print(sql)
        #     for s in Masterdatatable.objects.raw(sql):
        #         # print(s.mth1ec)
        #         hourlyec_list.extend([float(s.mth1ec),float(s.mth2ec),float(s.mth3ec),float(s.mth4ec),float(s.mth5ec),float(s.mth6ec),float(s.mth7ec),float(s.mth8ec),
        #                             float(s.mth9ec),float(s.mth10ec),float(s.mth11ec),float(s.mth12ec),float(s.mth13ec),float(s.mth14ec),float(s.mth15ec),float(s.mth16ec),
        #                             float(s.mth17ec),float(s.mth18ec),float(s.mth19ec),float(s.mth20ec),float(s.mth21ec),float(s.mth22ec),float(s.mth23ec),
        #                             float(s.mth24ec)])
                # print(connection.queries)    
            # print(hourlyec_list)
        #LOGIC TO GET THIS WEEK, THIS MONTH, THIS YEAR AND LAST 7DAYS ENERGY CONSUMPTION
        if (rtrntype =='This week' or rtrntype =='This month' or rtrntype =='This year' or rtrntype =='last 7 days' or rtrntype == 'Today' or rtrntype == 'Yesterday' or rtrntype == 'last 30days' or rtrntype == 'Last 12months'):
            # print(rtrntype)
            # print(meterdashboarddata)
            metername=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtmtrname','mtgrpname').distinct()
            # print(groupname)
            for i in metername:
                meter_list.append(i["mtmtrname"])
            # for i in metername:
            #     mtrngrp_list.append({"name":i["mtmtrname"],"group":i["mtgrpname"]})
            # metername_list = list(metername)
            # for index in range(len(metername_list)):
            #     for key in metername_list[index]:
            #         meter_list.append(metername_list[index][key])
            # print(meter_list)
            for metername in meter_list:
                # print(metername)
                meterquery="(mtmtrname='"+metername+"')"
                datequery="(mtdate BETWEEN '"+strttime+"' AND '"+endtime+"')"
                plantquery="(mtplntlctn='"+plntnme+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+meterquery+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                daywiselist=[]
                datelist=[]
                mtrdict=[]
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    daywiselist.append(float(s.mtenergycons))
                    datelist.append(str(s.mtdate))
                    # print(s.mtdate)
                    mtrdict.append({"date":str(s.mtdate),"energycons":float(s.mtenergycons)})
                # print(sum)
                allmtrdict.append({metername:mtrdict})
                ec_sumlist.append(daywiselist)
                date_list.append(datelist)
            # print(ec_sumlist)
            # print(allmtrdict)
        cmptype = rcvd["cmptype"]
        cmpstrtdate1 = rcvd["cmpstrtdate1"]
        cmpenddate1 = rcvd["cmpenddate1"]
        cmpstrtdate2 = rcvd["cmpstrtdate2"]
        cmpenddate2 = rcvd["cmpenddate2"]
        cmpplantname = rcvd["cmpplantname"]     
        cmpmetername = rcvd["cmpmetername"]
        #LOGIC FOR METER AND GROUP NAMES TO THE METERS
        metername=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtmtrname','mtgrpname').distinct()
            # print(groupname)
        for i in metername:
            meter_list.append(i["mtmtrname"])
        for i in metername:
            mtrngrp_list.append({"name":i["mtmtrname"],"group":i["mtgrpname"]})

        # print(cmptype,cmpstrtdate1,cmpenddate1,cmpstrtdate2,cmpenddate2,cmpplantname,cmpmetername)
        cmpmeter_list=[]
        cmp1_eclist=[]
        cmp2_eclist=[]
        #LOGIC TO GET THIS WEEK AND LAST WEEK ENERGY CONSUMPTION
        if (cmptype == 'This week over Last week' or cmptype == 'This month over Last month' or 
            cmptype == 'Today vs Yesterday' or cmptype == 'Last 24 Hrs over Previous 24 Hrs' or
            cmptype == 'Last 7 days over previous 7 days' or cmptype== 'Today vs Same day last week' or
            cmptype == 'This Year Over Last year' or cmptype=='Last 12 months over previous 12  months'):
            # print(cmptype)
            metername=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtmtrname','mtmtrname').distinct()
            # print(groupname)
            metername_list = list(metername)
            for index in range(len(metername_list)):
                for key in metername_list[index]:
                    cmpmeter_list.append(metername_list[index][key])
            # print(cmpmeter_list)
            for metername in cmpmeter_list:
                # print(metername)
                mtrnmequry="(mtmtrname='"+metername+"')"
                datequery="(mtdate BETWEEN '"+cmpstrtdate1+"' AND '"+cmpenddate1+"')"
                plantquery="(mtplntlctn='"+cmpplantname+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+mtrnmequry+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                daywiselist=[]
                datecmp1=[]
                cmp1dict=[]
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    daywiselist.append(float(s.mtenergycons))
                    cmp1dict.append({"date":str(s.mtdate),"energycons":float(s.mtenergycons)})
                # print(sum)
                allmtrdictcmp1.append({metername:cmp1dict})
                cmp1_eclist.append(daywiselist)
            for metername in cmpmeter_list:
                # print(groupname)
                mtrnmequry="(mtmtrname='"+metername+"')"
                datequery="(mtdate BETWEEN '"+cmpstrtdate2+"' AND '"+cmpenddate2+"')"
                plantquery="(mtplntlctn='"+cmpplantname+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+mtrnmequry+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                daywiselist=[]
                cmp2dict=[]
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    daywiselist.append(float(s.mtenergycons))
                    cmp2dict.append({"date":str(s.mtdate),"energycons":float(s.mtenergycons)})
                # print(sum)
                allmtrdictcmp2.append({metername:cmp2dict})
                cmp2_eclist.append(daywiselist)
                # print("Chart Running")
            # print(cmp1_eclist,cmp2_eclist,cmpmeter_list)
            #LOGIC TO APPEND THE LIST FOR COMPARE METERS
            # cmpallmtrdict=[]
            # for metername in meter_list:
            #     i=0
            #     cmpmtrdict=[]
            #     for ecindmtrarr in cmp1_eclist:
            #         j=0
            #         for ec in ecindmtrarr:
            #             mtrdict.append({"date":str(s.mtdate),"energycons1":float(s.mtenergycons),
            #                             "energycons2":})
            #             j=j+1
            #         i=i+1
        mydict={"mtrname":mtrngrp_list,"scheduledchart": allmtrdict,"comparisonchart1":{"cmpmtrname":cmpmeter_list,
                "cmpmtr1ec":allmtrdictcmp1,"cmpmtr2ec":allmtrdictcmp2}}
    return JsonResponse(mydict, status=200,safe=False)

