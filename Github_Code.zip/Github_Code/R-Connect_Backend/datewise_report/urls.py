from django.conf.urls import url
from datewise_report import views

urlpatterns=[
    url('reportgraph/',views.reportgraph,name='reportgraph')
]