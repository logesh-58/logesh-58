from django.http import JsonResponse
from meter_data.models import Masterdatatable
from source_management.models import AddSource
from datetime import datetime , date, timedelta
from group_management.models import AddGroup
from meter_management.models import AddMeter
from django.views.decorators.csrf import csrf_exempt
from workflow_dashboard.models import WorkflowData
# import plotly.graph_objects as go
import pandas 
from django.db.models import Sum as add

# Create your views here.
@csrf_exempt
def sankey_fun (request):
    Plantname = WorkflowData.objects.values('wfplantname').last()
    for i in Plantname:
        Plantname = (Plantname[i])
    # current_date = date.today()
    current_date = '2023-05-22'
    nodes = []
    nodes.append({"name": "Total Consumption"})
    masterdata   = []; meter_link = []; masterdata_cur = [] ; masterdata_next = []; group_link = []; source_link = []; link = []; after_list = []
    sourcenames = AddSource.objects.filter(asplantname=Plantname).distinct('assourcename').values('assourcename')
    groupnames = list(AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname'))
    meternames_nodes = AddMeter.objects.distinct('ammetername').values('ammetername')
#    total_consumption_MTR = 0; total_consumptions_GRP = 0; total_consumptions_SRC = 0
    for src_nod in sourcenames:
       nodes.append({"name":src_nod['assourcename']})
#   
    for src_nme in sourcenames:
        Total_consumption = Masterdatatable.objects.filter(mtdate = current_date, mtcategory = 'Secondary', mtgrpname = 'Incomer', mtsrcname = src_nme['assourcename']).aggregate((add('mtenergycons')))
        #print(src_nme['assourcename'], Total_consumption)
        link.append({"source": 'Total_consumption', "target":src_nme['assourcename'], "value":Total_consumption['mtenergycons__sum']})
    for src_nme in sourcenames:
        for grp_nme in groupnames:
            if grp_nme['aggroupname'] != 'Incomer' and src_nme['assourcename'] == 'Transformer1':
                group_consumption = Masterdatatable.objects.filter(mtdate = current_date, mtcategory = 'Secondary', mtgrpname = grp_nme['aggroupname'], mtsrcname = src_nme['assourcename']).aggregate((add('mtenergycons')))
                link.append({"source":"Incomer", "target":grp_nme['aggroupname'], "value":group_consumption['mtenergycons__sum']})
    
    for grp_nme in groupnames:
        if grp_nme['aggroupname'] != 'Incomer':
            meternames =  AddMeter.objects.filter(ammetergroup = grp_nme['aggroupname']).distinct('ammetername').values('ammetername')
            for mtr_nme in meternames:
                meter_consumption = Masterdatatable.objects.filter(mtdate = current_date, mtmtrname = mtr_nme['ammetername'], mtcategory = 'Secondary', mtgrpname = grp_nme['aggroupname'], mtsrcname = 'Transformer1').aggregate((add('mtenergycons')))
                link.append({"source":grp_nme['aggroupname'], "target":mtr_nme['ammetername'], "value":meter_consumption['mtenergycons__sum']})
            
    nodes.append({"name": "Incomer"})
    
    for grp_nod in groupnames:
      if grp_nod['aggroupname'] != 'Incomer':
        nodes.append({"name":grp_nod['aggroupname']})

    for mtr_nod in meternames_nodes:
        nodes.append({"name":mtr_nod['ammetername']})
        
    empty_list = []; source_index = []; target_index = []; value_index = []
    for i in nodes:
        empty_list.append(i['name'])
    
    for v in link:
        value_index.append(v['value'])
    
    for i in sourcenames:
        source_index.append(empty_list.index('Total Consumption'))
        target_index.append(empty_list.index(i['assourcename']))
    
    for t in target_index:
        source_index.append(3)
        break

    for s in sourcenames:
        target_index.append(empty_list.index('Incomer'))
        break
    
    for grp_nod in groupnames:
      if grp_nod['aggroupname'] != 'Incomer':    
        source_index.append(empty_list.index('Incomer'))
        target_index.append(empty_list.index(grp_nod['aggroupname']))
    
 
    
    for grp_len in groupnames:
        if grp_len['aggroupname'] != 'Incomer':
            meter_index = AddMeter.objects.filter(ammetergroup = grp_len['aggroupname']).distinct('ammetername').values('ammetername')
            for mtr_nm in meter_index:
                target_index.append(empty_list.index(mtr_nm['ammetername']))
                source_index.append(empty_list.index(grp_len['aggroupname']))
    
    # print(empty_list)
    # print(source_index)
    # print(target_index)
    # print(value_index)
    
    # ##################################################################################################################################################################################

    # fig = go.Figure(data=[go.Sankey(node = dict(
    #     pad = 8,
    #     thickness = 10,
    #     line = dict(color = "yellow", width = 0.3),
    #     label = empty_list,
    #     color = "red"
    # ),
    # link = dict(
    #     source = source_index, # indices correspond to labels, eg A1, A2, A1, B1, ...
    #     target = target_index,
    #     value =  value_index
    # ))])
    # fig.update_layout(title_text="Energy Balancce", font_size=15)
    # fig.show()
    return JsonResponse({"node": nodes, "link":link}, safe=False)
   