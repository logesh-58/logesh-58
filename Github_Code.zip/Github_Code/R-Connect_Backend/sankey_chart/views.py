from django.http import JsonResponse
from meter_data.models import Masterdatatable
from source_management.models import AddSource
from datetime import datetime , date, timedelta
from group_management.models import AddGroup
from meter_management.models import AddMeter
from django.views.decorators.csrf import csrf_exempt
from workflow_dashboard.models import WorkflowData
from django.db.models import Sum as add

# Create your views here.
@csrf_exempt
def sankey_fun (request):
   Plantname = request.GET['plantname']   
   current_date = date.today()
   link = []; nodes = []
   nodes.append({"name": "Total Consumption"})
   sourcenames = AddSource.objects.filter(asplantname=Plantname).distinct('assourcename').values('assourcename')
   groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
   meternames = AddMeter.objects.distinct('ammetername').values('ammetername')
   node_groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
   for srcname in sourcenames:
      if srcname['assourcename'] == 'Transformer1':
         node_srcnm = 'Transformer'
         nodes.append({"name": node_srcnm})
         link.append({"source":"Total Consumption",
                     "target":node_srcnm,
                     "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
      else:
         nodes.append({"name": srcname['assourcename']})
         link.append({"source":"Total Consumption",
                     "target":srcname['assourcename'],
                     "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
   for data in node_groupnames:
      if data['aggroupname'] != 'Incomer':
         nodes.append({"name":data['aggroupname']})
   for srcname in sourcenames:
      if srcname['assourcename'] == 'Transformer1':
         node_srcnm = 'Transformer'
         for grupnme in groupnames:
            if grupnme['aggroupname'] != 'Incomer':
               link.append({"source":node_srcnm,
                           "target":grupnme['aggroupname'],
                           "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
      else:
         for grupnme in groupnames:
            if grupnme['aggroupname'] != 'Incomer':
               link.append({"source":srcname['assourcename'],
                           "target":grupnme['aggroupname'],
                           "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
   for grupnme in groupnames:
     meternames = AddMeter.objects.filter(ammetergroup = grupnme ['aggroupname']).distinct('ammetername').values('ammetername')
     if grupnme['aggroupname'] != 'Incomer':
         for mtrnme in meternames:
            if mtrnme['ammetername'] != 'Elite500':
               nodes.append({"name": mtrnme['ammetername']})
               link.append({"source":grupnme['aggroupname'],
                           "target":mtrnme['ammetername'],
                           "value":Masterdatatable.objects.filter(mtdate = current_date, mtgrpname = grupnme['aggroupname'], mtmtrname = mtrnme['ammetername'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
   return JsonResponse({"node": nodes, "link":link}, safe=True)
