from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from meter_management.models import AddMeter
from meter_management.serializers import MeterManagementdbSerializer
# from .forms import AddMeter

# Create your views here.
@csrf_exempt
def addmeter(request):
    plntname=request.GET['plantname']
    if request.method=="GET":
        metermanagement = AddMeter.objects.filter(amplantname=plntname).order_by('ammetercode')
        mmdbSerializer = MeterManagementdbSerializer(metermanagement,many=True)
        return JsonResponse(mmdbSerializer.data,safe=False)

    elif request.method=="POST":
        metermanagement_DBdata =  JSONParser().parse(request)
        mtrcode = metermanagement_DBdata["ammetercode"]
        getrow = AddMeter.objects.all()
        count=0
        for s in getrow:
            # print(s.ammetercode)
            if mtrcode == s.ammetercode:
                count=count+1

        if count == 0:
            metermanagemntSerializer = MeterManagementdbSerializer(data=metermanagement_DBdata, partial=True)
            if metermanagemntSerializer.is_valid():
                metermanagemntSerializer.save()
            return JsonResponse("Meter Management data saved to the db successfully",safe=False)
        else:
            return JsonResponse("Meter data alreay Exist",safe=False)

    elif request.method=="PUT":
        metermanagement_DBdata =  JSONParser().parse(request)
        AddMeter.objects.filter(ammetercode=metermanagement_DBdata["ammetercode"]).update(ammetername=metermanagement_DBdata["ammetername"],
                                                                                          ammetergroup=metermanagement_DBdata["ammetergroup"],
                                                                                          ammetersource=metermanagement_DBdata["ammetersource"],
                                                                                          ammetercategory=metermanagement_DBdata["ammetercategory"],
                                                                                          ammeterlocation=metermanagement_DBdata["ammeterlocation"],
                                                                                          amplantname=metermanagement_DBdata["amplantname"],
                                                                                          amconsiderbool=metermanagement_DBdata["amconsiderbool"])

        return JsonResponse("Meter Management data updated to the db successfully",safe=False)

    elif request.method=="DELETE":
        Dbdata= JSONParser().parse(request)
            # print(Dbdata["code"])
        AddMeter.objects.filter(ammetercode=Dbdata["code"]).delete()

        return JsonResponse("Meter Record Deleted Successfully",safe=False)
