from machinemanagement import views
from django.urls import path


urlpatterns=[
    path('machinemanagement/',views.machine,name="machinemanagement"),
]
