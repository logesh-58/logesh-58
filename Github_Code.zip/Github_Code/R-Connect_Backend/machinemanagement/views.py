from django.http.response import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import AddMachine
from .serializers import MachineManagementSerializer
import json

@csrf_exempt
def machine(request):
    if request.method == "GET":
        Plantname = request.GET['Plantname']
        machinedata = AddMachine.objects.filter(amPlantname = Plantname).all().order_by('amid')
        machinedataserializer=MachineManagementSerializer(machinedata, many=True)
        return JsonResponse(machinedataserializer.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET.get('Plantname')  # Use .get() to avoid KeyError
        if not Plantname:
            return JsonResponse({'error': 'Invalid Plantname'}, status=400)

        data = json.loads(request.body)

        required_fields = [
            'ammachinecode', 'amMachinename', 'ammachinelocation', 
            'ammachineimage', 'amconsiderbool', 'ambarelzonecount', 'amhrtczonecount'
        ]

        # Check if any required field is missing or None
        if any(field not in data or data[field] in [None, ""] for field in required_fields):
            return JsonResponse({'error': 'Invalid data, all fields are required'}, status=400)
        
        machinecode = data['ammachinecode']
        Machinename = data['amMachinename']
        machinelocation = data['ammachinelocation']
        machineimage = data['ammachineimage']
        considerbool = data['amconsiderbool']
        barelzonecount = data['ambarelzonecount']
        hrtczonecount = data['amhrtczonecount']
        
        # Check if machinecode already exists
        if AddMachine.objects.filter(ammachinecode=machinecode).exists():
            return JsonResponse({'error': 'Data already exists.'}, status=400)
        
        # Save new machine
        # amboolvalue = 1 if barelzonecount is not None and barelzonecount != 0 else 0
        
        ins = AddMachine(
            ammachinecode=machinecode,
            amMachinename=Machinename,
            ammachinelocation=machinelocation,
            amPlantname=Plantname,
            amconsiderbool=considerbool,
            ammachineimage=machineimage,
            ammachineip='None',
            ambarelzonecount=barelzonecount,
            amhrtczonecount = hrtczonecount
            # amboolvalue=amboolvalue  # Assuming amboolvalue is a model field
        )
        ins.save()
        
        return JsonResponse({'message': 'Data saved successfully'}, status=201)
    
    if request.method == 'PUT':
        Plantname = request.GET.get('Plantname')  # Use .get() to avoid KeyError
        data = request.body
        httpdata = json.loads(data)
        
        machinecode = httpdata.get('ammachinecode')
        Machinename = httpdata.get('amMachinename')
        machinelocation = httpdata.get('ammachinelocation')
        machineimage = httpdata.get('ammachineimage')
        considerbool = httpdata.get('amconsiderbool')
        barelzonecount = httpdata.get('ambarelzonecount')
        machineip = httpdata.get('ammachineip')
        hrtczonecount = httpdata.get('amhrtczonecount')
        
        # Check if machine exists before updating
        if AddMachine.objects.filter(ammachinecode=machinecode).exists():
            # amboolvalue = 1 if barelzonecount is not None and barelzonecount != 0 else 0
            
            AddMachine.objects.filter(ammachinecode=machinecode).update(
                amMachinename=Machinename,
                ammachinelocation=machinelocation,
                amPlantname=Plantname,
                amconsiderbool=considerbool,
                ammachineimage=machineimage,
                ammachineip=machineip,
                ambarelzonecount=barelzonecount,
                amhrtczonecount = hrtczonecount
                # amboolvalue=amboolvalue  # Assuming amboolvalue is a model field
            )
            return JsonResponse({'message': 'Data updated successfully'}, status=200)
        else:
            return JsonResponse({'error': 'Failed to update data'}, status=404)

    if request.method == 'DELETE':
        data = request.body
        httpdata  = json.loads(data)
        machinecode  = httpdata['code']
        if(AddMachine.objects.filter(ammachinecode = machinecode).exists()):
            AddMachine.objects.filter(ammachinecode = machinecode).delete()
            return JsonResponse('Data deleted successfully', safe=False)
        else:
            return JsonResponse('Failed to delete data', safe=False)
