from itertools import count
from django.db import models
from django.db.models.aggregates import Sum
from django.shortcuts import render
from django.http import HttpResponse
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from meter_data.models import Masterdatatable
from meter_data.serializers import MasterTableDbSerializer
from django.db.models import Sum
from rest_framework.parsers import JSONParser
from datetime import timedelta , datetime
from general_settings.models import Timingtable
from source_management.models import AddSource
from costestimator.models import  Cost_DG, Cost_EB, Cost_Solar, Cost_Wind
from overview_dashboard.monthcost import totalcost
import pandas as pd
# Create your views here.
@csrf_exempt
def overviewdata(request):
    plntname=request.GET['plantname']
    timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
    s1string = ''
    global s1time, s2time, s3time, avg_freq
    avg_freq=0
    for s in timingtblrow:
        dailyreporttime = s["ttdaystarttime"]
        s1time = s["tts1time"]
        s2time = s["tts2time"]
        s3time = s["tts3time"]
    s1string = s1time.strftime('%H')
    s1hrint = int(s1string)
    current_time = datetime.now()
    # print(current_time)
    # Subtract 2 hours from datetime object containing current time
    past_time = current_time - timedelta(hours=s1hrint)
    # Convert datetime object to string in specific format 
    past_time_str = past_time.strftime('%Y-%m-%d')
    #Overvie Dashboar GET Method
    if request.method == 'GET':
        distgroupname=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtgrpname').distinct()
        distgroupname_list=list(distgroupname)
        #LOGIC TO GET THE GROUPWISE ENERGY CONSUMPTION OF THE METERS
        emission_list = []
        groupeng_list=[]
        for index in range(len(distgroupname_list)):
            for key in distgroupname_list[index]:
                matchrow=Masterdatatable.objects.filter(mtgrpname=distgroupname_list[index][key],mtplntlctn=plntname,mtcategory="Secondary",mtdate=past_time_str).values("mtenergycons")
                groupenergy=list(matchrow)
                total = 0.00
                for instance in groupenergy:
                    total= total + float(instance["mtenergycons"])
                groupeng_list.append(round(total,0))
                emission_list.append(round(total * 0.7132))
        #LOGIC TO GET THE DISTINCT GROUP NAME'S
        group_list=[]
        for index in range(len(distgroupname_list)):
            for key in distgroupname_list[index]:
                group_list.append(distgroupname_list[index][key])

        #LOGIC TO GET THE TOTAL ENERGY CONSUMED BY THE PLANT ON CURRENT DAY
        plantmtrs=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary",mtgrpname='Incomer', mtdate=past_time_str).values("mtenergycons")
        plantec_list=list(plantmtrs)
        plantec=0.00
        for instance in plantec_list:
            plantec= plantec + float(instance["mtenergycons"])
            # print(plantec)
        #LOGIC TO GET THE POWER FACTOR OF THE METER'S CONNECTED TO THE PLANT
        current_date = ((datetime.today()).date())
        try:
            mtrpfctrrow=Masterdatatable.objects.get(mtdate = current_date, mtsrcname='Transformer1',mtgrpname='Incomer',mtcategory="Secondary")
            avgpfctr = round(mtrpfctrrow.mtpwrfctr, 2)
            max_demands = round(mtrpfctrrow.mtmaxdemands, 0)
            avg_freq = round(mtrpfctrrow.mtavgfreq,1)
        except Exception as Error:
            avgpfctr = 0 ; max_demands = 0; avg_freq=0
        print(avgpfctr, max_demands)
            
        yesterday = Masterdatatable.objects.filter(mtdate = current_date - timedelta(days = 1),mtsrcname='Transformer1', mtcategory="Secondary",mtgrpname='Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            yesterday_data = (round(yesterday['mtenergycons__sum'], 1))
        except:
            yesterday_data = 0
            
        # Calculate the start and end of the current week
        week_date = datetime.now().date()
        # print(week_date)
        start_of_week = week_date - timedelta(days=week_date.weekday())
        end_of_week = start_of_week + timedelta(days=6)
        # print(start_of_week, end_of_week)
        weekly_energy = Masterdatatable.objects.filter(mtdate__range = (start_of_week, end_of_week),mtsrcname='Transformer1', mtcategory="Secondary",mtgrpname='Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            weekly_energy_data = (round(weekly_energy['mtenergycons__sum'], 1))
        except:
            weekly_energy_data = 0
        # print(weekly_energy_data)
        
        # Find the first day of the current month
        first_day_of_month = current_date.replace(day=1)
        if current_date.month == 12:
            last_day_of_month = current_date.replace(year=current_date.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            last_day_of_month = current_date.replace(month=current_date.month + 1, day=1) - timedelta(days=1)
        # print(first_day_of_month, last_day_of_month)
        
        monthly_energy = Masterdatatable.objects.filter(mtdate__range = (first_day_of_month, last_day_of_month),mtsrcname='Transformer1', mtcategory="Secondary",mtgrpname='Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            monthly_energy_data = (round(monthly_energy['mtenergycons__sum'], 1))
        except:
            monthly_energy_data = 0

        #LOGIC TO GET THE SHIFT-WISE ENERGY CONSUMPTION OF GROUPWISE METERS
        s1eng_list=[]
        s2eng_list=[]
        s3eng_list=[]
        for index in range(len(distgroupname_list)):
            for key in distgroupname_list[index]:
                matchrow=Masterdatatable.objects.filter(mtgrpname=distgroupname_list[index][key],mtplntlctn=plntname,mtdate=past_time_str,mtcategory="Secondary").values("mts1ec","mts2ec","mts3ec")
                groupenergy=list(matchrow)
                totals1 = 0.00
                totals2 = 0.00
                totals3 = 0.00
                for instance in groupenergy:
                    try: 
                        totals1= totals1 + float(instance["mts1ec"])
                    except:
                        pass
                    try:
                        totals2=totals2 + float(instance["mts2ec"])
                    except:
                        pass
                    try:
                        totals3=totals3 + float(instance["mts3ec"])
                    except:
                        pass

                s1eng_list.append(round(totals1, 0))
                s2eng_list.append(round(totals2, 0))
                s3eng_list.append(round(totals3, 0))
        # LOGIC TO GET SECTOR OR SOURCE NAME'S
        distsrcname=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtsrcname').distinct()
        distsrc_list=list(distsrcname)
        src_names=[]
        for index in range(len(distsrc_list)):
            for key in distsrc_list[index]:
                src_names.append(distsrc_list[index][key])
        # LOGIC TO GET THE SOURCE-WISE ENERGY CONSUMPTION
        src_ec=[]
        for index in range(len(distsrc_list)):
            for key in distsrc_list[index]:
                matchrow=Masterdatatable.objects.filter(mtsrcname=distsrc_list[index][key],mtplntlctn=plntname,mtdate=past_time_str,mtcategory="Secondary",mtgrpname='Incomer').values("mtenergycons")
                srcenergy=list(matchrow)
                total = 0.00
                for instance in srcenergy:
                    total= total + float(instance["mtenergycons"])
                src_ec.append(round(total, 0))
        #LOGIC TO GET THE SHIFT-WISE ENERGY CONSUMPTION OF DIFFERENT SOURCE METER'S
        srcs1eng_list=[]
        srcs2eng_list=[]
        srcs3eng_list=[]
        for index in range(len(distsrc_list)):
            for key in distsrc_list[index]:
                matchrow=Masterdatatable.objects.filter(mtsrcname=distsrc_list[index][key],mtplntlctn=plntname,mtdate=past_time_str,mtcategory="Secondary").values("mts1ec","mts2ec","mts3ec")
                srcenergy=list(matchrow)
                totals1 = 0.00
                totals2 = 0.00
                totals3 = 0.00
                for instance in srcenergy:
                    try: 
                        totals1= totals1 + float(instance["mts1ec"])
                    except:
                        totals1=0.00
                    try:
                        totals2=totals2 + float(instance["mts2ec"])
                    except:
                        totals2=0.00
                    try:   
                        totals3=totals3 + float(instance["mts3ec"])
                    except:
                        totals3=0.00
                    
                srcs1eng_list.append(round(totals1, 0))
                srcs2eng_list.append(round(totals2, 0))
                srcs3eng_list.append(round(totals3, 0))
                clckdgrp=distgroupname_list[0]
        #LOGIC TO GET THE CLICKED GROUP METERS LIST OF METER NAMES AND ENERGY CONSUMPTION
        try:
            if clckdgrp != " ":
                matchrow=Masterdatatable.objects.filter(mtgrpname=clckdgrp,mtplntlctn=plntname,mtdate=past_time_str,mtcategory="Secondary").values("mtenergycons","mtmtrname")
                clckdgrpeng=list(matchrow)
                clckdgrpeng_list=[]
                clckdgrpnme_list=[]
                for instance in clckdgrpeng:
                    clckdgrpeng_list.append(float(instance["mtenergycons"]))
                    clckdgrpnme_list.append(instance["mtmtrname"])
        except:
            clckdgrpnme_list=""
            clckdgrpeng_list=""
        #LOGIC TO GET THE METER DETAILS FOR THE NEW FORMAT
        clckrow=Masterdatatable.objects.filter(mtplntlctn=plntname,mtdate=past_time_str,mtcategory="Secondary").values("mtmtrname","mtgrpname","mtenergycons")
        clckdrowlist=list(clckrow)
        grpmtrname_list=[]
        for instance in clckdrowlist:
            emission = (round(float(instance['mtenergycons']) * 0.7132, 2))
            grpmtrname={"metername":instance["mtmtrname"],"metergroup":instance["mtgrpname"],"EnergyConsumed":round(instance["mtenergycons"], 2), "Emission": emission}
            grpmtrname_list.append(grpmtrname)
        #------------------------------------------------------
        month_number = int((datetime.now()).strftime("%m"))
        try:
            windpercent = int((list(Cost_Wind.objects.filter(Wind_month = month_number).values('Wind_percentage'))[0])['Wind_percentage'])
            # print(windpercent)
        except:
            windpercent =0

        start_date = datetime.today().replace(day=1).date()
        end_date = datetime.now().date()
        # print(start_date, end_date)
        srcenergylist = []
        sourcedict = {}
        EBValue = 0
        DGCost_Value = 0
        SolarCost_Value = 0
        DGCost_data = Cost_DG.objects.filter(dg_date__gte=start_date, dg_date__lt=end_date).values('dg_lit_cons', 'dg_lit_cpl')
        for dg_data in list(DGCost_data):
            # print(dg_data)
            DGCost_Value += (dg_data['dg_lit_cons'] * dg_data['dg_lit_cpl'])
        
        for sourcename in distsrc_list:
            # print(sourcename['mtsrcname']) 
            if (sourcename['mtsrcname'] != 'Transformer1'):
                Energydata = Masterdatatable.objects.filter(mtdate__gte=start_date,mtdate__lte=end_date,mtcategory="Secondary", mtsrcname=sourcename['mtsrcname']).values('mtenergycons').aggregate(Sum('mtenergycons'))
                try: 
                    sourcedict[sourcename['mtsrcname'] ]= int(Energydata['mtenergycons__sum'])
                except: 
                    sourcedict[sourcename['mtsrcname'] ] =0
            if (sourcename['mtsrcname'] == 'Transformer1'):            
                Energydata = Masterdatatable.objects.filter(mtdate__gte=start_date,mtdate__lte=end_date,mtcategory="Secondary",mtgrpname='Incomer', mtsrcname=sourcename['mtsrcname']).values('mtdate','mtmtrname','mtenergycons')
                for data in list(Energydata):
                    EBValue += round(data['mtenergycons'], 0)
                # print(EBValue)
                sourcedict[sourcename['mtsrcname'] ]= int(EBValue)
        # print(sourcedict)
        try:
            SolarCost_Value = ((Cost_Solar.objects.values('solar_cst').last())['solar_cst'])* (sourcedict['Solar Energy'])
        except:
            SolarCost_Value = 0
        sourcedict['DGCost'] = round(DGCost_Value,0)
        sourcedict['SolarCost'] = round(SolarCost_Value, 0)
        sourcedict['Wind'] = round(((EBValue * windpercent )/100), 0)
        eb_cost = totalcost()
        sourcedict['Transformer1'] = int(EBValue) - int((EBValue * windpercent )/100)
        sourcedict['WindCost'] = int((eb_cost * windpercent)/100)
        sourcedict['EBCost'] = int(eb_cost) - int((eb_cost * windpercent)/100)
        
        mtaprtpwr1 = 0; mtaprtpwr2 = 0; mtaprtpwr3 = 0; mtlv1 = 0; mtlv2 = 0; mtlv3= 0; mtlc1 = 0; mtlc2 = 0; mtlc3 = 0; mtrealpwr1 = 0; mtrealpwr2 = 0; mtrealpwr3 = 0; mtrctpwr1 = 0; mtrctpwr2 = 0; mtrctpwr3 = 0; mtTHDC1 = 0; mtTHDC2 = 0; mtTHDC3 = 0; mtTHDL1= 0; mtTHDL2 = 0; mtTHDL3 = 0
        
        apparentpower = list(Masterdatatable.objects.filter(mtdate = current_date, mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1').values('mtaprtpwr1', 'mtaprtpwr2', 'mtaprtpwr3', 'mtlv1', 'mtlv2', 'mtlv3', 'mtlc1', 'mtlc2', 'mtlc3', 'mtrealpwr1', 'mtrealpwr2', 'mtrealpwr3', 'mtrctpwr1', 'mtrctpwr2', 'mtrctpwr3', 'mtTHDC1', 'mtTHDC2', 'mtTHDC3', 'mtTHDL1', 'mtTHDL2', 'mtTHDL3', 'mtpeakvolt', 'mtpeakcrnt', 'mttotalreactivepower', 'mttotalpower'))
        # print(apparentpower)
        for data1 in apparentpower:
            mtaprtpwr1 = (round(data1['mtaprtpwr1'], 1))
            mtaprtpwr2 = (round(data1['mtaprtpwr2'], 1))
            mtaprtpwr3 = (round(data1['mtaprtpwr3'], 1))
            mtlv1 = round(data1['mtlv1'], 1)
            mtlv2 = round(data1['mtlv2'], 1)
            mtlv3 = round(data1['mtlv3'], 1)
            mtlc1 = round(data1['mtlc1'], 1)
            mtlc2 = round(data1['mtlc2'], 1)
            mtlc3 = round(data1['mtlc3'], 1)
            mtrealpwr1 = round(data1['mtrealpwr1'], 1)
            mtrealpwr2 = round(data1['mtrealpwr2'], 1)
            mtrealpwr3 = round(data1['mtrealpwr3'], 1)
            mtrctpwr1 = round(data1['mtrctpwr1'], 1)
            mtrctpwr2 = round(data1['mtrctpwr2'], 1)
            mtrctpwr3 = round(data1['mtrctpwr3'], 1)
            mtTHDC1 = round(data1['mtTHDC1'], 1)
            mtTHDC2 = round(data1['mtTHDC2'], 1)
            mtTHDC3 = round(data1['mtTHDC3'], 1)
            mtTHDL1 = round(data1['mtTHDL1'], 1)
            mtTHDL2 = round(data1['mtTHDL2'], 1)
            mtTHDL3 = round(data1['mtTHDL3'], 1)
            mtpeakvolt = round(data1['mtpeakvolt'], 1)
            mtpeakcrnt = round(data1['mtpeakcrnt'], 1)
            mttotalreactivepower = round(data1['mttotalreactivepower'], 1)
            mttotalpower = round(data1['mttotalpower'], 1)
            
        
        # print(windenergy)
        #------------------------------------------------------
        mydict={"groupname":group_list,"groupec":groupeng_list,"groupemission":emission_list,"plantec":round(plantec, 1),"avgpwrfctr":abs(avgpfctr), "maxdemands":max_demands, "avg_freq":avg_freq
                ,"s1energy":s1eng_list,"s2energy":s2eng_list,"s3energy":s3eng_list,"srcname":src_names,"srcec":src_ec, "srcs1energy":srcs1eng_list,"srcs2energy":srcs2eng_list,"srcs3energy":srcs3eng_list, "grpmtrname":clckdgrpnme_list,"grpmtrec":clckdgrpeng_list,"grpmtrname":grpmtrname_list, "energydata":sourcedict, "weekEnergy": weekly_energy_data, "CurHar1": mtTHDC1, "CurHar2": mtTHDC2, "CurHar3": mtTHDC3, "VolHar1": mtTHDL1, "VolHar2": mtTHDL2, "VolHar3": mtTHDL3, "AppPwr1": mtaprtpwr1, "AppPwr2": mtaprtpwr2, "AppPwr3": mtaprtpwr3, "Recpwr1": mtrctpwr1, "Recpwr2": mtrctpwr2, "Recpwr3": mtrctpwr3, "TRecpwr":mttotalreactivepower, "totRelpwr": mttotalpower, "Relpwr1": mtrealpwr1, "Relpwr2": mtrealpwr2, "Relpwr3": mtrealpwr3, "totCur": mtpeakcrnt, "cur1": mtlc1, "cur2": mtlc2, "cur3": mtlc3, "totVol": mtpeakvolt, "vol1": mtlv1, "vol2": mtlv2, "vol3": mtlv3, "minpwrfctr": 0, "mindemands": 0, "totDemands": 0, "monthEnergy": monthly_energy_data, "yesterEnergy": yesterday_data }   
        return JsonResponse(mydict, safe=False)
