from django.db import models

# Create your models here.
class AddEdgeDevice(models.Model):
    aeid = models.AutoField(primary_key=True)
    aedevicecode = models.CharField(max_length=255,default=False,null=True)
    aeplantname = models.CharField(max_length=255, default=False, null=True)
    aeedgedevicename = models.CharField(max_length=255,default=False,null=True)
    aeapikey = models.CharField(max_length=255,default=False,null=True)
    aestatus = models.CharField(max_length=255,default=False,null=True)
    aelocation = models.CharField(max_length=255,default=False,null=True)