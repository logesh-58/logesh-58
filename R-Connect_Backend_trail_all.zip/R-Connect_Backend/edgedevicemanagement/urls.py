from django.conf.urls import url
from edgedevicemanagement import views

urlpatterns=[
    url('edgedevicemanagement/',views.edgedevice,name="edgedevicemanagement")
]