from django.shortcuts import render
from timeline.models import breakdown
import json 
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from django.db.models import Q
from timeline.time_line import shiftStarttime
# Create your views here.
@csrf_exempt
def down_time(request):
    if request.method == 'POST':
        user_data = json.loads(request.body)
        current_date = user_data['date']['date']
        machinename = user_data['machinename']['machinename']
        nexDate = str((datetime.strptime(current_date, '%Y-%m-%d') + timedelta(days = 1)).date())
        plntname=request.GET['Plantname']
        daystart = shiftStarttime(plntname)
        # print(yesterday, current_date, daystart, machinename)
        break_down = list(breakdown.objects.filter(Q(date = current_date, time__gte = str(daystart), Machinename = machinename, Plantname = plntname)|
                                              Q (date = nexDate, time__lte = str(daystart), Machinename = machinename, Plantname = plntname)).order_by('id').values())
        # print(break_down)
        user_response = []
        reason_list = [None,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Breakdown', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
        for dat0 in range(0, len(break_down)):
                if break_down[dat0]['MachineState'] == 0:
                    if break_down[dat0-1]['MachineState'] !=0:
                        for dat1 in range(dat0, len(break_down)):
                            if break_down[dat1]['MachineState'] == 1:
                                starttime =  break_down[dat0]['date'] + ' ' + break_down[dat0]['time']
                                endtime   =  break_down[dat1]['date'] + ' ' + break_down[dat1]['time']
                                frm_time = datetime.strptime(starttime, '%Y-%m-%d %H:%M:%S')
                                to_time  = datetime.strptime(endtime, '%Y-%m-%d %H:%M:%S')
                                idleminutes = (to_time - frm_time).total_seconds()
                                if idleminutes >= 300 and break_down[dat1]['primaryreason'] != 0:
                                    minutes = round((int(idleminutes)/60), 2)
                                    user_response.append({"Date":break_down[dat1]['date'], "Machinename":machinename, "IdleReason":reason_list[break_down[dat1]['primaryreason']], "ReasonNumber":break_down[dat1]['primaryreason'], "Idleminutes":minutes, "Time":str(break_down[dat0]['time']) +' - '+ str(break_down[dat1]['time'])})
                                break
        return JsonResponse(user_response, safe=False)