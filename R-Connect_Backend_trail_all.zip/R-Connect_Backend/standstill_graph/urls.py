from django.urls import path
from standstill_graph import views

urlpatterns=[
    path("standstill/", views.down_time, name="downtime")
]