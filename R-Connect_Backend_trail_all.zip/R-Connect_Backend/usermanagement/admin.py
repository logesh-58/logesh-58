from django.contrib import admin

# Register your models here.
from usermanagement.models import AddUser

admin.site.register(AddUser)