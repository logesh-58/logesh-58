from .models import AddUser
from rest_framework import serializers

class UserManagementDbSerializer(serializers.ModelSerializer):
    #table class
    class Meta:
        model = AddUser
        fields = '__all__'
class UserManagementSerializer(serializers.ModelSerializer):
    # my configuration class
    class Meta:
        model = AddUser
        fields = '__all__'