import re
from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from usermanagement.models import AddUser
from usermanagement.serializers import UserManagementDbSerializer,UserManagementSerializer
import json
import datetime


@csrf_exempt
def adduser(request):
    if request.method == "GET":
        Plantname = request.GET['Plantname']
        userdata=AddUser.objects.filter(udPlantname=Plantname).all().order_by('udid')
        userdataserializer=UserManagementDbSerializer(userdata,many=True)
        return JsonResponse(userdataserializer.data, safe=False)

    if request.method == 'POST':
        data = request.body
        httpdata  = json.loads(data)
        usercode  = httpdata['udusercode']
        username  = httpdata['udusername']
        usertype  = httpdata['udtype']
        firstname = httpdata['udfirstName']
        lastname  = httpdata['udlastName']
        email     = httpdata['udemail']
        location  = httpdata['udlocation']
        password  = httpdata['udpassword']
        confirmpassword = httpdata['udconfirmpassword']
        Plantname = httpdata['udPlantname']

        if AddUser.objects.filter(udusercode=usercode,udPlantname=Plantname).exists() or AddUser.objects.filter(udemail=email,udPlantname=Plantname).exists():
            return JsonResponse('Data already exist..', safe=False)    

        else:
            ins = AddUser(
                udusercode = usercode,
                udusername = username,
                udtype     = usertype,
                udfirstName = firstname,
                udlastName  = lastname,
                udemail     = email,
                udpassword  = password,
                udconfirmpassword = confirmpassword,
                udlocation = location,
                udPlantname  = Plantname
            )
            ins.save()
            return JsonResponse('Data saved successfully', safe=False)
    
    if request.method == 'PUT':
        
        data = request.body
        httpdata  = json.loads(data)
        usercode  = httpdata['udusercode']
        username  = httpdata['udusername']
        usertype  = httpdata['udtype']
        firstname = httpdata['udfirstName']
        lastname  = httpdata['udlastName']
        email     = httpdata['udemail']
        location  = httpdata['udlocation']
        password  = httpdata['udpassword']
        confirmpassword = httpdata['udconfirmpassword']
        Plantname = httpdata['udPlantname']

        if(AddUser.objects.filter(udusercode = usercode,udPlantname=Plantname).exists()):
            AddUser.objects.filter(udusercode = usercode).update(
                udusername = username,
                udtype     = usertype,
                udfirstName = firstname,
                udlastName  = lastname,
                udemail     = email,
                udpassword  = password,
                udconfirmpassword = confirmpassword,
                udlocation = location,
                udPlantname  = Plantname
            )
            return JsonResponse('Data updated successfully', safe=False)
        else:
            return JsonResponse('Failed to update data', safe=False)

    if request.method == 'DELETE':
        data = request.body
        httpdata = json.loads(data)
        deldata = httpdata['code']
        if(AddUser.objects.filter(udusercode = deldata).exists()):
            AddUser.objects.filter(udusercode = deldata).delete()
            return JsonResponse('Data deleted successfully', safe=False)
        else:
            return JsonResponse('Failed to delete data', safe=False)
