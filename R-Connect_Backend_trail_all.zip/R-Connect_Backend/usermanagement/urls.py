from django.urls import path
from usermanagement import views

urlpatterns=[
    path('usermanagement/',views.adduser,name="usermanagement_management"),
    # url('getuser/',views.getuser,name="usermanagement_management")
]