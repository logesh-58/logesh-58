from django.db import models
from mouldmanagement.models import Mouldmodel

# Create your models here.

class Dashboard(models.Model):
    id                      = models.AutoField(primary_key=True)
    datetime                = models.DateTimeField(null=True)
    Plantname               = models.CharField(max_length=255, default=False, null=True)
    Machinename             = models.CharField(max_length=255, default=False, null=True)
    Mouldname               = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    MachineState            = models.IntegerField(default=False, null=True)
    Alarm                   = models.IntegerField(default=False, null=True)
    ProductionTimeActual    = models.DecimalField(max_digits=999, decimal_places=3, default=False, null=True)
    ProductionTimeTotal     = models.DecimalField(max_digits=999, decimal_places=3, default=False, null=True)
    CycletimeActual         = models.DecimalField(max_digits=999, decimal_places=3, default=False, null=True)
    CycletimeSet            = models.DecimalField(max_digits=999, decimal_places=3, default=False, null=True)
    ProductionCountActual   = models.IntegerField(default=False, null=True)
    ProductionCountSet      = models.IntegerField(default=False, null=True)
    RejectionParts          = models.IntegerField(default=0)
    Cavity                  = models.IntegerField(default=1)
    mail_trigger            = models.BooleanField(default=False,null=True)
    maxcount_trigger        = models.BooleanField(default=False,null=True)
    machinestatus           = models.CharField(max_length=255, default=False, null=True)
