from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dashboard
from productiontable.models import ProductionTable
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from datetime import datetime, time, timedelta
import pytz
from django.db.models import Q, Min, Max, Count, F, Sum
from analysis.views import machineArray
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from timeline.models import breakdown, badpart

def delete_dashboarddata(Plantname):
    getMachines = machineArray(Plantname)
    for machine in getMachines:
        getis = Dashboard.objects.filter(Plantname = Plantname, Machinename = machine).values('id').order_by('id').last()
        try: Dashboard.objects.filter(Machinename = machine, id__lt = getis['id']).delete()
        except: continue
    return None

#Write Your Code Buddy
@csrf_exempt
def production_dashboards(request):
    if request.method=="GET":
        Plantname = request.GET['Plantname']
        API_list = []; dict = {}
        machinelist = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename', 'ammachineimage', 'amconsiderbool').order_by('amid')
        # current_date = (datetime.today()).date()
        current_date = "2023-04-26"
        print(current_date)
        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

        for machine_value in machinelist:

            Mac_Log = machine_value['amconsiderbool']

            if Mac_Log == True:

                machine_name  = machine_value['amMachinename']
                machine_image = machine_value['ammachineimage']
                dashboard_value  = Dashboard.objects.filter(Plantname = Plantname, Machinename = machine_name).values('Machinename', 'Mouldname_id', 'MachineState', 'Alarm', 'ProductionTimeActual', 'CycletimeActual', 'CycletimeSet', 'ProductionCountActual', 'RejectionParts', 'machinestatus').last()
                machine_status  = dashboard_value['machinestatus']
                ########################### Getting the Shift Start and End time #####################################
                # if ProductionTable.objects.filter(date = current_date, Plantname = Plantname, Machinename = machine_name, time__gte = shift_starttime).count() != 0:
                if ProductionTable.objects.filter(Plantname = Plantname, Machinename = machine_name, time__gte = shift_starttime).count() != 0:
                    if dashboard_value['ProductionTimeActual'] != 0:
                        ProductionTimeActual_minute = dashboard_value['ProductionTimeActual']
                        A_ProductionTimeActual_hour = dashboard_value['ProductionTimeActual'] / 60
                    else:
                        A_ProductionTimeActual_hour = 0
                        ProductionTimeActual_minute = 0
                    Mouldname_id  = dashboard_value['Mouldname_id']
                    Mouldname     = Mouldmodel.objects.get(id = Mouldname_id).Mouldname
                    MachineState  = dashboard_value['MachineState']
                    Alarm = int(dashboard_value['Alarm'])
                    # try:
                    #     ProductionTimeTotal     = round(float(dashboard_value['ProductionTimeTotal']), 2)
                    # except:
                    #     ProductionTimeTotal  = 0
                    CycletimeActual         = float(dashboard_value['CycletimeActual'])
                    CycletimeSet            = float(dashboard_value['CycletimeSet'])
                    ProductionCountActual   = int(dashboard_value['ProductionCountActual'])
                    # ProductionCountSet      = int(dashboard_value['ProductionCountSet'])
                    # RejectionParts          = int(dashboard_value['RejectionParts'])
                    # RejectionParts = 0
                    
                    ################

                    ist_timezone = pytz.timezone('Asia/Kolkata')

                    # Get the current time in IST
                    # timenow_ist = datetime.now(ist_timezone).time()
                    timenow_ist_str = "23:59:24"
                    timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

                    print("Current IST time:", timenow_ist)
                    # Define the shift time ranges
                    shift_A_start = time(6, 0, 0)
                    shift_A_end = time(13, 59, 59)

                    shift_B_start = time(14, 0, 0)
                    shift_B_end = time(21, 59, 59)

                    shift_C_start = time(22, 0, 0)
                    shift_C_end = time(5, 59, 59)

                    # Determine the company shift
                    if shift_A_start <= timenow_ist <= shift_A_end:
                        company_shift = 'A'
                        time_shift = ['06:00:00', '13:59:59']
                    elif shift_B_start <= timenow_ist <= shift_B_end:
                        company_shift = 'B'
                        time_shift = ['14:00:00', '21:59:59']
                    # Special case for shift C, which spans over midnight
                    elif timenow_ist >= shift_C_start or timenow_ist <= shift_C_end:
                        company_shift = 'C'
                        time_shift = ['22:00:00', '05:59:59']
                    else:
                        company_shift = 0
                        time_shift = 0

                    print("Current Company Shift:", company_shift, "time_shift:", time_shift)
                    ################
                    if company_shift == 'C':
                        current_date_str = "2023-04-26"
                        current_date = datetime.strptime(current_date_str, "%Y-%m-%d").date()
                        next_date = current_date + timedelta(days=1)
                        previous_date = current_date - timedelta(days=1)

                        time_start = time(22, 0, 0)
                        time_end = time(23, 59, 59)

                        if time_start <= timenow_ist <= time_end:
                            saw = breakdown.objects.filter(
                                Q(date=current_date, time__range=['22:00:00', '23:59:59']) |
                                Q(date=next_date, time__range=['00:00:00', '05:59:59']),
                                    Machinename=machine_name,
                                    Plantname=Plantname
                                ).values('time', 'MachineState')
                            print("step1.....")
                            RejectionParts_calculate = badpart.objects.filter(
                                Q(date=current_date, time__range=['22:00:00', '23:59:59']) |
                                Q(date=next_date, time__range=['00:00:00', '05:59:59']), 
                                                        Plantname = Plantname, 
                                                        Machinename = machine_name).values('partcount').order_by('id').last()
                            print("step1111.....", RejectionParts_calculate)

                        else:
                            saw = breakdown.objects.filter(
                                Q(date=previous_date, time__range=['22:00:00', '23:59:59']) |
                                Q(date=current_date, time__range=['00:00:00', '05:59:59']),
                                    Machinename=machine_name,
                                    Plantname=Plantname
                                ).values('time', 'MachineState')
                            print("step2...")
                            RejectionParts_calculate = badpart.objects.filter(
                                Q(date=previous_date, time__range=['22:00:00', '23:59:59']) |
                                Q(date=current_date, time__range=['00:00:00', '05:59:59']), 
                                                        Plantname = Plantname, 
                                                        Machinename = machine_name).values('partcount').order_by('id').last()

                    else:
                        saw = breakdown.objects.filter(date=current_date, time__range= time_shift,
                                Machinename=machine_name,
                                Plantname=Plantname
                            ).values('time', 'MachineState')
                        
                        RejectionParts_calculate = badpart.objects.filter(date = current_date, Plantname = Plantname, 
                                                                Machinename = machine_name, time__range= time_shift).values('partcount').order_by('id').last()
                    
                    if RejectionParts_calculate is not None:
                        RejectionParts = RejectionParts_calculate.get('partcount', 0)
                    else:
                        RejectionParts = 0
                    print("RejectionParts:", RejectionParts)
                    # Calculate total idle time
                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                    ################
                    aggregated_data = ShiftProductiondata.objects.filter(
                                        sp_date=current_date,
                                        sp_plantname=Plantname,
                                        sp_machinename=machine_name
                                    ).aggregate(total_hoursss=Max('sp_shift'))
                    
                    aggregated_data2 = ShiftProductiondata.objects.filter(
                                        sp_date=current_date,
                                        sp_plantname=Plantname,
                                        sp_machinename=machine_name,
                                        sp_shift = company_shift
                                    ).aggregate(total_hours=Sum('sp_totalproductiontime'), count_set=Sum('sp_totalproduction'))
                    mac_hours = aggregated_data2['total_hours'] or 0
                    mac_counts = aggregated_data2['count_set'] or 0
                    print(machine_name, "mac_counts:", mac_counts, "mac_hours:", mac_hours)
                    shift = aggregated_data['total_hoursss']

                    print("machine:", machine_name, "shift:", shift)

                    if shift == 'A':
                        mac_hoursss = 8
                    elif shift == 'B':
                        mac_hoursss = 16
                    elif shift == 'C':
                        mac_hoursss = 24
                    else:
                        mac_hoursss = 0

                    ProductionTimeActual_hour = float(A_ProductionTimeActual_hour) - total_idle_time_hours

                    uptime_cal = mac_hoursss - total_idle_time_hours

                    try:
                        ProductionTimeTotal     = round(float(mac_hours), 2)
                    except:
                        ProductionTimeTotal  = 0
                    ################
                    try:
                        efficiency = ((ProductionCountActual/mac_counts)*(abs(ProductionCountActual-RejectionParts)/ProductionCountActual))*100
                        #---------------------
                        oee_availability = (float(ProductionTimeActual_hour)/mac_hours)*100
                        oee_performance = (ProductionCountActual/mac_counts)*100
                        oee_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                        oee = ((oee_availability / 100) * (oee_performance / 100) * (oee_quality / 100)) * 100
                        #---------------------
                        teep_availability = (float(ProductionTimeActual_hour)/24)*100
                        teep_performance = (ProductionCountActual/mac_counts)*100
                        teep_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                        teep = ((teep_availability / 100) * (teep_performance / 100) * (teep_quality / 100)) * 100
                        #---------------------
                        ooe_availability = (float(ProductionTimeActual_hour)/mac_hoursss)*100
                        ooe_performance = (ProductionCountActual/mac_counts)*100
                        ooe_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                        ooe = ((ooe_availability / 100) * (ooe_performance / 100) * (ooe_quality / 100)) * 100
                        #---------------------
                        Availability = (float(ProductionTimeActual_hour) / (mac_hours)) * 100
                        #---------------------
                        Uptime = (uptime_cal / 24) * 100
                        #---------------------
                        Utilization_Rate = (mac_hours / 24) * 100
                    except:
                        efficiency = 0
                        ooe = 0
                        teep = 0
                        oee  = 0
                        Availability = 0
                        Uptime = 0
                        oee_availability = 0
                        oee_performance = 0
                        oee_quality = 0
                        teep_availability = 0
                        teep_performance = 0
                        teep_quality = 0
                        ooe_availability = 0
                        ooe_performance = 0
                        ooe_quality = 0
                        Utilization_Rate = 0

                    try:
                        # Convert ProductionTimeTotal from hours to minutes
                        ProductionTimeTotal_minutes = ProductionTimeTotal * 60
                    except:
                        ProductionTimeTotal_minutes = 0

                    try:
                        mprogress = (float(ProductionCountActual) / mac_counts) *100
                        RemainingProdTime = float(int(ProductionTimeTotal_minutes)) - float(ProductionTimeActual_minute)
                    except:
                        mprogress = 0
                        RemainingProdTime = 0
                    dict = {'Alarm'             : Alarm,
                            'machineimage'      : machine_image,
                            'RejectionParts'    : RejectionParts,
                            'Machinename'       : machine_name,
                            'MachineState'      : MachineState,
                            'Mouldname'         : Mouldname,
                            'CycletimeSet'      : CycletimeSet,
                            'CycletimeActual'   : CycletimeActual,
                            'ProductionCountActual' : ProductionCountActual,
                            'ProductionCountSet'    :mac_counts,
                            'ProductionTimeActual'  : float(ProductionTimeActual_minute),
                            'ProductionTimeTotal'   : ProductionTimeTotal_minutes,
                            'efficiency'            : round(efficiency, 2),
                            "oee"               : round(oee, 2),
                            "teep"              :round(teep, 2),
                            "ooe"               :round(ooe, 2),
                            "Availability"      :round(Availability, 2),
                            "Uptime"            :round(Uptime, 2),
                            "oee_availability" : round(oee_availability, 2),
                            "oee_performance" : round(oee_performance, 2),
                            "oee_quality" : round(oee_quality, 2),
                            "teep_availability" : round(teep_availability, 2),
                            "teep_performance" : round(teep_performance, 2),
                            "teep_quality" : round(teep_quality, 2),
                            "ooe_availability" : round(ooe_availability, 2),
                            "ooe_performance" : round(ooe_performance, 2),
                            "ooe_quality" : round(ooe_quality, 2),
                            "Utilization_Rate" : round(Utilization_Rate, 2),
                            "machinestatus"     :machine_status,
                            "mprogress"         : round(mprogress, 2),
                            "RemainingProdTime" : round(RemainingProdTime, 2)
                            }
                    API_list.append(dict)
                    delete_dashboarddata(Plantname)
                else:
                    dict = {'Alarm'             :0,
                            'machineimage'      :machine_image,
                            'RejectionParts'    :0,
                            'Machinename'       :machine_name,
                            'MachineState'      :2,
                            'Mouldname'         :None,
                            'CycletimeSet'      :0,
                            'CycletimeActual'   :0,
                            'ProductionCountActual' :0,
                            'ProductionCountSet'    :0,
                            'ProductionTimeActual'  :0,
                            'ProductionTimeTotal'   :0,
                            'efficiency'            :0,
                            "ooe"               :0,
                            "teep"              :0,
                            "ooe"               :0,
                            "Availability"      :0,
                            "Uptime"            :0,
                            "oee_availability" : 0,
                            "oee_performance" : 0,
                            "oee_quality" : 0,
                            "teep_availability" : 0,
                            "teep_performance" : 0,
                            "teep_quality" : 0,
                            "ooe_availability" : 0,
                            "ooe_performance" : 0,
                            "ooe_quality" : 0,
                            "Utilization_Rate" : 0,
                            "machinestatus"     :machine_status,
                            "mprogress"         :0,
                            "RemainingProdTime" :0
                            }
                    API_list.append(dict)

            else:
                print("Machine is Not Added")

        return JsonResponse(API_list, safe=False)

#_________________________________________________________________________________________________________________

# @csrf_exempt
# def mould_count(request):
#     if request.method == "GET":
#         Plantname = request.GET['Plantname']

#         response_data = []

#         MachinenamesArray = machineArray(Plantname)

#         ###########
#         firstday_start = '06:00:00'
#         firstday_end = '23:59:59'
#         secondday_start = '00:00:00'
#         secondday_end = '05:59:59'
#         ###########

#         ###############################################################################
#         ist_timezone = pytz.timezone('Asia/Kolkata')

#         # Get the current time in IST
#         timenow_ist_str = "23:59:24"
#         timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

#         print("Current IST time:", timenow_ist)

#         time_start_A = time(0, 0, 0)
#         time_end_A = time(5, 59, 59)

#         if time_start_A <= timenow_ist <= time_end_A:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1)
#             print("date1:", current_date)
#         else:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
#             print("date2:", current_date)
#         ###############################################################################

#         next_date = current_date + timedelta(days=1)
#         print("next_date:", next_date)

#         # Use strftime to convert the datetime object to a string if needed
#         startdate_str = current_date.strftime("%Y-%m-%d")
#         enddate_str = next_date.strftime("%Y-%m-%d")

#         pre_startdate_str = (current_date - timedelta(days=1)).strftime("%Y-%m-%d")
#         nex_enddate_str = (next_date + timedelta(days=1)).strftime("%Y-%m-%d")

#         # Retrieve and store all data for the date range
#         all_mould_value = ProductionTable.objects.filter(
#             Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
#             Plantname=Plantname,
#             Machinename__in=MachinenamesArray,
#             MachineState=1
#         ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')

#         print(all_mould_value)

#         # Fix: removed .order_by('id') after .last()
#         all_dashboard_value = Dashboard.objects.filter(
#             Plantname=Plantname, Machinename__in=MachinenamesArray
#         ).values('Machinename', 'Mouldname_id').order_by('id')

#         for machine_name in MachinenamesArray:
#             if ProductionTable.objects.filter(date = startdate_str, Plantname = Plantname, Machinename = machine_name, time__gte = firstday_start).count() != 0:

#                 dashboard_value = [r for r in all_dashboard_value if r['Machinename'] == machine_name]
                
#                 Mouldname_ids = dashboard_value[-1]['Mouldname_id'] if dashboard_value else 0

#                 print("machine_name:", machine_name, "Mouldname_id:", Mouldname_ids)

#                 Mouldname = Mouldmodel.objects.get(id=Mouldname_ids).Mouldname

#                 saw = [p for p in all_mould_value if
#                        p['Machinename'] == machine_name and 
#                        p['Mouldname_id'] == Mouldname_ids and
#                        ((p['date'] == startdate_str and firstday_start <= p['time'] <= firstday_end) or
#                         (p['date'] == enddate_str and secondday_start <= p['time'] <= secondday_end))]

#                 mould_ProductionCountActual = len(saw)

#             else:

#                 mould_ProductionCountActual = 0

#                 Mouldname = "No Data Found!"

#             # Construct the response for the current date
#             response_data.append({
#                 "date": startdate_str,
#                 "Machine": machine_name,
#                 "mould_production_count": mould_ProductionCountActual,
#                 "Mouldname": Mouldname
#             })

#         return JsonResponse(response_data, safe=False)
    
#         #JI

@csrf_exempt
def mould_count(request):
    if request.method == "GET":
        Plantname = request.GET['Plantname']

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        ###########
        firstday_start = '06:00:00'
        firstday_end = '23:59:59'
        secondday_start = '00:00:00'
        secondday_end = '05:59:59'
        ###########

        ###############################################################################
        ist_timezone = pytz.timezone('Asia/Kolkata')

        # Get the current time in IST
        timenow_ist_str = "23:59:24"
        timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

        print("Current IST time:", timenow_ist)

        time_start_A = time(0, 0, 0)
        time_end_A = time(5, 59, 59)

        if time_start_A <= timenow_ist <= time_end_A:
            current_date = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1)
            print("date1:", current_date)
        else:
            current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
            print("date2:", current_date)
        ###############################################################################

        next_date = current_date + timedelta(days=1)
        print("next_date:", next_date)

        # Use strftime to convert the datetime object to a string if needed
        startdate_str = current_date.strftime("%Y-%m-%d")
        enddate_str = next_date.strftime("%Y-%m-%d")

        pre_startdate_str = (current_date - timedelta(days=1)).strftime("%Y-%m-%d")
        nex_enddate_str = (next_date + timedelta(days=1)).strftime("%Y-%m-%d")

        # Retrieve and store all data for the date range
        all_mould_value = ProductionTable.objects.filter(
            Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
            Plantname=Plantname,
            Machinename__in=MachinenamesArray,
            MachineState=1
        ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')

        # print(all_mould_value)

        # Fix: removed .order_by('id') after .last()
        all_dashboard_value = Dashboard.objects.filter(
            Plantname=Plantname, Machinename__in=MachinenamesArray
        ).values('Machinename', 'Mouldname_id').order_by('id')

        all_mach = ProductionTable.objects.filter(date = startdate_str, 
                                                  Plantname = Plantname, 
                                                  Machinename__in=MachinenamesArray,
                                                  time__gte = firstday_start).order_by('id')

        for machine_name in MachinenamesArray:

            # if any(v.Machinename == machine_name for v in all_mach):                        #  BOTH LINES OF CURRECT
            if len([v for v in all_mach if v.Machinename == machine_name]) != 0:

                dashboard_value = [r for r in all_dashboard_value if r['Machinename'] == machine_name]
                
                Mouldname_ids = dashboard_value[-1]['Mouldname_id'] if dashboard_value else 0

                print("machine_name:", machine_name, "Mouldname_id:", Mouldname_ids)

                Mouldname = Mouldmodel.objects.get(id=Mouldname_ids).Mouldname

                saw = [p for p in all_mould_value if
                       p['Machinename'] == machine_name and 
                       p['Mouldname_id'] == Mouldname_ids and
                       ((p['date'] == startdate_str and firstday_start <= p['time'] <= firstday_end) or
                        (p['date'] == enddate_str and secondday_start <= p['time'] <= secondday_end))]

                mould_ProductionCountActual = len(saw)

            else:

                mould_ProductionCountActual = 0

                Mouldname = "No Data Found!"

            # Construct the response for the current date
            response_data.append({
                "date": startdate_str,
                "Machine": machine_name,
                "mould_production_count": mould_ProductionCountActual,
                "Mouldname": Mouldname
            })

        return JsonResponse(response_data, safe=False)

#_________________________________________________________________________________________________________________
    
# @csrf_exempt
# def totalfg(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']

#         startdate = "2023-04-26"  
#         print("startdate:", startdate)
#         MachinenamesArray = machineArray(Plantname)
#         print(MachinenamesArray)

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

#         response_data = []
#         ################
#         startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
#         print("startdate_str:", startdate_str)

#         current_date = startdate_str
#         current_date_str = current_date.strftime('%Y-%m-%d')

#         shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#         shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

#         next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
#         next_day = current_date + timedelta(days=1)

#         total_ProductionCountActual = 0
#         total_RejectionParts = 0

#         for machine in MachinenamesArray:

#             dashboard_value = ProductionTable.objects.filter(
#                     Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
#                     Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
#                     Plantname=Plantname,
#                     Machinename=machine,
#                     MachineState=1
#                 ).values('time')
            
#             RejectionParts_calculate = badpart.objects.filter(
#                     Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
#                     Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]), 
#                                             Plantname = Plantname, 
#                                             Machinename = machine).values('partcount').order_by('id').last()
            
#             ProductionCountActual = dashboard_value.count()

#             if RejectionParts_calculate is not None:
#                 RejectionParts = RejectionParts_calculate.get('partcount', 0)
#             else:
#                 RejectionParts = 0

#             total_ProductionCountActual += ProductionCountActual

#             total_RejectionParts += RejectionParts

#         total_parts = total_ProductionCountActual

#         bad_parts = total_RejectionParts

#         good_parts = total_ProductionCountActual - total_RejectionParts

#         # Append the cumulative data to response
#         response_data.append({
#             "parameter": "today",
#             "time": 6_7,
#             "total parts": total_parts,
#             "good parts": good_parts,
#             "bad parts": bad_parts
#         })

#         return JsonResponse(response_data, safe=False)                    # CUMULATIVE TIME OWN CODE

# @csrf_exempt
# def totalfg(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']
#         startdate = "2023-04-26"
#         print("startdate:", startdate)
#         MachinenamesArray = machineArray(Plantname)
#         # print(MachinenamesArray)

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

#         response_data = []
#         startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
#         # print("startdate_str:", startdate_str)

#         current_date = startdate_str
#         current_date_str = current_date.strftime('%Y-%m-%d')

#         next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
#         next_day = current_date + timedelta(days=1)

#         previous_day_str = (current_date - timedelta(days=1)).strftime('%Y-%m-%d')
#         previous_day = current_date - timedelta(days=1)

#         shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#         print("shift_start_datetime:", shift_start_datetime)
#         shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

#         total_ProductionCountActual = 0
#         total_RejectionParts = 0

#         # Iterate over each hour in the shift from 6:00 AM to 5:59 AM next day
#         current_hour_start = shift_start_datetime
#         while current_hour_start < shift_end_datetime:
#             next_hour_start = current_hour_start + timedelta(hours=1)
#             hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
#             print("hour_range_start_str:", hour_range_start_str)
#             hour_range_end = next_hour_start - timedelta(seconds=1)
#             hour_range_end_str = hour_range_end.strftime('%H:%M:%S')
#             # hour_range_end_str = next_hour_start.strftime('%H:%M:%S')
#             print("hour_range_end_str:", hour_range_end_str)

#             for machine in MachinenamesArray:

#                 ################

#                 ist_timezone = pytz.timezone('Asia/Kolkata')

#                 # Get the current time in IST
#                 # timenow_ist = datetime.now(ist_timezone).time()
#                 timenow_ist_str = "23:59:24"
#                 timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

#                 print("Current IST time:", timenow_ist)

#                 time_start_A = time(0, 0, 0)
#                 time_end_A = time(5, 59, 59)

#                 if time_start_A <= timenow_ist <= time_end_A:

#                     time_start = time(6, 0, 0)
#                     time_end = time(23, 59, 59)

#                     hour_range_start_time = datetime.strptime(hour_range_start_str, '%H:%M:%S').time()

#                     if time_start <= hour_range_start_time <= time_end:
#                         print("tack1")
#                         dashboard_value = ProductionTable.objects.filter(
#                             date=previous_day_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine,
#                             MachineState=1
#                         ).values('time')

#                         RejectionParts_calculate = badpart.objects.filter(
#                             date=previous_day_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine
#                         ).values('partcount').order_by('id').last()

#                     else:
#                         print("tack2")
#                         dashboard_value = ProductionTable.objects.filter(
#                             date=current_date_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine,
#                             MachineState=1
#                         ).values('time')

#                         RejectionParts_calculate = badpart.objects.filter(
#                             date=current_date_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine
#                         ).values('partcount').order_by('id').last()
                
#                 else:

#                     time_start = time(6, 0, 0)
#                     time_end = time(23, 59, 59)

#                     hour_range_start_time = datetime.strptime(hour_range_start_str, '%H:%M:%S').time()

#                     if time_start <= hour_range_start_time <= time_end:
#                         print("tack3")
#                         dashboard_value = ProductionTable.objects.filter(
#                             date=current_date_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine,
#                             MachineState=1
#                         ).values('time')

#                         RejectionParts_calculate = badpart.objects.filter(
#                             date=current_date_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine
#                         ).values('partcount').order_by('id').last()

#                     else:
#                         print("tack4")
#                         dashboard_value = ProductionTable.objects.filter(
#                             date=next_day_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine,
#                             MachineState=1
#                         ).values('time')

#                         RejectionParts_calculate = badpart.objects.filter(
#                             date=next_day_str, time__range=[hour_range_start_str, hour_range_end_str],
#                             Plantname=Plantname,
#                             Machinename=machine
#                         ).values('partcount').order_by('id').last()

#                 ProductionCountActual = dashboard_value.count()

#                 if RejectionParts_calculate is not None:
#                     RejectionParts = RejectionParts_calculate.get('partcount', 0)
#                 else:
#                     RejectionParts = 0

#                 total_ProductionCountActual += ProductionCountActual
#                 total_RejectionParts += RejectionParts

#             total_parts = total_ProductionCountActual
#             bad_parts = total_RejectionParts
#             good_parts = total_ProductionCountActual - total_RejectionParts

#             # Append the data for the current hour
#             response_data.append({
#                 "parameter": "today",
#                 "time": f"{hour_range_start_str} to {hour_range_end_str}",
#                 "total parts": total_parts,
#                 "good parts": good_parts,
#                 "bad parts": bad_parts
#             })

#             # Reset counters for the next hour
#             total_ProductionCountActual = 0
#             total_RejectionParts = 0

#             # Move to the next hour
#             current_hour_start = next_hour_start

#         return JsonResponse(response_data, safe=False)               # SEPARATE TIME OWN CODE
#ji

@csrf_exempt
def totalfg(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']                        # SEPARATE TIME AI GENERATED CODE october month
        startdate = "2023-04-26"
        MachinenamesArray = machineArray(Plantname)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        current_date_str = startdate_str.strftime('%Y-%m-%d')
        next_day_str = (startdate_str + timedelta(days=1)).strftime('%Y-%m-%d')
        previous_day_str = (startdate_str - timedelta(days=1)).strftime('%Y-%m-%d')

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

        ist_timezone = pytz.timezone('Asia/Kolkata')
        timenow_ist_str = "23:59:24"
        timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

        # Pre-fetch data for all machines and all time ranges in a single query
        production_data = ProductionTable.objects.filter(
            Plantname=Plantname,
            Machinename__in=MachinenamesArray,
            date__in=[previous_day_str, current_date_str, next_day_str]
        ).values('date', 'time', 'Machinename', 'MachineState').order_by('id')

        rejection_data = badpart.objects.filter(
            Plantname=Plantname,
            Machinename__in=MachinenamesArray,
            date__in=[previous_day_str, current_date_str, next_day_str]
        ).values('date', 'time', 'Machinename', 'partcount').order_by('id')

        response_data = []
        current_hour_start = shift_start_datetime

        while current_hour_start < shift_end_datetime:
            next_hour_start = current_hour_start + timedelta(hours=1)
            hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
            hour_range_end_str = (next_hour_start - timedelta(seconds=1)).strftime('%H:%M:%S')

            total_ProductionCountActual = 0
            total_RejectionParts = 0

            for machine in MachinenamesArray:
                if timenow_ist < time(6, 0, 0):
                    date = previous_day_str
                else:
                    date = current_date_str if current_hour_start.time() >= time(6, 0, 0) else next_day_str

                filtered_production = [p for p in production_data if 
                                       p['Machinename'] == machine and 
                                       p['date'] == date and 
                                       hour_range_start_str <= p['time'] <= hour_range_end_str and
                                       p['MachineState'] == 1]
                
                filtered_rejection = [r for r in rejection_data if 
                                      r['Machinename'] == machine and 
                                      r['date'] == date and 
                                      hour_range_start_str <= r['time'] <= hour_range_end_str]

                total_ProductionCountActual += len(filtered_production)
                if filtered_rejection:
                    # total_RejectionParts += sum(r['partcount'] for r in filtered_rejection)
                    total_RejectionParts += len(filtered_rejection)

            good_parts = total_ProductionCountActual - total_RejectionParts
            response_data.append({
                "parameter": "today",
                "time": f"{hour_range_start_str} to {hour_range_end_str}",
                "total parts": total_ProductionCountActual,
                "good parts": good_parts,
                "bad parts": total_RejectionParts
            })

            current_hour_start = next_hour_start

        return JsonResponse(response_data, safe=False)
    

@csrf_exempt
def total_production(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']

        response_data = []

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        ###############################################################################
        ist_timezone = pytz.timezone('Asia/Kolkata')

        # Get the current time in IST
        # timenow_ist = datetime.now(ist_timezone).time()
        timenow_ist_str = "23:59:24"
        timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

        print("Current IST time:", timenow_ist)

        time_start_A = time(0, 0, 0)
        time_end_A = time(5, 59, 59)

        if time_start_A <= timenow_ist <= time_end_A:
            # current_date = (datetime.today()).date()
            current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
            print("date1:", current_date)
        else:
            current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
            print("date2:", current_date)
        ###############################################################################

        next_date = current_date + timedelta(days=1)

        # Use strftime to convert the datetime object to a string if needed
        startdate_str = current_date.strftime("%Y-%m-%d")
        enddate_str = next_date.strftime("%Y-%m-%d")

        pre_startdate_str = (current_date - timedelta(days=1)).strftime("%Y-%m-%d")
        nex_enddate_str = (next_date + timedelta(days=1)).strftime("%Y-%m-%d")

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproduction').order_by('sp_id')

        # Retrieve and store all data for the date range
        all_dashboard_value = ProductionTable.objects.filter(
            Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
            Plantname=Plantname,
            Machinename__in=MachinenamesArray,
            MachineState=1
        ).values('Machinename', 'time', 'date').order_by('id')

        for select_machine in MachinenamesArray:

            # Filter stored data for the current day and the shift boundaries specific to the machine
            dashboard_value = [p for p in all_dashboard_value if
                p['Machinename'] == select_machine and
                ((p['date'] == startdate_str and '06:00:00' <= p['time'] <= '23:59:59') or
                    (p['date'] == enddate_str and '00:00:00' <= p['time'] <= '05:59:59'))
            ]

            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == startdate_str
                            ]

            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            ProductionCountActual = 0

            if dashboard_value:
                ProductionCountActual = len(dashboard_value)
            else:
                ProductionCountActual = 0

            # Construct the response for the current date
            response_data.append({
                "date": startdate_str,
                "Machine": select_machine,
                "Current_production_count": ProductionCountActual,
                "Production_count_set": mac_counts
            })

        return JsonResponse(response_data, safe=False)