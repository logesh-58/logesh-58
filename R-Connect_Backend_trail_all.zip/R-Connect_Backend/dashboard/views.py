from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dashboard
from productiontable.models import ProductionTable
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
import datetime
from analysis.views import machineArray
from shiftmanagement.models import ShiftTimings

def delete_dashboarddata(Plantname):
    getMachines = machineArray(Plantname)
    for machine in getMachines:
        getis = Dashboard.objects.filter(Plantname = Plantname, Machinename = machine).values('id').order_by('id').last()
        try: Dashboard.objects.filter(Machinename = machine, id__lt = getis['id']).delete()
        except: continue
    return None

#Write Your Code Buddy
@csrf_exempt
def production_dashboard(request):
    if request.method=="GET":
        Plantname = request.GET['Plantname']
        API_list = []; dict = {}
        machinelist = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename', 'ammachineimage', 'amconsiderbool').order_by('amid')
        current_date = (datetime.datetime.today()).date()
        print(current_date)
        shift_starttime = ShiftTimings.objects.values('shift1start').last()['shift1start']
        for machine_value in machinelist:

            java = machine_value['amconsiderbool']
            print(java)

            if java == True:

                print("java true")

                machine_name  = machine_value['amMachinename']
                machine_image = machine_value['ammachineimage']
                dashboard_value  = Dashboard.objects.filter(Plantname = Plantname, Machinename = machine_name).values('Machinename', 'Mouldname_id', 'MachineState', 'Alarm', 'ProductionTimeActual', 'ProductionTimeTotal', 'CycletimeActual', 'CycletimeSet', 'ProductionCountActual', 'ProductionCountSet', 'RejectionParts', 'machinestatus').last()
                machine_status  = dashboard_value['machinestatus']
                ########################### Getting the Shift Start and End time #####################################
                if ProductionTable.objects.filter(date = current_date, Plantname = Plantname, Machinename = machine_name, time__gte = shift_starttime).count() != 0:
                    if dashboard_value['ProductionTimeActual'] != 0:
                        ProductionTimeActual_minute = dashboard_value['ProductionTimeActual']
                        ProductionTimeActual_hour = dashboard_value['ProductionTimeActual'] / 60
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionTimeActual_minute = 0
                    Mouldname_id  = dashboard_value['Mouldname_id']
                    Mouldname     = Mouldmodel.objects.get(id = Mouldname_id).Mouldname
                    MachineState  = dashboard_value['MachineState']
                    Alarm = int(dashboard_value['Alarm'])
                    try:
                        ProductionTimeTotal     = round(float(dashboard_value['ProductionTimeTotal']), 2)
                    except:
                        ProductionTimeTotal  = 0
                    CycletimeActual         = float(dashboard_value['CycletimeActual'])
                    CycletimeSet            = float(dashboard_value['CycletimeSet'])
                    ProductionCountActual   = int(dashboard_value['ProductionCountActual'])
                    ProductionCountSet      = int(dashboard_value['ProductionCountSet'])
                    RejectionParts          = int(dashboard_value['RejectionParts'])
                    try:
                        efficiency = ((ProductionCountActual/ProductionCountSet)*(abs(ProductionCountActual-RejectionParts)/ProductionCountActual))*100
                        oee = ((float(ProductionTimeActual_hour)/8)*(ProductionCountActual/ProductionCountSet)*(abs(ProductionCountActual-RejectionParts)/ProductionCountActual))*100
                        teep = ((float(ProductionTimeActual_hour)/24)*(ProductionCountActual/ProductionCountSet)*(abs(ProductionCountActual-RejectionParts)/ProductionCountActual))*100
                        ooe = 0
                    except:
                        efficiency = 0
                        ooe = 0
                        teep = 0
                        oee  = 0
                    try:
                        mprogress = (float(ProductionCountActual) / ProductionCountSet) *100
                        RemainingProdTime = float(int(ProductionTimeTotal)) - float(ProductionTimeActual_minute)
                    except:
                        mprogress = 0
                        RemainingProdTime = 0
                    dict = {'Alarm'             : Alarm,
                            'machineimage'      : machine_image,
                            'RejectionParts'    : RejectionParts,
                            'Machinename'       : machine_name,
                            'MachineState'      : MachineState,
                            'Mouldname'         : Mouldname,
                            'CycletimeSet'      : CycletimeSet,
                            'CycletimeActual'   : CycletimeActual,
                            'ProductionCountActual' : ProductionCountActual,
                            'ProductionCountSet'    :ProductionCountSet,
                            'ProductionTimeActual'  : float(ProductionTimeActual_minute),
                            'ProductionTimeTotal'   : ProductionTimeTotal,
                            'efficiency'            : round(efficiency, 2),
                            "oee"               : round(oee, 2),
                            "teep"              :round(teep, 2),
                            "ooe"               : 0,
                            "machinestatus"     :machine_status,
                            "mprogress"         : round(mprogress, 2),
                            "RemainingProdTime" : round(RemainingProdTime, 2)
                            }
                    API_list.append(dict)
                    delete_dashboarddata(Plantname)
                else:
                    dict = {'Alarm'             :0,
                            'machineimage'      :machine_image,
                            'RejectionParts'    :0,
                            'Machinename'       :machine_name,
                            'MachineState'      :2,
                            'Mouldname'         :None,
                            'CycletimeSet'      :0,
                            'CycletimeActual'   :0,
                            'ProductionCountActual' :0,
                            'ProductionCountSet'    :0,
                            'ProductionTimeActual'  :0,
                            'ProductionTimeTotal'   :0,
                            'efficiency'            :0,
                            "ooe"               :0,
                            "teep"              :0,
                            "ooe"               :0,
                            "machinestatus"     :machine_status,
                            "mprogress"         :0,
                            "RemainingProdTime" :0
                            }
                    API_list.append(dict)

            else:
                print("java false")

        return JsonResponse(API_list, safe=False)