# from django.conf.urls import url
from django.urls import path
from dashboard import views
# from .newfeatures_dashboard import production_dashboards, totalfg, total_production, mould_count
from .prefetch_dash import production_dashboards

urlpatterns = [
    path('dashboard/', views.production_dashboard,name="dashboard"), # get
    path('production_dashboards', production_dashboards),
    # path('totalfg', totalfg),
    # path('totalpd', total_production),
    # path('mould_count', mould_count),
]
