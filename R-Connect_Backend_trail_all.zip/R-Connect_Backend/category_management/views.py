from django.http.response import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from category_management.models import AddCategory
from category_management.serializers import CategoryManagementDbSerializer
from rest_framework.parsers import JSONParser

# Create your views here.
@csrf_exempt
def addcategory(request):
    plntname=request.GET['plantname']
    if request.method == "GET":
        categorydata=AddCategory.objects.filter(acplantname=plntname).values()
        categorydataserializer=CategoryManagementDbSerializer(categorydata,many=True)
        return JsonResponse(categorydataserializer.data,safe=False)

    elif request.method == "POST":
        categorymanagement_Dbdata =  JSONParser().parse(request)
        catname = categorymanagement_Dbdata["accategorycode"]
        getrow = AddCategory.objects.all()
        count=0
        for s in getrow:
            # print(s.accategorycode)
            if catname == s.accategorycode:
                count=count+1

        if count == 0:
            categorymanagementSerializer = CategoryManagementDbSerializer(data=categorymanagement_Dbdata, partial=True)
            if categorymanagementSerializer.is_valid():
                categorymanagementSerializer.save()
                AddCategory.objects.filter(accategorycode=categorymanagement_Dbdata["accategorycode"]).update(acplantname=plntname)

            return JsonResponse("Category Management data saved to the db successfully",safe=False)
        else:
            return JsonResponse("Category Code Already exist",safe=False)

    elif request.method=="PUT":
        categorymanagement_Dbdata =  JSONParser().parse(request)
        AddCategory.objects.filter(accategorycode=categorymanagement_Dbdata["accategorycode"]).update(accategoryname=categorymanagement_Dbdata["accategoryname"])

        return JsonResponse("Category Management data updated to the db successfully",safe=False)
    
    elif request.method=="DELETE":
        Dbdata= JSONParser().parse(request)
            # print(Dbdata["code"])
        AddCategory.objects.filter(accategorycode=Dbdata["code"]).delete()

        return JsonResponse("Source Record Deleted Successfully",safe=False)
