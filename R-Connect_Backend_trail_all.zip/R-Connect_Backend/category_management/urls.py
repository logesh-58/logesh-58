from django.urls import path
from category_management import views

urlpatterns=[
    path('categorymanagement/',views.addcategory,name='category_management')
]