from django.apps import AppConfig


class CategoryManagementConfig(AppConfig):
    name = 'category_management'
