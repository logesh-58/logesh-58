from category_management.models import AddCategory
from rest_framework import serializers

class CategoryManagementDbSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddCategory
        fields = ['acid',
                  'accategoryname',
                  'acplantname',
                  'accategorycode'
                  ]