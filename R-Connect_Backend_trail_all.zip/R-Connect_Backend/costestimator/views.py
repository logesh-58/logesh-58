from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse, HttpResponse
from costestimator.models import Cost_DG, Cost_EB, Cost_Solar, Cost_Wind, Cost_Petrol, Cost_CNG, Cost_LPG, Cost_PNG, cost_water
from costestimator.serializers import  DGSerializer, SolarSerializer, EBSerializer, WindSerializer, PetrolSerializer, CNGSerializer, LPGSerializer, PNGSerializer, WaterSerializer
import json
from datetime import datetime
from rest_framework.response import Response
from meter_data.models import Masterdatatable
from django.db.models import Q
from django.db.models.aggregates import Sum
from costestimator.reportfile import costreport
from peakhour_dashboard.models import PeakConfig
# Create your views here.
# @csrf_exempt
# def CostSettings(request):
#     if request.method == "GET":
#         plntname=request.GET['plantname']
#         costconfigdata = CostEstimationModel.objects.filter(ce_plantname=plntname)
#         serializeddata = CostSettingsSerializer(costconfigdata,many=True)
#         return JsonResponse(serializeddata.data,safe=False)
#     elif request.method == "POST":
#         plntname=request.GET['plantname']
#         # print(plntname)
#         costdata=json.loads(request.body)
#         print(costdata)
#         # print(costdata['ce_srcname'])
#         if CostEstimationModel.objects.filter(ce_srcname=costdata['ce_srcname']).exists():
#             return JsonResponse("cost data already exists",safe=False)
#         else:
#             new_costdata=CostEstimationModel.objects.create(ce_plantname=plntname
#                                                             ,ce_srcname=costdata['ce_srcname']
#                                                             ,ce_unitcost=costdata['ce_unitcost'])
#             new_costdata.save()
#             return JsonResponse("cost data saved successfully",safe=False)
#     elif request.method == "PUT":
#         plntname=request.GET['plantname']
#         costdata=json.loads(request.body)
#         cost_id=costdata["ce_id"]
#         edit_cost=CostEstimationModel.objects.filter(ce_id=cost_id).update(ce_srcname=costdata["ce_srcname"]
#                                                                            ,ce_unitcost=costdata["ce_unitcost"])
#         # edit_cost.update()
#         return JsonResponse("cost data updated",safe=False)

#     elif request.method=="DELETE":
#         plntname=request.GET['plantname']
#         costdata=json.loads(request.body)
#         cost_id=costdata["ce_id"]
#         CostEstimationModel.objects.filter(ce_id=cost_id).delete()
#         return JsonResponse("cost data deleted",safe=False)


# @csrf_exempt
# def CostCalculator(request):
#     if request.method == "POST":
#         cost_data=json.loads(request.body)
#         month_year=cost_data["ce_month"]
#         # print(month_year)
#         splitted=month_year.split("-")
#         year=splitted[0]
#         month=splitted[1]
#         # print(month,year)
#         cost_estimate_data=CostEstimationModel.objects.all()
#         costing_report=[]
#         # sum_val=[]
#         for data in cost_estimate_data:
#             sum_val=Masterdatatable.objects.filter(Q(mtdate__year=year,mtdate__month=month) &
#                                                    Q(mtsrcname=data.ce_srcname)).aggregate(Sum('mtenergycons'))
#             # print(sum_val["mtenergycons__sum"])
#             # total_ec=sum_val["mtenergycons__sum"]
#             total_ec=round(sum_val["mtenergycons__sum"],2) if sum_val["mtenergycons__sum"]!=None else 0
#             costing_report.append({"ce_srcname":data.ce_srcname,"ce_unitcost":data.ce_unitcost
#             ,"ce_totalconsumption":total_ec,"ce_totalcost":total_ec*(data.ce_unitcost)})
#         # print(costing_report)
#         # print(cost_estimate_data)
#         return JsonResponse(costing_report,safe=False)

#----------Updated--------------------
#-------------------------------------

@csrf_exempt
def Costing(request):
    if request.method == 'GET':
        # plntname=request.GET['plantname']
        srcname=request.GET['source']
        if srcname == 'DG':
            data = Cost_DG.objects.all().order_by('dg_id')
            serial = DGSerializer(data, many=True)
        if srcname == 'SOLAR':
            data = Cost_Solar.objects.all().order_by('solar_id')
            serial = SolarSerializer(data, many=True)
        if srcname == 'EB':
            data = Cost_EB.objects.all().order_by('EB_id')
            serial = EBSerializer(data, many=True)
        if srcname == 'WIND':
            data = Cost_Wind.objects.all().order_by('Wind_id')
            serial = WindSerializer(data, many=True)
        if srcname == 'PETROL':
             data = Cost_Petrol.objects.all().order_by('pt_id')
             serial = PetrolSerializer(data, many=True)
        if srcname == 'LPG':
             data = Cost_LPG.objects.all().order_by('LPG_id')
             serial = LPGSerializer(data, many=True)
        if srcname == 'CNG':
             data = Cost_CNG.objects.all().order_by('CNG_id')
             serial = CNGSerializer(data, many=True)
        if srcname == 'PNG':
             data = Cost_PNG.objects.all().order_by('PNG_id')
             serial = PNGSerializer(data, many=True)
        if srcname == 'WATER':
            data = cost_water.objects.all().order_by('wt_id')
            # print(data)
            serial = WaterSerializer(data, many=True)
        return JsonResponse(serial.data, safe=False)

    if request.method == 'POST':
        # plntname=request.GET['plantname']
        srcname=request.GET['source']
        data = json.loads(request.body)
        # print('POST: ', data)
        if srcname == 'DG':
            ins = Cost_DG(dg_date = data['dg_date'], dg_desc = data['dg_desc'], dg_lit_cons = data['dg_lit_cons'], dg_lit_cpl = data['dg_lit_cpl'])
        if srcname == 'SOLAR':
            ins = Cost_Solar(solar_installedCap = data['solar_installedCap'],solar_cst = data['solar_cst'])
        if srcname == 'EB':
            ins = Cost_EB(EB_date = data['EB_date'],EB_Session = data['EB_Session'],EB_SessionCost = data['EB_SessionCost'])
        if srcname == 'WIND':
            ins = Cost_Wind(Wind_month = data['Wind_month'], Wind_percentage = data['Wind_percentage'])
        if srcname == 'PETROL':
             ins = Cost_Petrol(pt_date = data['pt_date'], pt_lit_cons = data['pt_lit_cons'], pt_cpl = data['pt_cpl'])
        if srcname == 'LPG':
             ins = Cost_LPG(LPG_date = data['LPG_date'], LPG_kg_cons = data['LPG_kg_cons'], LPG_cpkg = data['LPG_cpkg'])
        if srcname == 'CNG':
             ins = Cost_CNG(CNG_date = data['CNG_date'], CNG_kg_cons = data['CNG_kg_cons'], CNG_cpkg = data['CNG_cpkg'])
        if srcname == 'PNG':
             ins = Cost_PNG(PNG_date = data['PNG_date'], PNG_kg_cons = data['PNG_kg_cons'], PNG_cpkg = data['PNG_cpkg'])
        if srcname == 'WATER':
            ins = cost_water(wt_date = data['wt_date'], wt_source = data['wt_source'], wt_type = data['wt_type'], wt_consume = data['wt_consume'], wt_state = data['wt_state'], wt_cost = data['wt_cost'])
        ins.save()
        return HttpResponse('Data Saved')

    if request.method == 'PUT':
        # plntname=request.GET['plantname']
        srcname=request.GET['source']
        data = json.loads(request.body)
        # print('PUT: ', data)
        if srcname == 'DG':
            Cost_DG.objects.filter(dg_id = data['dg_id']).update(dg_date = data['dg_date'], dg_desc = data['dg_desc'], dg_lit_cons = data['dg_lit_cons'], dg_lit_cpl = data['dg_lit_cpl'])
        if srcname == 'SOLAR':
            Cost_Solar.objects.filter(solar_id = data['solar_id']).update(solar_installedCap = data['solar_installedCap'],solar_cst = data['solar_cst'])
        if srcname == 'EB':
            Cost_EB.objects.filter(EB_id = data['EB_id']).update(EB_Session = data['EB_Session'],EB_SessionCost = data['EB_SessionCost'])
        if srcname == 'WIND':
            Cost_Wind.objects.filter(Wind_id = data['Wind_id']).update(Wind_month = data['Wind_month'], Wind_percentage = data['Wind_percentage'])
        if srcname == 'PETROL':
             Cost_Petrol.objects.filter(pt_id = data['pt_id']).update(pt_date = data['pt_date'], pt_lit_cons = data['pt_lit_cons'], pt_cpl = data['pt_cpl'])
        if srcname == 'LPG':
             Cost_LPG.objects.filter(LPG_id = data['LPG_id']).update(LPG_date = data['LPG_date'], LPG_kg_cons = data['LPG_kg_cons'], LPG_cpkg = data['LPG_cpkg'])
        if srcname == 'CNG':
             Cost_CNG.objects.filter(CNG_id = data['CNG_id']).update(CNG_date = data['CNG_date'], CNG_kg_cons = data['CNG_kg_cons'], CNG_cpkg = data['CNG_cpkg'])
        if srcname == 'PNG':
             Cost_PNG.objects.filter(PNG_id = data['PNG_id']).update(PNG_date = data['PNG_date'], PNG_kg_cons = data['PNG_kg_cons'], PNG_cpkg = data['PNG_cpkg'])
        if srcname == 'WATER':
            cost_water.objects.filter(wt_id = data['wt_id']).update(wt_date = data['wt_date'], wt_source = data['wt_source'], wt_type = data['wt_type'], wt_consume = data['wt_consume'],wt_state = data['wt_state'], wt_cost = data['wt_cost'])
        return HttpResponse('Data Updated')

    if request.method == 'DELETE':
        # plntname=request.GET['plantname']
        srcname=request.GET['source']
        data = json.loads(request.body)
        # print('DELETE: ', data)
        if srcname == 'DG':
            Cost_DG.objects.filter(dg_id = data['code']).delete()
        if srcname == 'SOLAR':
            Cost_Solar.objects.filter(solar_id = data['code']).delete()
        if srcname == 'EB':
            Cost_EB.objects.filter(EB_id = data['code']).delete()
        if srcname == 'WIND':
            Cost_Wind.objects.filter(Wind_id = data['code']).delete()
        if srcname == 'PETROL':
            Cost_Petrol.objects.filter(pt_id = data['code']).delete()
        if srcname == 'LPG':
            Cost_LPG.objects.filter(LPG_id = data['code']).delete()
        if srcname == 'CNG':
            Cost_CNG.objects.filter(CNG_id = data['code']).delete()
        if srcname == 'PNG':
             Cost_PNG.objects.filter(PNG_id = data['code']).delete()
        if srcname == 'WATER':
             cost_water.objects.filter(wt_id = data['code']).delete()
        return HttpResponse('Data Deleted')


@csrf_exempt
def costreport(request):
    costreport()
    return HttpResponse('Data')

@csrf_exempt
def energycost(request):
    frm_dte = request.GET['from_date']
    to_dte = request.GET['to_date']
    # print(frm_dte , to_dte)
    totalSLR_consumptions = 0
    ###########  SOLAR ENERGY ################
    slr_enrgy = Masterdatatable.objects.filter(mtdate__range = [frm_dte , to_dte] , mtsrcname = 'Solar Energy').values('mtenergycons')
    for n in slr_enrgy:
        totalSLR_consumptions  = n['mtenergycons'] + totalSLR_consumptions
    # print(total_SLRconsumptions) 
    try:
        solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
        print(solar_cst)
    except:
        solar_cst = 0
    totalSLR_cost = totalSLR_consumptions*solar_cst
    # print(total_SLRcost)
    
    ########### DG ##########
    totalDG_costs = 0
    dg_enrgy = Masterdatatable.objects.filter(mtdate__range = [frm_dte , to_dte] , mtsrcname = 'DG').values('mtenergycons', 'mtdate', 'mtmtrname')
    for m in dg_enrgy:
        try:
            dg_data = Cost_DG.objects.get(dg_date = m['mtdate'], dg_desc = m['mtmtrname'])
            if dg_data.dg_date == m['mtdate'] and  dg_data.dg_desc == m['mtmtrname']:
                totalDG_costs = ((dg_data.dg_lit_cons*dg_data.dg_lit_cpl)) + totalDG_costs 
        except:
            totalDG_costs = 0 + totalDG_costs
    # print("dg_cost",totalDG_costs)

    ######### Transformer1 #########
    totalTRN_costs = 0
    trs_enrgy = Masterdatatable.objects.filter(mtdate__range = [frm_dte , to_dte] , mtsrcname = 'Transformer1').all().values()
    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
    session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")
    Masterdata_tranformer  = Masterdatatable.objects.filter(mtdate__range = [frm_dte , to_dte] ,  mtsrcname = 'Transformer1').all().values()
    count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
    count_13= 0;count_14 = 0; count_15 = 0; count_16 = 0; count_17 =0; count_18 = 0; count_19 = 0; count_20 = 0; count_21 = 0; count_22 = 0; count_23 = 0; count_24 = 0
    for ms in Masterdata_tranformer:
        for w in ms:
            # print(w)
            if w == "mth1ec":
                mth1ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                count_1 = 1
                # print(mth1ec)
            if w == "mth2ec":
                mth2ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                count_2 = 2
                # print(mth2ec)
            if w == "mth3ec":
                mth3ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                count_3 = 3
                # print(mth3ec)
            if w == "mth4ec":
                mth4ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                count_4 = 4
                # print(mth4ec)
            if w == "mth5ec":
                mth5ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                count_5 = 5
                # print(mth5ec)
            if w == "mth6ec":
                mth6ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                count_6 = 6
                # print(mth6ec)
            if w == "mth7ec":
                mth7ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                count_7 = 7
                # print(mth7ec)
            if w == "mth8ec":
                mth8ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                count_8 = 8
                # print(mth8ec)
            if w == "mth9ec":
                mth9ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                count_9 = 9
                # print(mth9ec)
            if w == "mth10ec":
                mth10ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                count_10 = 10
                # print(mth10ec)
            if w == "mth11ec":
                mth11ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                count_11 = 11
                # print(mth11ec)
            if w == "mth12ec":
                mth12ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                count_12 = 12
                # print(mth12ec)
            if w == "mth13ec":
                mth13ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                count_13 = 13
                # print(mth13ec)
            if w == "mth14ec":
                mth14ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                count_14 = 14
                # print(mth14ec)
            if w == "mth15ec":
                mth15ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                count_15 = 15
                # print(mth15ec)
            if w == "mth16ec":
                mth16ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                count_16 = 16
                # print(mth16ec)
            if w == "mth17ec":
                mth17ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                count_17 = 17
                # print(mth17ec)
            if w == "mth18ec":
                mth18ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                count_18 = 18
                # print(mth18ec)
            if w == "mth19ec":
                mth19ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                count_19 = 19
                # print(mth19ec)
            if w == "mth20ec":
                mth20ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                count_20 = 20
                # print(mth20ec)
            if w == "mth21ec":
                mth21ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                count_21 = 21
                # print(mth21ec)
            if w == "mth22ec":
                mth22ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                count_22 = 22
                # print(mth22ec)
            if w == "mth23ec":
                mth23ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                count_23 = 23
                # print(mth23ec)
            if w == "mth24ec":
                mth24ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                count_24 = 24
                # print(mth24ec)
        # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
        break

    pkstr = 0 ; pkend =  0
    for e in session_config:
        if e['pkstart'] ==  mth1ec: 
            # print("ps_mth1ec :",e["pkstart"])
            pkstr = count_1
        if e['pkstart'] == mth2ec:
            # print("ps_mth2ec :",e['pkstart'])
            pkstr = count_2
        if e['pkstart'] == mth3ec:
            # print("ps_mth3ec :",e['pkstart'])
            pkstr = count_3
        if e['pkstart'] == mth4ec:
            # print("ps_mth4ec :",e['pkstart'])
            pkstr = count_4
        if e['pkstart'] == mth5ec:
            # print("ps_mth5ec :",e['pkstart'])
            pkstr = count_5
        if e['pkstart'] == mth6ec:
            # print("ps_mth6ec :",i['pkstart'])
            pkstr = count_6
        if e['pkstart'] == mth7ec:
            # print("ps_mth7ec :",i['pkstart'])
            pkstr = count_7
        if e['pkstart'] == mth8ec:
            # print("ps_mth8ec :",i['pkstart'])
            pkstr = count_8
        if e['pkstart'] == mth9ec:
            # print("ps_mth9ec :",i['pkstart'])
            pkstr = count_9
        if e['pkstart'] == mth10ec:
            # print("ps_mth10ec :",i['pkstart'])
            pkstr = count_10
        if e['pkstart'] == mth11ec:
            # print("ps_mth11ec :",i['pkstart'])
            pkstr = count_11
        if e['pkstart'] == mth12ec:
            # print("ps_mth12ec :",i['pkstart'])
            pkstr = count_12
        if e['pkstart'] == mth13ec:
            # print("ps_mth13ec :",i['pkstart'])
            pkstr = count_13
        if e['pkstart'] == mth14ec:
            # print("ps_mth14ec :",i['pkstart'])
            pkstr = count_14
        if e['pkstart'] == mth15ec:
            # print("ps_mth15ec :",i['pkstart'])
            pkstr = count_15
        if e['pkstart'] == mth16ec:
            # print("ps_mth16ec :",i['pkstart'])
            pkstr = count_16
        if e['pkstart'] == mth17ec:
            # print("ps_mth17ec :",i['pkstart'])
            pkstr = count_17
        if e['pkstart'] == mth18ec:
            # print("ps_mth18ec :",i['pkstart'])
            pkstr = count_18
        if e['pkstart'] == mth19ec:
            # print("ps_mth19ec :",i['pkstart'])
            pkstr = count_19 
        if e['pkstart'] == mth20ec:
            # print("ps_mth20ec :",i['pkstart'])
            pkstr = count_20
        if e['pkstart'] == mth21ec:
            # print("ps_mth21ec :",i['pkstart'])
            pkstr = count_21
        if e['pkstart'] == mth22ec:
            # print("ps_mth22ec :",i['pkstart'])
            pkstr = count_22
        if e['pkstart'] == mth23ec:
            # print("ps_mth23ec :",i['pkstart'])
            pkstr = count_23
        if e['pkstart'] == mth24ec:
            # print("ps_mth24ec :",i['pkstart'])
            pkstr = count_24

        #pkend
        if e['pkend'] == mth1ec:
            # print("pe_mth1ec :" , i['pkend'])
            pkend = count_1
        if e['pkend'] == mth2ec:
            # print("pe_mth2ec :" , i['pkend'])
            pkend = count_2
        if e['pkend'] == mth3ec:
            # print("pe_mth3ec :" , i['pkend'])
            pkend = count_3
        if e['pkend'] == mth4ec:
            # print("pe_mth4ec :" , i['pkend'])
            pkend = count_4
        if e['pkend'] == mth5ec:
            # print("pe_mth5ec :", i['pkend'])
            pkend = count_5
        if e['pkend'] == mth6ec:
            # print("pe_mth6ec :", i['pkend'])
            pkend = count_6
        if e['pkend'] == mth7ec:
            # print("pe_mth7ec :", i['pkend'])
            pkend = count_7
        if e['pkend'] == mth8ec:
            # print("pe_mth8ec :", i['pkend'])
            pkend = count_8
        if e['pkend'] == mth9ec:
            # print("pe_mth9ec :", i['pkend'])
            pkend = count_9
        if e['pkend'] == mth10ec:
            # print("pe_mth10ec :", i['pkend'])
            pkend = count_10
        if e['pkend'] == mth11ec:
            # print("pe_mth11ec :", i['pkend'])
            pkend = count_11
        if e['pkend'] == mth12ec:
            # print("pe_mth12ec :", i['pkend'])
            pkend = count_12
        if e['pkend'] == mth13ec:
            # print("pe_mth13ec :", i['pkend'])
            pkend = count_13 
        if e['pkend'] == mth14ec:
            # print("pe_mth14ec :", i['pkend'])
            pkend = count_14
        if e['pkend'] == mth15ec:
            # print("pe_mth15ec :", i['pkend'])
            pkend = count_15 
        if e['pkend'] == mth16ec:
            # print("pe_mth16ec :", i['pkend'])
            pkend = count_16
        if e['pkend'] == mth17ec:
            # print("pe_mth17ec :", i['pkend'])
            pkend = count_17
        if e['pkend'] == mth18ec:
            # print("pe_mth18ec :", i['pkend'])
            pkend = count_18 
        if e['pkend'] == mth19ec:
            # print("pe_mth19ec :", i['pkend'])
            pkend = count_19 
        if e['pkend'] == mth20ec:
            # print("pe_mth20ec :", i['pkend'])
            pkend = count_20
        if e['pkend'] == mth21ec:
            # print("pe_mth21ec :", i['pkend'])
            pkend = count_21
        if e['pkend'] == mth22ec:
            # print("pe_mth22ec :", i['pkend'])
            pkend = count_22 
        if e['pkend'] == mth23ec:
            # print("pe_mth23ec :", i['pkend'])
            pkend = count_23 
        if e['pkend'] == mth24ec:
            # print("pe_mth24ec :", i['pkend'])
            pkend = count_24 

        # print(val , val_2)
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
        m24ec='' 
        # print(pkstr, pkend)
        for n in range(pkstr, pkend+1):
            if n == 1:
                m1ec = 'mth1ec'
                # print(m1ec)
            if n == 2:
                m2ec = 'mth2ec'
                # print(m2ec)
            if n == 3:
                m3ec = 'mth3ec'
                # print(m3ec)      
            if n == 4:
                m4ec = 'mth4ec'
                # print(m4ec)
            if n == 5:
                m5ec = 'mth5ec'
                # print(m5ec)
            if n == 6:
                m6ec = 'mth6ec'
                # print(m6ec)
            if n == 7:
                m7ec = 'mth7ec'
                # print(m7ec)
            if n == 8:
                m8ec = 'mth8ec'
                # print(m8ec)
            if n == 9:
                m9ec = 'mth9ec'
                # print(m9ec)
            if n == 10:
                m10ec = 'mth10ec'
                # print(m10ec)
            if n == 11:
                m11ec = 'mth11ec'
                # print(m11ec)
            if n == 12:
                m12ec = 'mth12ec'
                # print(m12ec)
            if n == 13:
                m13ec = 'mth13ec'
                # print(m13ec)
            if n == 14:
                m14ec = 'mth14ec'
                # print(m14ec)
            if n == 15:
                m15ec = 'mth15ec'
                # print(m15ec)
            if n == 16:
                m16ec = 'mth16ec'
                # print(m16ec)
            if n == 17:
                m17ec = 'mth17ec'
                # print(m17ec)
            if n == 18:
                m18ec = 'mth18ec'
                # print(m18ec)
            if n == 19:
                m19ec = 'mth19ec'
                # print(m19ec)
            if n == 20:
                m20ec = 'mth20ec'
                # print(m20ec)
            if n == 21:
                m21ec = 'mth21ec'
                # print(m21ec)
            if n == 22:
                m22ec = 'mth22ec'
                # print(m22ec)
            if n == 23:
                m23ec = 'mth23ec'
                # print(m23ec)
            if n == 24:
                m24ec = 'mth24ec'
                # print(m24ec)

        trs_enrgy = Masterdatatable.objects.filter(mtdate__range = [frm_dte , to_dte] , mtsrcname = 'Transformer1').all().values()
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
        total_cons = 0
        for q in trs_enrgy:
            # print(q['mtmtrname'])
            for z in q:
                    # print(z)
                if z == m1ec:
                        vl_1  = q['mth1ec']
                        # print(vl_1)
                if z == m2ec:
                        vl_2 = q['mth2ec']
                        # print(vl_2)
                if z == m3ec:
                        vl_3 = q['mth3ec']
                        # print(vl_3)
                if z == m4ec:
                        vl_4  = q['mth4ec']
                        # print(vl_4)
                if z == m5ec:
                        vl_5 = q['mth5ec']
                        # print(vl_5) 
                if z == m6ec:
                        vl_6 = q['mth6ec'] 
                        # print(vl_6)
                if z == m7ec:
                        vl_7 = q['mth7ec']
                        # print(vl_7) 
                if z == m8ec:
                        vl_8 = q['mth8ec']
                        # print(vl_8)
                if z == m9ec:
                        vl_9 = q['mth9ec'] 
                        # print(vl_9)
                if z == m10ec:
                        vl_10 = q['mth10ec']
                        # print(vl_10)
                if z == m11ec:
                        vl_11 = q['mth11ec'] 
                        # print(vl_11)
                if z == m12ec:
                        vl_12 = q['mth12ec'] 
                        # print(vl_12)
                if z == m13ec:
                        vl_13 = q['mth13ec']
                        # print(vl_13)
                if z == m14ec:
                        vl_14 = q['mth14ec'] 
                        # print(vl_14)
                if z == m15ec:
                        vl_15 = q['mth15ec'] 
                        # print(vl_15)
                if z == m16ec:
                        vl_16 = q['mth16ec'] 
                        # print(vl_16)
                if z == m17ec:
                        vl_17 = q['mth17ec'] 
                        # print(vl_17)
                if z == m18ec:
                        vl_18 = q['mth18ec'] 
                        # print(vl_18)
                if z == m19ec:
                        vl_19 = q['mth19ec'] 
                        # print(vl_19)
                if z == m20ec:
                        vl_20 = q['mth20ec'] 
                        # print(vl_20)
                if z == m21ec:
                        vl_21 = q['mth21ec']
                        # print(vl_21)
                if z == m22ec:
                        vl_22 = q['mth22ec'] 
                        # print(vl_22)
                if z == m23ec:
                        vl_23 = q['mth23ec'] 
                        # print(vl_23)
                if z == m24ec:
                        vl_24 = q['mth24ec'] 
                        # print(vl_24)    
                    
            Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
            total_cons = total_cons + Add
        # print(e['pkstatus'])
        cost_eb = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
        total_cst = 0
        # print("consumption :",total_cons)
        if cost_eb:
          for cst in cost_eb:
            total_cst = cst['EB_SessionCost'] * total_cons
        else:
            total_cst = 0
        # print("cost :", total_cst)
        totalTRN_costs = total_cst + totalTRN_costs
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
    # print(totalTRN_costs)
    return JsonResponse([{"date":[frm_dte , to_dte],"Solar Energy":[totalSLR_cost], "DG":[totalDG_costs], "Transformer1":[totalTRN_costs]}], safe=False)