from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from costestimator.models import Cost_EB, Cost_DG, Cost_Petrol, Cost_LPG, Cost_CNG, Cost_PNG, Cost_Solar, Cost_Wind, cost_water
from peakhour_dashboard.models import PeakConfig
from meter_data.models import Masterdatatable
from datetime import datetime, timedelta
import calendar
from django.db.models.aggregates import Sum

@csrf_exempt
def PlantCost(request):
    if request.method == 'POST':
        request_data = json.loads(request.body)
        
        type_data = request_data['Type']
        year_data = int(request_data['Year'])
        
        today = datetime.now()
        current_date = today.day; current_month = today.month; current_year = today.year
        start_month = 4
        end_month = 3
        
        start_time = datetime.strptime("06:00:00", "%H:%M:%S").time()
        end_time = datetime.strptime("05:00:00", "%H:%M:%S").time()
        # print(start_time, end_time)
        time_array = []
        while start_time >= end_time:
            time_array.append(start_time)
            start_time = (datetime.combine(datetime.today(), start_time) + timedelta(hours = 1)).time()
        while end_time >= start_time:
            time_array.append(start_time)
            start_time = (datetime.combine(datetime.today(), start_time) + timedelta(hours = 1)).time()
        # print(time_array)

        if year_data == current_year:
            if current_month > 3:
                start_date = datetime(current_year, start_month, 1)
                end_date = datetime(current_year, current_month, current_date)
                date_array = []
                while start_date <= end_date:
                    date_array.append(start_date.strftime("%Y-%m-%d"))
                    start_date += timedelta(days = 1)
            else:
                start_date = datetime(current_year - 1, start_month, 1)
                end_date = datetime(current_year, current_month, current_date)
                date_array = []
                while start_date <= end_date:
                    date_array.append(start_date.strftime("%Y-%m-%d"))
                    start_date += timedelta(days = 1)
        else:
            start_date = datetime(year_data, start_month, 1)
            end_date = datetime(year_data + 1, end_month, 31)
            date_array = []
            while start_date <= end_date:
                date_array.append(start_date.strftime("%Y-%m-%d"))
                start_date += timedelta(days = 1)
                
        if type_data == 'Month Basis':
            
            month_data = int(request_data['Month'])
            
            month_startdate = datetime(year_data, month_data, 1)
            if month_data == 12:
                month_enddate = datetime(year_data, 12, 31)
            else:
                month_enddate = datetime(year_data, month_data + 1, 1) - timedelta(days = 1)
            month_date_array = []
            while month_startdate <= month_enddate:
                month_date_array.append(month_startdate.strftime("%Y-%m-%d"))
                month_startdate += timedelta(days = 1)

            dg = list(Cost_DG.objects.filter(dg_date__gte = month_date_array[0], dg_date__lte = month_date_array[-1]  ).values('dg_lit_cons', 'dg_lit_cpl'))
            try:
                total_diesel_cons = sum(list(map(lambda x: x['dg_lit_cons'], dg)))
                total_diesel_cost = sum(list(map(lambda x: x['dg_lit_cons']*x['dg_lit_cpl'], dg)))
            except:
                total_diesel_cons = 0
                total_diesel_cost = 0
            try:
                petrol = list(Cost_Petrol.objects.filter(pt_date__gte = month_date_array[0], pt_date__lte = month_date_array[-1]  ).values('pt_lit_cons', 'pt_cpl'))
                total_petrol_cons = sum(list(map(lambda x: x['pt_lit_cons'], petrol)))
                total_petrol_cost = sum(list(map(lambda x: x['pt_lit_cons']*x['pt_cpl'], petrol)))
            except:
                total_petrol_cons = 0
                total_petrol_cost = 0
            
            try:    
                lpg = list(Cost_LPG.objects.filter(LPG_date__gte = month_date_array[0], LPG_date__lte = month_date_array[-1]  ).values('LPG_kg_cons', 'LPG_cpkg'))
                total_lpg_cons = sum(list(map(lambda x: x['LPG_kg_cons'], lpg)))
                total_lpg_cost = sum(list(map(lambda x: x['LPG_kg_cons']*x['LPG_cpkg'], lpg)))
            except:
                total_lpg_cons = 0
                total_lpg_cost = 0
            
            try:    
                cng = list(Cost_CNG.objects.filter(CNG_date__gte = month_date_array[0], CNG_date__lte = month_date_array[-1]  ).values('CNG_kg_cons', 'CNG_cpkg'))
                total_cng_cons = sum(list(map(lambda x: x['CNG_kg_cons'], cng)))
                total_cng_cost = sum(list(map(lambda x: x['CNG_kg_cons']*x['CNG_cpkg'], cng)))
            except:
                total_cng_cons = 0
                total_cng_cost = 0
            
            try:    
                png = list(Cost_PNG.objects.filter(PNG_date__gte = month_date_array[0], PNG_date__lte = month_date_array[-1]  ).values('PNG_kg_cons', 'PNG_cpkg'))
                total_png_cons = sum(list(map(lambda x: x['PNG_kg_cons'], png)))
                total_png_cost = sum(list(map(lambda x: x['PNG_kg_cons']*x['PNG_cpkg'], png)))
            except:
                total_png_cons = 0
                total_png_cost = 0
            
            try:    
                water = list(cost_water.objects.filter(wt_date__gte = month_date_array[0], wt_date__lte = month_date_array[-1]  ).values('wt_consume', 'wt_cost'))
                water_cons_array = sum(list(map(lambda x: x['wt_consume'], water)))
                water_cost_array = sum(list(map(lambda x: x['wt_consume']*x['wt_cost'], water)))
            except:
                water_cons_array = 0
                water_cost_array = 0
            
            try:    
                solar_energy =  (sum(list(map(lambda x: round(x['mtenergycons'], 0), list(Masterdatatable.objects.filter(mtdate__gte = month_date_array[0], mtdate__lte = month_date_array[-1], mtsrcname = 'Solar Energy', mtcategory = 'Secondary').values('mtenergycons'))))))
                solar_cost = (list(Cost_Solar.objects.values('solar_cst'))[0]['solar_cst'])*solar_energy
            except:
                solar_energy = 0
                solar_cost = 0
            
            try:
                wind_percent = float(list(Cost_Wind.objects.filter(Wind_month = calendar.month_name[month_data]).values('Wind_percentage'))[0]['Wind_percentage'])
                costwind = float(list(Cost_Wind.objects.filter(Wind_month = calendar.month_name[month_data]).values('Wind_cost'))[0]['Wind_cost'])
            except:
                wind_percent = 0
                costwind = 0
            
            transformer_cons = 0; num=1; transformer_cost= 0; wind_cons = 0; wind_cost = 0
            peakstatus = list(PeakConfig.objects.values('pkstatus', 'pkstart', 'pkend').order_by('pkcode'))
            for data2 in peakstatus:
                hour_array = []
                peakhour = data2['pkstatus']
                peakstart = data2['pkstart']
                peakend = data2['pkend']
                while peakstart > peakend:
                    hour_array.append(peakstart)
                    peakstart = (datetime.combine(datetime.today(), peakstart) + timedelta(hours = 1)).time()
                while peakend > peakstart:
                    hour_array.append(peakstart)
                    peakstart = (datetime.combine(datetime.today(), peakstart) + timedelta(hours = 1)).time()
                try:
                    ebcost = list(Cost_EB.objects.filter(EB_Session = peakhour).values('EB_SessionCost'))[0]['EB_SessionCost']
                except:
                    ebcost = 0
                for i in range(1, len(hour_array) + 1):
                    mthour = "mth" + str(num) + "ec"
                    transformer = float((Masterdatatable.objects.filter(mtdate__gte = month_date_array[0], mtdate__lte = month_date_array[-1], mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1').values(mthour).aggregate(Sum(mthour)))[mthour + '__sum'])
                    if transformer is None:
                        transformer = 0
                    transformer_cons += (transformer*((100-wind_percent)/100)) 
                    wind_cons += (transformer*(wind_percent/100))         
                    transformer_cost += ((transformer*((100-wind_percent)/100)) * ebcost)           
                    num += 1
            wind_cost = wind_cons * costwind
    #########################################################################################################################################################################################      
        if type_data == 'Year Basis':
            
            dg = list(Cost_DG.objects.filter(dg_date__gte = date_array[0], dg_date__lte = date_array[-1]  ).values('dg_lit_cons', 'dg_lit_cpl'))
            try:
                total_diesel_cons = sum(list(map(lambda x: x['dg_lit_cons'], dg)))
                total_diesel_cost = sum(list(map(lambda x: x['dg_lit_cons']*x['dg_lit_cpl'], dg)))
            except:
                total_diesel_cons = 0
                total_diesel_cost = 0
            try:
                petrol = list(Cost_Petrol.objects.filter(pt_date__gte = date_array[0], pt_date__lte = date_array[-1]  ).values('pt_lit_cons', 'pt_cpl'))
                total_petrol_cons = sum(list(map(lambda x: x['pt_lit_cons'], petrol)))
                total_petrol_cost = sum(list(map(lambda x: x['pt_lit_cons']*x['pt_cpl'], petrol)))
            except:
                total_petrol_cons = 0
                total_petrol_cost = 0
            try:    
                lpg = list(Cost_LPG.objects.filter(LPG_date__gte = date_array[0], LPG_date__lte = date_array[-1]  ).values('LPG_kg_cons', 'LPG_cpkg'))
                total_lpg_cons = sum(list(map(lambda x: x['LPG_kg_cons'], lpg)))
                total_lpg_cost = sum(list(map(lambda x: x['LPG_kg_cons']*x['LPG_cpkg'], lpg)))
            except:
                total_lpg_cons = 0
                total_lpg_cost = 0
            try:    
                cng = list(Cost_CNG.objects.filter(CNG_date__gte = date_array[0], CNG_date__lte = date_array[-1]  ).values('CNG_kg_cons', 'CNG_cpkg'))
                total_cng_cons = sum(list(map(lambda x: x['CNG_kg_cons'], cng)))
                total_cng_cost = sum(list(map(lambda x: x['CNG_kg_cons']*x['CNG_cpkg'], cng)))
            except:
                total_cng_cons = 0
                total_cng_cost = 0
            try:   
                png = list(Cost_PNG.objects.filter(PNG_date__gte = date_array[0], PNG_date__lte = date_array[-1]  ).values('PNG_kg_cons', 'PNG_cpkg'))
                total_png_cons = sum(list(map(lambda x: x['PNG_kg_cons'], png)))
                total_png_cost = sum(list(map(lambda x: x['PNG_kg_cons']*x['PNG_cpkg'], png)))
            except:
                total_png_cons = 0
                total_png_cost = 0
            try:    
                water = list(cost_water.objects.filter(wt_date__gte = date_array[0], wt_date__lte = date_array[-1]  ).values('wt_consume', 'wt_cost'))
                water_cons_array = sum(list(map(lambda x: x['wt_consume'], water)))
                water_cost_array = sum(list(map(lambda x: x['wt_consume']*x['wt_cost'], water)))
            except:
                water_cons_array = 0
                water_cost_array = 0
            try:    
                solar_energy =  sum(list(map(lambda x: round(x['mtenergycons'], 0), list(Masterdatatable.objects.filter(mtdate__gte = date_array[0], mtdate__lte = date_array[-1], mtsrcname = 'Solar Energy', mtcategory = 'Secondary').values('mtenergycons')))))
                solar_cost = (list(Cost_Solar.objects.values('solar_cst'))[0]['solar_cst'])*solar_energy
            except:
                solar_energy = 0
                solar_cost = 0
            transformer_cons = 0; transformer_cost= 0; wind_cost = 0; wind_cons = 0
            wind = list(Cost_Wind.objects.values('Wind_month', 'Wind_cost', 'Wind_percentage'))
            for data in wind:
                num = 1; dates_array = []
                wind_percent = data['Wind_percentage']
                costwind = data['Wind_cost']
                monthname = data['Wind_month']
                parsed_date = datetime.strptime(monthname, "%B")
                month_number = parsed_date.month
                if month_number > 3:
                    if month_number == 12:
                        startdate = datetime(year_data, month_number, 1)
                        enddate = datetime(year_data, month_number, 31)
                    else:
                        startdate = datetime(year_data, month_number, 1)
                        enddate = (datetime(year_data, month_number + 1, 1) - timedelta(days = 1))
                else:
                    startdate = datetime(year_data + 1, month_number, 1)
                    enddate = (datetime(year_data + 1, month_number + 1, 1) - timedelta(days = 1))
                while startdate <= enddate:
                    dates_array.append(startdate.strftime("%Y-%m-%d"))
                    startdate += timedelta(days = 1)
            
                peakstatus = list(PeakConfig.objects.values('pkstatus', 'pkstart', 'pkend').order_by('pkcode'))
                for data2 in peakstatus:
                    hour_array = []
                    peakhour = data2['pkstatus']
                    peakstart = data2['pkstart']
                    peakend = data2['pkend']
                    while peakstart > peakend:
                        hour_array.append(peakstart)
                        peakstart = (datetime.combine(datetime.today(), peakstart) + timedelta(hours = 1)).time()
                    while peakend > peakstart:
                        hour_array.append(peakstart)
                        peakstart = (datetime.combine(datetime.today(), peakstart) + timedelta(hours = 1)).time()
                    ebcost = list(Cost_EB.objects.filter(EB_Session = peakhour).values('EB_SessionCost'))[0]['EB_SessionCost']
                    for i in range(1, len(hour_array) + 1):
                        mthour = "mth" + str(num) + "ec"
                        try:
                            transformer = abs((Masterdatatable.objects.filter(mtdate__gte = dates_array[0], mtdate__lte = dates_array[-1], mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1').values(mthour).aggregate(Sum(mthour)))[mthour + '__sum'])
                        except:
                            transformer = 0
                        transformer_cons += (transformer*((100-wind_percent)/100)) 
                        wind_cons += (transformer*(wind_percent/100))         
                        transformer_cost += ((transformer*((100-wind_percent)/100)) * ebcost)           
                        num += 1
                wind_cost = wind_cons * costwind    
                
    source_name = ["Transformer", "Solar Energy", "Diesel", "Petrol", "LPG", "CNG", "PNG", "Wind", "Water"]
    costedata = [round(transformer_cost), round(solar_cost), round(total_diesel_cost), round(total_petrol_cost), round(total_lpg_cost), round(total_cng_cost), round(total_png_cost), round(wind_cost), round(water_cost_array)]
    sourcedata = [round(transformer_cons), round(solar_energy), round(total_diesel_cons), round(total_petrol_cons), round(total_lpg_cons), round(total_cng_cons), round(total_png_cons), round(wind_cons), round(water_cons_array)]
    my_dict = {
        "Source_name" : source_name,
        "Costdata" : costedata,
        "Energydata" : sourcedata
    }
        
    return JsonResponse(my_dict, safe=False)