from django.apps import AppConfig


class CostestimatorConfig(AppConfig):
    name = 'costestimator'
