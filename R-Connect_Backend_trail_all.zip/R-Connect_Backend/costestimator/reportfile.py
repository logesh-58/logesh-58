from __future__ import absolute_import
from email import encoders
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse , JsonResponse
import json
from datetime import timedelta , datetime 
import os   
from REnergy.settings import BASE_DIR
import xlwt
# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.use('Agg')
# from PIL import Image
# from io import BytesIO
from meter_data.models import Masterdatatable
from costestimator.models import Cost_Solar
from peakhour_dashboard.models import PeakConfig
from datetime import datetime 
from costestimator.models import Cost_EB , Cost_DG
import pandas as pd
import numpy as np
from django.views.decorators.csrf import csrf_exempt
from SEC.models import secmodel
from master_administrator.models import AddMasterAdministrator
from source_management.models import AddSource
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from celery import shared_task
from email.mime.base import MIMEBase
from email import encoders
import json
from REnergy.settings import BASE_DIR   
# import pandas as pd
import xlwt
from django.db.models import Sum as add
import calendar

# @csrf_exempt
def costreport():
    date = (datetime.now()).date()
    print(date)
    yesterday = date  - timedelta(days=1)
    # response = HttpResponse(content_type='application/ms-excel')
    # response['Content-Disposition'] = 'attachment; filename="EMSCostReport.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    # ws = wb.add_sheet(str(yesterday))
    ws1 = wb.add_sheet("SEC")
    ws2 = wb.add_sheet('Day Wise Consumption')
    ws3 = wb.add_sheet('Monthly Consumption')
    ws4 = wb.add_sheet('Yearly Consumption')
    
    style = xlwt.XFStyle()
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()
    style4 = xlwt.XFStyle()
    style5 = xlwt.XFStyle()
    style6 = xlwt.XFStyle()

    #Set Alignment 
    #--style    
    alignment       = xlwt.Alignment()
    alignment.horz  = xlwt.Alignment.HORZ_CENTER
    alignment.vert  = xlwt.Alignment.VERT_CENTER

    alignment_1       = xlwt.Alignment()
    alignment_1.horz  = xlwt.Alignment.HORZ_LEFT
    alignment_1.vert = xlwt.Alignment.VERT_CENTER
    
    alignment.wrap      = 1
    alignment_1.wrap    = 1
    style6.alignment    = alignment_1
    style.alignment     = alignment
    style1.alignment    = alignment
    style2.alignment    = alignment
    style3.alignment    = alignment
    style4.alignment    = alignment
    style5.alignment    = alignment

    #Set Border
    border          = xlwt.Borders()
    border.left     = xlwt.Borders.THIN 
    border.right    = xlwt.Borders.THIN 
    border.top      = xlwt.Borders.THIN 
    border.bottom   = xlwt.Borders.THIN 
    style.borders   = border
    
    border          = xlwt.Borders()
    border.left     = xlwt.Borders.THIN 
    border.right    = xlwt.Borders.THIN 
    border.top      = xlwt.Borders.THIN 
    border.bottom   = xlwt.Borders.THIN
    style1.borders  = border
    style2.borders  = border
    style3.borders  = border
    style4.borders  = border
    style5.borders  = border
    style6.borders  = border
    
    #Set Background Color
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 0
    style.pattern = pattern
    
    #style1
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
    style.pattern = pattern
    
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['ice_blue']
    style1.pattern = pattern
    
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['tan']
    style2.pattern = pattern

    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['lime']
    style4.pattern = pattern
    
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['light_yellow']
    style5.pattern = pattern

    #Set Font Color
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'Calibri'
    font.bold = True
    font.italic = False
    font.height = 300
    style.font = font
    
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'Calibri'
    font.bold = True
    font.italic = True
    font.height = 210
    style1.font = font
    style2.font = font
   
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'Calibri'
    font.bold = False
    font.italic = False
    font.height = 210
    style3.font = font
    style4.font = font
    style5.font  = font
    style6.font = font

    plant_name = AddMasterAdministrator.objects.get(amaid = 1).amaplantname
    soruce_name = AddSource.objects.values('assourcename')
    session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")

    #############################################################################################################
    ############################################### Current Day Report ##########################################
    #############################################################################################################
    
#     graph_totalcons = []; graph_totalcost = []
#     r = 1
#     c = 2
#     ws.write_merge(r, r+1, c, c+15, ('R-ENERGY -'+plant_name), style)
    
#     r = 6
#     c = 2
#     for data in ['DG', 'Solar', 'TNEB']:
#         ws.write_merge(r, r, c, c+1, ('Source Name:'), style1)
#         ws.write_merge(r+1, r+1, c, c+1, ('Date:'), style1)
#         c+=2
#         ws.write_merge(r, r, c, c+1, (data), style1)
#         ws.write_merge(r+1, r+1, c, c+1, (str(yesterday)), style1)
#         c+= 3
    
#     r = 9; c=2
#     for data in ['S.No', 'Description', 'Consumption', 'Cost']:
#         ws.col(c).width = 3500
#         ws.row(r).height_mismatch = True
#         ws.row(r).height = 1500
#         ws.write(r, c, data, style2)
#         c+=1
    
#     r = 10; rc=10;c=3; coe = "DG"; date = datetime.now() ;cost_cst = 0
#     mastertble_cur_dg = Masterdatatable.objects.filter(mtsrcname = coe , mtdate = date).values('mtmtrname','mtenergycons', 'mtdate')
#     Cost_dg = Cost_DG.objects.filter(dg_date = date).all().values('dg_date','dg_desc','dg_lit_cons')
#     # print(Cost_dg)
#     count = 1; total_dg = 0; total_cst_dg = 0
#     for i in mastertble_cur_dg:
#         total_dg = i['mtenergycons'] + total_dg
#         ws.write(r,c-1,count,style3)
#         ws.write(r , c , i['mtmtrname'] , style3)
#         ws.write(r, c+1, i['mtenergycons'], style3)
#         # print(i['mtmtrname'])
#         try:
#            cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
#            cost_cst = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_cst
#         except Cost_DG.DoesNotExist:
#           if cost_cst == 0:
#             cost_cst = 0
#         total_cst_dg = cost_cst + total_cst_dg
#         ws.write(r, c+2, cost_cst, style3)
#         r+=1; count +=1
        
#     ws.write_merge(r+1,r+1,c-1,c+1,"TotalCosumption",style5)
#     ws.write_merge(r+2,r+2,c-1,c+1,"TotalCost(INR)",style4)
#     graph_totalcons.append({"srcname":coe,"totalcons":int(total_dg)})
#     ws.write(r+1,c+2,total_dg,style5)
#     ws.write(r+2,c+2,total_cst_dg,style4)
#     graph_totalcost.append({"srcname":coe,"totalcost":int(total_cst_dg)})
    
#     r = 9; c=7
#     for data in ['S.No', 'Description', 'Consumption', 'Cost']:
#         ws.col(c).width = 3500
#         ws.row(r).height_mismatch = True
#         ws.row(r).height = 1500
#         ws.write(r, c, data, style2)
#         c+=1

#     r = 10; c=8; coe = "Solar Energy"  
#     mastertble_2 = Masterdatatable.objects.filter(mtsrcname = coe , mtdate = date).values('mtmtrname','mtenergycons')
#     # solar_cst = Cost_Solar.objects.get(solar_id = 1).solar_cst
#     try:
#         solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
#         # print(solar_cst)
#     except:
#         solar_cst = 0
#     # print(solar_cst)
#     count = 1; total = 0; total_enrgy = 0
#     for i in mastertble_2:
#         data = i['mtenergycons']*solar_cst
#         total_enrgy  = i['mtenergycons'] + total_enrgy
#         # print(data)
#         total = i['mtenergycons']*solar_cst + total
#         ws.write(r,c-1,count,style3)
#         ws.write(r , c ,i['mtmtrname'], style3)
#         ws.write(r, c+1, i['mtenergycons'], style3)
#         ws.write(r , c+2, data , style3)
#         r+=1; count +=1
        
#     ws.write_merge(r+1,r+1,c-1,c+1,"TotalConsumptions",style5)
#     ws.write_merge(r+2,r+2,c-1,c+1,"TotalCost(INR)",style4)
#     ws.write(r+1,c+2,total_enrgy,style5)
#     graph_totalcons.append({"srcname":coe,"totalcons":int(total_enrgy)})
#     ws.write(r+2,c+2,total,style4)
#     graph_totalcost.append({"srcname":coe,"totalcost":int(total)})
#     graph_row = r+9
    
#     r = 9; c=12
#     ws.col(c).width = 2000 
#     ws.col(c+1).width = 5100
#     ws.col(c+2).width = 4000
    
 
#     for data in ['S.No', 'Description','''Total Consumption
#     (24 hrs)''']:
#         ws.row(r).height_mismatch = True
#         ws.row(r).height = 1500
#         ws.write(r, c, data, style2)
#         c+=1

#     r=10; c=12; coe = "Transformer1"; date = datetime.now()
#     # print(date)
#     session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")
#     mastertble_cur = Masterdatatable.objects.filter(mtsrcname = 'Transformer1',mtcategory="Secondary",mtgrpname='Incomer', mtdate = date).all().values()
#     k = 1; total = 0; empty_lis = []
#     for s in mastertble_cur:
#             total = s['mtenergycons'] + total
#             empty_lis.append(s['mtmtrname'])
#             ws.write(r, c, k, style3)
#             ws.write(r, c+1, s['mtmtrname'], style6)
#             ws.write(r, c+2, s['mtenergycons'], style3)
#             k = k+1; r=r+1
#     ws.write_merge(r+1,r+1,c,c+1,"TotalConsumption",style5)
#     graph_totalcons.append({"srcname":coe,"totalcons":int(total)})
#     ws.write_merge(r+2,r+2,c,c+1,"TotalCost(INR)",style4)
#     ws.write(r+1,c+2,total,style5)
    
#     mastertble = Masterdatatable.objects.filter(mtsrcname = coe , mtdate = date).values('mtmtrname','mtdate','mth1ec','mth2ec','mth3ec','mth4ec','mth5ec','mth6ec',
#                                                                                         'mth7ec','mth8ec','mth9ec','mth10ec','mth11ec','mth12ec','mth13ec',
#                                                                                         'mth14ec','mth15ec','mth16ec','mth17ec','mth18ec','mth19ec','mth20ec',
#                                                                                         'mth21ec','mth22ec','mth23ec','mth24ec')
#     # print(mastertble)
#     count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
#     mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
#     for i in mastertble:
#         # print(i['mtmtrname'])
#         for j in i:
#             # print(j)
#             if j == "mth1ec":
#                 mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
#                 count_1 = 1
#                 # print(mth1ec)
#             if j == "mth2ec":
#                 mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
#                 count_2 = 2
#                 # print(mth2ec)
#             if j == "mth3ec":
#                 mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
#                 count_3 = 3
#                 # print(mth3ec)
#             if j == "mth4ec":
#                 mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
#                 count_4 = 4
#                 # print(mth4ec)
#             if j == "mth5ec":
#                 mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
#                 count_5 = 5
#                 # print(mth5ec)
#             if j == "mth6ec":
#                 mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
#                 count_6 = 6
#                 # print(mth6ec)
#             if j == "mth7ec":
#                 mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
#                 count_7 = 7
#                 # print(mth7ec)
#             if j == "mth8ec":
#                 mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
#                 count_8 = 8
#                 # print(mth8ec)
#             if j == "mth9ec":
#                 mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
#                 count_9 = 9
#                 # print(mth9ec)
#             if j == "mth10ec":
#                 mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
#                 count_10 = 10
#                 # print(mth10ec)
#             if j == "mth11ec":
#                 mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
#                 count_11 = 11
#                 # print(mth11ec)
#             if j == "mth12ec":
#                 mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
#                 count_12 = 12
#                 # print(mth12ec)
#             if j == "mth13ec":
#                 mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
#                 count_13 = 13
#                 # print(mth13ec)
#             if j == "mth14ec":
#                 mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
#                 count_14 = 14
#                 # print(mth14ec)
#             if j == "mth15ec":
#                 mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
#                 count_15 = 15
#                 # print(mth15ec)
#             if j == "mth16ec":
#                 mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
#                 count_16 = 16
#                 # print(mth16ec)
#             if j == "mth17ec":
#                 mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
#                 count_17 = 17
#                 # print(mth17ec)
#             if j == "mth18ec":
#                 mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
#                 count_18 = 18
#                 # print(mth18ec)
#             if j == "mth19ec":
#                 mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
#                 count_19 = 19
#                 # print(mth19ec)
#             if j == "mth20ec":
#                 mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
#                 count_20 = 20
#                 # print(mth20ec)
#             if j == "mth21ec":
#                 mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
#                 count_21 = 21
#                 # print(mth21ec)
#             if j == "mth22ec":
#                 mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
#                 count_22 = 22
#                 # print(mth22ec)
#             if j == "mth23ec":
#                 mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
#                 count_23 = 23
#                 # print(mth23ec)
#             if j == "mth24ec":
#                 mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
#                 count_24 = 24
#                 # print(mth24ec)
#     # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
#     val = 0
#     val_2 =  0 
#     r_1 = 9; c_1 = 15
#     r = 10 ; c = 12; empty_lis = []; total_cos = 0
#     for i in session_config:
#         time = i['pkstatus'] + "\n" + "( "+str ( i['pkstart'] ) + " to "+ str ( i['pkend'] ) + " )"
#         ws.col(c_1).width = 3500
#         ws.write(r_1,c_1, time ,style2)
#         # print("pkstart:" ,(i['pkstart']+timedelta(hours=1)))
#         # print(type(i['pkstart']+timedelta(hours=1)))
#         # print("pkend :" , (i['pkend'])) 
#         pkstart = i['pkstart']
#         datetime_objects = datetime.combine(datetime.now() , pkstart) 
#         incr_onehur = datetime_objects + timedelta(hours=1) 
#         pkstart =  incr_onehur.time()
#         if pkstart ==  mth1ec:
#             # print("ps_mth1ec :",i["pkstart"])
#             val = count_1
#         if pkstart == mth2ec:
#             # print("ps_mth2ec :",i['pkstart'])
#             val = count_2
#         if pkstart == mth3ec:
#             # print("ps_mth3ec :",i['pkstart'])
#             val = count_3
#         if pkstart == mth4ec:
#             # print("ps_mth4ec :",i['pkstart'])
#             val = count_4
#         if pkstart == mth5ec:
#             # print("ps_mth5ec :",i['pkstart'])
#             val = count_5
#         if pkstart == mth6ec:
#             # print("ps_mth6ec :",i['pkstart'])
#             val = count_6
#         if pkstart == mth7ec:
#             # print("ps_mth7ec :",i['pkstart'])
#             val = count_7
#         if pkstart == mth8ec:
#             # print("ps_mth8ec :",i['pkstart'])
#             val = count_8
#         if pkstart == mth9ec:
#             # print("ps_mth9ec :",i['pkstart'])
#             val = count_9
#         if pkstart == mth10ec:
#             # print("ps_mth10ec :",i['pkstart'])
#             val = count_10
#         if pkstart == mth11ec:
#             # print("ps_mth11ec :",i['pkstart'])
#             val = count_11
#         if pkstart == mth12ec:
#             # print("ps_mth12ec :",i['pkstart'])
#             val = count_12
#         if pkstart== mth13ec:
#             # print("ps_mth13ec :",i['pkstart'])
#             val = count_13
#         if pkstart == mth14ec:
#             # print("ps_mth14ec :",i['pkstart'])
#             val = count_14
#         if pkstart == mth15ec:
#             # print("ps_mth15ec :",i['pkstart'])
#             val = count_15
#         if pkstart == mth16ec:
#             # print("ps_mth16ec :",i['pkstart'])
#             val = count_16
#         if pkstart == mth17ec:
#             # print("ps_mth17ec :",i['pkstart'])
#             val = count_17
#         if pkstart== mth18ec:
#             # print("ps_mth18ec :",i['pkstart'])
#             val = count_18
#         if pkstart == mth19ec:
#             # print("ps_mth19ec :",i['pkstart'])
#             val = count_19 
#         if pkstart == mth20ec:
#             # print("ps_mth20ec :",i['pkstart'])
#             val = count_20
#         if pkstart == mth21ec:
#             # print("ps_mth21ec :",i['pkstart'])
#             val = count_21
#         if pkstart == mth22ec:
#             # print("ps_mth22ec :",i['pkstart'])
#             val = count_22
#         if pkstart == mth23ec:
#             # print("ps_mth23ec :",i['pkstart'])
#             val = count_23
#         if pkstart == mth24ec:
#             # print("ps_mth24ec :",i['pkstart'])
#             val = count_24

#         #pkend
#         if i['pkend'] == mth1ec:
#             # print("pe_mth1ec :" , i['pkend'])
#             val_2 = count_1
#         if i['pkend'] == mth2ec:
#             # print("pe_mth2ec :" , i['pkend'])
#             val_2 = count_2
#         if i['pkend'] == mth3ec:
#             # print("pe_mth3ec :" , i['pkend'])
#             val_2 = count_3
#         if i['pkend'] == mth4ec:
#             # print("pe_mth4ec :" , i['pkend'])
#             val_2 = count_4
#         if i['pkend'] == mth5ec:
#             # print("pe_mth5ec :", i['pkend'])
#             val_2 = count_5
#         if i['pkend'] == mth6ec:
#             # print("pe_mth6ec :", i['pkend'])
#             val_2 = count_6
#         if i['pkend'] == mth7ec:
#             # print("pe_mth7ec :", i['pkend'])
#             val_2 = count_7
#         if i['pkend'] == mth8ec:
#             # print("pe_mth8ec :", i['pkend'])
#             val_2 = count_8
#         if i['pkend'] == mth9ec:
#             # print("pe_mth9ec :", i['pkend'])
#             val_2 = count_9
#         if i['pkend'] == mth10ec:
#             # print("pe_mth10ec :", i['pkend'])
#             val_2 = count_10
#         if i['pkend'] == mth11ec:
#             # print("pe_mth11ec :", i['pkend'])
#             val_2 = count_11
#         if i['pkend'] == mth12ec:
#             # print("pe_mth12ec :", i['pkend'])
#             val_2 = count_12
#         if i['pkend'] == mth13ec:
#             # print("pe_mth13ec :", i['pkend'])
#             val_2 = count_13 
#         if i['pkend'] == mth14ec:
#             # print("pe_mth14ec :", i['pkend'])
#             val_2 = count_14
#         if i['pkend'] == mth15ec:
#             # print("pe_mth15ec :", i['pkend'])
#             val_2 = count_15 
#         if i['pkend'] == mth16ec:
#             # print("pe_mth16ec :", i['pkend'])
#             val_2 = count_16
#         if i['pkend'] == mth17ec:
#             # print("pe_mth17ec :", i['pkend'])
#             val_2 = count_17
#         if i['pkend'] == mth18ec:
#             # print("pe_mth18ec :", i['pkend'])
#             val_2 = count_18 
#         if i['pkend'] == mth19ec:
#             # print("pe_mth19ec :", i['pkend'])
#             val_2 = count_19 
#         if i['pkend'] == mth20ec:
#             # print("pe_mth20ec :", i['pkend'])
#             val_2 = count_20
#         if i['pkend'] == mth21ec:
#             # print("pe_mth21ec :", i['pkend'])
#             val_2 = count_21
#         if i['pkend'] == mth22ec:
#             # print("pe_mth22ec :", i['pkend'])
#             val_2 = count_22 
#         if i['pkend'] == mth23ec:
#             # print("pe_mth23ec :", i['pkend'])
#             val_2 = count_23 
#         if i['pkend'] == mth24ec:
#             # print("pe_mth24ec :", i['pkend'])
#             val_2 = count_24 

#         # print(val , val_2)
#         m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
#         m24ec=''
#         for n in range(val, val_2+1):
#             if n == 1:
#                 m1ec = 'mth1ec'
#                 # print(m1ec)
#             if n == 2:
#                 m2ec = 'mth2ec'
#                 # print(m2ec)
#             if n == 3:
#                 m3ec = 'mth3ec'
#                 # print(m3ec)      
#             if n == 4:
#                 m4ec = 'mth4ec'
#                 # print(m4ec)
#             if n == 5:
#                 m5ec = 'mth5ec'
#                 # print(m5ec)
#             if n == 6:
#                 m6ec = 'mth6ec'
#                 # print(m6ec)
#             if n == 7:
#                 m7ec = 'mth7ec'
#                 # print(m7ec)
#             if n == 8:
#                 m8ec = 'mth8ec'
#                 # print(m8ec)
#             if n == 9:
#                 m9ec = 'mth9ec'
#                 # print(m9ec)
#             if n == 10:
#                 m10ec = 'mth10ec'
#                 # print(m10ec)
#             if n == 11:
#                 m11ec = 'mth11ec'
#                 # print(m11ec)
#             if n == 12:
#                 m12ec = 'mth12ec'
#                 # print(m12ec)
#             if n == 13:
#                 m13ec = 'mth13ec'
#                 # print(m13ec)
#             if n == 14:
#                 m14ec = 'mth14ec'
#                 # print(m14ec)
#             if n == 15:
#                 m15ec = 'mth15ec'
#                 # print(m15ec)
#             if n == 16:
#                 m16ec = 'mth16ec'
#                 # print(m16ec)
#             if n == 17:
#                 m17ec = 'mth17ec'
#                 # print(m17ec)
#             if n == 18:
#                 m18ec = 'mth18ec'
#                 # print(m18ec)
#             if n == 19:
#                 m19ec = 'mth19ec'
#                 # print(m19ec)
#             if n == 20:
#                 m20ec = 'mth20ec'
#                 # print(m20ec)
#             if n == 21:
#                 m21ec = 'mth21ec'
#                 # print(m21ec)
#             if n == 22:
#                 m22ec = 'mth22ec'
#                 # print(m22ec)
#             if n == 23:
#                 m23ec = 'mth23ec'
#                 # print(m23ec)
#             if n == 24:
#                 m24ec = 'mth24ec'
#                 # print(m24ec)
            
#         vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
#         vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
        
#         # print(cur_day)
        
#         r = 10; total_cost = 0
#         for q in mastertble_cur:
#             # print(q['mtmtrname'])
#             for z in q:
#                     # print(z)
#                 if z == m1ec:
#                         vl_1  = q['mth1ec']
#                         # print(vl_1)
#                 if z == m2ec:
#                         vl_2 = q['mth2ec']
#                         # print(vl_2)
#                 if z == m3ec:
#                         vl_3 = q['mth3ec']
#                         # print(vl_3)
#                 if z == m4ec:
#                         vl_4  = q['mth4ec']
#                         # print(vl_4)
#                 if z == m5ec:
#                         vl_5 = q['mth5ec']
#                         # print(vl_5) 
#                 if z == m6ec:
#                         vl_6 = q['mth6ec'] 
#                         # print(vl_6)
#                 if z == m7ec:
#                         vl_7 = q['mth7ec']
#                         # print(vl_7) 
#                 if z == m8ec:
#                         vl_8 = q['mth8ec']
#                         # print(vl_8)
#                 if z == m9ec:
#                         vl_9 = q['mth9ec'] 
#                         # print(vl_9)
#                 if z == m10ec:
#                         vl_10 = q['mth10ec']
#                         # print(vl_10)
#                 if z == m11ec:
#                         vl_11 = q['mth11ec'] 
#                         # print(vl_11)
#                 if z == m12ec:
#                         vl_12 = q['mth12ec'] 
#                         # print(vl_12)
#                 if z == m13ec:
#                         vl_13 = q['mth13ec']
#                         # print(vl_13)
#                 if z == m14ec:
#                         vl_14 = q['mth14ec'] 
#                         # print(vl_14)
#                 if z == m15ec:
#                         vl_15 = q['mth15ec'] 
#                         # print(vl_15)
#                 if z == m16ec:
#                         vl_16 = q['mth16ec'] 
#                         # print(vl_16)
#                 if z == m17ec:
#                         vl_17 = q['mth17ec'] 
#                         # print(vl_17)
#                 if z == m18ec:
#                         vl_18 = q['mth18ec'] 
#                         # print(vl_18)
#                 if z == m19ec:
#                         vl_19 = q['mth19ec'] 
#                         # print(vl_19)
#                 if z == m20ec:
#                         vl_20 = q['mth20ec'] 
#                         # print(vl_20)
#                 if z == m21ec:
#                         vl_21 = q['mth21ec']
#                         # print(vl_21)
#                 if z == m22ec:
#                         vl_22 = q['mth22ec'] 
#                         # print(vl_22)
#                 if z == m23ec:
#                         vl_23 = q['mth23ec'] 
#                         # print(vl_23)
#                 if z == m24ec:
#                         vl_24 = q['mth24ec'] 
#                         # print(vl_24)    
                    
#             Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
#             total_cost = total_cost + Add
#             # print(q['mtmtrname'], Add)
#             ws.write(r, c+3, Add, style3)
#             r = r+1  
        
#         cost_eb = Cost_EB.objects.filter(EB_Session = i['pkstatus']).values('EB_SessionCost')
#         # print(cost_eb)
#         total = 0
#         if cost_eb:
#           for cst in cost_eb:
#             total = cst['EB_SessionCost'] * total_cost
#         else:
#             total = 0
        
#         total_cos = total + total_cos

#         ws.write(r+1, c+3, total_cost, style5)
#         ws.write(r+2,c+3,total,style4)    
        
#         vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
#         vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
#         m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
#         c=c+1; c_1 +=1
    
#     ws.write(r+2,14,total_cos,style4) 
#     graph_totalcost.append({"srcname":coe,"totalcost":int(total_cos)})
    
#   ##########################################   GRAPH REPORT #########################################

#     # print(graph_totalcons)
#     # print(graph_totalcost)
#     totalcons_consumption = []; slots_consumption = []  
#     for q in soruce_name:
#         src_nm_1 = q['assourcename'] 
#         for z in graph_totalcons:
#             src_nm_2 = z['srcname']
#             if src_nm_1 == src_nm_2:
#                totalcons_consumption.append(z['totalcons'])
#                slots_consumption.append(src_nm_1)
#     # print(totalcons,slots)
#     # TotalConsumptions = totalcons_consumption; bars_cons = slots_consumption
#     # X_pos = np.arange(len(bars_cons))
#     # plt.bar(X_pos, TotalConsumptions , color = 'darkslategrey' , width = 0.3)
#     # plt.xlabel('slots')
#     # plt.ylabel('consumptions')
#     # plt.legend(labels=['TotalConsumptions'])
#     # plt.xticks(X_pos, bars_cons)
#     # plt.savefig('Report/Plot/1.jpeg')
#     # # plt.show()
#     # plt.close()
#     totalcons_cost = []; slots_cost = []
#     for q in soruce_name:
#         src_nm_1 = q['assourcename'] 
#         for z in graph_totalcost:
#             src_nm_2 = z['srcname']
#             if src_nm_1 == src_nm_2:
#                totalcons_cost.append(z['totalcost'])
#                slots_cost.append(src_nm_1)
#     # print(totalcons_cost,slots_cost)
    # TotalCosts = totalcons_cost; bars_cost = slots_cost
    # X_pos = np.arange(len(bars_cost))
    # plt.bar(X_pos, TotalCosts , color = 'r' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('costs')
    # plt.legend(labels=['TotalCosts'])
    # plt.xticks(X_pos, bars_cost)
    # plt.savefig('Report/Plot/2.jpeg')
    # # plt.show()
    # plt.close()
    
    # # #----------------------
    # cons=2 ; cost = 2 ; row_grh_1 = graph_row ; row_grh_2 = graph_row + 30
    # for im in range(1,3):
    #     # print("image",im)
    #     if im == 1:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws.insert_bitmap('TNEB.bmp',row_grh_1,cons)
    #         # print("image_1 is inserted")
    #     if im == 2:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws.insert_bitmap('TNEB.bmp',row_grh_2,cost)
    #         # print("image_2 is inserted")

    ############################################################################################################
    ############################################## Dialy Wise Report ###########################################
    ############################################################################################################
    
    graph_totalcons_daily = [] ;  graph_totalcost_daily = []

    r = 1
    c = 2
    ws2.write_merge(r, r+1, c, c+12, ('R-ENERGY -'+plant_name), style)

    r = 6
    c = 2
    for data in ['DG', 'Solar', 'TNEB']:
        ws2.write_merge(r, r, c, c+1, ('Source Name:'), style1)
        ws2.write_merge(r+1, r+1, c, c+1, ('Date:'), style1)
        c+=2
        ws2.write_merge(r, r, c, c, (data), style1)
        ws2.write_merge(r+1, r+1, c, c, str(yesterday), style1)
        c+=2

    r = 9; c=2
    for data in ['Date', 'Consumption', 'Cost']:
        ws2.col(c).width = 3500
        # ws2.row(r).height_mismatch = True
        ws2.row(r).height = 1500
        ws2.write(r, c, data, style2)
        c+=1   
 
    r=9; c=6
    for data in ['Date', 'Consumption', 'Cost']:
        ws2.col(c).width =  3500
        # ws2.row(r).height_mismatch = True
        ws2.row(r).height = 1500
        ws2.write(r, c, data, style2)
        c+=1

    r=9; c =10
    ws2.col(c).width = 3700
    ws2.col(c+1).width = 3500
    for data in ['Date','''Total Consumption
    (24 hrs)''']:
        # ws2.row(r).height_mismatch = True
        ws2.row(r).height = 1500
        ws2.write(r, c, data, style2)
        c+=1
    
    r = 10; c=2; coe = "DG"; total_cst_dg = 0
    mastertble_dg = Masterdatatable.objects.filter(mtsrcname = coe).values('mtmtrname','mtenergycons','mtdate').order_by("mtdate")
    total_dg = 0
    
    date = (datetime.today()).date()
    cur_date  = date
    # print(cur_date)
    srt_date = (cur_date.replace(day=1))
    # print(srt_date)
    dly_date = pd.date_range(start=srt_date, end=cur_date)
    cost_cst = 0; total_dgmeters = 0 ; cost_dgmeters = 0; count = 0
    for dte in dly_date:
        dly_dte = (dte.date())
        daily_date = str(dly_dte)
        # print("daily_date", str(dly_dte))
        for i in mastertble_dg:
            if i['mtdate'] == dly_dte:
               total_dgmeters = i['mtenergycons'] + total_dgmeters
               total_dg = i['mtenergycons'] + total_dg
               try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_cst= cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_cst
               except Cost_DG.DoesNotExist:
                  if cost_cst == 0:
                    cost_cst = 0
               toal_cst_dg = cost_cst + total_cst_dg
               cost_dgmeters = cost_dgmeters + cost_cst

        ws2.write(r,c,daily_date,style3)
        ws2.write(r, c+1, total_dgmeters , style3)
        ws2.write(r, c+2, cost_dgmeters, style3)
        r+=1; count +=1 ; total_dgmeters = 0; cost_dgmeters = 0
        
    ws2.write_merge(r+1,r+1,c,c+1,"TotalCosumption",style5)
    ws2.write_merge(r+2,r+2,c,c+1,"TotalCost(INR)",style4)
    ws2.write(r+1,c+2,total_dg,style5)
    ws2.write(r+2,c+2,total_cst_dg,style4)
    graph_totalcons_daily.append({'srcname':coe,'totalcons':int(total_dg)})
    graph_totalcost_daily.append({'srcname':coe,'totalcost':int(total_cst_dg)})

    r = 10; c=7; coe = "Solar Energy"  
    mastertble_solar = Masterdatatable.objects.filter(mtsrcname = coe).values('mtmtrname','mtenergycons','mtdate').order_by('mtdate')
    # solar_cst = Cost_Solar.objects.get(solar_id = 1).solar_cst
    try:
        solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
        # print(solar_cst)
    except:
        solar_cst = 0
    
    # print(solar_cst)
    # count = 1
    total = 0 ; total_energy = 0; total_solarenergy = 0
    for dte in dly_date:
        dly_dte = (dte.date())
        daily_date = str(dly_dte)
        # print(dly_dte)
        for i in mastertble_solar:
            if i['mtdate'] == dly_dte:
                data = i['mtenergycons']*solar_cst
                # print(i['mtdate'])
                total_energy = i['mtenergycons'] + total_energy
                total = data + total
                total_solarenergy = i['mtenergycons'] + total_solarenergy
            
        ws2.write(r, c-1, daily_date, style3)
        ws2.write(r, c ,total_solarenergy, style3)
        ws2.write(r, c+1 ,data, style3)
        r+=1; total_solarenergy = 0; data = 0
       
    ws2.write_merge(r+1,r+1,c-1,c,"TotalConsumption",style5)            
    ws2.write_merge(r+2,r+2,c-1,c,"TotalCost(INR)",style4)
    # print('SE: ', mastertble_solar)
    ws2.write(r+1 , c+1 , total_energy , style5)
    ws2.write(r+2 , c+1 , total , style4)
    graph_totalcons_daily.append({'srcname':coe,'totalcons':int(total_energy)})
    graph_totalcost_daily.append({'srcname':coe,'totalcost':int(total)})
    
    r = 10; c =10; coe = "Transformer1" 
    mastertable_transformer = Masterdatatable.objects.filter(mtsrcname = coe, mtcategory="Secondary", mtgrpname='Incomer').values('mtmtrname','mtenergycons','mtdate').order_by('mtdate')
    total = 0; row = 10; col = 10; a = 0
    
    for dte in dly_date:
        dly_dte = (dte.date())
        # print(dly_dte)
        for t in mastertable_transformer:
            if t['mtdate'] == dly_dte:
            #     global a
                a = t['mtenergycons'] + a
                total = t['mtenergycons'] + total
               
        #    print(dly_dte, a)
        ws2.write(row , col , str(dly_dte), style3)
        ws2.write(row , col+1 , a , style3)
        row = row + 1
        a=0
       
    ws2.write_merge(row+1, row+1, col , col,  "TotalConsumption", style5)
    ws2.write_merge(row+2, row+2 ,col , col , "TotalCost(INR)" , style4)
    ws2.write(row+1, col+1, total, style5)
    
    graph_totalcons_daily.append({'srcname':coe,'totalcons':int(total)})
    current_date = datetime.now()
    mastertble_trans = Masterdatatable.objects.filter(mtsrcname = coe,mtdate = current_date).values('mtmtrname','mtdate','mth1ec','mth2ec','mth3ec','mth4ec','mth5ec','mth6ec',
                                                                                        'mth7ec','mth8ec','mth9ec','mth10ec','mth11ec','mth12ec','mth13ec',
                                                                                        'mth14ec','mth15ec','mth16ec','mth17ec','mth18ec','mth19ec','mth20ec',
                                                                                        'mth21ec','mth22ec','mth23ec','mth24ec')
    # print(mastertble)
    count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
    
    for ms in mastertble_trans:
        # print(i['mtmtrname'])
        for w in ms:
            # print(w)
            if w == "mth1ec":
                mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                count_1 = 1
                # print(mth1ec)
            if w == "mth2ec":
                mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                count_2 = 2
                # print(mth2ec)
            if w == "mth3ec":
                mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                count_3 = 3
                # print(mth3ec)
            if w == "mth4ec":
                mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                count_4 = 4
                # print(mth4ec)
            if w == "mth5ec":
                mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                count_5 = 5
                # print(mth5ec)
            if w == "mth6ec":
                mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                count_6 = 6
                # print(mth6ec)
            if w == "mth7ec":
                mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                count_7 = 7
                # print(mth7ec)
            if w == "mth8ec":
                mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                count_8 = 8
                # print(mth8ec)
            if w == "mth9ec":
                mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                count_9 = 9
                # print(mth9ec)
            if w == "mth10ec":
                mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                count_10 = 10
                # print(mth10ec)
            if w == "mth11ec":
                mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                count_11 = 11
                # print(mth11ec)
            if w == "mth12ec":
                mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                count_12 = 12
                # print(mth12ec)
            if w == "mth13ec":
                mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                count_13 = 13
                # print(mth13ec)
            if w == "mth14ec":
                mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                count_14 = 14
                # print(mth14ec)
            if w == "mth15ec":
                mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                count_15 = 15
                # print(mth15ec)
            if w == "mth16ec":
                mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                count_16 = 16
                # print(mth16ec)
            if w == "mth17ec":
                mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                count_17 = 17
                # print(mth17ec)
            if w == "mth18ec":
                mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                count_18 = 18
                # print(mth18ec)
            if w == "mth19ec":
                mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                count_19 = 19
                # print(mth19ec)
            if w == "mth20ec":
                mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                count_20 = 20
                # print(mth20ec)
            if w == "mth21ec":
                mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                count_21 = 21
                # print(mth21ec)
            if w == "mth22ec":
                mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                count_22 = 22
                # print(mth22ec)
            if w == "mth23ec":
                mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                count_23 = 23
                # print(mth23ec)
            if w == "mth24ec":
                mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                count_24 = 24
                # print(mth24ec)
    # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
    val = 0
    val_2 =  0 
    r_1 = 9; c_1 = 12
    r = 10 ; c = 10 ;  total_cos = 0
    for e in session_config:
        # print(e['pkstatus'] , e['pkstart'], e['pkend'])
        time = e['pkstatus'] + "\n" + "( "+str ( e['pkstart'] ) + " to "+ str ( e['pkend'] ) + " )"
        ws2.col(c_1).width = 3500
        ws2.write(r_1,c_1, time ,style2)
        # print("pkstart:" ,(i['pkstart']))
        # print("pkend :" , (i['pkend'])) 
        pkstart = e['pkstart']
        datetime_objects = datetime.combine(datetime.now() , pkstart) 
        incr_onehur = datetime_objects + timedelta(hours=1) 
        pkstart =  incr_onehur.time()
        if pkstart ==  mth1ec:
            # print("ps_mth1ec :",e["pkstart"])
            val = count_1
        if pkstart == mth2ec:
            # print("ps_mth2ec :",e['pkstart'])
            val = count_2
        if pkstart== mth3ec:
            # print("ps_mth3ec :",e['pkstart'])
            val = count_3
        if pkstart == mth4ec:
            # print("ps_mth4ec :",e['pkstart'])
            val = count_4
        if pkstart == mth5ec:
            # print("ps_mth5ec :",e['pkstart'])
            val = count_5
        if pkstart == mth6ec:
            # print("ps_mth6ec :",i['pkstart'])
            val = count_6
        if pkstart == mth7ec:
            # print("ps_mth7ec :",i['pkstart'])
            val = count_7
        if pkstart == mth8ec:
            # print("ps_mth8ec :",i['pkstart'])
            val = count_8
        if pkstart == mth9ec:
            # print("ps_mth9ec :",i['pkstart'])
            val = count_9
        if pkstart == mth10ec:
            # print("ps_mth10ec :",i['pkstart'])
            val = count_10
        if pkstart == mth11ec:
            # print("ps_mth11ec :",i['pkstart'])
            val = count_11
        if pkstart == mth12ec:
            # print("ps_mth12ec :",i['pkstart'])
            val = count_12
        if pkstart == mth13ec:
            # print("ps_mth13ec :",i['pkstart'])
            val = count_13
        if pkstart == mth14ec:
            # print("ps_mth14ec :",i['pkstart'])
            val = count_14
        if pkstart == mth15ec:
            # print("ps_mth15ec :",i['pkstart'])
            val = count_15
        if pkstart == mth16ec:
            # print("ps_mth16ec :",i['pkstart'])
            val = count_16
        if pkstart == mth17ec:
            # print("ps_mth17ec :",i['pkstart'])
            val = count_17
        if pkstart == mth18ec:
            # print("ps_mth18ec :",i['pkstart'])
            val = count_18
        if pkstart == mth19ec:
            # print("ps_mth19ec :",i['pkstart'])
            val = count_19 
        if pkstart == mth20ec:
            # print("ps_mth20ec :",i['pkstart'])
            val = count_20
        if pkstart == mth21ec:
            # print("ps_mth21ec :",i['pkstart'])
            val = count_21
        if pkstart == mth22ec:
            # print("ps_mth22ec :",i['pkstart'])
            val = count_22
        if pkstart == mth23ec:
            # print("ps_mth23ec :",i['pkstart'])
            val = count_23
        if pkstart == mth24ec:
            # print("ps_mth24ec :",i['pkstart'])
            val = count_24

        #pkend
        if e['pkend'] == mth1ec:
            # print("pe_mth1ec :" , i['pkend'])
            val_2 = count_1
        if e['pkend'] == mth2ec:
            # print("pe_mth2ec :" , i['pkend'])
            val_2 = count_2
        if e['pkend'] == mth3ec:
            # print("pe_mth3ec :" , i['pkend'])
            val_2 = count_3
        if e['pkend'] == mth4ec:
            # print("pe_mth4ec :" , i['pkend'])
            val_2 = count_4
        if e['pkend'] == mth5ec:
            # print("pe_mth5ec :", i['pkend'])
            val_2 = count_5
        if e['pkend'] == mth6ec:
            # print("pe_mth6ec :", i['pkend'])
            val_2 = count_6
        if e['pkend'] == mth7ec:
            # print("pe_mth7ec :", i['pkend'])
            val_2 = count_7
        if e['pkend'] == mth8ec:
            # print("pe_mth8ec :", i['pkend'])
            val_2 = count_8
        if e['pkend'] == mth9ec:
            # print("pe_mth9ec :", i['pkend'])
            val_2 = count_9
        if e['pkend'] == mth10ec:
            # print("pe_mth10ec :", i['pkend'])
            val_2 = count_10
        if e['pkend'] == mth11ec:
            # print("pe_mth11ec :", i['pkend'])
            val_2 = count_11
        if e['pkend'] == mth12ec:
            # print("pe_mth12ec :", i['pkend'])
            val_2 = count_12
        if e['pkend'] == mth13ec:
            # print("pe_mth13ec :", i['pkend'])
            val_2 = count_13 
        if e['pkend'] == mth14ec:
            # print("pe_mth14ec :", i['pkend'])
            val_2 = count_14
        if e['pkend'] == mth15ec:
            # print("pe_mth15ec :", i['pkend'])
            val_2 = count_15 
        if e['pkend'] == mth16ec:
            # print("pe_mth16ec :", i['pkend'])
            val_2 = count_16
        if e['pkend'] == mth17ec:
            # print("pe_mth17ec :", i['pkend'])
            val_2 = count_17
        if e['pkend'] == mth18ec:
            # print("pe_mth18ec :", i['pkend'])
            val_2 = count_18 
        if e['pkend'] == mth19ec:
            # print("pe_mth19ec :", i['pkend'])
            val_2 = count_19 
        if e['pkend'] == mth20ec:
            # print("pe_mth20ec :", i['pkend'])
            val_2 = count_20
        if e['pkend'] == mth21ec:
            # print("pe_mth21ec :", i['pkend'])
            val_2 = count_21
        if e['pkend'] == mth22ec:
            # print("pe_mth22ec :", i['pkend'])
            val_2 = count_22 
        if e['pkend'] == mth23ec:
            # print("pe_mth23ec :", i['pkend'])
            val_2 = count_23 
        if e['pkend'] == mth24ec:
            # print("pe_mth24ec :", i['pkend'])
            val_2 = count_24 

        # print(val , val_2)
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
        m24ec=''
        for n in range(val, val_2+1):
            if n == 1:
                m1ec = 'mth1ec'
                # print(m1ec)
            if n == 2:
                m2ec = 'mth2ec'
                # print(m2ec)
            if n == 3:
                m3ec = 'mth3ec'
                # print(m3ec)      
            if n == 4:
                m4ec = 'mth4ec'
                # print(m4ec)
            if n == 5:
                m5ec = 'mth5ec'
                # print(m5ec)
            if n == 6:
                m6ec = 'mth6ec'
                # print(m6ec)
            if n == 7:
                m7ec = 'mth7ec'
                # print(m7ec)
            if n == 8:
                m8ec = 'mth8ec'
                # print(m8ec)
            if n == 9:
                m9ec = 'mth9ec'
                # print(m9ec)
            if n == 10:
                m10ec = 'mth10ec'
                # print(m10ec)
            if n == 11:
                m11ec = 'mth11ec'
                # print(m11ec)
            if n == 12:
                m12ec = 'mth12ec'
                # print(m12ec)
            if n == 13:
                m13ec = 'mth13ec'
                # print(m13ec)
            if n == 14:
                m14ec = 'mth14ec'
                # print(m14ec)
            if n == 15:
                m15ec = 'mth15ec'
                # print(m15ec)
            if n == 16:
                m16ec = 'mth16ec'
                # print(m16ec)
            if n == 17:
                m17ec = 'mth17ec'
                # print(m17ec)
            if n == 18:
                m18ec = 'mth18ec'
                # print(m18ec)
            if n == 19:
                m19ec = 'mth19ec'
                # print(m19ec)
            if n == 20:
                m20ec = 'mth20ec'
                # print(m20ec)
            if n == 21:
                m21ec = 'mth21ec'
                # print(m21ec)
            if n == 22:
                m22ec = 'mth22ec'
                # print(m22ec)
            if n == 23:
                m23ec = 'mth23ec'
                # print(m23ec)
            if n == 24:
                m24ec = 'mth24ec'
                # print(m24ec)
            
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
               
        mastertble_daily_wise = Masterdatatable.objects.filter(mtsrcname = 'Transformer1', mtcategory="Secondary", mtgrpname='Incomer').all().values()
        r = 10; total_cost = 0 
        for dte in dly_date:
            dly_dte = (dte.date())
            for q_sess in mastertble_daily_wise:
                if q_sess['mtdate'] == dly_dte:
                    for z in q_sess:
                        if z == m1ec:
                            if q_sess['mth1ec'] == None:
                                vl_1 = 0 + vl_1
                            else:
                               vl_1  = q_sess['mth1ec'] + vl_1
                            #    print(vl_1)
                        if z == m2ec:
                            if q_sess['mth2ec'] == None:
                                vl_2 = 0 + vl_2
                            else:
                               vl_2  = q_sess['mth2ec'] + vl_2
                            #    print(vl_2)
                        if z == m3ec:
                            if q_sess['mth3ec'] == None:
                                vl_3= 0 + vl_3
                            else:
                               vl_3  = q_sess['mth3ec'] + vl_3
                            #    print(vl_3)
                        if z == m4ec:
                            if q_sess['mth4ec'] == None:
                                vl_4 = 0 + vl_4
                            else:
                               vl_4  = q_sess['mth4ec']  + vl_4
                            #    print(vl_4) 
                        if z == m5ec:
                            if q_sess['mth5ec'] == None:
                                vl_5 = 0 + vl_5
                            else:
                               vl_5  = q_sess['mth5ec'] + vl_5
                            #    print(vl_5)
                        if z == m6ec:
                            if q_sess['mth6ec'] == None:
                                vl_6 = 0 + vl_6
                            else:
                               vl_6  = q_sess['mth6ec'] + vl_6
                            #    print(vl_6)
                        if z == m7ec:
                            if q_sess['mth7ec'] == None:
                                vl_7 = 0 + vl_7
                            else:
                               vl_7  = q_sess['mth7ec'] + vl_7
                            #    print(vl_7)
                        if z == m8ec:
                            if q_sess['mth8ec'] == None:
                                vl_8 = 0 + vl_8
                            else:
                               vl_8  = q_sess['mth8ec'] + vl_8
                            #    print(vl_8)
                        if z == m9ec:
                            if q_sess['mth9ec'] == None:
                                vl_9 = 0 + vl_9
                            else:
                               vl_9  = q_sess['mth9ec'] + vl_9
                            #    print(vl_9)
                        if z == m10ec:
                            if q_sess['mth10ec'] == None:
                                vl_10 = 0 + vl_10
                            else:
                               vl_10  = q_sess['mth10ec'] + vl_10
                            #    print(vl_10)
                        if z == m11ec:
                            if q_sess['mth11ec'] == None:
                                vl_11 = 0 + vl_11
                            else:
                               vl_11  = q_sess['mth11ec'] + vl_11
                            #    print(vl_11)
                        if z == m12ec:
                            if q_sess['mth12ec'] == None:
                                vl_12 = 0 + vl_12
                            else:
                               vl_12  = q_sess['mth12ec'] + vl_12
                            #    print(vl_12)
                        if z == m13ec:
                            if q_sess['mth13ec'] == None:
                                vl_13 = 0 + vl_13
                            else:
                               vl_13  = q_sess['mth13ec'] + vl_13
                            #    print(vl_13)
                        if z == m14ec:
                            if q_sess['mth14ec'] == None:
                                vl_14 = 0 + vl_14
                            else:
                               vl_14  = q_sess['mth14ec'] + vl_14
                            #    print(vl_14)
                        if z == m15ec:
                            if q_sess['mth15ec'] == None:
                                vl_15 = 0 + vl_15
                            else:
                               vl_15  = q_sess['mth15ec'] + vl_15
                            #    print(vl_15)
                        if z == m16ec:
                            if q_sess['mth16ec'] == None:
                                vl_16 = 0 + vl_16
                            else:
                               vl_16  = q_sess['mth16ec'] + vl_16
                            #    print(vl_16)
                        if z == m17ec:
                            if q_sess['mth17ec'] == None:
                                vl_17 = 0 + vl_17
                            else:
                               vl_17  = q_sess['mth17ec'] + vl_17
                            #    print(vl_17)
                        if z == m18ec:
                            if q_sess['mth18ec'] == None:
                                vl_18 = 0 + vl_18
                            else:
                               vl_18  = q_sess['mth18ec'] + vl_18
                            #    print(vl_18)
                        if z == m19ec:
                            if q_sess['mth19ec'] == None:
                                vl_19 = 0 + vl_19
                            else:
                               vl_19  = q_sess['mth19ec'] + vl_19
                            #    print(vl_19)
                        if z == m20ec:
                            if q_sess['mth20ec'] == None:
                                vl_20 = 0 + vl_20
                            else:
                               vl_20 = q_sess['mth20ec'] + vl_20
                            #    print(vl_20)
                        if z == m21ec:
                            if q_sess['mth21ec'] == None:
                                vl_21 = 0 + vl_21
                            else:
                               vl_21  = q_sess['mth21ec'] + vl_21
                            #    print(vl_21)
                        if z == m22ec:
                            if q_sess['mth22ec'] == None:
                                vl_22 = 0 + vl_22
                            else:
                               vl_22  = q_sess['mth22ec'] + vl_22
                            #    print(vl_22)
                        if z == m23ec:
                            if q_sess['mth23ec'] == None:
                                vl_23 = 0 + vl_23
                            else:
                               vl_23  = q_sess['mth23ec'] + vl_23
                            #    print(vl_23)
                        if z == m24ec:
                            if q_sess['mth24ec'] == None:
                                vl_24 = 0 + vl_24
                            else:
                               vl_24 = q_sess['mth24ec'] + vl_24
                            #    print(vl_24)  
            
            Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
            # print(dly_dte ,  Add)
            vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
            vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
            total_cost = total_cost + Add
            # print(q['mtmtrname'], Add)
            
            ws2.write(r, c+2, Add, style3)
            r = r+1  
            
        cost_eb = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
        # print(cost_eb)
        total = 0
        if cost_eb:
          for cst in cost_eb:
            total = cst['EB_SessionCost'] * total_cost
        else:
            total = 0

        total_cos = total + total_cos

        ws2.write(r+1, c+2, total_cost, style5)
        ws2.write(r+2,c+2,total,style4)    
        
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
        c=c+1; c_1 +=1
    
    ws2.write(r+2,11,total_cos,style4) 
    graph_totalcost_daily.append({'srcname':coe,'totalcost':int(total_cos)})
    
    ############################################  GRAPH REPORT ################################################

    totalcons_consumption_daily = []; slots_consumption_daily = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcons_daily:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
               totalcons_consumption_daily.append(z['totalcons'])
               slots_consumption_daily.append(src_nm_1)

    # TotalConsumptions = totalcons_consumption_daily; bars_dly_cons  = slots_consumption_daily
    # X_pos = np.arange(len(bars_dly_cons))
    # plt.bar(X_pos, TotalConsumptions , color = 'darkslategrey' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('consumptions')
    # plt.legend(labels=['TotalConsumptions'])
    # plt.xticks(X_pos, bars_dly_cons)
    # plt.savefig('Report/Plot/3.jpeg')
    # # plt.show()
    # plt.close()
    
    totalcons_cost_daily = []; slots_cost_daily = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcost_daily:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
               totalcons_cost_daily.append(z['totalcost'])
               slots_cost_daily.append(src_nm_1)
    
    TotalCosts = totalcons_cost_daily ; bars_dly_cost = slots_cost_daily
    # X_pos = np.arange(len(bars_dly_cost))
    # plt.bar(X_pos, TotalCosts , color = 'r' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('costs')
    # plt.legend(labels=['TotalCosts'])
    # plt.xticks(X_pos, bars_dly_cost)
    # plt.savefig('Report/Plot/4.jpeg')
    # # plt.show()
    # plt.close()
    
    # #----------------------
    # cons=2 ; cost = 2 ; row_grh_1 = graph_row ; row_grh_2 = graph_row + 30
    # for im in range(3,5):
    #     # print("image",im)
    #     if im == 3:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws2.insert_bitmap('TNEB.bmp',row_grh_1,cons)
    #         # print("image_1 is inserted")
    #     if im == 4:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws2.insert_bitmap('TNEB.bmp',row_grh_2,cost)
    #         # print("image_2 is inserted")

    ############################################################################################################
    ############################################## Monthly Wise Report #########################################
    ############################################################################################################
    
    graph_totalcons_month = [] ;  graph_totalcost_month = []

    r = 1
    c = 2
    ws3.write_merge(r, r+1, c, c+12, ('R-ENERGY -'+plant_name), style)

    r = 6
    c = 2
    for data in ['DG', 'Solar', 'TNEB']:
        ws3.write_merge(r, r, c, c+1, ('Source Name:'), style1)
        ws3.write_merge(r+1, r+1, c, c+1, ('Date:'), style1)
        c+=2
        ws3.write_merge(r, r, c, c, (data), style1)
        ws3.write_merge(r+1, r+1, c, c, str(yesterday) , style1)
        c+= 2

    r = 9; c=2
    for data in ['Month', 'Consumption', 'Cost']:
        ws3.col(c).width = 4000
        # ws3.row(r).height_mismatch = True
        ws3.row(r).height = 1500
        ws3.write(r, c, data, style2)
        c+=1   

    r=9; c=6
    for data in ['Month', 'Consumption', 'Cost']:
        ws3.col(c).width = 4000
        # ws3.row(r).height_mismatch = True
        ws3.row(r).height = 1500
        ws3.write(r, c, data, style2)
        c+=1

    r=9; c =10
    ws3.col(c).width = 4000
    ws3.col(c+1).width = 3500
    for data in ['Date','''Total Consumption
    (24 hrs)''']:    
        # ws3.row(r).height_mismatch = True
        ws3.row(r).height = 1500    
        ws3.write(r, c, data, style2)
        c+=1
    
    ###################  monthly wise for the dg ####################
    
    coe = "DG"  
    mastertable_dg_month = Masterdatatable.objects.filter(mtsrcname = coe).values('mtmtrname','mtenergycons','mtdate').order_by('mtdate__month')
    
    list_dg = []
    month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
    cost_1  = 0; cost_2 = 0; cost_3 = 0; cost_4 = 0; cost_5=0; cost_6=0; cost_7=0; cost_8=0; cost_9=0; cost_10=0; cost_10=0; cost_11=0; cost_12=0
    cst_12 = 0
    cur_year = datetime.now().year
    for k in range(2022,cur_year+1):
        yrs = k
        # print(yrs)
        for i in mastertable_dg_month:
            month = i['mtdate'].month
            year = i['mtdate'].year
            # print(year)
            if month == 1 and yrs == year:
                month_1 = i['mtenergycons'] + month_1
                try:
                 cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                 cost_1 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_1
                except Cost_DG.DoesNotExist:
                  if cost_1 == 0:
                     cost_1 = 0 
                 
            if month == 2 and yrs == year:
                month_2 = i['mtenergycons'] + month_2
                try:
                 cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                 cost_2 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_2
                except Cost_DG.DoesNotExist:
                  if cost_2 == 0:
                    cost_2 = 0 
                
            if month == 3 and yrs == year:
                month_3 = i['mtenergycons'] + month_3
                try:
                   cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                   cost_3 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_3
                except Cost_DG.DoesNotExist:
                  if cost_3 == 0:
                    cost_3 = 0 
                
            if month == 4 and yrs == year:
                month_4 = i['mtenergycons'] + month_4
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_4 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_4
                except Cost_DG.DoesNotExist:
                  if cost_4 == 0:
                    cost_4 = 0
                
            if month == 5 and yrs == year:
                month_5 = i['mtenergycons'] + month_5
                try: 
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_5 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_5
                except Cost_DG.DoesNotExist:
                  if cost_5 == 0:
                    cost_5 = 0 
                
            if month == 6 and yrs == year:
                month_6 = i['mtenergycons'] + month_6
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_6 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_6
                except Cost_DG.DoesNotExist:
                  if cost_6 == 0:
                    cost_6 = 0
                 
            if month == 7 and yrs == year:
                month_7 = i['mtenergycons'] + month_7
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_7 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_7
                except Cost_DG.DoesNotExist:
                  if cost_7 == 0:
                    cost_7 = 0 
                
            if month == 8 and yrs == year:
                month_8 = i['mtenergycons'] + month_8
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_8 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_8
                except Cost_DG.DoesNotExist:
                  if cost_8 == 0:
                    cost_8 = 0 
                
            if month == 9 and yrs == year:
                month_9 = i['mtenergycons'] + month_9
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_9 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_9
                except Cost_DG.DoesNotExist:
                  if cost_9 == 0:
                    cost_9 = 0
               
            if month == 10 and yrs == year:
                month_10 = i['mtenergycons'] + month_10
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_10 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_10
                except Cost_DG.DoesNotExist:
                  if cost_10 == 0:
                    cost_10 = 0 
                
            if month == 11 and yrs == year:
                month_11 = i['mtenergycons'] + month_11
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_11 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_11
                except Cost_DG.DoesNotExist:
                  if cost_11 == 0:
                    cost_11 = 0 
                
            if month == 12 and yrs == year:
                month_12 = i['mtenergycons'] + month_12
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost_12 = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost_12                 
                except Cost_DG.DoesNotExist:
                  if cost_12 == 0:
                    cost_12 = 0  
                
        if month_1 != 0 :
            list_dg.append({"month":month_1 , "year": str("January_"+str(yrs)), "cost":cost_1})
        if month_2 != 0:
            list_dg.append({"month":month_2 , "year": str("February_"+str(yrs)), "cost":cost_2})
        if month_3 != 0:
            list_dg.append({"month":month_3 , "year": str("March_"+str(yrs)), "cost":cost_3})
        if month_4 != 0:
            list_dg.append({"month":month_4 , "year": str("April"+str(yrs)), "cost":cost_4})
        if month_5 != 0:
            list_dg.append({"month":month_5 , "year": str("May_"+str(yrs)), "cost":cost_5})
        if month_6 != 0:
            list_dg.append({"month":month_6 , "year": str("June_"+str(yrs)), "cost":cost_6})
        if month_7 != 0:
            list_dg.append({"month":month_7 , "year": str("July_"+str(yrs)), "cost":cost_7})
        if month_8 != 0:
            list_dg.append({"month":month_8 , "year": str("August_"+str(yrs)), "cost":cost_8})
        if month_9 != 0:
            list_dg.append({"month":month_9 , "year": str("September_"+str(yrs)), "cost":cost_9})
        if month_10 != 0:
            list_dg.append({"month":month_10 , "year": str("November_"+str(yrs)), "cost":cost_10})
        if month_11 != 0:
            list_dg.append({"month":month_11 , "year": str("October_"+str(yrs)), "cost":cost_11})
        if month_12 != 0:
            list_dg.append({"month":month_12 , "year": str("December_"+str(yrs)), "cost":cost_12})

        month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
        cost_1  = 0; cost_2 = 0; cost_3 = 0; cost_4 = 0; cost_5=0; cost_6=0; cost_7=0; cost_8=0; cost_9=0; cost_10=0; cost_10=0; cost_11=0; cost_12=0
        cst_12 = 0
    # print(list)
    r = 10; c=2; total =0 ; total_cost = 0
    for m in list_dg:
       ws3.write(r,c,m['year'],style3)
       ws3.write(r,c+1,m['month'],style3)
       ws3.write(r,c+2,m['cost'], style3) 
       total = m['month'] + total
       total_cost = m['cost'] + total_cost
       r+=1
    
    ws3.write_merge(r+1,r+1,c,c+1,"Total Consumption(INR)",style5)
    ws3.write_merge(r+2,r+2,c,c+1,"TotalCost(INR)",style4)
    ws3.write(r+1, c+2, total , style5)
    ws3.write(r+2, c+2, total_cost , style4)

    graph_totalcons_month.append({"srcname":coe,"totalcons":int(total)})
    graph_totalcost_month.append({"srcname":coe,"totalcost":int(total_cost)})
    
    ########  monthly wise for solar energy #########

    coe = "Solar Energy"  
    mastertable_solar_month = Masterdatatable.objects.filter(mtsrcname = coe).values('mtmtrname','mtenergycons','mtdate').order_by('mtdate__month')
    # solar_cst = Cost_Solar.objects.get(solar_id = 1).solar_cst
    try:
        solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
        # print(solar_cst)
    except:
        solar_cst = 0
    # print(master_tble)
    # print(solar_cst)
    
    list = []
    month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
    cost_1  = 0; cost_2 = 0; cost_3 = 0; cost_4 = 0; cost_5=0; cost_6=0; cost_7=0; cost_8=0; cost_9=0; cost_10=0; cost_10=0; cost_11=0; cost_12=0
    cur_year = datetime.now().year
    for k in range(2022,cur_year+1):
        yrs = k
        # print(yrs)
        for i in mastertable_solar_month: 
            month = i['mtdate'].month
            year = i['mtdate'].year
            # print(year)
            if month == 1 and yrs == year:
                month_1 = i['mtenergycons'] + month_1
                cost_1  = i['mtenergycons']*solar_cst + cost_1
                
            if month == 2 and yrs == year:
                month_2 = i['mtenergycons'] + month_2
                cost_2  = i['mtenergycons']*solar_cst + cost_2
                
            if month == 3 and yrs == year:
                month_3 = i['mtenergycons'] + month_3
                cost_3  = i['mtenergycons']*solar_cst + cost_3
            
            if month == 4 and yrs == year:
                month_4 = i['mtenergycons'] + month_4
                cost_4  = i['mtenergycons']*solar_cst + cost_4
               
            if month == 5 and yrs == year:
                month_5 = i['mtenergycons'] + month_5
                cost_5  = i['mtenergycons']*solar_cst + cost_5
            
            if month == 6 and yrs == year:
                month_6 = i['mtenergycons'] + month_6
                cost_6  = i['mtenergycons']*solar_cst + cost_6
                
            if month == 7 and yrs == year:
                month_7 = i['mtenergycons'] + month_7
                cost_7  = i['mtenergycons']*solar_cst + cost_7
               
            if month == 8 and yrs == year:
                month_8 = i['mtenergycons'] + month_8
                cost_8  = i['mtenergycons']*solar_cst + cost_8
               
            if month == 9 and yrs == year:
                month_9 = i['mtenergycons'] + month_9
                cost_9  = i['mtenergycons']*solar_cst + cost_9
             
            if month == 10 and yrs == year:
                month_10 = i['mtenergycons'] + month_10
                cost_10  = i['mtenergycons']*solar_cst + cost_10
            
            if month == 11 and yrs == year:
                month_11 = i['mtenergycons'] + month_11
                cost_11  = i['mtenergycons']*solar_cst + cost_11
              
            if month == 12 and yrs == year:
                month_12 = i['mtenergycons'] + month_12
                cost_12  = i['mtenergycons']*solar_cst + cost_12
        
        if month_1 != 0:
            list.append({"month":month_1 , "year": str("January_"+str(yrs)) , "cost":cost_1 })
        if month_2 != 0:
            list.append({"month":month_2 , "year": str("February_"+str(yrs)) , "cost":cost_2})
        if month_3 != 0:
            list.append({"month":month_3 , "year": str("March_"+str(yrs)) , "cost":cost_3})
        if month_4 != 0:
            list.append({"month":month_4 , "year": str("April"+str(yrs)) , "cost":cost_4})
        if month_5 != 0:
            list.append({"month":month_5 , "year": str("May_"+str(yrs)) , "cost":cost_5})
        if month_6 != 0:
            list.append({"month":month_6 , "year": str("June_"+str(yrs)) , "cost":cost_6})
        if month_7 != 0:
            list.append({"month":month_7 , "year": str("July_"+str(yrs)) , "cost":cost_7})
        if month_8 != 0:
            list.append({"month":month_8 , "year": str("August_"+str(yrs)) , "cost":cost_8})
        if month_9 != 0:
            list.append({"month":month_9 , "year": str("September_"+str(yrs)) , "cost":cost_9})
        if month_10 != 0:
            list.append({"month":month_10 , "year": str("November_"+str(yrs)) , "cost":cost_10})
        if month_11 != 0:
            list.append({"month":month_11 , "year": str("October_"+str(yrs)) , "cost":cost_11})
        if month_12 != 0:
            list.append({"month":month_12 , "year": str("December_"+str(yrs)) , "cost":cost_12})

        month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
        cost_1  = 0; cost_2 = 0; cost_3 = 0; cost_4 = 0; cost_5=0; cost_6=0; cost_7=0; cost_8=0; cost_9=0; cost_10=0; cost_10=0; cost_11=0; cost_12=0
    
    # print(list)
    r = 10; c=6; total = 0 ; total_cons = 0
    for m in list:
       ws3.write(r,c,m['year'],style3)
       ws3.write(r,c+1,m['month'],style3)
       ws3.write(r,c+2,m['cost'],style3)
       r+=1
       total = m['cost'] + total
       total_cons = m['month'] + total_cons
    
    ws3.write_merge(r+1,r+1,c,c+1,"TotalConsumption",style5)
    ws3.write_merge(r+2,r+2,c,c+1,"Total Cost(INR)",style4)
    ws3.write(r+1 , c+2 , total_cons , style5)
    ws3.write(r+2 , c+2 , total , style4)

    # graph_totalcons_month.append({"srcname":coe,"totalcons":int(total_cons)})
    # graph_totalcost_month.append({"srcname":coe,"totalcost":int(total)})
    
    coe = "Transformer1"
    mastertable_transformer_month = Masterdatatable.objects.filter(mtsrcname = coe, mtcategory="Secondary", mtgrpname='Incomer').all().values().order_by('mtdate__month')
    list_tr_mon = []
    month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
    cost_1  = 0; cost_2 = 0; cost_3 = 0; cost_4 = 0; cost_5=0; cost_6=0; cost_7=0; cost_8=0; cost_9=0; cost_10=0; cost_10=0; cost_11=0; cost_12=0
    cur_year = datetime.now().year
    for k in range(2020,cur_year+1):
        yrs = k
        # print(yrs)
        for r in mastertable_transformer_month: 
            month = r['mtdate'].month
            year = r['mtdate'].year
            # print(year)
            if month == 1 and yrs == year:
                month_1 = r['mtenergycons'] + month_1
                
            if month == 2 and yrs == year:
                month_2 = r['mtenergycons'] + month_2
                
            if month == 3 and yrs == year:
                month_3 = r['mtenergycons'] + month_3
            
            if month == 4 and yrs == year:
                month_4 = r['mtenergycons'] + month_4
               
            if month == 5 and yrs == year:
                month_5 = r['mtenergycons'] + month_5
            
            if month == 6 and yrs == year:
                month_6 = r['mtenergycons'] + month_6
                
            if month == 7 and yrs == year:
                month_7 = r['mtenergycons'] + month_7
               
            if month == 8 and yrs == year:
                month_8 = r['mtenergycons'] + month_8
               
            if month == 9 and yrs == year:
                month_9 = r['mtenergycons'] + month_9
             
            if month == 10 and yrs == year:
                month_10 = r['mtenergycons'] + month_10
            
            if month == 11 and yrs == year:
                month_11 = r['mtenergycons'] + month_11
              
            if month == 12 and yrs == year:
                month_12 = r['mtenergycons'] + month_12

        if month_1 != 0 :
            list_tr_mon.append({"month":month_1 , "year": str("January_"+str(yrs))})
        if month_2 != 0:
            list_tr_mon.append({"month":month_2 , "year": str("February_"+str(yrs))})
        if month_3 != 0:
            list_tr_mon.append({"month":month_3 , "year": str("March_"+str(yrs))})
        if month_4 != 0:
            list_tr_mon.append({"month":month_4 , "year": str("April"+str(yrs))})
        if month_5 != 0:
            list_tr_mon.append({"month":month_5 , "year": str("May_"+str(yrs))})
        if month_6 != 0:
            list_tr_mon.append({"month":month_6 , "year": str("June_"+str(yrs))})
        if month_7 != 0:
            list_tr_mon.append({"month":month_7 , "year": str("July_"+str(yrs))})
        if month_8 != 0:
            list_tr_mon.append({"month":month_8 , "year": str("August_"+str(yrs))})
        if month_9 != 0:
            list_tr_mon.append({"month":month_9 , "year": str("September_"+str(yrs))})
        if month_10 != 0:
            list_tr_mon.append({"month":month_10 , "year": str("November_"+str(yrs))})
        if month_11 != 0:
            list_tr_mon.append({"month":month_11 , "year": str("October_"+str(yrs))})
        if month_12 != 0:
            list_tr_mon.append({"month":month_12 , "year": str("December_"+str(yrs))})

        month_1 = 0; month_2 = 0; month_3 = 0; month_4 = 0; month_5=0; month_6=0; month_7=0; month_8 = 0; month_9=0; month_10=0; month_11=0; month_12=0
    
    r = 10; c=10; total = 0; total_cons = 0
    for m in list_tr_mon:
       total_cons = m['month'] + total_cons
       ws3.write(r,c,m['year'],style3)
       ws3.write(r,c+1,m['month'],style3)
       r+=1
    
    ws3.write_merge(r+1, r+1, c, c, "TotalConsumption", style5)
    ws3.write_merge(r+2, r+2, c, c, "TotalCost(INR)", style4)
    ws3.write(r+1,c+1,total_cons,style5)
    graph_totalcons_month.append({"srcname":coe,"totalcons":int(total_cons)})
    
    mastertble_mon = Masterdatatable.objects.filter(mtsrcname = coe, mtcategory="Secondary", mtgrpname='Incomer').values('mtmtrname','mtdate','mth1ec','mth2ec','mth3ec','mth4ec','mth5ec','mth6ec',
                                                                                        'mth7ec','mth8ec','mth9ec','mth10ec','mth11ec','mth12ec','mth13ec',
                                                                                        'mth14ec','mth15ec','mth16ec','mth17ec','mth18ec','mth19ec','mth20ec',
                                                                                        'mth21ec','mth22ec','mth23ec','mth24ec')
    # print(mastertble)
    count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
    
    for ms in mastertble_mon:
        # print(i['mtmtrname'])
        for w in ms:
            # print(w)
            if w == "mth1ec":
                mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                count_1 = 1
                # print(mth1ec)
            if w == "mth2ec":
                mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                count_2 = 2
                # print(mth2ec)
            if w == "mth3ec":
                mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                count_3 = 3
                # print(mth3ec)
            if w == "mth4ec":
                mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                count_4 = 4
                # print(mth4ec)
            if w == "mth5ec":
                mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                count_5 = 5
                # print(mth5ec)
            if w == "mth6ec":
                mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                count_6 = 6
                # print(mth6ec)
            if w == "mth7ec":
                mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                count_7 = 7
                # print(mth7ec)
            if w == "mth8ec":
                mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                count_8 = 8
                # print(mth8ec)
            if w == "mth9ec":
                mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                count_9 = 9
                # print(mth9ec)
            if w == "mth10ec":
                mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                count_10 = 10
                # print(mth10ec)
            if w == "mth11ec":
                mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                count_11 = 11
                # print(mth11ec)
            if w == "mth12ec":
                mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                count_12 = 12
                # print(mth12ec)
            if w == "mth13ec":
                mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                count_13 = 13
                # print(mth13ec)
            if w == "mth14ec":
                mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                count_14 = 14
                # print(mth14ec)
            if w == "mth15ec":
                mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                count_15 = 15
                # print(mth15ec)
            if w == "mth16ec":
                mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                count_16 = 16
                # print(mth16ec)
            if w == "mth17ec":
                mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                count_17 = 17
                # print(mth17ec)
            if w == "mth18ec":
                mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                count_18 = 18
                # print(mth18ec)
            if w == "mth19ec":
                mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                count_19 = 19
                # print(mth19ec)
            if w == "mth20ec":
                mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                count_20 = 20
                # print(mth20ec)
            if w == "mth21ec":
                mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                count_21 = 21
                # print(mth21ec)
            if w == "mth22ec":
                mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                count_22 = 22
                # print(mth22ec)
            if w == "mth23ec":
                mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                count_23 = 23
                # print(mth23ec)
            if w == "mth24ec":
                mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                count_24 = 24
                # print(mth24ec)
    # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
    val = 0
    val_2 =  0 
    r_1 = 9; c_1 = 12
    rw = 10 ; cl = 12 ; total_cost_inr = 0
    for e in session_config:
        # print(e['pkstatus'] , e['pkstart'], e['pkend'])
        time = e['pkstatus'] + "\n" + "( "+str ( e['pkstart'] ) + " to "+ str ( e['pkend'] ) + " )"
        ws3.col(c_1).width = 3500
        ws3.write(r_1,c_1, time ,style2)
        # print("pkstart:" ,(i['pkstart']))
        # print("pkend :" , (i['pkend']))
        pkstart = e['pkstart']
        datetime_objects = datetime.combine(datetime.now() , pkstart) 
        incr_onehur = datetime_objects + timedelta(hours=1) 
        pkstart =  incr_onehur.time()
        
        if pkstart ==  mth1ec: 
            # print("ps_mth1ec :",pkstart)
            val = count_1
        if pkstart == mth2ec:
            # print("ps_mth2ec :",e['pkstart'])
            val = count_2
        if pkstart == mth3ec:
            # print("ps_mth3ec :",e['pkstart'])
            val = count_3
        if pkstart == mth4ec:
            # print("ps_mth4ec :",e['pkstart'])
            val = count_4
        if pkstart == mth5ec:
            # print("ps_mth5ec :",e['pkstart'])
            val = count_5
        if pkstart == mth6ec:
            # print("ps_mth6ec :",i['pkstart'])
            val = count_6
        if pkstart == mth7ec:
            # print("ps_mth7ec :",i['pkstart'])
            val = count_7
        if pkstart == mth8ec:
            # print("ps_mth8ec :",i['pkstart'])
            val = count_8
        if pkstart == mth9ec:
            # print("ps_mth9ec :",i['pkstart'])
            val = count_9
        if pkstart == mth10ec:
            # print("ps_mth10ec :",i['pkstart'])
            val = count_10
        if pkstart == mth11ec:
            # print("ps_mth11ec :",i['pkstart'])
            val = count_11
        if pkstart== mth12ec:
            # print("ps_mth12ec :",i['pkstart'])
            val = count_12
        if pkstart == mth13ec:
            # print("ps_mth13ec :",i['pkstart'])
            val = count_13
        if pkstart == mth14ec:
            # print("ps_mth14ec :",i['pkstart'])
            val = count_14
        if pkstart == mth15ec:
            # print("ps_mth15ec :",i['pkstart'])
            val = count_15
        if pkstart == mth16ec:
            # print("ps_mth16ec :",i['pkstart'])
            val = count_16
        if pkstart == mth17ec:
            # print("ps_mth17ec :",i['pkstart'])
            val = count_17
        if pkstart == mth18ec:
            # print("ps_mth18ec :",i['pkstart'])
            val = count_18
        if pkstart == mth19ec:
            # print("ps_mth19ec :",i['pkstart'])
            val = count_19 
        if pkstart == mth20ec:
            # print("ps_mth20ec :",i['pkstart'])
            val = count_20
        if pkstart == mth21ec:
            # print("ps_mth21ec :",i['pkstart'])
            val = count_21
        if pkstart == mth22ec:
            # print("ps_mth22ec :",i['pkstart'])
            val = count_22
        if pkstart == mth23ec:
            # print("ps_mth23ec :",i['pkstart'])
            val = count_23
        if pkstart == mth24ec:
            # print("ps_mth24ec :",i['pkstart'])
            val = count_24

        #pkend
        if e['pkend'] == mth1ec:
            # print("pe_mth1ec :" , i['pkend'])
            val_2 = count_1
        if e['pkend'] == mth2ec:
            # print("pe_mth2ec :" , i['pkend'])
            val_2 = count_2
        if e['pkend'] == mth3ec:
            # print("pe_mth3ec :" , i['pkend'])
            val_2 = count_3
        if e['pkend'] == mth4ec:
            # print("pe_mth4ec :" , i['pkend'])
            val_2 = count_4
        if e['pkend'] == mth5ec:
            # print("pe_mth5ec :", i['pkend'])
            val_2 = count_5
        if e['pkend'] == mth6ec:
            # print("pe_mth6ec :", i['pkend'])
            val_2 = count_6
        if e['pkend'] == mth7ec:
            # print("pe_mth7ec :", i['pkend'])
            val_2 = count_7
        if e['pkend'] == mth8ec:
            # print("pe_mth8ec :", i['pkend'])
            val_2 = count_8
        if e['pkend'] == mth9ec:
            # print("pe_mth9ec :", i['pkend'])
            val_2 = count_9
        if e['pkend'] == mth10ec:
            # print("pe_mth10ec :", i['pkend'])
            val_2 = count_10
        if e['pkend'] == mth11ec:
            # print("pe_mth11ec :", i['pkend'])
            val_2 = count_11
        if e['pkend'] == mth12ec:
            # print("pe_mth12ec :", i['pkend'])
            val_2 = count_12
        if e['pkend'] == mth13ec:
            # print("pe_mth13ec :", i['pkend'])
            val_2 = count_13 
        if e['pkend'] == mth14ec:
            # print("pe_mth14ec :", i['pkend'])
            val_2 = count_14
        if e['pkend'] == mth15ec:
            # print("pe_mth15ec :", i['pkend'])
            val_2 = count_15 
        if e['pkend'] == mth16ec:
            # print("pe_mth16ec :", i['pkend'])
            val_2 = count_16
        if e['pkend'] == mth17ec:
            # print("pe_mth17ec :", i['pkend'])
            val_2 = count_17
        if e['pkend'] == mth18ec:
            # print("pe_mth18ec :", i['pkend'])
            val_2 = count_18 
        if e['pkend'] == mth19ec:
            # print("pe_mth19ec :", i['pkend'])
            val_2 = count_19 
        if e['pkend'] == mth20ec:
            # print("pe_mth20ec :", i['pkend'])
            val_2 = count_20
        if e['pkend'] == mth21ec:
            # print("pe_mth21ec :", i['pkend'])
            val_2 = count_21
        if e['pkend'] == mth22ec:
            # print("pe_mth22ec :", i['pkend'])
            val_2 = count_22 
        if e['pkend'] == mth23ec:
            # print("pe_mth23ec :", i['pkend'])
            val_2 = count_23 
        if e['pkend'] == mth24ec:
            # print("pe_mth24ec :", i['pkend'])
            val_2 = count_24 
        
        # print(val , val_2)
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
        m24ec='' ; total_cost = 0; rw = 10
        for n in range(val, val_2+1):
            if n == 1:
                m1ec = 'mth1ec'
                # print(m1ec)
            if n == 2:
                m2ec = 'mth2ec'
                # print(m2ec)
            if n == 3:
                m3ec = 'mth3ec'
                # print(m3ec)      
            if n == 4:
                m4ec = 'mth4ec'
                # print(m4ec)
            if n == 5:
                m5ec = 'mth5ec'
                # print(m5ec)
            if n == 6:
                m6ec = 'mth6ec'
                # print(m6ec)
            if n == 7:
                m7ec = 'mth7ec'
                # print(m7ec)
            if n == 8:
                m8ec = 'mth8ec'
                # print(m8ec)
            if n == 9:
                m9ec = 'mth9ec'
                # print(m9ec)
            if n == 10:
                m10ec = 'mth10ec'
                # print(m10ec)
            if n == 11:
                m11ec = 'mth11ec'
                # print(m11ec)
            if n == 12:
                m12ec = 'mth12ec'
                # print(m12ec)
            if n == 13:
                m13ec = 'mth13ec'
                # print(m13ec)
            if n == 14:
                m14ec = 'mth14ec'
                # print(m14ec)
            if n == 15:
                m15ec = 'mth15ec'
                # print(m15ec)
            if n == 16:
                m16ec = 'mth16ec'
                # print(m16ec)
            if n == 17:
                m17ec = 'mth17ec'
                # print(m17ec)
            if n == 18:
                m18ec = 'mth18ec'
                # print(m18ec)
            if n == 19:
                m19ec = 'mth19ec'
                # print(m19ec)
            if n == 20:
                m20ec = 'mth20ec'
                # print(m20ec)
            if n == 21:
                m21ec = 'mth21ec'
                # print(m21ec)
            if n == 22:
                m22ec = 'mth22ec'
                # print(m22ec)
            if n == 23:
                m23ec = 'mth23ec'
                # print(m23ec)
            if n == 24:
                m24ec = 'mth24ec'
                # print(m24ec)
            
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0; month = 0
               
        mastertble_monthly_wise = Masterdatatable.objects.filter(mtsrcname = 'Transformer1', mtcategory="Secondary", mtgrpname='Incomer').all().values()
        
        for y in range(2020,cur_year+1):
            year = y
            for x in range(1,12+1):
                mon_wise = x
                for q_sess in mastertble_monthly_wise:
                  if q_sess['mtdate'].month == mon_wise and q_sess['mtdate'].year == year:
                    month = q_sess['mtdate'].month
                    for z in q_sess:
                        if z == m1ec:
                            if q_sess['mth1ec'] == None:
                                vl_1 = 0 + vl_1
                            else:
                               vl_1  = q_sess['mth1ec'] + vl_1
                            #    print(vl_1)
                        if z == m2ec:
                            if q_sess['mth2ec'] == None:
                                vl_2 = 0 + vl_2
                            else:
                               vl_2  = q_sess['mth2ec'] + vl_2
                            #    print(vl_2)
                        if z == m3ec:
                            if q_sess['mth3ec'] == None:
                                vl_3= 0 + vl_3
                            else:
                               vl_3  = q_sess['mth3ec'] + vl_3
                            #    print(vl_3)
                        if z == m4ec:
                            if q_sess['mth4ec'] == None:
                                vl_4 = 0 + vl_4
                            else:
                               vl_4  = q_sess['mth4ec']  + vl_4
                            #    print(vl_4) 
                        if z == m5ec:
                            if q_sess['mth5ec'] == None:
                                vl_5 = 0 + vl_5
                            else:
                               vl_5  = q_sess['mth5ec'] + vl_5
                            #    print(vl_5)
                        if z == m6ec:
                            if q_sess['mth6ec'] == None:
                                vl_6 = 0 + vl_6
                            else:
                               vl_6  = q_sess['mth6ec'] + vl_6
                            #    print(vl_6)
                        if z == m7ec:
                            if q_sess['mth7ec'] == None:
                                vl_7 = 0 + vl_7
                            else:
                               vl_7  = q_sess['mth7ec'] + vl_7
                            #    print(vl_7)
                        if z == m8ec:
                            if q_sess['mth8ec'] == None:
                                vl_8 = 0 + vl_8
                            else:
                               vl_8  = q_sess['mth8ec'] + vl_8
                            #    print(vl_8)
                        if z == m9ec:
                            if q_sess['mth9ec'] == None:
                                vl_9 = 0 + vl_9
                            else:
                               vl_9  = q_sess['mth9ec'] + vl_9
                            #    print(vl_9)
                        if z == m10ec:
                            if q_sess['mth10ec'] == None:
                                vl_10 = 0 + vl_10
                            else:
                               vl_10  = q_sess['mth10ec'] + vl_10
                            #    print(vl_10)
                        if z == m11ec:
                            if q_sess['mth11ec'] == None:
                                vl_11 = 0 + vl_11
                            else:
                               vl_11  = q_sess['mth11ec'] + vl_11
                            #    print(vl_11)
                        if z == m12ec:
                            if q_sess['mth12ec'] == None:
                                vl_12 = 0 + vl_12
                            else:
                               vl_12  = q_sess['mth12ec'] + vl_12
                            #    print(vl_12)
                        if z == m13ec:
                            if q_sess['mth13ec'] == None:
                                vl_13 = 0 + vl_13
                            else:
                               vl_13  = q_sess['mth13ec'] + vl_13
                            #    print(vl_13)
                        if z == m14ec:
                            if q_sess['mth14ec'] == None:
                                vl_14 = 0 + vl_14
                            else:
                               vl_14  = q_sess['mth14ec'] + vl_14
                            #    print(vl_14)
                        if z == m15ec:
                            if q_sess['mth15ec'] == None:
                                vl_15 = 0 + vl_15
                            else:
                               vl_15  = q_sess['mth15ec'] + vl_15
                            #    print(vl_15)
                        if z == m16ec:
                            if q_sess['mth16ec'] == None:
                                vl_16 = 0 + vl_16
                            else:
                               vl_16  = q_sess['mth16ec'] + vl_16
                            #    print(vl_16)
                        if z == m17ec:
                            if q_sess['mth17ec'] == None:
                                vl_17 = 0 + vl_17
                            else:
                               vl_17  = q_sess['mth17ec'] + vl_17
                            #    print(vl_17)
                        if z == m18ec:
                            if q_sess['mth18ec'] == None:
                                vl_18 = 0 + vl_18
                            else:
                               vl_18  = q_sess['mth18ec'] + vl_18
                            #    print(vl_18)
                        if z == m19ec:
                            if q_sess['mth19ec'] == None:
                                vl_19 = 0 + vl_19
                            else:
                               vl_19  = q_sess['mth19ec'] + vl_19
                            #    print(vl_19)
                        if z == m20ec:
                            if q_sess['mth20ec'] == None:
                                vl_20 = 0 + vl_20
                            else:
                               vl_20 = q_sess['mth20ec'] + vl_20
                            #    print(vl_20)
                        if z == m21ec:
                            if q_sess['mth21ec'] == None:
                                vl_21 = 0 + vl_21
                            else:
                               vl_21  = q_sess['mth21ec'] + vl_21
                            #    print(vl_21)
                        if z == m22ec:
                            if q_sess['mth22ec'] == None:
                                vl_22 = 0 + vl_22
                            else:
                               vl_22  = q_sess['mth22ec'] + vl_22
                            #    print(vl_22)
                        if z == m23ec:
                            if q_sess['mth23ec'] == None:
                                vl_23 = 0 + vl_23
                            else:
                               vl_23  = q_sess['mth23ec'] + vl_23
                            #    print(vl_23)
                        if z == m24ec:
                            if q_sess['mth24ec'] == None:
                                vl_24 = 0 + vl_24
                            else:
                               vl_24 = q_sess['mth24ec'] + vl_24
                            #    print(vl_24)  
            
                Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
                total_cost = Add + total_cost
                if mon_wise == month:
                #    print(year, mon_wise, Add)
                   ws3.write(rw, cl, Add, style3)
                   rw = rw+1 
                vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
                vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
                      
        cost_eb = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
        # print(cost_eb)
        total_cst = 0
        if cost_eb:
            for cst in cost_eb:
                total_cst = cst['EB_SessionCost'] * total_cost
                # print("total_cst",total_cst)
        else:
            total_cst = 0
        
        total_cost_inr = total_cst + total_cost_inr

        ws3.write(rw+1, cl, total_cost, style5)
        ws3.write(rw+2, cl, total_cst,style4)    

        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
        
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
        cl+=1; c_1 +=1

    ws3.write(rw+2,11,total_cost_inr,style4)  
    graph_totalcost_month.append({"srcname":coe,"totalcost":int(total_cost_inr)})
    
    ####################################################  GRAPH REPORT #################################################
    
    # print(graph_totalcost_month , graph_totalcons_month)
    totalcons_consumption_mon = []; slots_consumption_mon = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcons_month:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
               totalcons_consumption_mon.append(z['totalcons'])
               slots_consumption_mon.append(src_nm_1)

    # TotalConsumptions = totalcons_consumption_mon; bars_mon_cons = slots_consumption_mon
    # X_pos = np.arange(len(bars_mon_cons))
    # plt.bar(X_pos, TotalConsumptions , color = 'darkslategrey' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('consumptions')
    # plt.legend(labels=['TotalConsumptions'])
    # plt.xticks(X_pos, bars_mon_cons)
    # plt.savefig('Report/Plot/6.jpeg')
    # # plt.show()
    # plt.close()
    
    totalcons_cost_mon = []; slots_cost_mon = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcost_month:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
               totalcons_cost_mon.append(z['totalcost'])
               slots_cost_mon.append(src_nm_1)

    # TotalCosts = totalcons_cost_mon; bars_mon_cost = slots_cost_mon
    # X_pos = np.arange(len(bars_mon_cost))
    # plt.bar(X_pos, TotalCosts , color = 'r' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('costs')
    # plt.legend(labels=['TotalCosts'])
    # plt.xticks(X_pos, bars_mon_cost)
    # plt.savefig('Report/Plot/7.jpeg')
    # # plt.show()
    # plt.close()
    
    # #----------------------
    # cons=2 ; cost = 2 ; row_grh_1 = graph_row ; row_grh_2 = graph_row + 30
    # for im in range(6,8):
    #     # print("image",im)
    #     if im == 6:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws3.insert_bitmap('TNEB.bmp',row_grh_1,cons)
    #         # print("image_1 is inserted")
    #     if im == 7:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws3.insert_bitmap('TNEB.bmp',row_grh_2,cost)
    #         # print("image_2 is inserted")
    ##################################### Yearly wise Report ######################
    
    graph_totalcons_year = []; graph_totalcost_year = []

    r = 1
    c = 2
    ws4.write_merge(r, r+1, c, c+12, ('R-ENERGY -'+plant_name), style)

    r = 6
    c = 2
    for data in ['DG', 'Solar', 'TNEB']:
        ws4.write_merge(r, r, c, c+1, ('Source Name:'), style1)
        ws4.write_merge(r+1, r+1, c, c+1, ('Date:'), style1)
        c+=2
        ws4.write_merge(r, r, c, c, (data), style1)
        ws4.write_merge(r+1, r+1, c, c, str(yesterday), style1)
        c+= 2

    r = 9; c=2
    for data in ['Year', 'Consumption', 'Cost']:
        ws4.col(c).width = 3500
        #ws4.row(r).height_mismatch = True
        ws4.row(r).height = 1500
        ws4.write(r, c, data, style2)
        c+=1   

    r=9; c=6
    for data in ['Year', 'Consumption', 'Cost']:
        ws4.col(c).width = 3500
        #ws4.row(r).height_mismatch = True
        ws4.row(r).height = 1500
        ws4.write(r, c, data, style2)
        c+=1

    r=9; c =10
    ws4.col(c).width = 4000
    ws4.col(c+1).width = 3500
    for data in ['Date','''Total Consumption
    (24 hrs)''']:
        #ws4.row(r).height_mismatch = True
        ws4.row(r).height = 1500
        ws4.write(r, c, data, style2)
        c+=1
    
    list_yrs_dg = []
    consumption = 0; coe = 'DG'
    cur_year = datetime.now().year
    mastertable_yrs_dg = Masterdatatable.objects.filter(mtsrcname=coe).all().values()
    for k in range(2020,cur_year+1):
        yrs = k
        # print(yrs)
        for i in mastertable_yrs_dg:    
            year = i['mtdate'].year
            # print(year)
            if yrs == year:
                consumption  = i['mtenergycons'] + consumption
                try:
                  cost_val = Cost_DG.objects.get(dg_date = i['mtdate'] , dg_desc = i['mtmtrname'])
                  cost = cost_val.dg_lit_cons * cost_val.dg_lit_cpl  + cost
                except Cost_DG.DoesNotExist:
                  if cost == 0:
                    cost = 0 
                
        if consumption != 0:
            list_yrs_dg.append({"consumption":consumption , "year": str(yrs) , "cost": cost})
        
        consumption = 0; cost = 0
    
    # print(val)
    r = 10; c=2; total = 0; total_cost = 0
    for k in list_yrs_dg:
       total = k['consumption'] + total
       total_cost = k['cost'] +  total_cost
       ws4.write(r,c,k['year'],style3)
       ws4.write(r,c+1,k['consumption'],style3)
       ws4.write(r,c+2,k['cost'],style3)
       r+=1
    #print(a)

    ws4.col(c+1).width = 5000
    ws4.write_merge(r+1,r+1,c,c+1,"Total Consumption(INR)",style5)
    ws4.write_merge(r+2,r+2,c,c+1,"TotalCost(INR)",style4)
    ws4.write(r+1 , c+2 , total , style5)
    ws4.write(r+2,c+2,total_cost,style4)
    graph_totalcons_year.append({"srcname":coe,"totalcons":int (total)})
    graph_totalcost_year.append({"srcname":coe,"totalcost":int(total_cost)})
    
    list_yrs_solar = []
    consumption = 0; coe = 'Solar Energy'; cost = 0
    cur_year = datetime.now().year
    mastertable_yrs_solar = Masterdatatable.objects.filter(mtsrcname=coe).all().values()
    for k in range(2020,cur_year+1):
        yrs = k
        # print(yrs)
        for i in mastertable_yrs_solar:   
            year = i['mtdate'].year
            # print(year)
            if yrs == year:
                consumption  = i['mtenergycons'] + consumption
                cost = i['mtenergycons']*solar_cst + cost
        if consumption != 0:
            list_yrs_solar.append({"consumption":consumption , "year": str(yrs), "cost":cost})
        
        consumption = 0; cost = 0
    
    # print(val)
    r = 10; c=6; total = 0 ; total_cons = 0
    for k in list_yrs_solar:
       total_cons = k['consumption'] + total_cons
       total = k['cost'] + total
       ws4.write(r,c,k['year'],style3)
       ws4.write(r,c+1,k['consumption'],style3)
       ws4.write(r,c+2, k['cost'],style3)
       r+=1
    #print(a)

    ws4.col(c+1).width = 5000
    ws4.write_merge(r+1,r+1,c,c+1,"Total Consumption(INR)",style5)
    ws4.write_merge(r+2,r+2,c,c+1,"TotalCost(INR)",style4)
    ws4.write(r+1 , c+2 , total_cons , style5)
    ws4.write(r+2 , c+2 , total , style4)
    graph_totalcons_year.append({"srcname":coe,"totalcons":int (total_cons)})
    graph_totalcost_year.append({"srcname":coe,"totalcost":int(total)})
    
    list_yrs_trs = []
    consumption = 0; coe = 'Transformer1'
    cur_year = datetime.now().year
    mastertable_yrs_trs = Masterdatatable.objects.filter(mtsrcname=coe, mtcategory="Secondary", mtgrpname='Incomer').all().values()
    for k in range(2020,cur_year+1):
        yrs = k
        # print("yearly_wise" , yrs)
        for i in mastertable_yrs_trs:   
            year = i['mtdate'].year
            # print(year)
            if yrs == year:
                if i['mtenergycons'] == None:
                    consumption = 0 + consumption
                else:
                    consumption  = i['mtenergycons'] + consumption

        if consumption != 0:
            list_yrs_trs.append({"consumption":consumption , "year": str(yrs)})
        consumption = 0; 
    # print(list_yrs_trs)
    # print(val)
    r = 10; c=10; total = 0; total_cons = 0
    # print(list_yrs_trs)
    for k in list_yrs_trs:
       total_cons = total_cons + k['consumption']
       ws4.write(r,c,k['year'],style3)
       ws4.write(r,c+1,k['consumption'],style3)
       r+=1
    
    ws4.write_merge(r+1, r+1, c, c, "TotalConsumption", style5)
    ws4.write(r+1, c+1, total_cons , style5)
    graph_totalcons_year.append({"srcname":coe,"totalcons":int (total_cons)})
    ws4.write_merge(r+2, r+2, c, c, "TotalCost(INR)", style4)
    
    mastertble_yrs = Masterdatatable.objects.filter(mtsrcname = 'Transformer1', mtcategory="Secondary", mtgrpname='Incomer').values('mtmtrname','mtdate','mth1ec','mth2ec','mth3ec','mth4ec','mth5ec','mth6ec',
                                                                                        'mth7ec','mth8ec','mth9ec','mth10ec','mth11ec','mth12ec','mth13ec',
                                                                                        'mth14ec','mth15ec','mth16ec','mth17ec','mth18ec','mth19ec','mth20ec',
                                                                                        'mth21ec','mth22ec','mth23ec','mth24ec')
    # print(mastertble)
    count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
    
    for ms in mastertble_yrs:
        # print(i['mtmtrname'])
        for w in ms:
            # print(w)
            if w == "mth1ec":
                mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                count_1 = 1
                # print(mth1ec)
            if w == "mth2ec":
                mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                count_2 = 2
                # print(mth2ec)
            if w == "mth3ec":
                mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                count_3 = 3
                # print(mth3ec)
            if w == "mth4ec":
                mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                count_4 = 4
                # print(mth4ec)
            if w == "mth5ec":
                mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                count_5 = 5
                # print(mth5ec)
            if w == "mth6ec":
                mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                count_6 = 6
                # print(mth6ec)
            if w == "mth7ec":
                mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                count_7 = 7
                # print(mth7ec)
            if w == "mth8ec":
                mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                count_8 = 8
                # print(mth8ec)
            if w == "mth9ec":
                mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                count_9 = 9
                # print(mth9ec)
            if w == "mth10ec":
                mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                count_10 = 10
                # print(mth10ec)
            if w == "mth11ec":
                mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                count_11 = 11
                # print(mth11ec)
            if w == "mth12ec":
                mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                count_12 = 12
                # print(mth12ec)
            if w == "mth13ec":
                mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                count_13 = 13
                # print(mth13ec)
            if w == "mth14ec":
                mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                count_14 = 14
                # print(mth14ec)
            if w == "mth15ec":
                mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                count_15 = 15
                # print(mth15ec)
            if w == "mth16ec":
                mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                count_16 = 16
                # print(mth16ec)
            if w == "mth17ec":
                mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                count_17 = 17
                # print(mth17ec)
            if w == "mth18ec":
                mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                count_18 = 18
                # print(mth18ec)
            if w == "mth19ec":
                mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                count_19 = 19
                # print(mth19ec)
            if w == "mth20ec":
                mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                count_20 = 20
                # print(mth20ec)
            if w == "mth21ec":
                mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                count_21 = 21
                # print(mth21ec)
            if w == "mth22ec":
                mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                count_22 = 22
                # print(mth22ec)
            if w == "mth23ec":
                mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                count_23 = 23
                # print(mth23ec)
            if w == "mth24ec":
                mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                count_24 = 24
                # print(mth24ec)
    # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
    val = 0
    val_2 =  0 
    r_1 = 9; c_1 = 12
    rw = 10 ; cl = 12; total_cst_inr = 0
    for e in session_config:
        # print(e['pkstatus'] , e['pkstart'], e['pkend'])
        time = e['pkstatus'] + "\n" + "( "+str ( e['pkstart'] ) + " to "+ str ( e['pkend'] ) + " )"
        ws4.col(c_1).width = 3500
        ws4.write(r_1,c_1, time ,style2)
        # print("pkstart:" ,(i['pkstart']))
        # print("pkend :" , (i['pkend']))
        pkstart = e['pkstart']
        datetime_objects = datetime.combine(datetime.now() , pkstart) 
        incr_onehur = datetime_objects + timedelta(hours=1) 
        pkstart =  incr_onehur.time()
        if pkstart ==  mth1ec:
            # print("ps_mth1ec :",e["pkstart"])
            val = count_1
        if pkstart == mth2ec:
            # print("ps_mth2ec :",e['pkstart'])
            val = count_2
        if pkstart == mth3ec:
            # print("ps_mth3ec :",e['pkstart'])
            val = count_3
        if pkstart == mth4ec:
            # print("ps_mth4ec :",e['pkstart'])
            val = count_4
        if pkstart == mth5ec:
            # print("ps_mth5ec :",e['pkstart'])
            val = count_5
        if pkstart == mth6ec:
            # print("ps_mth6ec :",i['pkstart'])
            val = count_6
        if pkstart == mth7ec:
            # print("ps_mth7ec :",i['pkstart'])
            val = count_7
        if pkstart == mth8ec:
            # print("ps_mth8ec :",i['pkstart'])
            val = count_8
        if pkstart == mth9ec:
            # print("ps_mth9ec :",i['pkstart'])
            val = count_9
        if pkstart == mth10ec:
            # print("ps_mth10ec :",i['pkstart'])
            val = count_10
        if pkstart == mth11ec:
            # print("ps_mth11ec :",i['pkstart'])
            val = count_11
        if pkstart == mth12ec:
            # print("ps_mth12ec :",i['pkstart'])
            val = count_12
        if pkstart == mth13ec:
            # print("ps_mth13ec :",i['pkstart'])
            val = count_13
        if pkstart == mth14ec:
            # print("ps_mth14ec :",i['pkstart'])
            val = count_14
        if pkstart == mth15ec:
            # print("ps_mth15ec :",i['pkstart'])
            val = count_15
        if pkstart == mth16ec:
            # print("ps_mth16ec :",i['pkstart'])
            val = count_16
        if pkstart == mth17ec:
            # print("ps_mth17ec :",i['pkstart'])
            val = count_17
        if pkstart == mth18ec:
            # print("ps_mth18ec :",i['pkstart'])
            val = count_18
        if pkstart == mth19ec:
            # print("ps_mth19ec :",i['pkstart'])
            val = count_19 
        if pkstart == mth20ec:
            # print("ps_mth20ec :",i['pkstart'])
            val = count_20
        if pkstart == mth21ec:
            # print("ps_mth21ec :",i['pkstart'])
            val = count_21
        if pkstart == mth22ec:
            # print("ps_mth22ec :",i['pkstart'])
            val = count_22
        if pkstart == mth23ec:
            # print("ps_mth23ec :",i['pkstart'])
            val = count_23
        if pkstart == mth24ec:
            # print("ps_mth24ec :",i['pkstart'])
            val = count_24

        #pkend
        if e['pkend'] == mth1ec:
            # print("pe_mth1ec :" , i['pkend'])
            val_2 = count_1
        if e['pkend'] == mth2ec:
            # print("pe_mth2ec :" , i['pkend'])
            val_2 = count_2
        if e['pkend'] == mth3ec:
            # print("pe_mth3ec :" , i['pkend'])
            val_2 = count_3
        if e['pkend'] == mth4ec:
            # print("pe_mth4ec :" , i['pkend'])
            val_2 = count_4
        if e['pkend'] == mth5ec:
            # print("pe_mth5ec :", i['pkend'])
            val_2 = count_5
        if e['pkend'] == mth6ec:
            # print("pe_mth6ec :", i['pkend'])
            val_2 = count_6
        if e['pkend'] == mth7ec:
            # print("pe_mth7ec :", i['pkend'])
            val_2 = count_7
        if e['pkend'] == mth8ec:
            # print("pe_mth8ec :", i['pkend'])
            val_2 = count_8
        if e['pkend'] == mth9ec:
            # print("pe_mth9ec :", i['pkend'])
            val_2 = count_9
        if e['pkend'] == mth10ec:
            # print("pe_mth10ec :", i['pkend'])
            val_2 = count_10
        if e['pkend'] == mth11ec:
            # print("pe_mth11ec :", i['pkend'])
            val_2 = count_11
        if e['pkend'] == mth12ec:
            # print("pe_mth12ec :", i['pkend'])
            val_2 = count_12
        if e['pkend'] == mth13ec:
            # print("pe_mth13ec :", i['pkend'])
            val_2 = count_13 
        if e['pkend'] == mth14ec:
            # print("pe_mth14ec :", i['pkend'])
            val_2 = count_14
        if e['pkend'] == mth15ec:
            # print("pe_mth15ec :", i['pkend'])
            val_2 = count_15 
        if e['pkend'] == mth16ec:
            # print("pe_mth16ec :", i['pkend'])
            val_2 = count_16
        if e['pkend'] == mth17ec:
            # print("pe_mth17ec :", i['pkend'])
            val_2 = count_17
        if e['pkend'] == mth18ec:
            # print("pe_mth18ec :", i['pkend'])
            val_2 = count_18 
        if e['pkend'] == mth19ec:
            # print("pe_mth19ec :", i['pkend'])
            val_2 = count_19 
        if e['pkend'] == mth20ec:
            # print("pe_mth20ec :", i['pkend'])
            val_2 = count_20
        if e['pkend'] == mth21ec:
            # print("pe_mth21ec :", i['pkend'])
            val_2 = count_21
        if e['pkend'] == mth22ec:
            # print("pe_mth22ec :", i['pkend'])
            val_2 = count_22 
        if e['pkend'] == mth23ec:
            # print("pe_mth23ec :", i['pkend'])
            val_2 = count_23 
        if e['pkend'] == mth24ec:
            # print("pe_mth24ec :", i['pkend'])
            val_2 = count_24 

        # print(val , val_2)
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
        m24ec='' ; total_cost = 0; rw = 10
        for n in range(val, val_2+1):
            if n == 1:
                m1ec = 'mth1ec'
                # print(m1ec)
            if n == 2:
                m2ec = 'mth2ec'
                # print(m2ec)
            if n == 3:
                m3ec = 'mth3ec'
                # print(m3ec)      
            if n == 4:
                m4ec = 'mth4ec'
                # print(m4ec)
            if n == 5:
                m5ec = 'mth5ec'
                # print(m5ec)
            if n == 6:
                m6ec = 'mth6ec'
                # print(m6ec)
            if n == 7:
                m7ec = 'mth7ec'
                # print(m7ec)
            if n == 8:
                m8ec = 'mth8ec'
                # print(m8ec)
            if n == 9:
                m9ec = 'mth9ec'
                # print(m9ec)
            if n == 10:
                m10ec = 'mth10ec'
                # print(m10ec)
            if n == 11:
                m11ec = 'mth11ec'
                # print(m11ec)
            if n == 12:
                m12ec = 'mth12ec'
                # print(m12ec)
            if n == 13:
                m13ec = 'mth13ec'
                # print(m13ec)
            if n == 14:
                m14ec = 'mth14ec'
                # print(m14ec)
            if n == 15:
                m15ec = 'mth15ec'
                # print(m15ec)
            if n == 16:
                m16ec = 'mth16ec'
                # print(m16ec)
            if n == 17:
                m17ec = 'mth17ec'
                # print(m17ec)
            if n == 18:
                m18ec = 'mth18ec'
                # print(m18ec)
            if n == 19:
                m19ec = 'mth19ec'
                # print(m19ec)
            if n == 20:
                m20ec = 'mth20ec'
                # print(m20ec)
            if n == 21:
                m21ec = 'mth21ec'
                # print(m21ec)
            if n == 22:
                m22ec = 'mth22ec'
                # print(m22ec)
            if n == 23:
                m23ec = 'mth23ec'
                # print(m23ec)
            if n == 24:
                m24ec = 'mth24ec'
                # print(m24ec)
            
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0; yr_ws = 0
               
        mastertble_year_wise = Masterdatatable.objects.filter(mtsrcname = 'Transformer1', mtcategory="Secondary", mtgrpname='Incomer').all().values()
        
        for y in range(2020,cur_year+1):
            year = y
            for q_sess in mastertble_year_wise:
                if q_sess['mtdate'].year == year:
                    yr_ws = q_sess['mtdate'].year
                    for z in q_sess:
                        if z == m1ec:
                            if q_sess['mth1ec'] == None:
                                vl_1 = 0 + vl_1
                            else:
                               vl_1  = q_sess['mth1ec'] + vl_1
                            #    print(vl_1)
                        if z == m2ec:
                            if q_sess['mth2ec'] == None:
                                vl_2 = 0 + vl_2
                            else:
                               vl_2  = q_sess['mth2ec'] + vl_2
                            #    print(vl_2)
                        if z == m3ec:
                            if q_sess['mth3ec'] == None:
                                vl_3= 0 + vl_3
                            else:
                               vl_3  = q_sess['mth3ec'] + vl_3
                            #    print(vl_3)
                        if z == m4ec:
                            if q_sess['mth4ec'] == None:
                                vl_4 = 0 + vl_4
                            else:
                               vl_4  = q_sess['mth4ec']  + vl_4
                            #    print(vl_4) 
                        if z == m5ec:
                            if q_sess['mth5ec'] == None:
                                vl_5 = 0 + vl_5
                            else:
                               vl_5  = q_sess['mth5ec'] + vl_5
                            #    print(vl_5)
                        if z == m6ec:
                            if q_sess['mth6ec'] == None:
                                vl_6 = 0 + vl_6
                            else:
                               vl_6  = q_sess['mth6ec'] + vl_6
                            #    print(vl_6)
                        if z == m7ec:
                            if q_sess['mth7ec'] == None:
                                vl_7 = 0 + vl_7
                            else:
                               vl_7  = q_sess['mth7ec'] + vl_7
                            #    print(vl_7)
                        if z == m8ec:
                            if q_sess['mth8ec'] == None:
                                vl_8 = 0 + vl_8
                            else:
                               vl_8  = q_sess['mth8ec'] + vl_8
                            #    print(vl_8)
                        if z == m9ec:
                            if q_sess['mth9ec'] == None:
                                vl_9 = 0 + vl_9
                            else:
                               vl_9  = q_sess['mth9ec'] + vl_9
                            #    print(vl_9)
                        if z == m10ec:
                            if q_sess['mth10ec'] == None:
                                vl_10 = 0 + vl_10
                            else:
                               vl_10  = q_sess['mth10ec'] + vl_10
                            #    print(vl_10)
                        if z == m11ec:
                            if q_sess['mth11ec'] == None:
                                vl_11 = 0 + vl_11
                            else:
                               vl_11  = q_sess['mth11ec'] + vl_11
                            #    print(vl_11)
                        if z == m12ec:
                            if q_sess['mth12ec'] == None:
                                vl_12 = 0 + vl_12
                            else:
                               vl_12  = q_sess['mth12ec'] + vl_12
                            #    print(vl_12)
                        if z == m13ec:
                            if q_sess['mth13ec'] == None:
                                vl_13 = 0 + vl_13
                            else:
                               vl_13  = q_sess['mth13ec'] + vl_13
                            #    print(vl_13)
                        if z == m14ec:
                            if q_sess['mth14ec'] == None:
                                vl_14 = 0 + vl_14
                            else:
                               vl_14  = q_sess['mth14ec'] + vl_14
                            #    print(vl_14)
                        if z == m15ec:
                            if q_sess['mth15ec'] == None:
                                vl_15 = 0 + vl_15
                            else:
                               vl_15  = q_sess['mth15ec'] + vl_15
                            #    print(vl_15)
                        if z == m16ec:
                            if q_sess['mth16ec'] == None:
                                vl_16 = 0 + vl_16
                            else:
                               vl_16  = q_sess['mth16ec'] + vl_16
                            #    print(vl_16)
                        if z == m17ec:
                            if q_sess['mth17ec'] == None:
                                vl_17 = 0 + vl_17
                            else:
                               vl_17  = q_sess['mth17ec'] + vl_17
                            #    print(vl_17)
                        if z == m18ec:
                            if q_sess['mth18ec'] == None:
                                vl_18 = 0 + vl_18
                            else:
                               vl_18  = q_sess['mth18ec'] + vl_18
                            #    print(vl_18)
                        if z == m19ec:
                            if q_sess['mth19ec'] == None:
                                vl_19 = 0 + vl_19
                            else:
                               vl_19  = q_sess['mth19ec'] + vl_19
                            #    print(vl_19)
                        if z == m20ec:
                            if q_sess['mth20ec'] == None:
                                vl_20 = 0 + vl_20
                            else:
                               vl_20 = q_sess['mth20ec'] + vl_20
                            #    print(vl_20)
                        if z == m21ec:
                            if q_sess['mth21ec'] == None:
                                vl_21 = 0 + vl_21
                            else:
                               vl_21  = q_sess['mth21ec'] + vl_21
                            #    print(vl_21)
                        if z == m22ec:
                            if q_sess['mth22ec'] == None:
                                vl_22 = 0 + vl_22
                            else:
                               vl_22  = q_sess['mth22ec'] + vl_22
                            #    print(vl_22)
                        if z == m23ec:
                            if q_sess['mth23ec'] == None:
                                vl_23 = 0 + vl_23
                            else:
                               vl_23  = q_sess['mth23ec'] + vl_23
                            #    print(vl_23)
                        if z == m24ec:
                            if q_sess['mth24ec'] == None:
                                vl_24 = 0 + vl_24
                            else:
                               vl_24 = q_sess['mth24ec'] + vl_24
                            #    print(vl_24)  
            
            Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
            total_cost = Add + total_cost
            if year == yr_ws:
                # print(year, Add)
                ws4.write(rw, cl, Add, style3)
                rw = rw+1 
            vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
            vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
                      
        cost_eb = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
        # print(cost_eb)
        total_cst = 0
        if cost_eb:
            for cst in cost_eb:
                total_cst = cst['EB_SessionCost'] * total_cost
                # print("total_cst",total_cst)
        else:
            total_cst = 0
        total_cst_inr = total_cst + total_cst_inr
        ws4.write(rw+1, cl, total_cost, style5)
        ws4.write(rw+2, cl, total_cst,style4)    

        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
        
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
        cl+=1; c_1 +=1

    ws4.write(rw+2,11, total_cst_inr ,style4) 
    graph_totalcost_year.append({"srcname":coe,"totalcost":int(total_cst)})
    
    ###############################################     GRAPH REPORT    ############################################################################
    
    totalcons_consumption_year = []; slots_consumption_year = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcons_year:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
               totalcons_consumption_year.append(z['totalcons'])
               slots_consumption_year.append(src_nm_1)
 
    # TotalConsumptions = totalcons_consumption_year; bars_year_cons = slots_consumption_year
    # X_pos = np.arange(len(bars_year_cons ))
    # plt.bar(X_pos, TotalConsumptions , color = 'darkslategrey' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('consumptions')
    # plt.legend(labels=['TotalConsumptions'])
    # plt.xticks(X_pos, bars_year_cons )
    # plt.savefig('Report/Plot/9.jpeg')
    # # plt.show()
    # plt.close()
    
    totalcons_cost_year = []; slots_cost_year = []  
    for q in soruce_name:
        src_nm_1 = q['assourcename'] 
        for z in graph_totalcost_year:
            src_nm_2 = z['srcname']
            if src_nm_1 == src_nm_2:
                totalcons_cost_year.append(z['totalcost'])
                slots_cost_year.append(src_nm_1)
     
    # TotalCosts = totalcons_cost_year; bars_year_cost = slots_cost_year
    # X_pos = np.arange(len(bars_year_cost))
    # plt.bar(X_pos, TotalCosts , color = 'r' , width = 0.3)
    # plt.xlabel('slots')
    # plt.ylabel('costs')
    # plt.legend(labels=['TotalCosts'])
    # plt.xticks(X_pos, bars_year_cost)
    # plt.savefig('Report/Plot/10.jpeg')
    # # plt.show()
    # plt.close()
    
    # #----------------------
    # cons=2 ; cost = 2 ; row_grh_1 = graph_row ; row_grh_2 = graph_row + 30
    # for im in range(9,11):
    #     # print("image",im)
    #     if im == 9:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws4.insert_bitmap('TNEB.bmp',row_grh_1,cons)
    #         # print("image_1 is inserted")
    #     if im == 10:
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws4.insert_bitmap('TNEB.bmp',row_grh_2,cost)
    #         # print("image_2 is inserted")
    
    ####################################################  SEC REPORT ########################################
    
    ####################################################  DAY WISE CONSUMPTIONS ########################################
    r = 1
    c = 2
    ws1.write_merge(r, r+1, c, c+8, ('R-ENERGY -'+plant_name), style)
    
    r = 6
    c = 2
    for data in ['SEC REPORT']:
        ws1.write_merge(r, r, c, c+1, ('Report Description:'), style1)
        c+=2
        ws1.write_merge(r, r, c, c, (data), style1)
    
    r = 8; c=2
    for data in ['Date', 'Energy Consumption(kWH)', 'Good Part Material(kG)', 'SEC']:
        ws1.col(c).width = 3500
        # ws1.row(r).height_mismatch = True
        ws1.row(r).height = 1500
        ws1.write(r, c, data, style2)
        c+=1   
    
    r = 9; c=2
    sec_data = secmodel.objects.all().values()
    ws1.col(c).width = 3000
    ws1.col(c+1).width = 5000
    ws1.col(c+2).width = 5000
    ws1.col(c+3).width = 5000 
    date = (datetime.today()).date()
    cur_date  = date
    # print(cur_date)
    srt_date = (cur_date.replace(day=1))
    # print(srt_date)
    dly_date = pd.date_range(start=srt_date, end=cur_date) 
    for i in dly_date:
        sec_dte = i.date() 
        ws1.write(r,c,str(sec_dte),style3) 
        try:
          secdata = secmodel.objects.get(sec_date = sec_dte) 
          daily_energy = secdata.sec_energy
          daily_material = secdata.sec_material
          daily_value = secdata.sec_value
        except secmodel.DoesNotExist:
            daily_energy = 0
            daily_material = 0
            daily_value = 0
        ws1.write(r, c+1, daily_energy, style3)
        ws1.write(r, c+2, daily_material, style3)
        ws1.write(r, c+3, daily_value,  style3)
        r+=1
    
    ############################################### MONTH WISE CONSUMPTIONS ###############################################
    r = 8; c=7
    for data in ['Month', 'Energy Consumption(kWH)', 'Good Part Material(kG)', 'SEC']:
        ws1.col(c).width = 3500
        # ws1.row(r).height_mismatch = True
        ws1.row(r).height = 1500
        ws1.write(r, c, data, style2)
        c+=1
    
    r = 9; c=7
    current_year = datetime.today().year
    for month in range(1,12+1):
        month_name   = calendar.month_abbr[month] + ' ' +str(current_year)
        sec_energy   = secmodel.objects.filter(sec_date__month = month, sec_date__year = current_year).aggregate((add('sec_energy'))) 
        sec_material = secmodel.objects.filter(sec_date__month = month).aggregate((add('sec_material'))) 
        sec_value    = secmodel.objects.filter(sec_date__month = month).aggregate((add('sec_value')))
        sec_count = secmodel.objects.filter(sec_date__month = month, sec_date__year = current_year).count()
        # print('SEC_Count: ', sec_count)
        # print(month_name, sec_energy, sec_material, sec_value)
        energy   = sec_energy['sec_energy__sum']
        material = sec_material['sec_material__sum'] 
        try:
            value    = round(((sec_value['sec_value__sum'])/sec_count), 2)
            print(value)
        except:
            value = 0
        if energy == None:energy = 0
        if material == None:material = 0
        if value == None:value = 0
        ws1.write(r, c, month_name.upper(), style3)
        ws1.write(r, c+1, energy , style3)
        ws1.write(r, c+2, material, style3)
        ws1.write(r, c+3, value, style3)
        r+=1
    
    # x = ['2022-11-01' , '2022-11-02' , '2022-11-03']
    # y = [30,30,30,30,30]  
    # # plot line
    # plt.plot(y,x)
    # plt.title("SEC DATA")  # add title
    # plt.savefig('Report/Plot/11.jpeg')
    # plt.close()
    
    # date_time = ["2011-09-01", "2011-08-01", "2011-07-01", "2011-06-01", "2011-05-01", "2011-05-03", "2011-04-03","2022-12-01","2022-12-02",
    #             "2022-12-03","2022-12-04","2022-12-05","2022-12-06","2022-12-07","2022-12-08","2022-12-09","2022-12-10","2022-12-11","2022-12-12"
    #             ,"2022-12-13","2022-12-14","2022-12-15","2022-12-16","2022-12-17","2022-12-18","2022-12-19","2022-12-20","2022-12-21","2022-12-21"
    #             ]
    # date_grh = pd.to_datetime(date_time)
    # # print(date_grh)
    # tst = [1.0 , 1.1 , 1.1 , 1.2, 1.3, 1.4 , 1.5, 1.0,1.1,1.2,1.3,1.4,1.5,1.0,1.2,1.3,1.5,1.8,
    #        1.9,1.10,1.1,1.4,1.5,1.6,1.3,1.7,1.4,1.3,1.2]
    # # plt.figure().set_figwidth()
    # # plt.figure(figsize=(5,5))
    # # plt.figure().set_figheight(15)
    # plt.figure(figsize=(6,8))
    # plt.plot(date_time , tst)
    # plt.xticks(fontsize=5.5, rotation = 90)
    # plt.yticks(fontsize = 5.5)
    # plt.xlabel("Date")
    # plt.ylabel("Cummulative Points")
    # plt.title("CUMMULATIVE SEC DATA")
    # plt.savefig('Report/Plot/11.jpeg')
    # plt.close()
    
    # # #----------------------
    # for im in range(11,12):
    #     if im == 11:s
    #         img = Image.open("Report/Plot/"+ str(im) + ".jpeg")
    #         img.save('TNEB.bmp')
    #         ws1.insert_bitmap('TNEB.bmp',9,7)
    
    savepath = os.path.join(BASE_DIR,'Report','EMS-CostReport.xls')
    wb.save(savepath)
    return savepath
    