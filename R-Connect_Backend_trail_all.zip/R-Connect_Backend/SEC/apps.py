from django.apps import AppConfig


class SecConfig(AppConfig):
    name = 'SEC'
