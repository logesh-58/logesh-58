from django.apps import AppConfig


class DatewiseReportConfig(AppConfig):
    name = 'datewise_report'
