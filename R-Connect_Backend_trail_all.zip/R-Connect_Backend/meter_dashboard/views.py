from django.shortcuts import render
from django.http import HttpResponse
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.fields import CreateOnlyDefault
from meter_data.models import Masterdatatable
from meter_data.serializers import MasterTableDbSerializer
from general_settings.models import Timingtable
from itertools import chain
import datetime
from datetime import timedelta

# Create your views here.

@csrf_exempt
def meterdashboard(request):
    plntname=request.GET['plantname']
    # print("Plantname:",a)
    if request.method == 'GET':
        timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
        print(timingtblrow)
        for s in timingtblrow:
            dailyreporttime = s["ttdaystarttime"]
            s1time = s["tts1time"]
            s2time = s["tts2time"]
            s3time = s["tts3time"]
        s1string = s1time.strftime('%H')
        s1hrint = int(s1string)
        current_time = datetime.datetime.now()
        # Subtract 2 hours from datetime object containing current time
        past_time = current_time - timedelta(hours=s1hrint)
        # Convert datetime object to string in specific format 
        past_time_str = past_time.strftime('%Y-%m-%d')
        meterdashboarddata=Masterdatatable.objects.filter(mtplntlctn=plntname,mtdate=past_time_str).values('mtmtrname','mtgrpname','mtenergycons','mts1ec','mts2ec','mts3ec',
                                                                                                    'mtpeakvolt','mtpeakcrnt','mtpwrfctr','mtacteng','mtavgfreq','mtmtrstatus').order_by('mtmtrname')
        # print(meterdashboarddata)
        groupname=Masterdatatable.objects.filter(mtplntlctn=plntname,mtdate=past_time_str).order_by('mtgrpname').values('mtgrpname').distinct()
        # print(groupname)
        groupname_list = list(groupname)
        group_list=[]
        for name in groupname:
            group_list.append(name["mtgrpname"])
        # for index in range(len(groupname_list)):
        #     for key in groupname_list[index]:
        #         group_list.append(groupname_list[index][key])
        print(group_list)
        meterdashboard_list = list(meterdashboarddata)
        # meterdashboard_list.append(mydict)
        mydict={"groups":group_list,"data":meterdashboard_list}
        # groupname_list = list(groupname)
        # mergedqueryset = groupname_list.append(meterdashboard_list)
        # print(meterdashboard_list)
        # meterdashSerializer = MasterTableDbSerializer(meterdashboarddata,many=True)
        return JsonResponse(mydict, safe=False)