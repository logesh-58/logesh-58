from django.apps import AppConfig


class MeterDashboardConfig(AppConfig):
    name = 'meter_dashboard'
