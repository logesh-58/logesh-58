from django.conf.urls import url
from meter_dashboard import views

urlpatterns=[
    url('meterdashboard/',views.meterdashboard,name='meterdashbard'),    
]