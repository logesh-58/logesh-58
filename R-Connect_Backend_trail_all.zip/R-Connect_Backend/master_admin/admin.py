from django.contrib import admin

# Register your models here.
from master_admin.models import AddMasterAdministrator

admin.site.register(AddMasterAdministrator)