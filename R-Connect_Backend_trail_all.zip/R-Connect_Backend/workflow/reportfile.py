import datetime
from email import encoders
from celery.app import shared_task
from analysis.views import machineArray
from .models import WorkflowData
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from django.db.models.aggregates import Sum
from datetime import timedelta

import os   
from RConnect.settings import BASE_DIR
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
import xlwt
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel

from celery.schedules import crontab
#from celery.task import periodic_task

def shiftreport(wfeventcode, data_list, yesterday):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Production_Report.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Shiftwise report')
    style = xlwt.XFStyle()
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()

    #Set Alignment
    alignment = xlwt.Alignment()
    alignment.horz = xlwt.Alignment.HORZ_CENTER
    alignment.vert = xlwt.Alignment.VERT_CENTER
    alignment.wrap = 1
    style1.alignment = alignment
    style2.alignment = alignment
    style.alignment = alignment
    style3.alignment = alignment

    #Set Border
    border = xlwt.Borders()
    border.left = xlwt.Borders.THIN 
    border.right = xlwt.Borders.THIN 
    border.top = xlwt.Borders.THIN 
    border.bottom = xlwt.Borders.THIN 
    style.borders = border
    style1.borders = border
    style2.borders = border
    style3.borders = border

    #Set Background Color
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 22
    style.pattern = pattern

    #Set Font Color
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'Time New Roman'
    font.bold = True
    font.height = 500
    style1.font = font

    font2 = xlwt.Font()
    font2.colour_index=xlwt.Style.colour_map['black']
    font2.name = 'Time New Roman'
    font2.bold = True
    font2.height = 300
    style2.font = font2

    font3 = xlwt.Font()
    font3.colour_index=xlwt.Style.colour_map['black']
    font3.name = 'Time New Roman'
    font3.bold = True
    font3.height = 175
    style.font = font3

    font4 = xlwt.Font()
    font4.colour_index=xlwt.Style.colour_map['black']
    font4.name = 'Time New Roman'
    font4.height = 175
    style3.font = font4
    #Set Date in FirstRowFirstColumn
    r = 0
    c = 0
    # ws.write_merge(r, r+2, c, c, ('Date: ' + str((datetime.datetime.now() - timedelta(days=1)).date())), style)
    ws.write_merge(r, r+2, c, c, ('Date: '+ yesterday), style)
    #For Production parameters
    r = 3
    c = 0
    columns = ['Machinename', 'Mouldname', 'Shift', 'Start time', 'End time', 'Std Cycle time in Machine (sec)', 'Avg Cycletime (sec)', 'Recommended Set cycleTime' , 'Planned Machine Running Time (min)', 'Actual Machine Running Time (mins)', 'Target Production', 'Actual Production', 'Bad Parts', 'Machine IdleTime (mins)']
    for j, col in enumerate(columns):
        #Set cell width
        ws.col(c).width = 3200
        #Set cell height
        ws.row(r).height_mismatch = True
        ws.row(r).height = 900
        #Write in cell
        ws.write(r, c, col, style)
        c = c + 1
    #For OEE parameters
    r = 3
    OEE_c = c
    columns1 = ['Actual Running Time (mins)', 'Total time (mins)', 'AE', 'Target Production', 'Actual Production', 'PE', 'Good Parts', 'Actual Production', 'QE',]
    for j, col in enumerate(columns1):
        #Set cell width
        ws.col(OEE_c).width = 3200
        #Set cell height
        ws.row(r).height_mismatch = True
        ws.row(r).height = 900
        #Write in cell
        ws.write(r, OEE_c, col, style)
        OEE_c = OEE_c + 1

    #Add column for OEE
    r = 2
    #Set cell width
    ws.col(OEE_c).width = 3100
    #Set cell height
    ws.row(r).height_mismatch = True
    ws.row(r).height = 900
    ws.write_merge(r, r+1, OEE_c, OEE_c, 'OEE (%)', style2)

    # r = 2
    # #Set cell width
    # ws.col(OEE_c+1).width = 3100
    # #Set cell height
    # ws.row(r).height_mismatch = True
    # ws.row(r).height = 900
    # ws.write_merge(r, r+1, OEE_c+1, OEE_c+1, 'OEE % (Recommended CycletimeSet)', style2)

    #Add Main Heading
    r = 0
    c1 = 1
    ws.write_merge(r, r+1, c1, OEE_c+1, 'Production Report', style1)

    #Add Sub heading 1-i
    r = 2
    c1 = 1
    # columnlength = math.ceil(c/2)
    # for i in range(columnlength):
    ws.write_merge(r, r, c1, c-1, 'Production', style2)

    #Add Sub heading 1-ii
    r = 2
    c1 = 1
    # columnlength = math.ceil(c/2)
    column2 = ['Availability', 'Performance', 'Quality']
    for j, col in enumerate(column2):
        ws.write_merge(r, r, c, c+2, col, style2)
        c = c+3
    #Write data
    row = 4
    data_col = 0
    for i in data_list:
        for j in i:
            #Set cell width
            ws.col(data_col).width = 3100
            #Set cell height
            ws.row(row).height_mismatch = True
            ws.row(row).height = 700
            ws.write(row, data_col, j, style3)
            data_col += 1
        row += 1
        data_col = 0

    now = datetime.datetime.now()
    # date = '05-10-2021'
    yesterday = (now - datetime.timedelta(days=1)).strftime('%d-%m-%Y %H-%M-%S')
    savepath = os.path.join(BASE_DIR,'Report','RConnect - DailyReport - '+yesterday+'.xls')
    wb.save(savepath)
    #------------------ Email --------------------
    workflowtab = WorkflowData.objects.get(wfeventcode=wfeventcode)
    ccmail=workflowtab.accemail
    tomail=workflowtab.atoemail
    sub=workflowtab.asubject
    msg=workflowtab.amessage
    message = '''Dear team, <br> 
                    Please find yesterday's IMM production report. 
                    <br>
                    <br>
                Regards, <br>
                R-Connect Team. 
                <br>
                <br> 
                Note: This is an system generated mail.'''
    msg = MIMEMultipart('alternative')
    msg['Subject'] = sub
    msg['From'] = "R-Connect <no-reply@rconnect.com>"
    msg['To'] = tomail
    part2 = MIMEText(message, 'html')
    msg.attach(part2)
    part = MIMEBase('application','octet-stream')
    part.set_payload(open(savepath, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="R-ConnectReport.xls"')
    msg.attach(part)
    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
    smtpObj.sendmail('ntpdpmt1@int.motherson.com',tomail.split(';'),msg.as_string())

    smtpObj.quit()
    print('Mail send successfully')
    return HttpResponse("Mail Sent")

# @periodic_task(run_every=(crontab(minute=30, hour=6)))
@csrf_exempt
# def report(wfeventcode='EVENT_1'):
def report(request):
    codedata = WorkflowData.objects.get(wfeventcode='EVENT_1')
    Plantname = codedata.wfPlantname
    #Set average of production data
    now = datetime.datetime.now()
    date = (now.date()).strftime('%Y-%m-%d')
    currentdate = date
    yesterday = (now.date() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')

    shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
    for i in shift_starttime:
        shift_starttime = i['shift1start']
    dateArray = []
    timeArray = []
    myarray   = []
    MachinenamesArray = machineArray(Plantname)
    distinctArray =  []
    for machine in MachinenamesArray:
        flag = 0; count = 0; prevcount = 0; firstid = 0; lastid = 0; prevmold = ''
        try:
            dateArray = [yesterday, currentdate]
            # print(machine, dateArray)
            timeArray = [str(shift_starttime), '23:59:00', '00:00:01', str(shift_starttime)]
            for i in range(0, len(dateArray)):
                ind = (i*i)+ i
                date_ = dateArray[i]
                fromtime = timeArray[ind]
                totime   = timeArray[ind + 1]
                # print('Time = ',machine, date_, fromtime, totime)
                getdatas = ProductionTable.objects.filter(date = date_, time__range = (fromtime, totime), Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0).values('id', 'ProductionCountActual', 'Machinename', 'Mouldname_id').order_by('id')
                for i in getdatas:
                    id = i['id']; count = int(i['ProductionCountActual']); Mouldname_id =  i['Mouldname_id']; Machinename = i['Machinename']
                    
                    if(flag == 0): prevcount = count; firstid = id; flag = 1
                    # if(prevcount <= count): lastid = id
                    if(prevcount > count or (prevmold != Mouldname_id and (prevmold != '' and Mouldname_id != ''))):
                        distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold }; distinctArray.append(distinctDict); lastid = id; firstid = id
                    prevcount = count; prevmold = Mouldname_id; lastid = id
            if(Machinename and Mouldname_id != ''):
                distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold }; distinctArray.append(distinctDict)
            Machinename = ''; Mouldname_id = ''
        except: 
            continue
        # print(distinctArray)

    for i in distinctArray:
        shift = ''; fidcount = 0
        Machinename = i['Machinename']; Mouldname = i['Mouldname']; fid = i['fid']; lid = i['lid']
        # print('Machinename, id =', Machinename, fid, lid)
        # ---------------- Get the running time of the mold-----------------------------------------
        flag = 0; firsttime = '00:00:00'; lasttime = '00:00:00'; prevmold = ''; currmold = ''; runningtime = 0; actualcount = 0; cycletime = 0.00
        firsttime = (list(ProductionTable.objects.filter(id = fid).values('time'))[0])['time']
        lasttime = (list(ProductionTable.objects.filter(id = lid).values('time'))[0])['time']
        # print('Firsttime = ', firsttime, 'Lasttime = ',lasttime)
        if(int(firsttime.split(":")[0]) >= 6 and int(firsttime.split(":")[0]) <= 13):
            shift = 'A' 
        elif(int(firsttime.split(":")[0]) >= 14 and int(firsttime.split(":")[0]) <= 21):
            shift = 'B'
        else:
            shift = 'C'

        # -- Get the actual count value --
        try: 
            countnumbers = ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).count()
        except: countnumbers = 0
        # print('Count Numbers = ', countnumbers)

        try: 
            actualcount = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('ProductionCountActual').last())['ProductionCountActual']
        except Exception as e: 
            print(Machinename, e)
            actualcount = 0
        
        fidcount = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
        # print('fidcount = ', fidcount)
        fidtime = (datetime.datetime.strptime(((list(ProductionTable.objects.filter(id=fid).values('time'))[0])['time']), '%H:%M:%S')).hour
        # print('fidtime = ', Machinename, Mouldname, fidtime)

        # print('ActualCount = ', actualcount)
        if(fidtime == shift_starttime.hour):
            # print('start time hour same')
            if(fidcount > 1 and fidcount <= actualcount):
                actualcount = (actualcount - fidcount) + 1
            # print('sub count = ', actualcount)
        # print(actualcount, Machinename)

        if(firsttime < lasttime): runningtime = (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')).total_seconds()
        elif(firsttime == lasttime): runningtime = 0
        else: runningtime = ((datetime.datetime.strptime('23:59:59', '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')) + (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime('00:00:01', '%H:%M:%S'))).total_seconds()
        # print('Running time (sec)', runningtime)
                    
        cycletime      = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('CycletimeSet').last())["CycletimeSet"]
        pcycletimeSumval    = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).aggregate(Sum('CycletimeActual')))["CycletimeActual__sum"]
        # ------------------------Cycle time set -------------------------------------
        # try: cycletime = round((cycletimevalue['CycletimeSet'] / 1000000), 1)
        # except: cycletime = 0
        # print('cyceltime = ', cycletime)

        # ------------------------previous Cycle time (Actual Cycle time) -------------------------------------
        # print(Machinename, cycletime, pcycletimeSumval, actualcount, countnumbers)
        
        try: 
            firstval = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
            # print('Fistval = ', firstval)
            if(firstval == 1 and (countnumbers == actualcount)):
                CycletimeActual = round((pcycletimeSumval/actualcount), 1) 
            else:
                CycletimeActual = round((pcycletimeSumval/countnumbers), 1) 
        except Exception as e: 
            # print('Cycletime exception error = ', e)
            CycletimeActual = 0

        # # print('CycletimeActual = ', CycletimeActual)
        
        RejectionParts = (list(ProductionTable.objects.filter(id = lid, Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname).values('RejectionParts'))[0])['RejectionParts']
        # print(RejectionParts)
        # ------------------------ Set or Target count calculation -------------------------------------
        try: totalpart = int(float(runningtime)/float(cycletime))
        except:  totalpart = 0
        # ------------------------ productiontime set and actual calculation -------------------------------------
        actualruntime   = float(round(runningtime/60, 1))
        totaltime = round((((actualruntime * 10)/100) + actualruntime), 1)
        # ------------------------ OEE parameters calculation -------------------------------------
        idletime = float(round((actualruntime - float((CycletimeActual * actualcount)/60)),1))
        if(idletime < 0):
            idletime = 0
        ##--Availability--
        try: Availability = float(round(((actualruntime/totaltime)*100),1))
        except: Availability = 0
        ##--Performance--
        try: Performance = float(round(((actualcount / totalpart)*100), 1))
        except: Performance = 0
        ##--Quality--
        try: Quality = float(round(((actualcount / actualcount)*100), 1))
        except: Quality = 0
        ##--OEE--
        try: oee = float(round(((Availability * Performance * Quality)/10000),1))
        except: oee = 0

        #-------------------- Recommended Calculations----------------------------------------
        num = CycletimeActual
        if (num%10)< 5 and (num%10)> 0:
            num = num + (5- (num%10))
        elif int(num%10)<= 9 and (num%10)> 5:
            num = num + (10- (num%10))

        try: totalpart_recommended = round(float(runningtime)/float(num))
        except: totalpart_recommended = 0

        try: performance_recommended = float(round(((actualcount / totalpart_recommended)*100), 1))
        except: performance_recommended = 0
        
        try: OEE_recommended = float(round(((Availability * performance_recommended * Quality)/10000),1))
        except: OEE_recommended = 0
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname).values('Mouldname')
        for i in Mouldname_data:
            Mouldname = i['Mouldname']                  
        #--------------------Append With Dictionary ---------------------------------------
        mydict = {  'Machinename'                   : Machinename, 
                    'Mouldname'                      : Mouldname, 
                    'Shift'                         : shift,
                    'Start time'                    : firsttime,
                    'End time'                      : lasttime,
                    'Cycletime Set (Sec)'           : cycletime,
                    'Cycletime Actual (Sec) '       : CycletimeActual,
                    'Recommended cycleTime'         : num,
                    'Productiontime Set (Min)'      : round(totaltime, 1),
                    'Productiontime Actual (Min)'   : round(actualruntime, 1),
                    'ProductionCount Set'           : totalpart_recommended,
                    'ProductionCount Actual'        : int(actualcount),
                    'RejectionParts'                      : RejectionParts,
                    'MachineIdletime (Min)'         : round(idletime, 1),
                    'Actual runtime (Min)'          : round(actualruntime, 1),
                    'Total runtime (Min)'           : round(totaltime, 1),
                    'AE (%)'                        : Availability,
                    'Target production'             : totalpart_recommended,
                    'Actual production'             : actualcount,
                    'PE (%)'                        : performance_recommended,
                    'Good parts'                    : actualcount,
                    'Produced parts'                : actualcount,
                    'QE (%)'                        : Quality,
                    # 'OEE (%)'                       : round(oee, 1),
                    'OEE (%)'                       : OEE_recommended
                    }
        myarray.append(mydict)

    if(myarray != []):
        data_list = [[str(row_data) for row_key, row_data in dict_data.items()] for dict_data in myarray ]
        data_col = [[str(row_key) for row_key, row_data in dict_data.items()] for dict_data in myarray ]
        datadict = {'Data': data_list, 'Heading': data_col[0]}
        shiftreport(wfeventcode, data_list, yesterday)
        return HttpResponse('Mail Send Successfully')
    else:
        print('No data available for auto report')
        return HttpResponse('Oops! Data not available')