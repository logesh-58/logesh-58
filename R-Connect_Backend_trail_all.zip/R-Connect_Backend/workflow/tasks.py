from __future__ import absolute_import
# from machinestopcheck.views import checkstop
from timeline.models import timeline
from workflow.models import WorkflowData
from productiontable.serializers import ProductionTableSerializers
from django.views.decorators.csrf import csrf_exempt
from celery import shared_task
from email import encoders
import xlwt
from productiontable.models import ProductionTable
from django.http.response import HttpResponse
import datetime
from django.core.mail import EmailMessage
import os   
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from machinemanagement.models import AddMachine
from RConnect.settings import BASE_DIR
import smtplib
from shiftmanagement.models import ShiftTimings
from workflow.reportfile import report

@shared_task
def gensendmail(wfeventcode):
    # New Report
    #report function imported from reportfile.py
    report(wfeventcode)
    print('Task Completed')

@shared_task
def alertsendmail(wfeventcode):
    print(wfeventcode)
    sendalertmail(wfeventcode)

# @shared_task
# def stopalertsendmail(wfeventcode):
#     print(wfeventcode)
#     # checkstop(wfeventcode)