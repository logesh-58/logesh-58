from django.db import models
from django.db.models.expressions import F
from django.contrib.postgres.fields import ArrayField

# Create your models here.
class WorkflowData(models.Model):
    wfid                = models.AutoField(primary_key=True)
    wfeventcode         = models.CharField(max_length=255,default=False,null=True)
    wfPlantname         = models.CharField(max_length=255, default=False, null=True)
    eventtype           = models.CharField(max_length=255, default=False, null=True)
    wfeventname         = models.CharField(max_length=255,default=False,null=True)
    wfeventgroup        = models.CharField(max_length=255,default=False,null=True)
    wfresetinterval     = models.IntegerField(default=False,null=True)
    wfpriority          = models.CharField(max_length=255,default=False,null=True)
    wfactive            = models.BooleanField(default=False,null=True)
    wfdescription       = models.CharField(max_length=255,default=False,null=True)
    wfalertmessage      = models.CharField(max_length=255,default=False,null=True)
    wfcorrectmessage    = models.CharField(max_length=255,default=False,null=True)
    wfcreatedon         = models.DateField(default=False,null=True)
    wfcreatedby         = models.CharField(max_length=255 ,default=False, null=True)
    wfmodifiedon        = models.DateField(default=False,null=True)
    wfmodifiedby        = models.CharField(max_length = 255, default=False, null=True)
    atoemail            = models.EmailField(default=False,null=True)
    accemail            = models.EmailField(default=False,null=True)
    asubject            = models.CharField(max_length=255,default=False,null=True)
    apriority           = models.CharField(max_length=255,default=False,null=True)
    amessage            = models.CharField(max_length=255,default=False,null=True)
    stime               = models.TimeField(default=False,null=True)
    sschedule_days      = ArrayField(models.CharField(max_length=255),default=False,null=True)
    saMouldname          = models.CharField(max_length=255, default=False, null=True)
    sanextmaintenance   = models.CharField(max_length=255, default=False, null=True)
    samoldalertinterval = models.CharField(max_length=255, default=False, null=True)

class Tickets(models.Model):
    tid             = models.AutoField(primary_key=True)
    tcode           = models.CharField(max_length=255,default=False,null=True)
    teventname      = models.CharField(max_length=255,default=False,null=True)
    tcreatedon      = models.DateField(default=False,null=True)
    tclosingon      = models.DateField(default=False,null=True, blank=True)
    tclosingtime    = models.TimeField(default=False,null=True)
    traisedby       = models.CharField(max_length=255,default=False,null=True)
    tclosedby       = models.CharField(max_length=255,default=False,null=True)
    tdescription    = models.CharField(max_length=255,default=False,null=True)
    treportingmail  = models.EmailField(default=False,null=True)
    tPlantname      = models.CharField(max_length=255,default=False,null=True) 
    tticketstatus   = models.CharField(max_length=255,default=False,null=True)
    tapprovalstatus = models.CharField(max_length=255,default=False,null=True)
    