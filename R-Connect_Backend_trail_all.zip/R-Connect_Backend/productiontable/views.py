from machinemanagement.views import machine
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from .models import ProductionTable
from timeline.models import timeline
from dashboard.models import Dashboard
from productionviewmaster.models import productionviewmaster
from .serializers import ProductionTableSerializers, MachinenameSerialzers
from mouldmanagement.models import Mouldmodel
from django.db.models.aggregates import Sum
import json
import datetime
from machinemanagement.models import AddMachine
from shiftmanagement.models import ShiftTimings
from rest_framework import viewsets
from rest_framework.decorators import api_view

# @csrf_exempt
class ProductionTableViewset(viewsets.ModelViewSet):
    serializer_class = ProductionTableSerializers
    # def get_queryset(self):
    #     return 
    def create(self,request,*args,**kwargs):
        Plantname = request.GET['Plantname']
        httpdata = request.data
        # httpdata = json.loads(data)

        Machinename = httpdata['Mname']
        mldname = httpdata['mldname']
        # print("start_date", httpdata['start'], "end_date", httpdata['end'])
        # fromdate = (datetime.datetime.strptime((httpdata['start']), "%Y-%m-%d").date()) + (datetime.timedelta(days = 1))
        # todate = datetime.datetime.strptime((httpdata['end']), "%Y-%m-%dT%H:%M:%S.%fZ").date() + (datetime.timedelta(days = 1))

        fromdate = httpdata['start']
        todate =  httpdata['end']
        # print('init: ', fromdate, todate, Machinename, mldname)
        
        if(mldname != ''):
            Mouldname_data = Mouldmodel.objects.filter(Mouldname = mldname).values('id')
            # print(Mouldname_data)
            Mouldname_id = 0
            for mdata in Mouldname_data:
                Mouldname_id = mdata['id']
            # ---------------------------------------------------------------------------------
            if(ProductionTable.objects.filter(date__range=(fromdate, todate), Machinename = Machinename, Plantname = Plantname, Mouldname = Mouldname_id, MachineState=1).exists()):
                date_data = ProductionTable.objects.filter(date__range=(fromdate, todate), Machinename = Machinename, Plantname = Plantname, Mouldname = Mouldname_id, MachineState=1).order_by('id')
                date_data_serializers = ProductionTableSerializers(date_data, many=True)
                data_ = (list(date_data_serializers.data))
                columns = list(data_[0].keys())
                ds = date_data_serializers.data
                my_dict = {'display': columns, 'values':ds}
                # print(my_dict)
                return JsonResponse(my_dict, safe=False)
            else:
                return JsonResponse('No data available', safe = False)
        else:
            # print(fromdate, todate, Plantname, Machinename)
            distinctmold = list(ProductionTable.objects.filter(date__range=(fromdate, todate), Plantname=Plantname, Machinename = Machinename).values('Mouldname').distinct())
            # print('distinctmold: ', distinctmold)
            MouldArray = []
            for ind in distinctmold:
                Mouldname_data = Mouldmodel.objects.filter(id = (ind['Mouldname'])).values('Mouldname')
                Mouldname = ''
                for mdata in Mouldname_data:
                    Mouldname = mdata['Mouldname']
                    MouldArray.append(Mouldname)
                    # print('Mouldname: ', MouldArray)
            return JsonResponse(MouldArray, safe = False)

@csrf_exempt
#Function to send machine names list to frontend dropdown in PDP page
def name(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        names = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
        nameserializer = MachinenameSerialzers(names, many = True)
        # print(names)
        return JsonResponse(nameserializer.data, safe=False)
