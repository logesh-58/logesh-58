from django.db.models import fields
from rest_framework import serializers
from .models import ProductionTable
from machinemanagement.models import AddMachine

class ProductionTableSerializers(serializers.ModelSerializer):
    class Meta:
        model = ProductionTable
        fields = "__all__"
        # depth=1
    #     fields = (
                    # 'date',
                    # 'time',
                    # 'Machinename',
                    # # 'machinetype',
                    # 'MachineState',
                    # 'Plantname',
                    # 'Mouldname',
                    # 'Alarm',
                    # 'ProductionCountSet',
                    # 'ProductionCountActual',
                    # 'ProductionTimeActual',
                    # 'productiontimeremaining',
                    # 'ProductionTimeTotal',
                    # 'CycletimeSet',
                    # 'CycletimeActual',
                    # 'actualplasttime',
                    # 'actualinjtime',
                    # 'actualcoolingtime',
                    # 'moldopentime',
                    # 'moldclosetime',
                    # 'injectionvelocity1',
                    # 'injectionvelocity2',
                    # 'injection_switchovercondition_timer',
                    # 'injection_switchovercondition_pressure',
                    # 'monitoringmeteringtimeset',
                    # 'monitoringmeteringtimeactual',
                    # 'ejectorforwardtime',
                    # 'ejectorbackwardtime',
                    # 'actualinjectionpressure',
                    # 'injectionpeakpressure',
                    # 'injectioncutoffpressure',
                    # 'zone1temp',
                    # 'zone2temp',
                    # 'zone3temp',
                    # 'zone4temp',
                    # 'zone5temp',
                    # 'zone6temp',
                    # 'zone7temp',
                    # 'zone8temp',
                    # 'zone9temp',
                    # 'zone10temp',
                    # 'zone11temp',
                    # 'zone12temp',
                    # 'userlevel',
                    # 'hotrunnerused',
                    # 'robotstate',
                    # 'plasticizingpressure',
                    # 'cushion',
                    # 'actualscrewrpm',
                    # 'injectionswitchover',
                    # 'cutoffscrewpositonset',
                    # 'noofzonesenbaled',
                    # 'heaterstate',
                    # 'Cavity',
                    # 'RejectionParts'
                    #     )

class MachinenameSerialzers(serializers.ModelSerializer):
    class Meta:
        model = AddMachine
        fields = ['amMachinename']

# class reportSerializers(serializers.ModelSerializer):
#     class Meta:
#         model = Report
#         fields = "__all__"