from machinemanagement.views import machine
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
from .models import ProductionTable
from timeline.models import timeline
from dashboard.models import Dashboard
from productionviewmaster.models import productionviewmaster
from .serializers import ProductionTableSerializers, MachinenameSerialzers
from mouldmanagement.models import Mouldmodel
from django.db.models.aggregates import Sum
import json
from datetime import datetime, timedelta, time
from machinemanagement.models import AddMachine
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from rest_framework import viewsets
from rest_framework.decorators import api_view
from django.db.models import Q

class ProductionTableViewset(viewsets.ModelViewSet):
    serializer_class = ProductionTableSerializers

    def create(self,request,*args,**kwargs):
        Plantname = request.GET['Plantname']
        httpdata = request.data

        Machinename = httpdata['Mname']
        mldname = httpdata['mldname']

        fromdate = httpdata['start']
        todate =  httpdata['end']

        shift_data = (ShiftTimings.objects.filter(Plantname=Plantname).values().last())['shift1start']

        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        if shift_times:
            # Directly assign time values without using strptime
            first_shift_start = shift_times['shift1start']
            first_shift_end = shift_times['shift1end']
            second_shift_start = shift_times['shift2start']
            second_shift_end = shift_times['shift2end']
            third_shift_start = shift_times['shift3start']
            third_shift_end = shift_times['shift3end']
            
            # print("first_shift_start:", first_shift_start)
            # print("first_shift_end:", first_shift_end)
            # print("second_shift_start:", second_shift_start)
            # print("second_shift_end:", second_shift_end)
            # print("third_shift_start:", third_shift_start)
            # print("third_shift_end:", third_shift_end)
        else:
            print("No shift times available for the specified Plantname.")

        # Convert the date strings to datetime objects
        startdate_dt = datetime.strptime(fromdate, "%Y-%m-%d")
        enddate_dt = datetime.strptime(todate, "%Y-%m-%d")

        # Calculate the total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        nex_enddate_dt = enddate_dt + timedelta(days=1)

        seconddate_dt = startdate_dt + timedelta(days=1)

        # Convert to string only for querying
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        enddate_str = enddate_dt.strftime('%Y-%m-%d')
        seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

        # Retrieve and store all data for the date range
        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=shift_data) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=shift_data),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values().order_by('id')
        
        # for entry in all_dashboard_value:
        #     print(entry)

        # Aggregate data
        all_aggregated_data = ShiftProductiondata.objects.filter(
            Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            sp_plantname=Plantname,
            sp_machinename=Machinename
        ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction', 'sp_mouldname_id').order_by('sp_id')

        if(mldname != ''):
            Mouldname_data = Mouldmodel.objects.filter(Mouldname=mldname).values('id')

            if Mouldname_data.exists():  # Check if data is present
                Mouldname_id = Mouldname_data[0]['id']  # Access the first item
                # print("Mouldname_id:", Mouldname_id)

                # # ---------------------------------------------------------------------------------
                # # Filter `all_dashboard_value` for entries with the matching `Mouldname_id`
                # change_data = [m for m in all_aggregated_data if m['sp_mouldname_id'] == Mouldname_id]
                
                # ---------------------------------------------------------------------------------
                # Filter `all_dashboard_value` for entries with the matching `Mouldname_id`
                date_data = [p for p in all_dashboard_value if p['Mouldname_id'] == Mouldname_id]
                
                if date_data:  # Check if date_data is not empty
                    date_data_serializers = ProductionTableSerializers(date_data, many=True)
                    data_ = list(date_data_serializers.data)
                    columns = list(data_[0].keys()) if data_ else []
                    ds = date_data_serializers.data

                    for record in ds:
                        record["Mouldname"] = mldname

                        # Convert record['time'] to a datetime.time object for comparison
                        record_time = datetime.strptime(record['time'], "%H:%M:%S").time()

                        if first_shift_start <= record_time <= first_shift_end:
                            shift = 'A'
                        elif second_shift_start <= record_time <= second_shift_end:
                            shift = 'B'
                        # Special case for shift C, which spans over midnight
                        elif record_time >= third_shift_start or record_time <= third_shift_end:
                            shift = 'C'
                        else:
                            shift = 0

                        if shift == 'C':
                    
                            current_date = datetime.strptime(record["date"], "%Y-%m-%d").date()
                            pre_date = current_date - timedelta(days=1)

                            time_start = third_shift_start
                            time_end = time(23, 59, 59)

                            if time_start <= record_time <= time_end:

                                # print("shift three 1 day")
                                
                                change_data = [m for m in all_aggregated_data if m['sp_date'] == record["date"]
                                                and m['sp_shift'] == shift and m['sp_mouldname_id'] == Mouldname_id]
                                
                                if change_data:
                                    record["ProductionCountSet"] = change_data[0]["sp_totalproduction"]
                                    record["ProductionTimeTotal"] = change_data[0]["sp_totalproductiontime"]
                                else:
                                    record["ProductionCountSet"] = 0
                                    record["ProductionTimeTotal"] = 0

                            else: 
                                # print("shift three 2 day")
                                change_data = [
                                        m for m in all_aggregated_data
                                        if datetime.strptime(m['sp_date'], '%Y-%m-%d').date() == pre_date
                                        and m['sp_shift'] == shift
                                        and m['sp_mouldname_id'] == Mouldname_id
                                    ]
                                
                                if change_data:
                                    record["ProductionCountSet"] = change_data[0]["sp_totalproduction"]
                                    record["ProductionTimeTotal"] = change_data[0]["sp_totalproductiontime"]
                                    # print("done")
                                else:
                                    record["ProductionCountSet"] = 0
                                    record["ProductionTimeTotal"] = 0
                                    # print("not done")

                        else:
                            # print("shift day")
                            # ---------------------------------------------------------------------------------
                            change_data = [m for m in all_aggregated_data if m['sp_date'] == record["date"] 
                                           and m['sp_shift'] == shift and m['sp_mouldname_id'] == Mouldname_id]

                            if change_data:
                                record["ProductionCountSet"] = change_data[0]["sp_totalproduction"]
                                record["ProductionTimeTotal"] = change_data[0]["sp_totalproductiontime"]
                            else:
                                record["ProductionCountSet"] = 0
                                record["ProductionTimeTotal"] = 0

                    my_dict = {'display': columns, 'values': ds}

                    return JsonResponse(my_dict, safe=False)
                else:
                    return JsonResponse('No data available', safe=False)
            else:
                return JsonResponse('No matching Mouldname found', safe=False)
            
        else:
            distinctMould = list(set(p['Mouldname_id'] for p in all_dashboard_value))

            MouldArray = []
            for ind in distinctMould:

                mouldname = Mouldmodel.objects.get(id = ind).Mouldname
                MouldArray.append(mouldname)

            return JsonResponse(MouldArray, safe = False)
        
        
@csrf_exempt
def name(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        names = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
        nameserializer = MachinenameSerialzers(names, many = True)
        return JsonResponse(nameserializer.data, safe=False)
