from django.apps import AppConfig


class SankeyChartConfig(AppConfig):
    name = 'sankey_chart'
