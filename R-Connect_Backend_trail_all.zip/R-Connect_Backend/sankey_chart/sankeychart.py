from django.http import JsonResponse
from meter_data.models import Masterdatatable
from source_management.models import AddSource
from datetime import datetime , date, timedelta
from group_management.models import AddGroup
from meter_management.models import AddMeter
from django.views.decorators.csrf import csrf_exempt
from workflow_dashboard.models import WorkflowData
from django.db.models import Sum as add
import json

@csrf_exempt
def Sankey(request):
    if request.method == 'POST':
        request_data = json.loads(request.body)
        request_type = request_data['Type']
        
        if request_type == 'Date Basis':
            Plantname = request.GET['plantname']   
            current_date = request_data['Date']  
            link = []; nodes = []; Solar_Consumption = 0; total_grpValue = 0; DG_Consumption = 0
            nodes.append({"name": "Total Consumption"})
            sourcenames = AddSource.objects.filter(asplantname=Plantname).distinct('assourcename').values('assourcename')
            groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            meternames = AddMeter.objects.distinct('ammetername').values('ammetername')
            node_groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            #Total to Incomer
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':
                    node_srcnm = 'Transformer'
                    nodes.append({"name": node_srcnm})
                    link.append({"source":"Total Consumption",
                                "target":node_srcnm,
                                "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
                else:
                    if(srcname['assourcename'] == 'Solar Energy'):
                        try:
                            Solar_Consumption = round(Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            Solar_Consumption = 0
                    if(srcname['assourcename'] == 'DG'):
                        try:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                    nodes.append({"name": srcname['assourcename']})
                    link.append({"source":"Total Consumption",
                                "target":srcname['assourcename'],
                                "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            #Append Group Name to nodes
            for data in node_groupnames:
                if data['aggroupname'] != 'Incomer':
                    nodes.append({"name":data['aggroupname']})
                    grp_val = Masterdatatable.objects.filter(mtdate = current_date, mtgrpname = data['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    if grp_val is None:
                        total_grpValue = 0
                    else:
                        total_grpValue += grp_val
            #Individual Group Percent
            grpPercent = []
            for grupnme in groupnames:
                if grupnme['aggroupname'] != 'Incomer':
                    grpVal = Masterdatatable.objects.filter(mtdate = current_date, mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    grpPercent.append({'Groupname':grupnme['aggroupname'], 
                                       'percent': round((grpVal/total_grpValue)*100, 2), 
                                       'solar_value': round(Solar_Consumption*(round((grpVal/total_grpValue)*100, 0) / 100)),
                                       'dg_value': round(DG_Consumption*(round((grpVal/total_grpValue)*100, 2) / 100))
                                       })
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':   
                    node_srcnm = 'Transformer'
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                diffvalue = data['solar_value'] + data['dg_value']
                                # print(grupnme['aggroupname'],diffvalue )
                                link.append({"source":node_srcnm,
                                            "target":grupnme['aggroupname'],
                                            "value":int(Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']) - diffvalue })
                elif srcname['assourcename'] == 'Solar Energy':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (Solar_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (Solar_Consumption/100)) })
                elif srcname['assourcename'] == 'DG':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (DG_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (DG_Consumption/100)) })
                else:
                    for grupnme in groupnames:
                        if grupnme['aggroupname'] != 'Incomer':
                            link.append({"source":srcname['assourcename'],
                                        "target":grupnme['aggroupname'],
                                        "value":Masterdatatable.objects.filter(mtdate = current_date, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            # #Group to Meters
            for grupnme in groupnames:
                meternames = AddMeter.objects.filter(ammetergroup = grupnme ['aggroupname']).distinct('ammetername').values('ammetername')
                if grupnme['aggroupname'] != 'Incomer':
                    for mtrnme in meternames:
                        if mtrnme['ammetername'] != 'Elite500':
                            nodes.append({"name": mtrnme['ammetername']})
                            link.append({"source":grupnme['aggroupname'],
                                        "target":mtrnme['ammetername'],
                                        "value":Masterdatatable.objects.filter(mtdate = current_date, mtgrpname = grupnme['aggroupname'], mtmtrname = mtrnme['ammetername'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})

        #################################################################################################################################################################

        if request_type == 'Month Basis':
            Plantname = request.GET['plantname']   
            request_month = request_data['Month'] 
            request_year = request_data['Year']
            link = []; nodes = []; Solar_Consumption = 0; total_grpValue = 0; DG_Consumption = 0
            nodes.append({"name": "Total Consumption"})
            sourcenames = AddSource.objects.filter(asplantname=Plantname).distinct('assourcename').values('assourcename')
            groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            meternames = AddMeter.objects.distinct('ammetername').values('ammetername')
            node_groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            #Total to Incomer
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':
                    node_srcnm = 'Transformer'
                    nodes.append({"name": node_srcnm})
                    link.append({"source":"Total Consumption",
                                "target":node_srcnm,
                                "value":Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
                else:
                    if(srcname['assourcename'] == 'Solar Energy'):
                        try:
                            Solar_Consumption = round(Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            Solar_Consumption = 0
                    if(srcname['assourcename'] == 'DG'):
                        try:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                    nodes.append({"name": srcname['assourcename']})
                    link.append({"source":"Total Consumption",
                                "target":srcname['assourcename'],
                                "value":Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            #Append Group Name to nodes
            for data in node_groupnames:
                if data['aggroupname'] != 'Incomer':
                    nodes.append({"name":data['aggroupname']})
                    grp_val = Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtgrpname = data['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    if grp_val is None:
                        total_grpValue = 0
                    else:
                        total_grpValue += grp_val
            #Individual Group Percent
            grpPercent = []
            for grupnme in groupnames:
                if grupnme['aggroupname'] != 'Incomer':
                    grpVal = Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    grpPercent.append({'Groupname':grupnme['aggroupname'], 
                                       'percent': round((grpVal/total_grpValue)*100, 2), 
                                       'solar_value': round(Solar_Consumption*(round((grpVal/total_grpValue)*100, 0) / 100)),
                                       'dg_value': round(DG_Consumption*(round((grpVal/total_grpValue)*100, 2) / 100))
                                       })
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':   
                    node_srcnm = 'Transformer'
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                diffvalue = data['solar_value'] + data['dg_value']
                                # print(grupnme['aggroupname'],diffvalue )
                                link.append({"source":node_srcnm,
                                            "target":grupnme['aggroupname'],
                                            "value":int(Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']) - diffvalue })
                elif srcname['assourcename'] == 'Solar Energy':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (Solar_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (Solar_Consumption/100)) })
                elif srcname['assourcename'] == 'DG':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (DG_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (DG_Consumption/100)) })
                else:
                    for grupnme in groupnames:
                        if grupnme['aggroupname'] != 'Incomer':
                            link.append({"source":srcname['assourcename'],
                                        "target":grupnme['aggroupname'],
                                        "value":Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            # #Group to Meters
            for grupnme in groupnames:
                meternames = AddMeter.objects.filter(ammetergroup = grupnme ['aggroupname']).distinct('ammetername').values('ammetername')
                if grupnme['aggroupname'] != 'Incomer':
                    for mtrnme in meternames:
                        if mtrnme['ammetername'] != 'Elite500':
                            nodes.append({"name": mtrnme['ammetername']})
                            link.append({"source":grupnme['aggroupname'],
                                        "target":mtrnme['ammetername'],
                                        "value":Masterdatatable.objects.filter(mtdate__month = request_month, mtdate__year = request_year, mtgrpname = grupnme['aggroupname'], mtmtrname = mtrnme['ammetername'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
                    
        #################################################################################################################################################################
                            
        if request_type == 'Year Basis':
            Plantname = request.GET['plantname']
            request_year = request_data['Year']
            start_date = datetime(request_year, 4, 1).strftime("%Y-%m-%d")
            end_date = datetime(request_year + 1, 3, 31).strftime("%Y-%m-%d")
            link = []; nodes = []; Solar_Consumption = 0; total_grpValue = 0; DG_Consumption = 0
            nodes.append({"name": "Total Consumption"})
            sourcenames = AddSource.objects.filter(asplantname=Plantname).distinct('assourcename').values('assourcename')
            groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            meternames = AddMeter.objects.distinct('ammetername').values('ammetername')
            node_groupnames = AddGroup.objects.filter(agplantname=Plantname).distinct('aggroupname').values('aggroupname')
            #Total to Incomer
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':
                    node_srcnm = 'Transformer'
                    nodes.append({"name": node_srcnm})
                    link.append({"source":"Total Consumption",
                                "target":node_srcnm,
                                "value":Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
                else:
                    if(srcname['assourcename'] == 'Solar Energy'):
                        try:
                            Solar_Consumption = round(Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            Solar_Consumption = 0
                    if(srcname['assourcename'] == 'DG'):
                        try:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                        except:
                            DG_Consumption = round(Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum'], 0)
                    nodes.append({"name": srcname['assourcename']})
                    link.append({"source":"Total Consumption",
                                "target":srcname['assourcename'],
                                "value":Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = 'Incomer', mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            #Append Group Name to nodes
            for data in node_groupnames:
                if data['aggroupname'] != 'Incomer':
                    nodes.append({"name":data['aggroupname']})
                    grp_val = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtgrpname = data['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    if grp_val is None:
                        total_grpValue = 0
                    else:
                        total_grpValue += grp_val
            #Individual Group Percent
            grpPercent = []
            for grupnme in groupnames:
                if grupnme['aggroupname'] != 'Incomer':
                    grpVal = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']
                    grpPercent.append({'Groupname':grupnme['aggroupname'], 
                                       'percent': round((grpVal/total_grpValue)*100, 2), 
                                       'solar_value': round(Solar_Consumption*(round((grpVal/total_grpValue)*100, 0) / 100)),
                                       'dg_value': round(DG_Consumption*(round((grpVal/total_grpValue)*100, 2) / 100))
                                       })
            for srcname in sourcenames:
                if srcname['assourcename'] == 'Transformer1':   
                    node_srcnm = 'Transformer'
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                diffvalue = data['solar_value'] + data['dg_value']
                                # print(grupnme['aggroupname'],diffvalue )
                                link.append({"source":node_srcnm,
                                            "target":grupnme['aggroupname'],
                                            "value":int(Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']) - diffvalue })
                elif srcname['assourcename'] == 'Solar Energy':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (Solar_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (Solar_Consumption/100)) })
                elif srcname['assourcename'] == 'DG':
                    for grupnme in groupnames:
                        for data in grpPercent:
                            if data['Groupname'] == grupnme['aggroupname']:
                                # print(round(data['percent'] * (DG_Consumption/100)), grupnme['aggroupname'], data['percent'])
                                link.append({"source":srcname['assourcename'],
                                            "target":grupnme['aggroupname'],
                                            "value":round(data['percent'] * (DG_Consumption/100)) })
                else:
                    for grupnme in groupnames:
                        if grupnme['aggroupname'] != 'Incomer':
                            link.append({"source":srcname['assourcename'],
                                        "target":grupnme['aggroupname'],
                                        "value":Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = srcname['assourcename'], mtgrpname = grupnme['aggroupname'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
            # #Group to Meters
            for grupnme in groupnames:
                meternames = AddMeter.objects.filter(ammetergroup = grupnme ['aggroupname']).distinct('ammetername').values('ammetername')
                if grupnme['aggroupname'] != 'Incomer':
                    for mtrnme in meternames:
                        if mtrnme['ammetername'] != 'Elite500':
                            nodes.append({"name": mtrnme['ammetername']})
                            link.append({"source":grupnme['aggroupname'],
                                        "target":mtrnme['ammetername'],
                                        "value":Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtgrpname = grupnme['aggroupname'], mtmtrname = mtrnme['ammetername'], mtcategory = 'Secondary').aggregate(add('mtenergycons'))['mtenergycons__sum']})
        
    return JsonResponse({"node": nodes, "link":link}, safe=False)