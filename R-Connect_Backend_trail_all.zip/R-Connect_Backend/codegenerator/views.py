from django.http.response import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from usermanagement.models import AddUser
from machinemanagement.models import AddMachine
from master_admin.models import AddMasterAdministrator
from workflow.models import WorkflowData
from mouldmanagement.models import Mouldmodel
from shiftmanagement.models import ShiftProductiondata

@csrf_exempt 
# Create your views here.
def ucode(request):
    if request.method == 'GET':
        machinecodeall = AddUser.objects.values('udusercode')
        max_code = 0
        for i in machinecodeall:
            lastcode = i['udusercode']
            lastcode_ = lastcode.split('_')
            lastcode_num = int(lastcode_[1])
            if(max_code < lastcode_num):
                max_code = lastcode_num
        # print(lastcode_num)
        code = 'USER_'+str(max_code + 1)
        # print(code)
        plantrow=AddMasterAdministrator.objects.all()
        Plantname=[]
        for instance in plantrow:
            # print(instance.amaPlantname)
            plntmdfd={"Plantname":instance.amaPlantname}
            Plantname.append(plntmdfd)
        # print(mtrgrpname)
        my_dict={"udusercode":code,"udplant":Plantname}
        print(my_dict)
        return JsonResponse(my_dict, safe= False)

@csrf_exempt
def mcode(request):
    if request.method == 'GET':
        machinecodeall = AddMachine.objects.values('ammachinecode')
        max_code = 0
        for i in machinecodeall:
            lastcode = i['ammachinecode']
            lastcode_ = lastcode.split('_')
            lastcode_num = int(lastcode_[1])
            if(max_code < lastcode_num):
                max_code = lastcode_num
        # print(lastcode_num)
        plantrow=AddMasterAdministrator.objects.all()
        Plantname=[]
        for instance in plantrow:
            # print(instance.amaPlantname)
            plntmdfd={"Plantname":instance.amaPlantname}
            Plantname.append(plntmdfd)
        code = {"mcode": 'MACHINE_'+str(max_code + 1),"amplant":Plantname}
        # print(code)
        return JsonResponse(code, safe= False)


@csrf_exempt
def eventcode(request):
    if request.method == 'GET':
        eventcodeall = WorkflowData.objects.values('wfeventcode')
        max_code = 0
        for i in eventcodeall:
            print(i)
            lastcode = i['wfeventcode']
            lastcode_ = lastcode.split('_')
            lastcode_num = int(lastcode_[1])
            if(max_code < lastcode_num):
                max_code = lastcode_num
        # print(lastcode_num)
        code = {"wfeventcode": 'EVENT_'+str(max_code + 1)}
        # print(code)
        return JsonResponse(code, safe= False)            


@csrf_exempt
def moldcode(request):
    if request.method == 'GET':
        eventcodeall = Mouldmodel.objects.values('moldcode')
        max_code = 0
        for i in eventcodeall:
            print(i)
            lastcode = i['moldcode']
            lastcode_ = lastcode.split('_')
            lastcode_num = int(lastcode_[1])
            if(max_code < lastcode_num):
                max_code = lastcode_num
        # print(lastcode_num)
        code = {"moldcode": 'MOULD_'+str(max_code + 1)}
        # print(code)
        return JsonResponse(code, safe= False)  

@csrf_exempt
def shiftproductioncode(request):
    if request.method == 'GET':
        eventcodeall =  ShiftProductiondata.objects.values('sp_code')
        max_code = 0
        for i in eventcodeall:
            # print(i)
            lastcode = i['sp_code']
            lastcode_ = lastcode.split('_')
            lastcode_num = int(lastcode_[1])
            if(max_code < lastcode_num):
                max_code = lastcode_num
        # print(lastcode_num)
        code = {"sp_code": 'spcode_'+str(max_code + 1)}
        # print(code)
        return JsonResponse(code, safe= False)  