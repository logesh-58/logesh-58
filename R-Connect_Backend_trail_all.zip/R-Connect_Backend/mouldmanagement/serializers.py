from rest_framework import  serializers
from .models import Mouldmodel

class MouldSerializers(serializers.ModelSerializer):
    class Meta:
        model = Mouldmodel
        fields = '__all__'