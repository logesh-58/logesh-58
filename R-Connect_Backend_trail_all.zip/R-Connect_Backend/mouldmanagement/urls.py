from django.urls import path
from mouldmanagement import views

urlpatterns=[
    path('mouldmanagement/',views.add,name="mould_management")
]