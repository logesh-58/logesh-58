from django.db.models.base import Model
from rest_framework import serializers
from machinemanagement.models import AddMachine

class MachineManagementSerializer(serializers.ModelSerializer):
    # class Meta:
    #     model = AddMachine
    #     fields = [
    #               'ammachinecode',
    #               'amMachinename',
    #               'ammachinelocation',
    #               'amPlantname',
    #               'amconsiderbool',
    #               'ambarelzonecount',
    #               'amhrtczonecount',
    #               'ammachineimage'
    #               ]

    class Meta:
        model = AddMachine
        fields = '__all__'