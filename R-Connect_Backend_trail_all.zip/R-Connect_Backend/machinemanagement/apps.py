from django.apps import AppConfig


class MachinemanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'machinemanagement'
