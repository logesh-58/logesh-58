from django.urls import path
from .import views, hurlyreport

urlpatterns = [
    path('hourlyreport/', hurlyreport.hurlyproduction, name="report"),
]
