from datetime import datetime , timedelta, date
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from meter_data.models import Masterdatatable
from mouldmanagement.models import Mouldmodel
from timeline.models import breakdown
from django.db.models import Sum as add
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from django.db.models import Q, Min, Max, Count, F, Sum

# @csrf_exempt
# def hurlyproduction(request):
#     if request.method == 'POST':
#         client_data = json.loads(request.body)
#         Machinename = client_data['machinename']
#         today = (datetime.strptime(client_data['date'], '%Y-%m-%d')).date()
#         nextdate = today + timedelta(days = 1)
#         # print(today, yesterday)
#         shift_data = (ShiftTimings.objects.values().last())['shift1start']
#         starttime = (datetime.strptime(str(shift_data), "%H:%M:%S")).hour
#         excel_map = []; hrsArray = []
#         for i in range(starttime,(24+starttime)):
#             if(i>23):
#                 start = ('0'+str(i-24)+':00:00')
#                 end = ('0'+str(i-24)+':59:59')
#                 dict = {"date":nextdate, "fromtime":start, "totime":end}
#                 # print(dict)
#                 hrsArray.append(dict)
#             else:
#                 if i<= 9 :
#                     start = ('0'+str(i)+':00:00')
#                     end = ('0'+str(i)+':59:59')
#                 else:
#                     start = (str(i)+':00:00')
#                     end = (str(i)+':59:59')
#                 dict = {"date":today, "fromtime":start, "totime":end}
#                 # print(dict)
#                 hrsArray.append(dict)
#         # print(hrsArray)
#         #--------------------------------------------------------------------------------
#         # print('Hourly Report')       
#         ############################# Energy Value ###################
#         # print(shift_datetime)
#         ## Get the Energy Hurs & Value (24 hrs format)
#         date_energyhurs = today
#         energy = []
#         for i in range(1,25):
#             hour = 'mth'+str(i)+'ec'
#             try:
#               hourdata = (round(Masterdatatable.objects.filter(mtdate = date_energyhurs, mtmtrname = Machinename).values(hour)[0][hour], 1))
#             except:
#               hourdata = 0
#             energy.append(hourdata)
#         # print(energy)
#         ############################## HOURLY PRODUCTION REPORT ####################################
#         # print(shift_start, shift_end)
        
#         # Get the from time, to time, total parts, good parts, part weight, mould name, stop reason
#         reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
#         goodpart_kg = []; reason_list = []; machine_stopreason = '-'
#         energyindex = 0; totalweight = 0
#         for hour in hrsArray:
#             mould_name = [];mould_list=[]; part_list=[]; reason_list = []
#             # print(hour)
#             date = hour['date']
#             fromTime = hour['fromtime']
#             toTime = hour['totime']
#             # try:
#             # print(date, fromTime, toTime)
#             totalshots = ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = Machinename, ProductionCountActual__gt = 0).count()
#             # print(totalshots)
#             # except:
#                 # totalshots = 0
#             try:
#                 distinctMould = list(ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = Machinename, ProductionCountActual__gt = 0).values( 'Mouldname_id').distinct())
#                 # print(distinctMould)
#                 for mould in distinctMould:
#                     id = mould['Mouldname_id']
#                     mouldname = Mouldmodel.objects.get(id = id).Mouldname
#                     weight = Mouldmodel.objects.get(id = id).weight
#                     mould_list.append(mouldname)
#                     part_list .append(str(weight))
#                     totalweight += (ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = Machinename, ProductionCountActual__gt = 0, Mouldname__id = id).count()) * weight
#                 mould_name = ', '.join(mould_list)
#                 part_weight = ', '.join(part_list)
#             except:
#                 mould_name = '-'
#                 part_weight = 0
#             try:
#                 runhour = round((ProductionTable.objects.filter(date = date, time__range=(fromTime, toTime), Machinename = Machinename).aggregate(add('CycletimeActual'))['CycletimeActual__sum']) / 60 )
#             except:
#                 runhour = 0
#             # print(energy[energyindex])
#             try:
#                 sec=round(energy[energyindex]/(totalweight/1000), 2)
#             except:
#                 sec=0
#             break_down = list(breakdown.objects.filter(date = str(date), time__range=(fromTime, toTime), Machinename = Machinename).values('date','time', 'MachineState', 'primaryreason').order_by('id'))
#             reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
#             prevstate = 0; currentstate = 0; count = 0
#             if list(break_down) != []:
#                 for data in break_down:
#                     # print(data['date'])
#                     currentstate = data['MachineState']
#                     if count == 0:
#                         starttime =  data['date'] + ' ' + data['time'] 
#                         prevstate = currentstate
#                         count = 1
#                     if count == 1:
#                         if prevstate != currentstate:
#                             index = break_down.index(data) + 1
#                             # print(index)
#                             try:
#                                 if break_down[index]['MachineState'] != 1:
#                                     # try:
#                                     endtime = data['date'] + ' ' + data['time']
#                                     # print(starttime, endtime)
#                                     frm_time = datetime.strptime(starttime, '%Y-%m-%d %H:%M:%S')
#                                     to_time  = datetime.strptime(endtime, '%Y-%m-%d %H:%M:%S')
#                                     idleminutes = (to_time - frm_time).total_seconds()
#                                     # print(idleminutes)
#                                     if idleminutes >= 300:
#                                         minutes = round((int(idleminutes)/60), 2)
#                                         if data['primaryreason'] != 0:
#                                             reason_list.append(reasons[data['primaryreason']])
#                             except:
#                                pass
#                             count = 0
#                             prevstate = currentstate
#                 if reason_list != []:
#                     print(reason_list)
#                     machine_stopreason = ', '.join(reason_list)
#                 else:
#                     machine_stopreason = '-'
#             excel_map.append({"mould_name":mould_name, "from_time":fromTime,"to_time":toTime, "Run_Hour":runhour, "total_shots":totalshots, "Goodparts":totalshots,  "part_weight":part_weight, "energy":energy[energyindex], "SEC":sec, "stop_reason": machine_stopreason})
#             energyindex +=1
#         API = []
#         for data_excel in excel_map:
#             if data_excel['mould_name'] != "":
#                 API.append({"mouldname": data_excel['mould_name'], "fromtime": data_excel['from_time'], "totime": data_excel['to_time'],
#                             "runhour" : data_excel['Run_Hour'], "totalshots": data_excel['total_shots'], "goodparts": data_excel['Goodparts'], 
#                             "partweight":data_excel['part_weight'], "energy":data_excel['energy'], "sec":data_excel['SEC'],"stopreason":data_excel['stop_reason']
#                             })
#         return JsonResponse (API, safe=False)


#ji
@csrf_exempt
def hurlyproduction(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        client_data = json.loads(request.body)
        Machinename = client_data['machinename']
        dan = (datetime.strptime(client_data['date'], '%Y-%m-%d')).date()
        law = dan + timedelta(days = 1)

        today = dan.strftime("%Y-%m-%d")
        nextdate = law.strftime("%Y-%m-%d")

        print("today:", today)
        print("nextdate:", nextdate)

        # shift_data = (ShiftTimings.objects.values().last())['shift1start']
        shift_data = (ShiftTimings.objects.filter(Plantname=Plantname).values().last())['shift1start']
        print("shift_data:", shift_data)

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=today, time__gte=shift_data) |
                    Q(date=nextdate, time__lte=shift_data),
                    Plantname=Plantname,
                    Machinename=Machinename,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename', 'time', 'date', 'MachineState', 'CycletimeActual', 'Mouldname_id').order_by('id')
        
        # print("all_dashboard_value:", all_dashboard_value)
        
        all_breakdown_data = breakdown.objects.filter(
                    Q(date=today, time__gte=shift_data) |
                    Q(date=nextdate, time__lte=shift_data),
                    Machinename=Machinename,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date', 'primaryreason').order_by('id')
        
        # print("all_breakdown_data:", all_breakdown_data)
        
        all_hourdata = Masterdatatable.objects.filter(
            mtdate=today,
            mtmtrname = Machinename).values('mtdate', 'mtmtrname', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec', 'mth5ec',
            'mth6ec', 'mth7ec', 'mth8ec', 'mth9ec', 'mth10ec', 'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec',
            'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec',
            'mth21ec', 'mth22ec', 'mth23ec', 'mth24ec').order_by('id')
        
        # print("all_hourdata:", all_hourdata)

        starttime = (datetime.strptime(str(shift_data), "%H:%M:%S")).hour
        excel_map = []; hrsArray = []
        for i in range(starttime,(24+starttime)):
            if(i>23):
                start = ('0'+str(i-24)+':00:00')
                end = ('0'+str(i-24)+':59:59')
                dict = {"date":nextdate, "fromtime":start, "totime":end}
                hrsArray.append(dict)
            else:
                if i<= 9 :
                    start = ('0'+str(i)+':00:00')
                    end = ('0'+str(i)+':59:59')
                else:
                    start = (str(i)+':00:00')
                    end = (str(i)+':59:59')
                dict = {"date":today, "fromtime":start, "totime":end}
                hrsArray.append(dict)
        ############################# Energy Value ###################
        energy = []
        for i in range(1,25):
            hour = 'mth'+str(i)+'ec'
            try:
              hourdata = round(next((r[hour] for r in all_hourdata), 0), 1)
            except:
              hourdata = 0
            energy.append(hourdata)
        ############################## HOURLY PRODUCTION REPORT ####################################
        reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
        goodpart_kg = []; reason_list = []; machine_stopreason = '-'
        energyindex = 0; totalweight = 0
        for hour in hrsArray:
            mould_name = [];mould_list=[]; part_list=[]; reason_list = []
            date = hour['date']
            fromTime = hour['fromtime']
            toTime = hour['totime']
            totalshots = len([p for p in all_dashboard_value if
                   (p['date'] == date and fromTime <= p['time'] <= toTime)
                 ])
            
            idlehours = 0

            try:               
                distinctMould = list(set(p['Mouldname_id'] for p in all_dashboard_value if p['date'] == date and fromTime <= p['time'] <= toTime))

                for mould_id in distinctMould:
                    mould_obj = Mouldmodel.objects.get(id=mould_id)
                    mould_list.append(mould_obj.Mouldname)
                    part_list.append(str(mould_obj.weight))
                    totalweight += len([
                        p for p in all_dashboard_value
                        if p['date'] == date and p['Mouldname_id'] == mould_id and fromTime <= p['time'] <= toTime
                    ]) * mould_obj.weight

                # Combine lists into comma-separated strings
                mould_name = ', '.join(mould_list)
                part_weight = ', '.join(part_list)
            except:
                mould_name = '-'
                part_weight = 0
            try:
                # runhour = round(sum(p['CycletimeActual'] for p in all_dashboard_value if
                #                     (p['date'] == date and fromTime <= p['time'] <= toTime)) / 60)
                runhour = sum(
                                p['CycletimeActual'] for p in all_dashboard_value if (p['date'] == date and fromTime <= p['time'] <= toTime)
                            ) / 3600
            except:
                runhour = 0
            try:
                sec=round(energy[energyindex]/(totalweight/1000), 2)
            except:
                sec=0
            break_down = [k for k in all_breakdown_data if
                          (k['date'] == date and fromTime <= k['time'] <= toTime)]
            for entry in break_down:
                print(entry)
            reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
            #  .total_seconds()     # .seconds
            total_idle_time = 0  # Initialize the sum

            last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            # Iterate through the breakdown data and calculate time differences
            for last, bd in zip(break_down, break_down[1:]):
                # If `MachineState = 0` for last, store its time but don't calculate yet
                if last['MachineState'] == 0:
                    # Capture the first occurrence of MachineState = 0
                    if last_time_str is None:
                        last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                
                # Only calculate the time difference when transitioning from 0 to 1
                if last_time_str and bd['MachineState'] == 1:
                    # Combine date and time for `bd`
                    bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    # Parse the combined date and time
                    last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    # Calculate the time difference in seconds
                    time_difference = (bd_time - last_time).total_seconds()

                    # Print the intermediate values
                    # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    # Accumulate the total time in seconds
                    total_idle_time += time_difference

                    # Reset last_time_str to None after calculating for this transition
                    last_time_str = None

            idlehours = total_idle_time / 3600  # Convert seconds to hours

            for bd_entry in break_down:
                if bd_entry['primaryreason'] != 0:
                    reason_list.append(reasons[bd_entry['primaryreason']])

            if reason_list != []:
                print(reason_list)
                machine_stopreason = ', '.join(reason_list)
            else:
                machine_stopreason = '-'

            # try:
            print("idlehours:", idlehours)
            total_runhour = float(runhour) - idlehours
            # except:
            #     total_runhour = 0

            total_seconds = int(total_runhour * 3600)
            time_formatted = str(timedelta(seconds=total_seconds))

            excel_map.append({"mould_name":mould_name, "from_time":fromTime,"to_time":toTime, "Run_Hour":time_formatted, "total_shots":totalshots, "Goodparts":totalshots,  "part_weight":part_weight, "energy":energy[energyindex], "SEC":sec, "stop_reason": machine_stopreason})
            energyindex +=1
        API = []
        for data_excel in excel_map:
            if data_excel['mould_name'] != "":
                API.append({"mouldname": data_excel['mould_name'], "fromtime": data_excel['from_time'], "totime": data_excel['to_time'],
                            "runhour" : data_excel['Run_Hour'], "totalshots": data_excel['total_shots'], "goodparts": data_excel['Goodparts'], 
                            "partweight":data_excel['part_weight'], "energy":data_excel['energy'], "sec":data_excel['SEC'],"stopreason":data_excel['stop_reason']
                            })
        return JsonResponse (API, safe=False)