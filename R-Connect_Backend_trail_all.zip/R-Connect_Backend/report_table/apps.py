from django.apps import AppConfig


class ReportTableConfig(AppConfig):
    name = 'report_table'
