from django.db import connection
from django.shortcuts import render
from django.http import HttpResponse
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from meter_data.models import Masterdatatable
from general_settings.models import Timingtable
import datetime
from datetime import timedelta
# Create your views here.

@csrf_exempt
def reportdashboard(request):
    plntname=request.GET['plantname']
    timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
    # print(timingtblrow)
    for s in timingtblrow:
        dailyreporttime = s["ttdaystarttime"]
        s1time = s["tts1time"]
        s2time = s["tts2time"]
        s3time = s["tts3time"]
    s1string = s1time.strftime('%H')
    s1hrint = int(s1string)
    current_time = datetime.datetime.now()
    # Subtract 2 hours from datetime object containing current time
    past_time = current_time - timedelta(hours=s1hrint)
    # Convert datetime object to string in specific format 
    past_time_str = past_time.strftime('%Y-%m-%d')
    s1string = s1time.strftime('%H')
    h1time = int(s1string)
    h2time = ((h1time-24) + 1) if h1time>=24 else (h1time + 1)
    h3time = ((h2time-24) + 1) if h2time>=24 else (h2time + 1)
    h4time = ((h3time-24) + 1) if h3time>=24 else (h3time + 1)
    h5time = ((h4time-24) + 1) if h4time>=24 else (h4time + 1)
    h6time = ((h5time-24) + 1) if h5time>=24 else (h5time + 1)
    h7time = ((h6time-24) + 1) if h6time>=24 else (h6time + 1)
    h8time = ((h7time-24) + 1) if h7time>=24 else (h7time + 1)
    h9time = ((h8time-24) + 1) if h8time>=24 else (h8time + 1)
    h10time = ((h9time-24) + 1) if h9time>=24 else (h9time + 1)
    h11time = ((h10time-24) + 1) if h10time>=24 else (h10time + 1)
    h12time = ((h11time-24) + 1) if h11time>=24 else (h11time + 1)
    h13time = ((h12time-24) + 1) if h12time>=24 else (h12time + 1)
    h14time = ((h13time-24) + 1) if h13time>=24 else (h13time + 1)
    h15time = ((h14time-24) + 1) if h14time>=24 else (h14time + 1)
    h16time = ((h15time-24) + 1) if h15time>=24 else (h15time + 1)
    h17time = ((h16time-24) + 1) if h16time>=24 else (h16time + 1)
    h18time = ((h17time-24) + 1) if h17time>=24 else (h17time + 1)
    h19time = ((h18time-24) + 1) if h18time>=24 else (h18time + 1)
    h20time = ((h19time-24) + 1) if h19time>=24 else (h19time + 1)
    h21time = ((h20time-24) + 1) if h20time>=24 else (h20time + 1)
    h22time = ((h21time-24) + 1) if h21time>=24 else (h21time + 1)
    h23time = ((h22time-24) + 1) if h22time>=24 else (h22time + 1)
    h24time = ((h23time-24) + 1) if h23time>=24 else (h23time + 1)
    date=[str(h1time)+":00",str(h2time)+":00",str(h3time)+":00",str(h4time)+":00",str(h5time)+":00",str(h6time)+":00",
         str(h7time)+":00",str(h8time)+":00",str(h9time)+":00",str(h10time)+":00",str(h11time)+":00",str(h12time)+":00",str(h13time)+":00",
         str(h14time)+":00",str(h15time)+":00",str(h16time)+":00",str(h17time)+":00",str(h18time)+":00",str(h19time)+":00",str(h20time)+":00",
        str(h21time)+":00",str(h22time)+":00",str(h23time)+":00",str(h24time)+":00"]
    if request.method == 'GET':
        meter_list=[]
        metername=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary",mtdate=past_time_str).values('mtmtrname').distinct()
            # print(groupname)
        metername_list = list(metername)
        for index in range(len(metername_list)):
            for key in metername_list[index]:
                meter_list.append(metername_list[index][key])
        # print(meter_list)
        mydict= {"metername":meter_list}
        return JsonResponse(mydict,safe=False)


    elif request.method == 'POST':
        rcvd =  JSONParser().parse(request)  
        rtrntype = rcvd["type"]
        strttime = rcvd["starttime"]
        endtime = rcvd["endtime"]
        plntnme = rcvd["plantname"]
        mtrname = rcvd["mtrname"]
    #   print(rtrntype,strttime,endtime,plntnme)
        # sortedrow = Masterdatatable.objects.filter(mtdate=[str(strttime),str(endtime)],mtplntlctn=str(plntnme))
        # print(sortedrow)
        # data = Masterdatatable.objects.raw("SELECT*From meter_data_masterdatatable WHERE id=1")
        #Getting Hourly Energy Consumption data from the Database
        # print(rtrntype)
        hourlyec_list=[]
        group_list=[]
        ec_sumlist=[]
        #LOGIC TO GET THE TODAY AND LAST 24 HOURS ENERGY CONSUMPTION
        if (rtrntype=='Meter view') and (mtrname != ""):
            print((rtrntype=='Today' or rtrntype=='Last 24Hours') and (mtrname != ""))
            plantquery="(mtplntlctn='"+plntnme+"')"
            datequery="(mtdate BETWEEN '"+strttime+"' AND '"+endtime+"')"
            mtrnmequry="(mtmtrname='"+mtrname+"')"
            mtrcatqury = "(mtcategory='Secondary')"
            sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+plantquery+" AND "+mtrnmequry+" AND "+mtrcatqury
            # print(sql)
            for s in Masterdatatable.objects.raw(sql):
                # print(s.mth1ec)
                try:
                    h1val = float(s.mth1ec)
                except:
                    h1val = 0.00
                try:
                    h2val = float(s.mth2ec)
                except:
                    h2val =0.00
                try:
                    h3val = float(s.mth3ec)
                except:
                    h3val =0.00
                try:
                    h4val = float(s.mth4ec)
                except:
                    h4val =0.00
                try:
                    h5val = float(s.mth5ec)
                except:
                    h5val =0.00
                try:
                    h6val = float(s.mth6ec)
                except:
                    h6val =0.00
                try:
                    h7val = float(s.mth7ec)
                except:
                    h7val =0.00
                try:
                    h8val = float(s.mth8ec)
                except:
                    h8val =0.00
                try:
                    h9val = float(s.mth9ec)
                except:
                    h9val =0.00
                try:
                    h10val = float(s.mth10ec)
                except:
                    h10val =0.00
                try:
                    h11val = float(s.mth11ec)
                except:
                    h11val =0.00
                try:
                    h12val = float(s.mth12ec)
                except:
                    h12val =0.00
                try:
                    h13val = float(s.mth13ec)
                except:
                    h13val =0.00
                try:
                    h14val = float(s.mth14ec)
                except:
                    h14val =0.00
                try:
                    h15val = float(s.mth15ec)
                except:
                    h15val =0.00
                try:
                    h16val = float(s.mth16ec)
                except:
                    h16val =0.00
                try:
                    h17val = float(s.mth17ec)
                except:
                    h17val =0.00
                try:
                    h18val = float(s.mth18ec)
                except:
                    h18val =0.00
                try:
                    h19val = float(s.mth19ec)
                except:
                    h19val =0.00
                try:
                    h20val = float(s.mth20ec)
                except:
                    h20val =0.00
                try:
                    h21val = float(s.mth21ec)
                except:
                    h21val =0.00
                try:
                    h22val = float(s.mth22ec)
                except:
                    h22val =0.00
                try:
                    h23val = float(s.mth23ec)
                except:
                    h23val =0.00
                try:
                    h24val = float(s.mth24ec)
                except:
                    h24val =0.00
                hourlyec_list.extend([h1val,h2val,h3val,h4val,h5val,h6val,h7val,h8val,h9val,h10val,h11val,h12val,h13val,h14val,
                                     h15val,h16val,h17val,h18val,h19val,h20val,h21val,h22val,h23val,h24val])
                # print(connection.queries)    
            # print(hourlyec_list)
        #LOGIC TO GET THIS WEEK, THIS MONTH, THIS YEAR AND LAST 7DAYS ENERGY CONSUMPTION
        elif (rtrntype =='This week' or rtrntype =='This month' or rtrntype =='This year' or rtrntype =='last 7 days' 
                or rtrntype=='last 30days' or rtrntype=='Last 12months' or rtrntype=='Today' or rtrntype=='Yesterday'):
            print(rtrntype)
            # print(meterdashboarddata)
            groupname=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtgrpname').distinct()
            # print(groupname)
            groupname_list = list(groupname)
            for index in range(len(groupname_list)):
                for key in groupname_list[index]:
                    group_list.append(groupname_list[index][key])
            # print(group_list)
            for groupname in group_list:
                # print(groupname)
                mainmtrquery="(mtgrpname='"+groupname+"')"
                datequery="(mtdate BETWEEN '"+strttime+"' AND '"+endtime+"')"
                plantquery="(mtplntlctn='"+plntnme+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+mainmtrquery+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                sum=0
                # print(sql)
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    sum=sum+(s.mtenergycons)
                # print(sum)
                ec_sumlist.append(float(sum))
            # print(ec_sumlist)
        cmptype = rcvd["cmptype"]
        cmpstrtdate1 = rcvd["cmpstrtdate1"]
        cmpenddate1 = rcvd["cmpenddate1"]
        cmpstrtdate2 = rcvd["cmpstrtdate2"]
        cmpenddate2 = rcvd["cmpenddate2"]
        cmpplantname = rcvd["cmpplantname"]
        cmpmetername = rcvd["cmpmetername"]

        # print(cmptype,cmpstrtdate1,cmpenddate1,cmpstrtdate2,cmpenddate2,cmpplantname,cmpmetername)
        cmpgroup_list=[]
        cmp1_eclist=[]
        cmp2_eclist=[]
        #LOGIC TO GET THIS WEEK AND LAST WEEK ENERGY CONSUMPTION
        if (cmptype == 'This week vs Last week' or cmptype == 'This month vs Last month' or 
            cmptype == 'Today vs Yesterday' or cmptype == 'Last 24 Hrs vs Previous 24 Hrs' or
            cmptype == 'Last 7 days vs previous 7 days' or cmptype=='This Year vs Last year' or
            cmptype == 'Last 12 months vs previous 12  months'or cmptype=='Today vs Same day last week'):
            print(cmptype)
            groupname=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary").values('mtgrpname').distinct()
            # print(groupname)
            groupname_list = list(groupname)
            for index in range(len(groupname_list)):
                for key in groupname_list[index]:
                    cmpgroup_list.append(groupname_list[index][key])
            print(cmpgroup_list)
            for groupname in cmpgroup_list:
                # print(groupname)
                mainmtrquery="(mtgrpname='"+groupname+"')"
                datequery="(mtdate BETWEEN '"+cmpstrtdate1+"' AND '"+cmpenddate1+"')"
                plantquery="(mtplntlctn='"+cmpplantname+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+mainmtrquery+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                sum=0
                print(sql)
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    sum=sum+(s.mtenergycons)
                # print(sum)
                cmp1_eclist.append(float(sum))
            for groupname in cmpgroup_list:
                # print(groupname)
                mainmtrquery="(mtgrpname='"+groupname+"')"
                datequery="(mtdate BETWEEN '"+cmpstrtdate2+"' AND '"+cmpenddate2+"')"
                plantquery="(mtplntlctn='"+cmpplantname+"')"
                mtrcatqury = "(mtcategory='Secondary')"
                sql="SELECT * FROM meter_data_masterdatatable WHERE"+datequery+" AND "+mainmtrquery+" AND "+plantquery+" AND "+mtrcatqury+" ORDER BY mtdate"
                sum=0
                for s in Masterdatatable.objects.raw(sql):
                    # print(s.mtenergycons)
                    sum=sum+(s.mtenergycons)
                print(sum)
                cmp2_eclist.append(float(sum))

            print(cmp1_eclist,cmp2_eclist,cmpgroup_list)
        mydict={"selectedmtrdata": {"lblmtr":date,"mtrdata":hourlyec_list},"scheduledchart": {"lblmtr":group_list,"groupec":ec_sumlist}
                ,"comparisonchart":{"cmpgrpname":cmpgroup_list,"cmpgrp1ec":cmp1_eclist,"cmpgrp2ec":cmp2_eclist}}
    return JsonResponse(mydict, status=200,safe=False)

cmpmeter_list=[]
@csrf_exempt
def metername(request):
    plntname=request.GET['plantname']
    timingtblrow = Timingtable.objects.filter(ttplntname=plntname).values()
    # print(timingtblrow)
    for s in timingtblrow:
        dailyreporttime = s["ttdaystarttime"]
        s1time = s["tts1time"]
        s2time = s["tts2time"]
        s3time = s["tts3time"]
    s1string = s1time.strftime('%H')
    s1hrint = int(s1string)
    current_time = datetime.datetime.now()
    # Subtract 2 hours from datetime object containing current time
    past_time = current_time - timedelta(hours=s1hrint)
    # Convert datetime object to string in specific format 
    past_time_str = past_time.strftime('%Y-%m-%d')
    if request.method=="GET":
        cmpmeter_list=[]
        metername=Masterdatatable.objects.filter(mtplntlctn=plntname,mtcategory="Secondary",mtdate=past_time_str).values('mtmtrname').distinct()
        # print(groupname)
        metername_list = list(metername)
        for index in range(len(metername_list)):
            for key in metername_list[index]:
                cmpmeter_list.append({"metername":metername_list[index][key]})
        # print(cmpmeter_list)
        mydict={"meters":cmpmeter_list}
    return JsonResponse(mydict,status=200,safe=False)

