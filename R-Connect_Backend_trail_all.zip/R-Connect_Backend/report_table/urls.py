from django.conf.urls import url
from report_table import views, heatmap

urlpatterns=[
    url('reporttable/',views.reportdashboard,name='reporttable'),   
    url('metername/',views.metername,name='metername'),
    url('heatmap/',heatmap.HeatMap,name='heatmap')
]