from django.urls import re_path, path

from . import websocket

websocket_urlpatterns = [
    re_path(r'ws/session/(?P<room_name>[\w\-\s]+)/$', websocket.SessionConsumer.as_asgi())
    #re_path(r'session/(?P<room_name>\w+)/$', websocket.SessionConsumer.as_asgi())
    # path('ws/session/', websocket.SessionConsumer.as_asgi())
]