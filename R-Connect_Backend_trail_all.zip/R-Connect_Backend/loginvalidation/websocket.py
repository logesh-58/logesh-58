import json
import asyncio
from urllib.parse import parse_qs
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.consumer import AsyncConsumer
from channels.db import database_sync_to_async
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from usermanagement.models import AddUser

class TokenChecker:
    @database_sync_to_async
    def CheckSessionID(self, data):
        roomname = data['udusername']
        SessionToken = data['udsession_id']
        channel_layer = get_channel_layer()
        validate =AddUser.objects.filter(udemail=data['udemail'], udsession_id=data['udsession_id'], udPlantname=data['udPlantname']).exists()
        if not validate:
          User = AddUser.objects.get(udemail=data['udemail'], udPlantname=data['udPlantname'])
          SessionToken = User.udsession_id
          async_to_sync(channel_layer.group_send)(
              f"session_{roomname}",
              {
                  'type': 'logout_notification',
                  'message': SessionToken
              }
          )
        else:
          async_to_sync(channel_layer.group_send)(
              f"session_{roomname}",
              {
                  'type': 'LoggedIn',
                  'message': SessionToken
              }
          )

class SessionConsumer(AsyncWebsocketConsumer, TokenChecker):
    async def connect(self):
        # Get the room name from the URL
        self.room_name = self.scope['url_route']['kwargs']['room_name']

        self.room_group_name = f"session_{self.room_name}"
        #print(self.room_name)
        # Join the room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave the group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data=None, bytes_data=None):
        try:
            data = json.loads(text_data)
            print(f'WebSocket Data Received : {data}')


            
            await self.CheckSessionID(data)
        except json.decoder.JSONDecodeError as e:
            print("JSON Decode Error:", e)

    async def LoggedIn(self, event):
      #print(event)
      await self.send(text_data=json.dumps({"message": event['message']}))

    async def logout_notification(self, event):
        #print(event)
        await self.send(text_data=json.dumps({"message": event['message']}))



