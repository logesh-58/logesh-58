from usermanagement.serializers import UserManagementDbSerializer
from django.http.response import JsonResponse
from django.shortcuts import render
from rest_framework.parsers import JSONParser
from usermanagement.models import AddUser
from django.views.decorators.csrf import csrf_exempt
import json
import uuid
# Create your views here.
#ji
@csrf_exempt
def validateuser(request):
    if request.method == "POST":
        lgndata=JSONParser().parse(request)
        email=lgndata["email"]
        pwd=lgndata["password"]
        validationstrng=""
        
        usrdata = AddUser.objects.filter(udemail=email).values("udpassword")
        # print(usrdata)
        if usrdata.exists():
            for s in usrdata:
                if (s["udpassword"]==pwd):

                    session_token = str(uuid.uuid4())
                    request.session['session_token'] = session_token

                    validationstrng="Email ID and Password matches"
                    userdetails = AddUser.objects.filter(udemail = email)
                    userdataserializers = UserManagementDbSerializer(userdetails, many=True)
                    data = userdataserializers.data
                    for i in data:
                        username     = i['udusername']
                        usertype     = i['udtype']
                        useremail    = i['udemail']
                        udusercode = i['udusercode']
                        userplant    = i['udPlantname']
                        userfname    = i['udfirstName']
                        userlname    = i['udlastName']
                        location = i['udlocation']
                        
                    # print(username, usertype, useremail, userplant, userfname, userlname, useraddress1, useraddress2)
                    my_dict = {'validationstring':validationstrng,
                               'udusername': username,
                               'udtype': usertype,
                               'udemail': useremail,
                               'udusercode': udusercode,
                               'udPlantname': userplant,
                               'udfirstName': userfname,
                               'udlastName': userlname,
                               'udlocation': location,
                               "sessionID": request.session['session_token']
                                }
                    AddUser.objects.filter(udemail=email).update(udsession_id=request.session['session_token'])
                    return JsonResponse(my_dict, safe=False)
                else:
                    validationstrng="Password doesn't matches"
        else:
            validationstrng="Email ID doesn't exist"
        print(validationstrng)
        return JsonResponse({'validationstring':validationstrng},safe=False)
