from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from maintenance.models import maintenance_module
import json
from machinemanagement.models import AddMachine
from datetime import datetime, timedelta
import pandas
import calendar
# mail packages
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders

# Create your views here.

def getmachinename (plantname):
    machine_name = AddMachine.objects.filter(amPlantname = plantname).values('amMachinename', 'ammachineimage', 'amconsiderbool').order_by('amid')
    return machine_name

@csrf_exempt
def maintenance_func(request):
    if request.method == 'GET':
        plantname = request.GET['Plantname']
        current_date = (datetime.today()).date()
        response_list = []
        Machine_Name = getmachinename(plantname)
        for mnm in Machine_Name:
            oil_filter = 0;  pumpstatus = 0; lubrication_oillevel = 0; hydraulic_oillevel = 0; frdoor = 0; rrdoor = 0
            moldleakage = 0; cooling = 0; injection = 0; oilfilter_motor = 0
            data = list(maintenance_module.objects.filter(mnt_date = str(current_date), mnt_machinename = mnm['amMachinename']).values('mnt_oilfilter_clogge', 'mnt_hydraulic', 
                                                                                                                                    'mnt_pumpstatus', 'mnt_lubrication',
                                                                                                                                    'mnt_FRdoor', 'mnt_RRdoor', 'mnt_moldleakage',
                                                                                                                                    'mnt_cooling', 'mnt_injection',
                                                                                                                                    'mnt_oilfilter_motor'))
            if data != []:
                for i in data:
                    if i['mnt_oilfilter_clogge'] != None:
                        oil_filter = 0
                    else:
                        oil_filter = 1
                    if i['mnt_lubrication'] != None:
                        lubrication_oillevel = 0
                    else:
                        lubrication_oillevel = 1
                    if i['mnt_hydraulic'] != None:
                        hydraulic_oillevel = 0
                    else:
                        hydraulic_oillevel = 1
                    if i['mnt_pumpstatus']:
                        pumpstatus = 0
                    else:
                        pumpstatus = 1
                    if i['mnt_FRdoor'] != None:
                        frdoor = 0
                    else:
                        frdoor = 1
                    if i['mnt_RRdoor'] != None:
                        rrdoor = 0
                    else:
                        rrdoor = 1
                    if i['mnt_moldleakage'] != None:
                        moldleakage = 0
                    else:
                        moldleakage = 1
                    if i['mnt_cooling'] != None:
                        cooling = 0
                    else:
                        cooling = 1
                    if i['mnt_injection'] != None:
                        injection = 0
                    else:
                        injection = 1
                    if i['mnt_oilfilter_motor'] != None:
                        oilfilter_motor = 0
                    else:
                        oilfilter_motor = 1
                    response_list.append({
                                        "machinename":mnm['amMachinename'],
                                        "Machineimage":mnm['ammachineimage'],
                                        "oilfilter_condition":oil_filter, 
                                        "lubricationoil_monitoring":lubrication_oillevel, 
                                        "hydraulicoil_monitoring":hydraulic_oillevel, 
                                        "pumpstatus_monitoring":pumpstatus,
                                        "frdoor_monitoring":frdoor,
                                        "rrdoor_monitoring":rrdoor,
                                        "moldleakage_monitoring":moldleakage,
                                        "cooling_monitoring":cooling,
                                        "injection_monitoring":injection,
                                        "oilfilter_motor":oilfilter_motor
                                        })
            else:
                response_list.append({
                                    "machinename":mnm['amMachinename'],
                                    "Machineimage":mnm['ammachineimage'],
                                    "oilfilter_condition":oil_filter, 
                                    "lubricationoil_monitoring":lubrication_oillevel, 
                                    "hydraulicoil_monitoring":hydraulic_oillevel, 
                                    "pumpstatus_monitoring":pumpstatus,
                                    "frdoor_monitoring":frdoor,
                                    "rrdoor_monitoring":rrdoor,
                                    "moldleakage_monitoring":moldleakage,
                                    "cooling_monitoring":cooling,
                                    "injection_monitoring":injection,
                                    "oilfilter_motor":oilfilter_motor
                                    })
        return JsonResponse (response_list, safe = False)

@csrf_exempt
def Analytics (request):
    if request.method == 'POST':
        request_data     = json.loads(request.body)
        start_date       = request_data['start_date']
        end_date         = request_data['end_date']
        machinename      = request_data['machinename']
        date_range = pandas.date_range(start = start_date, end = end_date)
        analytics_list = []
        for date in date_range:
            oilfilterclogging = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_oilfilter_clogge__gte = 0).values('mnt_oilfilter_clogge').count()
            lubricationoil = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_lubrication__gte = 0).values('mnt_lubrication').count()
            hydraulicoil   = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename,  mnt_hydraulic__gte = 0).values('mnt_hydraulic').count()
            pumpstatus     = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_pumpstatus__gte = 0).values('mnt_pumpstatus').count()
            frdoor         = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_FRdoor__gte = 0).values('mnt_FRdoor').count()
            rrdoor         = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_RRdoor__gte = 0).values('mnt_RRdoor').count()
            moldleakage    = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_moldleakage__gte = 0).values('mnt_moldleakage').count()
            cooling        = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_cooling__gte = 0).values('mnt_cooling').count()
            injection      = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_injection__gte = 0).values('mnt_injection').count()
            oilfiltermotor = maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_oilfilter_motor__gte = 0).values('mnt_oilfilter_motor').count()
            analytics_list.append({"date":date.date(), "oilfilter_clogging":oilfilterclogging,
                                   "lubrication_oillevel":lubricationoil, "hydraulic_oillevel":hydraulicoil,
                                   "pump_status":pumpstatus, "frdoor_monitoring":frdoor,
                                   "rrdoor_monitoring":rrdoor, "mold_leakge":moldleakage,
                                   "cooling_monitoring":cooling, "injection_monitoring":injection,
                                   "oilfiltermotor":oilfiltermotor})
        return JsonResponse (analytics_list , safe = False)

@csrf_exempt
def Historical (request):
    if request.method == 'POST':
        request_data     = json.loads(request.body)
        start_date       = request_data['start_date']
        end_date         = request_data['end_date']
        machinename      = request_data['machinename']
        date_range = pandas.date_range(start = start_date, end = end_date)
        historical_response = []
        for date in date_range:
            oilfilterclogging = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_oilfilter_clogge__gte = 0).values('mnt_oilfilter_clogge', 'mnt_time'))
            lubricationoil = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_lubrication__gte = 0).values('mnt_lubrication', 'mnt_time'))
            hydraulicoil   = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_hydraulic__gte = 0).values('mnt_hydraulic', 'mnt_time'))
            pumpstatus     = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_pumpstatus__gte = 0).values('mnt_pumpstatus', 'mnt_time'))
            frdoor         = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_FRdoor__gte = 0).values('mnt_FRdoor', 'mnt_time'))
            rrdoor         = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_RRdoor__gte = 0).values('mnt_RRdoor', 'mnt_time'))
            moldleakage    = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_moldleakage__gte = 0).values('mnt_moldleakage', 'mnt_time'))
            cooling        = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_cooling__gte = 0).values('mnt_cooling', 'mnt_time'))
            injection      = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_injection__gte = 0).values('mnt_injection', 'mnt_time'))
            oilfiltermotor = list(maintenance_module.objects.filter(mnt_date = date.date(), mnt_machinename = machinename, mnt_oilfilter_motor__gte = 0).values('mnt_oilfilter_motor', 'mnt_time'))
            if oilfilterclogging != []:
                historical_response.append({"date":date.date(), "time": oilfilterclogging[0]['mnt_time'], "machinename":machinename, "condition": 'Oilfilter is clogged'})
            if lubricationoil != []:
                historical_response.append({"date":date.date(), "time": lubricationoil[0]['mnt_time'], "machinename":machinename, "condition": 'Lubrication Oil Level is Droped'})
            if hydraulicoil   != []:
                historical_response.append({"date":date.date(), "time": hydraulicoil[0]['mnt_time'], "machinename":machinename, "condition": 'Hydraulic Oil Level is Droped'})
            if pumpstatus     != []:
                historical_response.append({"date":date.date(), "time": pumpstatus[0]['mnt_time'], "machinename":machinename, "condition": 'Main Motor is Powered Off'})
            if frdoor         != []:
                historical_response.append({"date":date.date(), "time": frdoor[0]['mnt_time'], "machinename":machinename, "condition": 'FR Safety Door is Opened'})
            if rrdoor         != []:
                historical_response.append({"date":date.date(), "time": rrdoor[0]['mnt_time'], "machinename":machinename, "condition": 'RR Safety Door is Opened'})
            if moldleakage    != []:
                historical_response.append({"date":date.date(), "time": moldleakage[0]['mnt_time'], "machinename":machinename, "condition": 'Mold is Leaking'})
            if cooling        != []:
                historical_response.append({"date":date.date(), "time": cooling[0]['mnt_time'], "machinename":machinename, "condition": 'cooling_monitoring'})
            if injection      != []:
                historical_response.append({"date":date.date(), "time": injection[0]['mnt_time'], "machinename":machinename, "condition": 'injection_monitoring'})
            if oilfiltermotor != []:
                historical_response.append({"date":date.date(), "time": oilfiltermotor[0]['mnt_time'], "machinename":machinename, "condition": 'Oil Filter Motor is Powered Off'})
        return JsonResponse (historical_response , safe = False)
