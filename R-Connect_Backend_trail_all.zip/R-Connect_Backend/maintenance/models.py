from django.db import models

# Create your models here.
class maintenance_module(models.Model):
    mnt_id = models.AutoField(primary_key=True)
    mnt_date = models.DateField(null = True)
    mnt_time = models.CharField(max_length = 255, null = True, default = False)
    mnt_machinename = models.CharField(max_length = 255, null = True, default = False)
    mnt_oilfilter_clogge = models.IntegerField(null = True)
    mnt_FRdoor = models.IntegerField(null = True)
    mnt_RRdoor = models.IntegerField(null = True)
    mnt_lubrication = models.IntegerField(null = True)
    mnt_moldleakage =  models.IntegerField(null = True)
    mnt_pumpstatus  = models.IntegerField(null = True)
    mnt_hydraulic   = models.IntegerField(null = True)
    mnt_injection   = models.IntegerField(null = True)
    mnt_cooling     = models.IntegerField(null = True)
    mnt_oilfilter_motor = models.IntegerField(null = True)
    