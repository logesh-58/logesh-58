from rest_framework import serializers
from .models import process_module, process_modulelive

class process_module_serial(serializers.ModelSerializer):
    class Meta:
        model = process_module
        fields = '__all__'


class process_modulelive_serial(serializers.ModelSerializer):
    class Meta:
        model = process_modulelive
        fields = '__all__'