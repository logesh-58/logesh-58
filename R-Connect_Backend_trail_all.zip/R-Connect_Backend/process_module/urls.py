from django.urls import path, include
from .views import process_modulef
from .new_views import process_modulefd

urlpatterns = [
   # path('Process_module', process_modulef), # Process_module
   path('Process_module', process_modulefd),  # Process_moduled
   
] 