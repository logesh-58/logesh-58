from django.db.models import Count
from datetime import datetime, time, timedelta
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
import json
from django.views.decorators.csrf import csrf_exempt
from .models import process_module, process_modulelive
from machinemanagement.models import AddMachine
from .serializers import process_module_serial, process_modulelive_serial
from dashboard.models import Dashboard, Mouldmodel
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
from django.db.models import Q, Min, Max, Count, F, Sum
import pytz


@csrf_exempt
def process_modulefd(request):
    if request.method == 'POST':
        
        plantname = request.GET.get('Plantname') 

        machinelist = AddMachine.objects.filter(amPlantname = plantname).values().order_by('amid')
        machine_names = [machine['amMachinename'] for machine in machinelist]
        
        shift_starttime = ShiftTimings.objects.filter(Plantname=plantname).values('shift1start').last()['shift1start']
        shift_starttime_str = shift_starttime.strftime('%H:%M:%S')
        ###########

        ist_timezone = pytz.timezone('Asia/Kolkata')

        # Get the current time in IST
        # timenow_ist = datetime.now(ist_timezone).time()
        timenow_ist_str = "23:59:24"
        timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

        time_start_A = time(0, 0, 0)
        time_end_A = time(5, 59, 59)

        if time_start_A <= timenow_ist <= time_end_A:
            # current_date = (datetime.today()).date()
            current_date = datetime.strptime("2024-10-26", "%Y-%m-%d")  - timedelta(days=1)
        else:
            current_date = datetime.strptime("2024-10-26", "%Y-%m-%d")
        ###############################################################################

        next_date = current_date + timedelta(days=1)

        # Use strftime to convert the datetime object to a string if needed
        current_date_str = current_date.strftime("%Y-%m-%d")
        next_day_str = next_date.strftime("%Y-%m-%d")

        ###########
        firstday_start = '06:00:00'
        firstday_end = '23:59:59'
        secondday_start = '00:00:00'
        secondday_end = '05:59:59'
        ###########

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__gte=firstday_start) |
                    Q(date=next_day_str, time__lte=secondday_end),
                    Plantname=plantname,
                    Machinename__in=machine_names,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values().order_by('id')
        
        all_dashboard_live = Dashboard.objects.filter(
            Plantname=plantname, Machinename__in=machine_names
        ).values('Machinename', 'Mouldname_id', 'MachineState', 'Alarm', 'ProductionTimeActual', 'CycletimeActual', 'CycletimeSet', 'ProductionCountActual', 'RejectionParts', 'machinestatus').order_by('id')

        response = []

        for machine_value in machinelist:

            item = {
                'machine_name': machine_value['amMachinename'],
                'ambarelzonecount': machine_value['ambarelzonecount'],
                'amhrtczonecount': machine_value['amhrtczonecount'],
                'machine_image': machine_value['ammachineimage'],
            }

            dashboard_value  = [r for r in all_dashboard_live if r['Machinename'] == item['machine_name']]

            if dashboard_value:
                    
                dashboard_value = dashboard_value[-1]     # 0   # -1
            
                item['machine_status']  = dashboard_value['machinestatus']

                if len([v for v in all_dashboard_value if v['date'] == current_date_str and v['Machinename'] == item['machine_name'] and v['time'] >= shift_starttime_str]) != 0:
                    
                    mouldname_id = dashboard_value['Mouldname_id']
                    mouldmodel_instance = Mouldmodel.objects.get(id=mouldname_id)

                    item['mouldname'] = mouldmodel_instance.Mouldname

                    barelsetcounts = {
                    "barelsetvalue1": int(mouldmodel_instance.barelsetvalue1) if str(mouldmodel_instance.barelsetvalue1).isdigit() else None,
                    "barelsetvalue2": int(mouldmodel_instance.barelsetvalue2) if str(mouldmodel_instance.barelsetvalue2).isdigit() else None,
                    "barelsetvalue3": int(mouldmodel_instance.barelsetvalue3) if str(mouldmodel_instance.barelsetvalue3).isdigit() else None,
                    "barelsetvalue4": int(mouldmodel_instance.barelsetvalue4) if str(mouldmodel_instance.barelsetvalue4).isdigit() else None,
                    "barelsetvalue5": int(mouldmodel_instance.barelsetvalue5) if str(mouldmodel_instance.barelsetvalue5).isdigit() else None,
                    "barelsetvalue6": int(mouldmodel_instance.barelsetvalue6) if str(mouldmodel_instance.barelsetvalue6).isdigit() else None,
                    "barelsetvalue7": int(mouldmodel_instance.barelsetvalue7) if str(mouldmodel_instance.barelsetvalue7).isdigit() else None,
                    "barelsetvalue8": int(mouldmodel_instance.barelsetvalue8) if str(mouldmodel_instance.barelsetvalue8).isdigit() else None,
                    "barelsetvalue9": int(mouldmodel_instance.barelsetvalue9) if str(mouldmodel_instance.barelsetvalue9).isdigit() else None,
                    "barelsetvalue10": int(mouldmodel_instance.barelsetvalue10) if str(mouldmodel_instance.barelsetvalue10).isdigit() else None,
                    "barelsetvalue11": int(mouldmodel_instance.barelsetvalue11) if str(mouldmodel_instance.barelsetvalue11).isdigit() else None,
                    "barelsetvalue12": int(mouldmodel_instance.barelsetvalue12) if str(mouldmodel_instance.barelsetvalue12).isdigit() else None,
                    }

                    item.update(barelsetcounts)

                if item['machine_status'] == "true":
                    machinestatusd = 1
                    
                elif item['machine_status'] == "false":
                    machinestatusd = 0

            GetData = process_modulelive.objects.filter(date="2024-12-27", Plantname = plantname, Machinename = item['machine_name']).order_by('id')

            Viewdata = process_modulelive_serial(GetData, many=True)

            print("Machinename:", item['machine_name'])

            for live_item in Viewdata.data:

                alarmset = live_item.get('hopperMaterialLevel')
                # alarmset = int(alarmset)

                if alarmset is not None:
                    alarmset = int(alarmset)
                else:
                    alarmset = 0  # Default value if alarmset is None

                # Use correct condition for alarm
                if alarmset == 0 or machinestatusd == 0:
                    alarm = False
                elif alarmset != 0 and machinestatusd == 1:
                    alarm = True

                live_item['alarm'] = alarm  # Add the alarm flag to the item dictionary

                # Convert existing item fields to integers where applicable
                for key in ['BarelTempZ1', 'BarelTempZ2', 'BarelTempZ3', 'BarelTempZ4', 'BarelTempZ5', 'BarelTempZ6', 'BarelTempZ7', 'BarelTempZ8', 'BarelTempZ9', 'BarelTempZ10', 'BarelTempZ11', 'BarelTempZ12', 'airInletPressureGuage', 'hopperMaterialLevel', 'hopperTemperature', 'MTC', 'CWIP', 'CWOP', 'CWIT', 'CWOT', 'HRTC1', 'HRTC2', 'HRTC3', 'HRTC4', 'HRTC5', 'HRTC6', 'HRTC7', 'HRTC8', 'HRTC9', 'HRTC10', 'HRTC11', 'HRTC12', 'HRTC13', 'HRTC14', 'HRTC15', 'HRTC16', 'HRTC17', 'HRTC18', 'HRTC19', 'HRTC20', 'HRTC21', 'HRTC22', 'HRTC23', 'HRTC24', 'HRTC25', 'HRTC26', 'HRTC27', 'HRTC28', 'HRTC29', 'HRTC30', 'HRTC31', 'HRTC32', 'HRTC33', 'HRTC34', 'HRTC35', 'HRTC36', 'HRTC37', 'HRTC38', 'HRTC39', 'HRTC40', 'HRTC41', 'HRTC42', 'HRTC43', 'HRTC44', 'HRTC45', 'HRTC46', 'HRTC47', 'HRTC48', 'HRTC49', 'HRTC50', 'HRTC51', 'HRTC52', 'HRTC53', 'HRTC54', 'HRTC55', 'HRTC56', 'HRTC57', 'HRTC58', 'HRTC59', 'HRTC60', 'HRTC61', 'HRTC62', 'HRTC63', 'HRTC64']:
                    if live_item.get(key) is not None:
                        live_item[key] = int(live_item[key])

                combined_data = {**item, **live_item}
                response.append(combined_data)

        return JsonResponse(response, safe=False)
    
