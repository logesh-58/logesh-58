from django.db.models import Count
from datetime import timedelta, datetime
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
import json
from django.views.decorators.csrf import csrf_exempt
from .models import process_module, process_modulelive
from machinemanagement.models import AddMachine
from .serializers import process_module_serial, process_modulelive_serial
from dashboard.models import Dashboard, Mouldmodel
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable


def get_mouldname(plantname, machinename):
    machinelist = AddMachine.objects.filter(amPlantname=plantname, amMachinename=machinename).values('amMachinename', 'amconsiderbool').order_by('amid')
    # current_date = (datetime.today()).date()
    current_date = "2024-10-26"
    print(current_date)
    shift_starttime = ShiftTimings.objects.values('shift1start').last()['shift1start']
    for machine_value in machinelist:
        java = machine_value['amconsiderbool']

        if java == True:

            machine_name = machine_value['amMachinename']
            dashboard_value = Dashboard.objects.filter(Plantname=plantname, Machinename=machine_name).values('Mouldname_id', 'machinestatus').last()
            machinestatus = dashboard_value['machinestatus']
            
            if ProductionTable.objects.filter(date = current_date, Plantname = plantname, Machinename = machine_name, time__gte = shift_starttime).count() != 0:
                mouldname_id = dashboard_value['Mouldname_id']
                mouldmodel_instance = Mouldmodel.objects.get(id=mouldname_id)
                # mouldname = Mouldmodel.objects.get(id=mouldname_id).Mouldname
                mouldname = mouldmodel_instance.Mouldname
                
                barelsetcounts = {
                    "barelsetvalue1": int(mouldmodel_instance.barelsetvalue1) if str(mouldmodel_instance.barelsetvalue1).isdigit() else None,
                    "barelsetvalue2": int(mouldmodel_instance.barelsetvalue2) if str(mouldmodel_instance.barelsetvalue2).isdigit() else None,
                    "barelsetvalue3": int(mouldmodel_instance.barelsetvalue3) if str(mouldmodel_instance.barelsetvalue3).isdigit() else None,
                    "barelsetvalue4": int(mouldmodel_instance.barelsetvalue4) if str(mouldmodel_instance.barelsetvalue4).isdigit() else None,
                    "barelsetvalue5": int(mouldmodel_instance.barelsetvalue5) if str(mouldmodel_instance.barelsetvalue5).isdigit() else None,
                    "barelsetvalue6": int(mouldmodel_instance.barelsetvalue6) if str(mouldmodel_instance.barelsetvalue6).isdigit() else None,
                    "barelsetvalue7": int(mouldmodel_instance.barelsetvalue7) if str(mouldmodel_instance.barelsetvalue7).isdigit() else None,
                    "barelsetvalue8": int(mouldmodel_instance.barelsetvalue8) if str(mouldmodel_instance.barelsetvalue8).isdigit() else None,
                    "barelsetvalue9": int(mouldmodel_instance.barelsetvalue9) if str(mouldmodel_instance.barelsetvalue9).isdigit() else None,
                    "barelsetvalue10": int(mouldmodel_instance.barelsetvalue10) if str(mouldmodel_instance.barelsetvalue10).isdigit() else None,
                    "barelsetvalue11": int(mouldmodel_instance.barelsetvalue11) if str(mouldmodel_instance.barelsetvalue11).isdigit() else None,
                    "barelsetvalue12": int(mouldmodel_instance.barelsetvalue12) if str(mouldmodel_instance.barelsetvalue12).isdigit() else None,
                }

                # print("barelsetcounts:", barelsetcounts)
                return mouldname, machinestatus, java, barelsetcounts  # Return four values
            else:
                print("No data in ProductionTable")
                return None, machinestatus, java, None  # Ensure to return four values even if there's no data
            
        else:
            print("out1!")

    return None, None, java, None  # Ensure to return four values


@csrf_exempt
def process_modulef(request):
    if request.method == 'POST':
        
        plantname = request.GET.get('Plantname')  # Extract Plantname from GET parameters
        
        if not plantname:
            return JsonResponse({'error': 'Plantname parameter is required'}, status=400)
        
        # current_date = (datetime.today()).date()
        current_date = "2024-12-27"

        GetData = process_modulelive.objects.filter(date=current_date).order_by('id')

        Viewdata = process_modulelive_serial(GetData, many=True)

        data_with_static_values = []

        for item in Viewdata.data:
            machinename = item.get('Machinename')

            print("machinename:", machinename)

            # Fetch Mouldname using the extracted Plantname
            Mouldname, machinestatus, java, barelsetcounts = get_mouldname(plantname, machinename)

            print("barelsetcounts:", barelsetcounts)
            
            item['java'] = java

            add_machine_data = AddMachine.objects.filter(amMachinename=machinename).values('ambarelzonecount', 'amhrtczonecount', 'ammachineimage', 'ammachinecode', 'amMachinename', 'ammachinelocation', 'ammachineip', 'amconsiderbool').first()
            
            if java == True:

                item['Mouldname'] = Mouldname
                item['machinestatus'] = machinestatus
                
                if barelsetcounts:
                    item.update(barelsetcounts)

                if 'ammachineimage' in add_machine_data:
                    add_machine_data['machineimage'] = add_machine_data['ammachineimage']

                # Convert relevant fields to integers
                if 'ambarelzonecount' in add_machine_data:
                    add_machine_data['ambarelzonecount'] = int(add_machine_data['ambarelzonecount'])

                if 'amhrtczonecount' in add_machine_data:
                    add_machine_data['amhrtczonecount'] = int(add_machine_data['amhrtczonecount'])

                item.update(add_machine_data)

            else:
                print("out2!")

            alarmset = item.get('hopperMaterialLevel')
            alarmset = int(alarmset)

            if machinestatus == "true":
                machinestatusd = 1
                
            elif machinestatus == "false":
                machinestatusd = 0

            # Use correct condition for alarm
            if alarmset == 0 or machinestatusd == 0:
                alarm = False
            elif alarmset != 0 and machinestatusd == 1:
                alarm = True

            item['alarm'] = alarm  # Add the alarm flag to the item dictionary

            # Convert existing item fields to integers where applicable
            for key in ['BarelTempZ1', 'BarelTempZ2', 'BarelTempZ3', 'BarelTempZ4', 'BarelTempZ5', 'BarelTempZ6', 'BarelTempZ7', 'BarelTempZ8', 'BarelTempZ9', 'BarelTempZ10', 'BarelTempZ11', 'BarelTempZ12', 'airInletPressureGuage', 'hopperMaterialLevel', 'hopperTemperature', 'MTC', 'CWIP', 'CWOP', 'CWIT', 'CWOT', 'HRTC1', 'HRTC2', 'HRTC3', 'HRTC4', 'HRTC5', 'HRTC6', 'HRTC7', 'HRTC8', 'HRTC9', 'HRTC10', 'HRTC11', 'HRTC12', 'HRTC13', 'HRTC14', 'HRTC15', 'HRTC16', 'HRTC17', 'HRTC18', 'HRTC19', 'HRTC20', 'HRTC21', 'HRTC22', 'HRTC23', 'HRTC24', 'HRTC25', 'HRTC26', 'HRTC27', 'HRTC28', 'HRTC29', 'HRTC30', 'HRTC31', 'HRTC32', 'HRTC33', 'HRTC34', 'HRTC35', 'HRTC36', 'HRTC37', 'HRTC38', 'HRTC39', 'HRTC40', 'HRTC41', 'HRTC42', 'HRTC43', 'HRTC44', 'HRTC45', 'HRTC46', 'HRTC47', 'HRTC48', 'HRTC49', 'HRTC50', 'HRTC51', 'HRTC52', 'HRTC53', 'HRTC54', 'HRTC55', 'HRTC56', 'HRTC57', 'HRTC58', 'HRTC59', 'HRTC60', 'HRTC61', 'HRTC62', 'HRTC63', 'HRTC64']:
                if item.get(key) is not None:
                    item[key] = int(item[key])

            data_with_static_values.append(item)

        response = data_with_static_values
        return JsonResponse(response, safe=False)
    
