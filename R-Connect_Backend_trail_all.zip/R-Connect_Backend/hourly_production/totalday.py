from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
import xlwt
from RConnect.settings import BASE_DIR
import os
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from usermanagement.models import AddUser
from meter_data.models import Masterdatatable
from group_management.models import AddGroup
from django.db.models import Sum as add
from datetime import datetime , timedelta, date
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from celery.schedules import crontab
# from celery.decorators import periodic_task
from mouldmanagement.models import Mouldmodel
from timeline.models import breakdown
# from celery import shared_task
from timeline.models import badpart
# @periodic_taskrun_every=(crontab(minute='*/1')))

@csrf_exempt
def enryhrs(request):
    #add new colour to palette and set RGB colour value
    work_book = xlwt.Workbook(encoding='utf-8')
    xlwt.add_palette_colour("custom_colour", 0x11)
    work_book.set_colour_RGB(0x11, 188, 225, 158)
    Ws_1 = work_book.add_sheet('Energy_Report')
    Ws_1.show_grid = False
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()
    styletotal1 = xlwt.XFStyle()
    styletotal2 = xlwt.XFStyle()
    #Set alignment
    alignment       = xlwt.Alignment()
    alignment.horz  = xlwt.Alignment.HORZ_CENTER
    alignment.vert  = xlwt.Alignment.VERT_CENTER
    alignment.wrap      = 1
    style1.alignment    = alignment
    style1.alignment = alignment
    style1.alignment = alignment
    style2.alignment = alignment
    style3.alignment = alignment
    style2.alignment    = alignment
    styletotal1.alignment = alignment
    styletotal2.alignment = alignment
    #Set border
    border          = xlwt.Borders()
    border.left     = xlwt.Borders.THIN 
    border.right    = xlwt.Borders.THIN 
    border.top      = xlwt.Borders.THIN 
    border.bottom   = xlwt.Borders.THIN
    style1.borders  = border
    style1.borders = border
    style1.borders = border
    style2.borders = border
    style3.borders = border
    styletotal1.borders = border
    styletotal2.borders = border
    # pattern
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['custom_colour']
    style2.pattern = pattern
    # pattern total
    pattern1 = xlwt.Pattern()
    pattern1.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern1.pattern_fore_colour = xlwt.Style.colour_map['tan']
    styletotal1.pattern = pattern1
    #Set Font Color
    # Set Font
    # Not Bold Letter
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['gray80']
    font.name = 'calibari'
    font.bold = True
    font.height = 200
    style2.font = font
    #style 3
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'calibri'
    font.bold = False
    font.height = 200
    style3.font = font
    # Bold Letter
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'calibri'
    font.bold = True
    font.height = 250
    style1.font = font
    #style total1
    font2 = xlwt.Font()
    font2.colour_index=xlwt.Style.colour_map['black']
    font2.name = 'calibri'
    font2.bold = True
    font2.height = 200
    styletotal1.font = font2
    #style total2
    font3 = xlwt.Font()
    font3.colour_index=xlwt.Style.colour_map['red']
    font3.name = 'calibri'
    font3.bold = True
    font3.height = 200
    styletotal2.font = font3
    #set custom color 
    # now you can use the colour in styles
    machinename_data = AddMachine.objects.order_by('amid').values('amMachinename').distinct()
    style = xlwt.easyxf('font: bold 1, colour_index gray80; align: rotation 90; pattern: pattern solid, fore_colour custom_colour; align: wrap on, vert center, horiz center; border : bottom thin,right thin,top thin,left thin;')
    row  = 1; col =1 
    Ws_1.write_merge(row, row+1, col, col+27, 'Energy Consumption Report', style1)
    row = 4 ; col = 1
    for i in ['S.No', 'Plantname', 'Group', 'Total Energy']:Ws_1.write_merge(row, row+1, col, col, i, style2);col+=1
    Ws_1.row(row).height_mismatch  = True
    Ws_1.row(row).height = 500
    Ws_1.write_merge(row, row, col, col+23, "Houry Energy Consumption", style2)
    start_time = 6; end_time = 7; row += 1; col = 5; start_end = ''
    for j in ['06:00 - 07:00', '07:00 - 08:00', '08:00 - 09:00' ,'09:00 - 10:00', '10:00 - 11:00', '11:00 - 12:00', 
                '12:00 - 13:00', '13:00 - 14:00', '14:00 - 15:00', '15:00 - 16:00', '16:00 - 17:00', '17:00 - 18:00', '18:00 - 19:00',
                '19:00 - 20:00', '20:00 - 21:00', '21:00 - 22:00', '22:00 - 23:00', '23:00 - 00:00','00:00 - 01:00', '01:00 - 02:00',
                '02:00 - 03:00', '03:00 - 04:00', '04:00 - 05:00', '05:00 - 06:00']:
        Ws_1.row(row).height_mismatch  = True
        Ws_1.row(row).height = 1600
        Ws_1.write(row, col, j, style)
        start_time += 1; end_time += 1; col += 1
    yesterday_date = (datetime.today()).date()-timedelta(days=1)
    # yesterday_date = '2023-12-28'
    group_data = AddGroup.objects.values('agplantname')
    Plant_Name = AddUser.objects.last().udPlantname
    row = 6; col = 1;serial_count = 1; grp_list = []
    #increase the column width
    Ws_1.col(col).width   = 1500
    Ws_1.col(col+1).width = 2800
    Ws_1.col(col+2).width = 3700
    column_nm = ['mtenergycons', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec','mth5ec','mth6ec','mth7ec', 'mth8ec', 'mth9ec', 'mth10ec'
                ,'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec', 'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec', 'mth21ec'
                ,'mth22ec', 'mth23ec', 'mth24ec']  
    for grup_nm in group_data:
        if grup_nm['agplantname'] != 'Incomer':
            Ws_1.row(row).height_mismatch  = True
            Ws_1.row(row).height = 500
            Ws_1.write(row, col, serial_count, style3)
            Ws_1.write(row, col+1, Plant_Name, style3)
            Ws_1.write(row, col+2, grup_nm['agplantname'], style3)
            grp_list.append(grup_nm['agplantname'])
            for column_data in column_nm:
                column_value = Masterdatatable.objects.filter(mtdate = yesterday_date
                                                    ,mtgrpname = grup_nm['agplantname']).aggregate(add(column_data))
                if col == 1:
                    Ws_1.col(col+3).width = 3700
                else:
                    Ws_1.col(col+3).width = 2000
                Ws_1.write(row, col+3, column_value[column_data + '__sum'], style3)
                col += 1
            row += 1; col = 1; serial_count += 1
    row = row; col = 1
    Ws_1.row(row).height_mismatch  = True
    Ws_1.row(row).height = 500
    Ws_1.write_merge(row, row, col, col+2, "Total", styletotal1)
    for column_data in column_nm:
        total_value = Masterdatatable.objects.filter(mtdate = yesterday_date
                                                ,mtgrpname__in = grp_list).aggregate(add(column_data))
        Ws_1.write(row, col+3, total_value[column_data + '__sum'], styletotal2)
        col += 1
    retrun_value = report(work_book, machinename_data)
    _datetime = datetime.now()
    datetime_str = _datetime.strftime("%d-%m-%Y-%H-%M-%S")

    # only_datetime_str = _datetime.strftime("%d-%m-%Y")

    savepath = os.path.join(BASE_DIR,'Report','Energy_Hourly'+datetime_str+'.xls')
    # savepath = os.path.join(BASE_DIR,'Report','Energy_Hourly_'+only_datetime_str+'.xls')
    work_book.save(savepath)
    # return savepath
    return HttpResponse ("Report Generated")

def report(work_book, machinename_data):
    # print("report function is generated")
    for machine in machinename_data:
        # print(machine['amMachinename'])
        work_sheet = work_book.add_sheet(machine['amMachinename'], cell_overwrite_ok=True)
        work_sheet.show_grid = False
        style  = xlwt.XFStyle()
        style1 = xlwt.XFStyle()
        style2 = xlwt.XFStyle()
        style3 = xlwt.XFStyle()
        style_bold = xlwt.XFStyle()
        style_header = xlwt.XFStyle()
        style_bold2 = xlwt.XFStyle()
        #set alignment
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap      = 1
        style.alignment     = alignment
        style1.alignment    = alignment
        style2.alignment    = alignment
        style3.alignment    = alignment
        style_bold2.alignment = alignment
        ######
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap = 1
        style_bold.alignment = alignment
        style_header.alignment = alignment
        #Set Border
        border          = xlwt.Borders()    
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style2.borders  = border
        style3.borders  = border
        ######
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style_bold.borders = border
        style_header.borders = border
        style_bold2.borders  = border
        #pattern
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
        style.pattern = pattern

        pattern1 = xlwt.Pattern()
        pattern1.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern1.pattern_fore_colour = xlwt.Style.colour_map['custom_colour']
        style_bold.pattern = pattern1

        pattern2 = xlwt.Pattern()
        pattern2.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern2.pattern_fore_colour = xlwt.Style.colour_map['tan']
        style_bold2.pattern = pattern2

        #Set Font Color
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['red']
        font.name = 'calibri'
        font.bold = True
        font.height = 250
        style3.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'calibri'
        font.bold = False
        font.height = 200
        style.font = font
        style1.font = font
        style2.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'calibri'
        font.bold = True
        font.height = 200
        style_bold.font = font 
        style_bold2.font = font
        #################### Hourly Reports ###################
        shift_data = (ShiftTimings.objects.values().last())['shift1start']
        starttime = (datetime.strptime(str(shift_data), "%H:%M:%S")).hour
        excel_map = []; hrsArray = []
        
        today = datetime.now().date()
        yesterday = today - timedelta(days = 1)
        
        # today = '2024-11-14'
        # yesterday = '2024-11-13'

        for i in range(starttime,(24+starttime)):
            if(i>23):
                start = ('0'+str(i-24)+':00:00')
                end = ('0'+str(i-24)+':59:59')
                dict = {"date":today, "fromtime":start, "totime":end}
                # print(dict)
                hrsArray.append(dict)
            else:
                if i<= 9 :
                    start = ('0'+str(i)+':00:00')
                    end = ('0'+str(i)+':59:59')
                else:
                    start = (str(i)+':00:00')
                    end = (str(i)+':59:59')
                dict = {"date":yesterday, "fromtime":start, "totime":end}
                # print(dict)
                hrsArray.append(dict)
        #--------------------------------------------------------------------------------
        def hourly_report():     
            # print('Hourly Report')       
            ############################# Energy Value ###################
            # print(shift_datetime)
            ## Get the Energy Hurs & Value (24 hrs format)
            date_energyhurs = ((datetime.today()) - timedelta(days = 1)).date()
            # date_energyhurs = '2023-12-28'
            energy = []; cummulative_energy = 0
            for i in range(1,25):
                hour = 'mth'+str(i)+'ec'
                try:
                   hourdata = (round(Masterdatatable.objects.filter(mtdate = date_energyhurs, mtmtrname = machine['amMachinename']).values(hour)[0][hour], 1))
                   cummulative_energy = cummulative_energy + hourdata
                except:
                   hourdata = 0
                   cummulative_energy = cummulative_energy + hourdata
                energy.append(hourdata)
            # print(energy)
            ############################## HOURLY PRODUCTION REPORT ####################################
            # print(shift_start, shift_end)
            for col_width in range(1, 13+1):
                work_sheet.col(col_width).width = 5300
            for row_width in range(1, 6):
                work_sheet.row(row_width).height_mismatch  = True
                work_sheet.row(row_width).height = 380
            r=1
            c=1
            work_sheet.write_merge(r, r+1, c, c+9,('HOURLY PRODUCTION REPORT-INJECTION MOULDING-IMG'),style3)
            
            r=3
            c=1
            work_sheet.write(r,  c,  None ,style_bold)

            r=4
            c=1
            work_sheet.write_merge(r, r+1, c, c,'MOLD NAME', style_bold)

            r=3
            c=2
            Date = ((datetime.today()).date() - timedelta(days = 1))
            work_sheet.write_merge(r, r, c, c+1, ('DATE -   '+ str(Date)),style_bold)

            r=4
            c=2
            work_sheet.write_merge(r, r, c, c+1, 'TIME',style_bold)

            r=5
            c=2
            work_sheet.write(r, c, 'FROM', style_bold)
            work_sheet.write(r, c+1, 'TO', style_bold)
            # work_sheet.write(r-2, c+2, None, style_bold)
            #########################
            # work_sheet.write_merge(r-1, r, c+2, c+2, 'CYCLE TIME ACTUAL (Minutes)', style_bold)

            # style_bold_with_wrap = xlwt.XFStyle()

            # # Copy the existing style_bold properties
            # style_bold_with_wrap.alignment = style_bold.alignment
            # style_bold_with_wrap.font = style_bold.font
            # style_bold_with_wrap.borders = style_bold.borders

            # # Enable text wrapping
            # alignment_with_wrap = xlwt.Alignment()
            # alignment_with_wrap.horz = xlwt.Alignment.HORZ_CENTER
            # alignment_with_wrap.vert = xlwt.Alignment.VERT_CENTER
            # alignment_with_wrap.wrap = 1  # Enable text wrap
            # style_bold_with_wrap.alignment = alignment_with_wrap

            work_sheet.write_merge(r-1, r, c+2, c+2, ('PRODUCTION HOURS'),style_bold)
            # work_sheet.write_merge(r-1, r, c+2, c+2, ('PRODUCTION HOURS'),style_bold_with_wrap)
            #############################
            work_sheet.write_merge(r-2, r-2, c+2, c+5, 'SHIFT -' + 'A B C', style_bold)
            work_sheet.write_merge(r-1, r, c+3, c+3, 'ENERGY CONSUMPTION (kWh)', style_bold)
            work_sheet.write_merge(r-1, r, c+4, c+4, 'TOTAL SHOTS', style_bold)
            # work_sheet.write(r-2, c+2, None, style_bold)
            work_sheet.col(c+5).width = 3000
            work_sheet.write_merge(r-1, r, c+5, c+5, 'GOOD PATRS', style_bold)
            work_sheet.write_merge(r-2, r-2, c+6, c+7,  None, style_bold)
            work_sheet.write_merge(r-1, r, c+6, c+6, 'TOTAL PART WEIGHT (Grams)', style_bold)   # ENERGY CONSUMPTION (kWh)
            work_sheet.write_merge(r-1, r, c+7, c+7, 'SEC', style_bold)
            work_sheet.write(r-2, c+8, None, style_bold)
            work_sheet.col(c+8).width = 4500
            work_sheet.write_merge(r-1, r, c+8, c+8, 'MACHINE STOP REASON', style_bold)
            ##
            # Get the from time, to time, total parts, good parts, part weight, mould name, stop reason
            reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
            goodpart_kg = []; reason_list = []; machine_stopreason = '-'
            energyindex = 0; totalweight = 0; cummulative_runhour = 0; rejection_count = 0; cummulative_shots = 0; cummulative_goodparts = 0; cummulative_energykwh = 0; cummulative_weight = 0; cummulative_sec = 0; cummulative_time = 0
            for hour in hrsArray:
                mould_name = [];mould_list=[]; part_list=[]; reason_list = []; sec_list = []; sec = 0; totalshots_list = []; goodpart_list = []; runhour = 0; runhour_list = []

                date = hour['date']
                fromTime = hour['fromtime']
                toTime = hour['totime']

                all_dashboard_value = ProductionTable.objects.filter(
                    date=date,
                    time__range=(fromTime, toTime),
                    Machinename = machine['amMachinename'],
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values().order_by('id')


                seen = set()
                distinctMould = [p['Mouldname_id'] for p in all_dashboard_value if not (p['Mouldname_id'] in seen or seen.add(p['Mouldname_id']))]

                if distinctMould !=  []:
                    for mould_id in distinctMould:

                        mould_instance = Mouldmodel.objects.get(id=mould_id)

                        try:
                            mouldname = mould_instance.Mouldname
                        except:
                            mouldname = '-'

                        weight = mould_instance.weight

                        cummulative_weight = weight + cummulative_weight

                        # mould_list.append(mouldname)

                        part_list.append(str(int(weight)))

                        # print(weight)

                        mould_data = [p for p in all_dashboard_value if
                                       p['Mouldname_id'] == mould_id]
                        
                        if mould_data:

                            totalshots_value = len(mould_data)
                            cummulative_shots = totalshots_value + cummulative_shots
                            totalshots_list.append(str(totalshots_value))

                            first_record = mould_data[0]
                            last_record = mould_data[-1]

                            mould_start_time = first_record['time'] # Start time
                            mould_end_time = last_record['time']  # End time
                            
                            first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                            last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                            first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                            last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                            #############################
                            basetime = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600

                            reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']

                            saw = breakdown.objects.filter(date = str(date), Machinename = machine['amMachinename'], 
                                                    time__range = [first_time, last_time], Mouldname_id=mould_id).values('date', 'time', 'Mouldname_id', 'MachineState', 'primaryreason').order_by('id')

                            total_idle_time = 0  # Initialize the sum

                            last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                            # Iterate through the breakdown data and calculate time differences
                            for last, bd in zip(saw, saw[1:]):
                                # If `MachineState = 0` for last, store its time but don't calculate yet
                                if last['MachineState'] == 0:
                                    # Capture the first occurrence of MachineState = 0
                                    if last_time_str is None:
                                        last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                                
                                # Only calculate the time difference when transitioning from 0 to 1
                                if last_time_str and bd['MachineState'] == 1:
                                    # Combine date and time for `bd`
                                    bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                                    # Parse the combined date and time
                                    last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                                    bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                                    # Calculate the time difference in seconds
                                    time_difference = (bd_time - last_time).total_seconds()

                                    if last['primaryreason'] == bd['primaryreason']:

                                        if last['primaryreason'] != 0:
                                            reason_list = reasons[last['primaryreason']]
                                        else:
                                            reason_list = '-'

                                    else:
                                        reason_list = '-'

                                    # Print the intermediate values
                                    print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                                    # Accumulate the total time in seconds
                                    total_idle_time += time_difference

                                    # Reset last_time_str to None after calculating for this transition
                                    last_time_str = None
                            # print("total_idle_time:", total_idle_time)
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            # total_runhour += basetime - total_idle_time_hours    
                                                    
                            # print("Machinename:", machine['amMachinename'], "mould_id:", mould_id, "mouldname:", mouldname, "total_idle_time_hours:", total_idle_time_hours, )

                            single_total_runhour = basetime - total_idle_time_hours   
                            single_total_seconds = int(single_total_runhour * 3600)
                            single_time_formatted = str(timedelta(seconds=single_total_seconds))

                            cummulative_time += single_total_seconds

                            try:
                                Rejection_CS =  first_record['RejectionParts']

                                # Rejection_CountStart = badpart.objects.filter(date = str(shift_fromdate_rejection) , Machinename = machine['amMachinename'], 
                                #                                             time__gte = shift_from_rejection, time__lte = shift_to_rejection,
                                #                                             # partcount__gt = 0, 
                                #                                             Mouldname_id = id).values('date', 'time', 'partcount', 'Mouldname_id').order_by('id')
                                # Rejection_CS =  Rejection_CountStart.last()['partcount']

                            except:
                                Rejection_CS = 0
                            try:
                                Rejetion_CE = last_record['RejectionParts']

                                # Rejection_COUNTSTART = badpart.objects.filter(date = str(db_date) , Machinename = machine['amMachinename'], 
                                #                                             time__gte = str_shift_from, time__lte = str_shift_to,
                                #                                             # partcount__gt = 0, 
                                #                                             Mouldname_id = id).values('date', 'time', 'partcount', 'Mouldname_id').order_by('id')
                                # Rejetion_CE = Rejection_COUNTSTART.last()['partcount']

                            except:
                                Rejetion_CE = 0

                            # #print(Rejection_CS, Rejetion_CE)

                            rejection_count = abs(Rejetion_CE - Rejection_CS)

                            goodparts_value = abs(totalshots_value - rejection_count)
                            cummulative_goodparts = goodparts_value + cummulative_goodparts
                            goodpart_list.append(str(goodparts_value))

                            totalweight = totalshots_value * weight

                            ########################################################
                            ##############################################
                            parent_dir = "Machines"
                            sub_dir1 = machine['amMachinename']
                            sub_dir2 = date               #date  #2024-11-14

                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        output_data = 0.0  # Initialize the sum

                                        # first_time = datetime.strptime("17:00:00", "%H:%M:%S").time()
                                        # last_time = datetime.strptime("18:00:00", "%H:%M:%S").time()

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if first_time <= time_obj <= last_time:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")
                                        # Format the output data in the desired list format
                                        
                                        # if output_data:
                                        if output_data > 0:
                                            output_data_str = round(output_data,2)
                                        else:
                                            output_data_str = 0   # "No data in time range"
                                except FileNotFoundError:
                                    output_data_str = 0  # "File not found"
                            else:
                                output_data_str = 0   # "Path does not exist"
                            #######################################################

                            try:
                                energy_index = output_data_str     #energy[energyindex]
                            except:
                                energy_index = 0

                            cummulative_energykwh = energy_index + cummulative_energykwh

                            # try:
                            #     sec_value = round(energy[energyindex]/(totalweight/1000), 2)
                            # except:
                            #     sec_value = 0

                            try:
                                sec_value = round(float(energy_index)/(float(totalweight)/1000), 2)  #energy[energyindex]
                            except:
                                sec_value = 0

                            sec_list.append(str(sec_value))

                            cummulative_sec = sec_value + cummulative_sec

                            if reason_list:
                                machine_stopreason = reason_list
                            else:
                                machine_stopreason = '-'

                            excel_map.append({"mould_name":mouldname, "from_time":mould_start_time,"to_time":mould_end_time, "Run_Hour":single_time_formatted, "total_shots":(totalshots_value), "Goodparts":(goodparts_value),  "part_weight":(weight), "energy":energy_index, "SEC":(sec_value), "stop_reason": machine_stopreason})

                        else:
                            mouldname = '-'
                        
                        mould_name = ', '.join(mould_list)
                        part_weight = ', '.join(part_list)
                        # if len(part_weight) <= 5:
                        #     part_weight = int(part_weight)
                        sec = ', '.join(sec_list)
                        # if len(sec) <= 5:
                        #     part_weight = int(sec)
                        totalshots = ', '.join(totalshots_list)
                        # if len(totalshots) <= 5:
                        #     part_weight = int(totalshots)
                        goodparts = ', '.join(goodpart_list)
                        # if len(goodparts) <= 5:
                        #     part_weight = int(goodparts)
                        runhour = ', '.join(runhour_list)
                        # if len(runhour) <= 5:
                        #     part_weight = int(runhour)

                        # except:
                        #     totalshots = 0
                        #     goodparts = 0
                        #     sec = 0
                        #     mould_name = '-'
                        #     part_weight = 0
                        #     totalweight = 0

                else:
                    totalshots = 0
                    goodparts = 0
                    sec = 0
                    mould_name = '-'
                    part_weight = 0
                    totalweight = 0
                    runhour = 0

                # print("runhour :", runhour)
                # print(energy[energyindex])
                
                # print(date, fromTime, toTime, machine['amMachinename'])
                
                # excel_map.append({"mould_name":mouldname, "from_time":mould_start_time,"to_time":mould_end_time, "Run_Hour":single_time_formatted, "total_shots":(totalshots_value), "Goodparts":(goodparts),  "part_weight":(part_weight), "energy":energy_index, "SEC":(sec), "stop_reason": machine_stopreason})
                energyindex +=1
                cummulative_runhour = 0; rejection_count = 0
            ## Mapping Excel Sheet
            # print("excel map")
            row = 6; col = 0
            for data_excel in excel_map:
                work_sheet.row(row).height_mismatch  = True
                work_sheet.row(row).height = 370
                work_sheet.write(row, col+1, data_excel['mould_name'], style1) 
                work_sheet.write(row, col+2, data_excel['from_time'], style1)
                work_sheet.write(row, col+3, data_excel['to_time'], style1)
                work_sheet.write(row, col+4, data_excel['Run_Hour'], style1)
                work_sheet.write(row, col+6, data_excel['total_shots'], style1)
                work_sheet.write(row, col+7, data_excel['Goodparts'], style1)
                work_sheet.write(row, col+8, data_excel['part_weight'], style1)
                work_sheet.write(row, col+5, data_excel['energy'], style1)
                work_sheet.write(row, col+9, data_excel['SEC'], style1)
                work_sheet.write(row, col+10, data_excel['stop_reason'], style1)
                # cummulative_shots = data_excel['total_shots'] + cummulative_shots ; cummulative_goodparts = data_excel['Goodparts'] + cummulative_goodparts
                row += 1
            col =  1
            work_sheet.row(row).height_mismatch  = True
            work_sheet.row(row).height = 370
            work_sheet.write_merge(row, row, col, col+2, 'Total', style_bold2) #col+3
            work_sheet.write(row, col+3, str(timedelta(seconds=cummulative_time)), style_bold2)
            work_sheet.write(row, col+5, cummulative_shots, style_bold2)
            work_sheet.write(row, col+6, cummulative_goodparts, style_bold2)
            work_sheet.write(row, col+7, cummulative_weight, style_bold2)
            work_sheet.write(row, col+4, cummulative_energykwh, style_bold2)
            work_sheet.write(row, col+8, cummulative_sec, style_bold2)
            work_sheet.write(row, col+9, None, style_bold2)
        hourly_report()
        # break
    return "report created"

    # savepath = os.path.join(BASE_DIR,'Report','ProductionReport.xls')
    # work_book.save(savepath)    
    # return savepath  

# @periodic_task(run_every=crontab(hour=6, minute=5))
# @csrf_exempt
def sendmail():
    print("Report generating")
    savepath = enryhrs()
    # print(savepath)
    # 'Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Mohankumar.Chinnasamy@motherson.com;praveen.srinivasan@motherson.com;Gokulraj.Rajasekaran@motherson.com;Gokul.Annadurai@motherson.com;u1ppc@int.motherson.com'
    tomail='Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Mohankumar.Chinnasamy@motherson.com;praveen.srinivasan@motherson.com;Gokulraj.Rajasekaran@motherson.com;Gokul.Annadurai@motherson.com;u1ppc@int.motherson.com;Sivakumar.Radhakrishnan@motherson.com;Elayaraja.Muthukrishnan@motherson.com;jagadeesang@int.motherson.com;imgu1@int.motherson.com;processengineeringu1.matechennai@motherson.com'
    sub='Houlry Wise and Rejection report for R-Connect'
    message = '''Dear Team, <br> 
                    Please find the Hourlywise and Rejection report for MATE UNIT - 1. 
                    <br>
                    <br>
                Regards, <br>
                R-Connect Team. 
                <br>
                <br> 
                Note: This is an system generated mail.'''
    msg = MIMEMultipart('mixed')
    msg['Subject'] = sub
    msg['From'] = "R-Connect <no-reply@rconnect.com>"
    msg['To'] = tomail
    part2 = MIMEText(message, 'html')
    msg.attach(part2)
    part = MIMEBase('application','octet-stream')
    part.set_payload(open(savepath, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="R-ConnectReport.xls"')
    msg.attach(part)
    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
    smtpObj.sendmail('R-Connect <no-reply@rconnect.com>',tomail.split(';'),msg.as_string())
    smtpObj.quit()
    print('Mail send successfully')
    print("Mail Sent to ",tomail)
    return HttpResponse (" Hourly Wise and Rejection Report is Generated")
