from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import pandas as pd
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
from datetime import datetime, timedelta
from meter_data.models import Masterdatatable
from  functools import reduce
from analysis.views import machineArray
from django.db.models import Q, Sum, Max, Min, Count
from decimal import Decimal, InvalidOperation

########################################### SEC CHART WISE AND TABLE WISE DATA ##############################################

# @csrf_exempt
# def sec_value(request):
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']
#         request_data = json.loads(request.body)
#         start_date  = request_data['start']
#         end_date    = request_data['end']
#         machine_name = request_data['Mname']
#         mouldname   = request_data['mldname']

#         ############################################

#         date_range = pd.date_range(start = start_date, end = end_date)

#         pre_startdate_str = datetime.strptime(start_date, "%Y-%m-%d") - timedelta(days=1)

#         nex_enddate_str = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
#         all_production_data = ProductionTable.objects.filter(
#                     Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
#                     Plantname=Plantname,
#                     Machinename=machine_name,
#                     ProductionCountActual__gte = 1,
#                     MachineState=1
#                 ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')
        
#         all_hourdata = Masterdatatable.objects.filter(
#             Q(mtdate__gte=pre_startdate_str, mtdate__lte=nex_enddate_str),
#             mtmtrname = machine_name).values('mtdate', 'mtmtrname', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec', 'mth5ec',
#             'mth6ec', 'mth7ec', 'mth8ec', 'mth9ec', 'mth10ec', 'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec',
#             'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec',
#             'mth21ec', 'mth22ec', 'mth23ec', 'mth24ec').order_by('id')
#         ############################################

#         shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start').last()['shift1start'].hour

#         list_hrs = [[str(shift_starttime), '24'],['0', str(shift_starttime)]]

#         mould_management = Mouldmodel.objects.get(Mouldname = mouldname)
#         weight = mould_management.weight
#         mouldid = mould_management.id

#         average_total = 0

#         sec_value = []; sec_hrs = []; sec_table = []

#         time_range = None; next_date = None; next_range = None

#         for date in date_range:
#             if str(date.date()) == start_date:
#                 time_range = list_hrs[0]
#                 next_range = list_hrs[1]
#             elif str(date.date()) == end_date:
#                 time_range = list_hrs[0]
#             else:
#                 time_range = list_hrs[0]
#                 next_range = list_hrs[1]
#             if time_range != None:
#                 for i in range(int(time_range[0]), int(time_range[1])):
#                     hour = 'mth'+str(i - 5)+'ec'
#                     try:
#                         hourdata = round(
#                                 next((r[hour] for r in all_hourdata if 
#                                     r['mtmtrname'] == machine_name and 
#                                     r['mtdate'] == date.date()), 0), 1
#                             )
                                          
#                     except:
#                       hourdata = 0

#                     print("hourdata:", hourdata)

#                     if i in range(0, 10):
#                        time_str = ('0'+str(i)+':00:00', '0'+str(i)+':59:59')
#                     else:
#                        time_str = (str(i)+':00:00', str(i)+':59:59')

#                     startdate_str = date.strftime("%Y-%m-%d")

#                     Product_Count = [p for p in all_production_data if
#                                     p['Machinename'] == machine_name and
#                                     p['Mouldname_id'] == mouldid and
#                                     p['date'] == startdate_str and
#                                     p['time'] >= time_str[0] and p['time'] <= time_str[1]]
                    
#                     production_data = len(Product_Count) * weight
                    
#                     print("production_data:", production_data)

#                     try:
#                       SEC = round(hourdata/(production_data/1000), 2)
#                     except:
#                        SEC = 0

#                     sec_value.append(float(SEC))
#                     sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
#                     sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})

#             if next_range != None:
#                for i in range(int(next_range[0]), int(next_range[1])):

#                   hour = 'mth'+str(19 + i)+'ec'
#                   try:
#                     #  hourdata = round(
#                     #     next((r[hour] for r in all_hourdata if 
#                     #           r['mtmtrname'] == machine_name and 
#                     #           r['mtdate'] == date.date() + timedelta(days=1)), 0), 1
#                     # )
#                      hourdata = round(
#                                 next((r[hour] for r in all_hourdata if 
#                                     r['mtmtrname'] == machine_name and 
#                                     r['mtdate'] == date.date()), 0), 1
#                             )
#                   except:
#                      hourdata = 0

#                   dayone = date + timedelta(days=1)
#                   startdate_str = dayone.strftime("%Y-%m-%d")
#                   Product_Count = [p for p in all_production_data if
#                                      p['Machinename'] == machine_name and
#                                      p['Mouldname_id'] == mouldid and
#                                      p['date'] == startdate_str and
#                                      p['time'] >= f'{i:02}:00:00' and p['time'] <= f'{i:02}:59:59'] 

#                   production_data = len(Product_Count) * weight
                  
#                   print(hourdata,production_data)
                  
#                   try:
#                      SEC = round(hourdata/(production_data/1000), 2)
#                   except:
#                      SEC = 0
#                   sec_value.append(float(SEC))
#                   sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
#                   sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})
#             next_date = None; next_range = None; time_range = None
#         re = reduce(lambda x,y:x+y,sec_value)
#         average_total = round(re/len(sec_hrs), 2)
#         return JsonResponse ({"average_value": average_total, "sec_date_hour":sec_hrs, "sec_value":sec_value , "sec_table":sec_table}, safe = False)

###################################################################################################################################################



# @csrf_exempt
# def sec_value(request):
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']
#         request_data = json.loads(request.body)
#         start_date  = request_data['start']
#         end_date    = request_data['end']
#         machine_name = request_data['Mname']
#         mouldname   = request_data['mldname']

#         ############################################

#         mould_management = Mouldmodel.objects.get(Mouldname = mouldname)
#         weight = mould_management.weight
#         mouldid = mould_management.id

#         date_range = pd.date_range(start = start_date, end = end_date)

#         pre_startdate_str = datetime.strptime(start_date, "%Y-%m-%d") - timedelta(days=1)

#         nex_enddate_str = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        
#         all_production_data = ProductionTable.objects.filter(
#                     Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
#                     Plantname=Plantname,
#                     Machinename=machine_name,
#                     ProductionCountActual__gte = 1,
#                     Mouldname_id = mouldid,
#                     MachineState=1
#                 ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')
        
#         all_hourdata = Masterdatatable.objects.filter(
#             Q(mtdate__gte=pre_startdate_str, mtdate__lte=nex_enddate_str),
#             mtmtrname = machine_name).values('mtdate', 'mtmtrname', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec', 'mth5ec',
#             'mth6ec', 'mth7ec', 'mth8ec', 'mth9ec', 'mth10ec', 'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec',
#             'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec',
#             'mth21ec', 'mth22ec', 'mth23ec', 'mth24ec').order_by('id')
#         ############################################

#         shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start').last()['shift1start'].hour

#         list_hrs = [[str(shift_starttime), '24'],['0', str(shift_starttime)]]

#         average_total = 0

#         sec_value = []; sec_hrs = []; sec_table = []

#         time_range = None; next_date = None; next_range = None

#         for date in date_range:
#             if str(date.date()) == start_date:
#                 time_range = list_hrs[0]
#                 next_range = list_hrs[1]
#             elif str(date.date()) == end_date:
#                 time_range = list_hrs[0]
#             else:
#                 time_range = list_hrs[0]
#                 next_range = list_hrs[1]
#             if time_range != None:
#                 for i in range(int(time_range[0]), int(time_range[1])):
#                     hour = 'mth'+str(i - 5)+'ec'
#                     try:
#                         hourdata = round(
#                                 next((r[hour] for r in all_hourdata if 
#                                     r['mtdate'] == date.date()), 0), 1
#                             )
                                          
#                     except:
#                       hourdata = 0

#                     print("hourdata:", hourdata)

#                     if i in range(0, 10):
#                        time_str = ('0'+str(i)+':00:00', '0'+str(i)+':59:59')
#                     else:
#                        time_str = (str(i)+':00:00', str(i)+':59:59')

#                     startdate_str = date.strftime("%Y-%m-%d")

#                     Product_Count = [p for p in all_production_data if
#                                     p['date'] == startdate_str and
#                                     p['time'] >= time_str[0] and p['time'] <= time_str[1]]
                    
#                     production_data = len(Product_Count) * weight
                    
#                     print("production_data:", production_data)

#                     try:
#                       SEC = round(hourdata/(production_data/1000), 2)
#                     except:
#                        SEC = 0

#                     sec_value.append(float(SEC))
#                     sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
#                     sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})

#             if next_range != None:
#                for i in range(int(next_range[0]), int(next_range[1])):

#                   hour = 'mth'+str(19 + i)+'ec'
#                   try:
#                     #  hourdata = round(
#                     #     next((r[hour] for r in all_hourdata if 
#                     #           r['mtmtrname'] == machine_name and 
#                     #           r['mtdate'] == date.date() + timedelta(days=1)), 0), 1
#                     # )
#                      hourdata = round(
#                                 next((r[hour] for r in all_hourdata if 
#                                     r['mtdate'] == date.date()), 0), 1
#                             )
#                   except:
#                      hourdata = 0

#                   # increasing one day
#                   dayone = date + timedelta(days=1)
#                   startdate_str = dayone.strftime("%Y-%m-%d")

#                   Product_Count = [p for p in all_production_data if
#                                      p['date'] == startdate_str and
#                                      p['time'] >= f'{i:02}:00:00' and p['time'] <= f'{i:02}:59:59'] 

#                   production_data = len(Product_Count) * weight
                  
#                   print(hourdata,production_data)
                  
#                   try:
#                      SEC = round(hourdata/(production_data/1000), 2)
#                   except:
#                      SEC = 0
#                   sec_value.append(float(SEC))
#                   sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
#                   sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})
#             next_date = None; next_range = None; time_range = None
#         re = reduce(lambda x,y:x+y,sec_value)
#         average_total = round(re/len(sec_hrs), 2)
#         return JsonResponse ({"average_value": average_total, "sec_date_hour":sec_hrs, "sec_value":sec_value , "sec_table":sec_table}, safe = False)

#############################################


@csrf_exempt
def sec_value(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        request_data = json.loads(request.body)
        start_date  = request_data['start']
        end_date    = request_data['end']
        machine_name = request_data['Mname']
        mouldname   = request_data['mldname']

        ############################################

        mould_management = Mouldmodel.objects.get(Mouldname = mouldname)
        weight = mould_management.weight
        mouldid = mould_management.id

        date_range = pd.date_range(start = start_date, end = end_date)

        #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # Convert the date strings to datetime objects
        startdate_dt = datetime.strptime(start_date, "%Y-%m-%d")
        enddate_dt = datetime.strptime(end_date, "%Y-%m-%d")

        # Calculate the total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        nex_enddate_dt = enddate_dt + timedelta(days=1)

        seconddate_dt = startdate_dt + timedelta(days=1)

        # Convert to string only for querying
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        enddate_str = enddate_dt.strftime('%Y-%m-%d')
        seconddate_str = seconddate_dt.strftime('%Y-%m-%d')
        #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        ###########
        firstday_start = '06:00:00'
        firstday_end = '23:59:59'
        secondday_start = '00:00:00'
        secondday_end = '05:59:59'
        ###########
        
        all_production_data = ProductionTable.objects.filter(
                            Q(date=startdate_str, time__gte=firstday_start) |
                            Q(date__range=[seconddate_str, enddate_str]) |
                            Q(date=nex_enddate_str, time__lte=secondday_end),
                            Plantname=Plantname,
                            Machinename=machine_name,
                            ProductionCountActual__gt=0,
                            Mouldname_id = mouldid,
                            MachineState=1
                        ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')
        
        all_hourdata = Masterdatatable.objects.filter(
            Q(mtdate__gte=startdate_str, mtdate__lte=enddate_str),
            mtmtrname = machine_name).values('mtdate', 'mtmtrname', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec', 'mth5ec',
            'mth6ec', 'mth7ec', 'mth8ec', 'mth9ec', 'mth10ec', 'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec',
            'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec',
            'mth21ec', 'mth22ec', 'mth23ec', 'mth24ec').order_by('id')
        ############################################

        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start').last()['shift1start'].hour

        list_hrs = [[str(shift_starttime), '24'],['0', str(shift_starttime)]]

        average_total = 0

        sec_value = []; sec_hrs = []; sec_table = []

        time_range = None; next_date = None; next_range = None

        for date in date_range:
            if str(date.date()) == start_date:
                time_range = list_hrs[0]
                next_range = list_hrs[1]
            elif str(date.date()) == end_date:
                time_range = list_hrs[0]
            else:
                time_range = list_hrs[0]
                next_range = list_hrs[1]
            if time_range != None:
                for i in range(int(time_range[0]), int(time_range[1])):
                    hour = 'mth'+str(i - 5)+'ec'
                    try:
                        hourdata = round(
                                next((r[hour] for r in all_hourdata if 
                                    r['mtdate'] == date.date()), 0), 1
                            )
                                          
                    except:
                      hourdata = 0

                    print("hourdata:", hourdata)

                    if i in range(0, 10):
                       time_str = ('0'+str(i)+':00:00', '0'+str(i)+':59:59')
                    else:
                       time_str = (str(i)+':00:00', str(i)+':59:59')

                    startdate_str = date.strftime("%Y-%m-%d")

                    Product_Count = [p for p in all_production_data if
                                    p['date'] == startdate_str and
                                    p['time'] >= time_str[0] and p['time'] <= time_str[1]]
                    
                    production_data = len(Product_Count) * weight
                    
                    print("production_data:", production_data)

                    try:
                      SEC = round(hourdata/(production_data/1000), 2)
                    except:
                       SEC = 0

                    sec_value.append(float(SEC))
                    sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
                    sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})

            if next_range != None:
               for i in range(int(next_range[0]), int(next_range[1])):

                  hour = 'mth'+str(19 + i)+'ec'
                  try:
                     hourdata = round(
                                next((r[hour] for r in all_hourdata if 
                                    r['mtdate'] == date.date()), 0), 1
                            )
                  except:
                     hourdata = 0

                  # increasing one day
                  dayone = date + timedelta(days=1)
                  startdate_str = dayone.strftime("%Y-%m-%d")

                  Product_Count = [p for p in all_production_data if
                                     p['date'] == startdate_str and
                                     p['time'] >= f'{i:02}:00:00' and p['time'] <= f'{i:02}:59:59'] 

                  production_data = len(Product_Count) * weight
                  
                  print(hourdata,production_data)
                  
                  try:
                     SEC = round(hourdata/(production_data/1000), 2)
                  except:
                     SEC = 0
                  sec_value.append(float(SEC))
                  sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
                  sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})
            next_date = None; next_range = None; time_range = None
        re = reduce(lambda x,y:x+y,sec_value)
        average_total = round(re/len(sec_hrs), 2)
        return JsonResponse ({"average_value": average_total, "sec_date_hour":sec_hrs, "sec_value":sec_value , "sec_table":sec_table}, safe = False)
    
############################################

# OPTIMIZE CODE ONGOING....