from meter_data.models import Masterdatatable
from django.http.response import JsonResponse
from datetime import datetime, timedelta
from django.views.decorators.csrf import csrf_exempt
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
import json
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from usermanagement.models import AddUser
from timeline.time_line import shiftStarttime

# Write Your Code Buddy!
@csrf_exempt
def mould_name(request):
    if request.method == 'POST':
        client_data = json.loads(request.body)
        inputDate = client_data['date']
        nextdate  = str((datetime.strptime(inputDate, "%Y-%m-%d") + timedelta(days = 1)).date())
        Plantname = request.GET['Plantname']
        Prd_strtime = shiftStarttime(Plantname)
        machinename = client_data['machinename']
        # print(inputDate, nextdate, machinename)
        Mould_id = ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Machinename = machinename) |
                                       Q (date = nextdate, time__lte = Prd_strtime, Machinename = machinename)).distinct('Mouldname_id').values('Mouldname_id')
        # print(Mould_Name)
        Mould_Name = [ Mouldmodel.objects.get(id = x['Mouldname_id']).Mouldname for x in Mould_id]
        return JsonResponse(Mould_Name, safe = False)
        
@csrf_exempt
def powerutilization(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        plantname = request.GET['Plantname']
        # print(data)
        date = datetime.strptime(data['date'], "%Y-%m-%d")
        machinename = data['machinename']
        mouldname = data['mouldname']
        Mould_id = Mouldmodel.objects.get(Mouldname = mouldname).id
        # print(Mould_id)
        date_energyhurs = date
        shift_data = (ShiftTimings.objects.values().last())['shift1start']
        starttime = (datetime.strptime(str(shift_data), "%H:%M:%S")).hour

        print("starttime:", starttime)
        print("endtime:", (24+starttime))

        hrsArray = []; energy = []
        # cummulative_timelist = []; cummulative_shotlist = []
        CurrentDate = date
        NextDate = CurrentDate + timedelta(days = 1)
        # Take the Hourly Wise Data
        for i in range(starttime,(24+starttime)):
            if(i>23):
                start = ('0'+str(i-24)+':00:00')
                end = ('0'+str(i-24)+':59:59')
                dict = {"date":str(NextDate.date()), "fromtime":start, "totime":end}
                hrsArray.append(dict)
            else:
                if i<= 9 :
                    start = ('0'+str(i)+':00:00')
                    end = ('0'+str(i)+':59:59')
                else:
                    start = (str(i)+':00:00')
                    end = (str(i)+':59:59')
                dict = {"date":str(CurrentDate.date()), "fromtime":start, "totime":end}
                # print(dict)
                hrsArray.append(dict)
        # Get the data for Power Utilization Profile in Machinewise
        shots_list = []; PowerUP= []; time_list = []
        for i in range(1,25):
            hour = 'mth'+str(i)+'ec'
            try:
               hourdata = (round(Masterdatatable.objects.filter(mtdate = date_energyhurs, mtmtrname = machinename).order_by('id').values(hour)[0][hour], 1))
            except:
               hourdata = 0
            energy.append(hourdata)
        # print(energy)
        for e,h in zip(energy, hrsArray):
            # print(e, "energy")
            enrgysec = e/3600
            date = h['date'];fromTime = h['fromtime']; toTime = h['totime']
            # print(date, fromTime, toTime)
            # hint = datetime.strptime(fromTime, '%H:%M:%S').hour
            # if hint == 23:
            #     key = (str(hint) + "-"+ str(hint-23))
            # else:
            #     key = (str(hint) + "-"+ str(hint+1))
            # print(date, fromTime, toTime, machinename, Mould_id)
            runhour = ProductionTable.objects.filter(date = str(date), time__range=(fromTime, toTime), Machinename = machinename, Mouldname_id = Mould_id, Plantname = plantname).values('CycletimeActual', 'time')
            # print(runhour)
            for j in runhour:
                #print(j['CycletimeActual'])
                shots = float(round((float(j['CycletimeActual']) * float(enrgysec)), 4))
                shots_list.append(shots)
                time_list.append(j['time'])
            # cummulative_timelist.append(time_list)
            # cummulative_shotlist.append(shots_list)
            # PowerUP.append({"x":time_list, "y":shots_list})
            # shots_list = []; time_list = []
        return JsonResponse ({"labels":time_list, "values":shots_list}, safe = False)