# from celery import shared_task
from django.http import HttpResponse
import xlwt
from RConnect.settings import BASE_DIR
import os
from datetime import datetime , timedelta, date
from django.views.decorators.csrf import csrf_exempt
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from celery.schedules import crontab
# from celery.task import periodic_task
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
from celery.schedules import crontab
# from celery.task import periodic_task
from timeline.models import badpart 
from mouldmanagement.models import Mouldmodel
from timeline.models import breakdown
from meter_data.models import Masterdatatable
from  functools import reduce
from decimal import Decimal

@csrf_exempt
def report(request):
    #jai hanuman
    # print(now)
    now = datetime(2024, 11, 14, 6, 45)    #datetime(2024, 11, 13, 14, 00)
    work_book = xlwt.Workbook(encoding='utf-8')
    # machinename_data = AddMachine.objects.values('amMachinename')
    machinename_data = AddMachine.objects.order_by('amid').values('amMachinename').distinct()
    
    for machine in machinename_data:
        work_sheet = work_book.add_sheet(machine['amMachinename'], cell_overwrite_ok=True)
        print(machine['amMachinename'])
        work_sheet.show_grid = False
        style  = xlwt.XFStyle()
        style1 = xlwt.XFStyle()
        style2 = xlwt.XFStyle()
        style3 = xlwt.XFStyle()
        style_bold = xlwt.XFStyle()
        style_header = xlwt.XFStyle()
        style_bold2 = xlwt.XFStyle()
        #set alignment
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap      = 1
        style.alignment     = alignment
        style1.alignment    = alignment
        style2.alignment    = alignment
        style3.alignment    = alignment
        ######
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        style_bold.alignment = alignment
        style_header.alignment = alignment
        ######
        alignment_1       = xlwt.Alignment()
        alignment_1.horz  = xlwt.Alignment.HORZ_LEFT
        alignment_1.vert  = xlwt.Alignment.VERT_CENTER
        alignment_1.wrap      = 1
        style_bold2.alignment = alignment_1
        #Set Border
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style2.borders  = border
        style3.borders  = border
        ######
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style_bold.borders = border
        style_header.borders = border
        style_bold2.borders  = border
        #pattern
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
        style.pattern = pattern
        #Set Font Color
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['red']
        font.name = 'Times New Roman'
        font.bold = True
        font.height = 250
        style3.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'Times New Roman'
        font.bold = False
        font.height = 200
        style.font = font
        style1.font = font
        style2.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'Times New Roman'
        font.bold = True
        font.height = 200
        style_bold.font = font 
        style_bold2.font = font
        #############################  GETTING THE SHIFT_WISE DATA ############################
        shift_list = []; shift_int = []; shift_datetime = []
        # current_date = datetime.now()
        current_date = now
        previous_date = current_date - timedelta(days=1)

        # print(current_date, previous_date)

        shift_data = ShiftTimings.objects.values().last() 
        shift1start = shift_data['shift1start']; shift1end   = shift_data['shift1end'] 
        shift2start = shift_data['shift2start']; shift2end   = shift_data['shift2end']
        shift3start = shift_data['shift3start']; shift3end   = shift_data['shift3end'] 
        ### STORED THE SHIFT DATETIME.TIME DATA'S INTO THE SHIFT_LIST
        shift_list.append(shift1start); shift_list.append(shift1end)
        shift_list.append(shift2start); shift_list.append(shift2end)
        shift_list.append(shift3start); shift_list.append(shift3end)
        ### CONVERT THE DATETIME.TIME TO INTEGER VALUE
        for string in shift_list:
            dttme_obj = datetime.strptime(str(string), "%H:%M:%S")
            shift_int.append(int(dttme_obj.hour))
        def Dummy():
            i = 0
            while i<len(shift_list):
                if shift_int[i] <= shift_int[i+1]:
                    
                    datetime_objects_from = datetime.combine(current_date , shift_list[i])
                    datetime_objects_to   = datetime.combine(current_date , shift_list[i+1])
                    shift_datetime.append(datetime_objects_from)
                    shift_datetime.append(datetime_objects_to)
                else:
                    datetime_objects_from = datetime.combine(previous_date , shift_list[i])
                    datetime_objects_to   = datetime.combine(current_date , shift_list[i+1])
                    shift_datetime.append(datetime_objects_from)
                    shift_datetime.append(datetime_objects_to)
                i+=2
        Dummy()
        # print(shift_datetime)
        
        excel_map = []
        # Current Day
        now_data = now.replace(second=0, microsecond= 0)
        #################### Hourly Reports ###################
        def hourly_report(shift_start, shift_end): 
            print(current_date, previous_date)           
            ############################# Energy Value #########
            energyhours = []; energy = []
            sft_start = ShiftTimings.objects.values().last()
            s1s = sft_start['shift1start'] 
            d_strt=int((str(s1s))[0:2] )
            s_strt=int((str(shift_start))[11:13])
            s_end = int((str(shift_end))[11:13])
            if(s_strt >= d_strt and s_strt < s_end):
                s = (s_strt - d_strt) + 1
                e = (s_end - s_strt)
                for i in range(0, e):
                    energyhours.append('mth'+str(i+s)+'ec')
                
            elif(s_strt >= d_strt and s_strt > s_end):
                s = (s_strt - d_strt) + 1
                e = (24 - (d_strt - s_end))
                if(e<23): pass
                else: e = (e-s) + 1
                for i in range(0, e):
                    energyhours.append('mth'+str(i+s)+'ec')
                    
            elif(s_strt < d_strt and s_strt < s_end):
                s = (24 - (d_strt - s_strt))+1
                e = (24 - (d_strt - s_end))
                if(e<23): pass
                else: e = (e-s) + 1
                for i in range(0, e):
                    energyhours.append('mth'+str(i+s)+'ec')

            date_energyhurs = ((datetime.today()) - timedelta(days = 1)).date()
            #print(date_energyhurs)
            for hour in energyhours:
                try:
                   hourdata = round(list(Masterdatatable.objects.filter(mtdate = date_energyhurs, mtmtrname = machine['amMachinename']).values(hour))[0][hour], 1)
                   energy.append(hourdata) 
                except:
                   hourdata = 0
                   energy.append(hourdata) 

            ############################## HOURLY PRODUCTION REPORT ####################################
            for col_width in range(1, 15):
                work_sheet.col(col_width).width = 5000
            r=1
            c=1
            work_sheet.write_merge(r, r+1, c, c+12,('HOURLY PRODUCTION REPORT-INJECTION MOULDING-IMG'),style3)

            r=3
            c=1
            work_sheet.write_merge(r, r+1, c, c+1, ('DATE & SHIFT'),style_bold)

            r=3
            c=7+4
            work_sheet.write(r, c, ('CYCLE TIME'),style_bold)
            r=4
            c=11
            work_sheet.write_merge(r, r, c, c, ('TOOL NO'),style_bold)

            r=5
            c=1
            work_sheet.write_merge(r, r, c, c+1, ('TIME'),style_bold)

            r=6
            c=1
            work_sheet.write_merge(r, r, c, c, ('FROM'),style_bold)

            r=6
            c=2
            work_sheet.write_merge(r, r, c, c, ('TO'),style_bold)

            r=5
            c=3
            work_sheet.write_merge(r, r, c, c+1, ('MOULD TIME'),style_bold)

            r=6
            c=3
            work_sheet.write_merge(r, r, c, c, ('START TIME'),style_bold)

            r=6
            c=4
            work_sheet.write_merge(r, r, c, c, ('END TIME'),style_bold)

            r=5
            c=5
            work_sheet.write_merge(r, r+1, c, c, ('MOULD NAME'),style_bold)

            ##########################################################

            r=5
            c=6

            style_bold_with_wrap = xlwt.XFStyle()

            # Copy the existing style_bold properties
            style_bold_with_wrap.alignment = style_bold.alignment
            style_bold_with_wrap.font = style_bold.font
            style_bold_with_wrap.borders = style_bold.borders

            # Enable text wrapping
            alignment_with_wrap = xlwt.Alignment()
            alignment_with_wrap.horz = xlwt.Alignment.HORZ_CENTER
            alignment_with_wrap.vert = xlwt.Alignment.VERT_CENTER
            alignment_with_wrap.wrap = 1  # Enable text wrap
            style_bold_with_wrap.alignment = alignment_with_wrap

            work_sheet.write_merge(r, r+1, c, c, ('PRODUCTION HOURS'),style_bold_with_wrap)

            ######################################################
            ############################################################################

            # r=5
            # c=9
            # work_sheet.write_merge(r, r+1, c, c, ('ENERGY CONSUMPTION (kWh)'),style_bold)


            r = 5
            c = 7
            style_bold_with_wrap = xlwt.XFStyle()

            # Copy the existing style_bold properties
            style_bold_with_wrap.alignment = style_bold.alignment
            style_bold_with_wrap.font = style_bold.font
            style_bold_with_wrap.borders = style_bold.borders

            # Enable text wrapping
            alignment_with_wrap = xlwt.Alignment()
            alignment_with_wrap.horz = xlwt.Alignment.HORZ_CENTER
            alignment_with_wrap.vert = xlwt.Alignment.VERT_CENTER
            alignment_with_wrap.wrap = 1  # Enable text wrap
            style_bold_with_wrap.alignment = alignment_with_wrap

            # Write the header with the updated style
            work_sheet.write_merge(r, r+1, c, c, ('ENERGY CONSUMPTION (kWh)'), style_bold_with_wrap)

            #######################################################################################
            ######################################################

            r=5
            c=8
            work_sheet.write_merge(r, r+1, c, c, ('COUNTER START'),style_bold)

            r=5
            c=9
            work_sheet.write_merge(r, r+1, c, c, ('COUNTER END'),style_bold)

            r=5
            c=10
            work_sheet.write_merge(r, r+1, c, c, ('TOTAL SHOTS'),style_bold)

            r=5
            c=11
            work_sheet.write_merge(r, r+1, c, c, ('GOOD PARTS'),style_bold)
            
            r=5
            c=12
            work_sheet.write_merge(r, r+1, c, c, ('SEC'),style_bold)

            r=5
            c=13
            work_sheet.write_merge(r, r+1, c, c, ('REJECTION PARTS'),style_bold)

            row = 4; col = 12
            work_sheet.write_merge(row, row, col, col+1, None, style_bold)  # tool no

            total_runhour = 0; mouldname_setlist = 0; mouldname_setlist = None; mouldname_setlist = []; break_down = []; mould_list=[]; part_list = [];cummulativecount_start = []; cummulativecount_end = []; cummulativecount_shots = []
            mould_name = []; part_list=[]; sec_list = []; sec = 0; totalshots_list = []; goodpart_list = []; CycletimeSet = []
            energyindex = 0; count_start_list = []; mouldnames = 0; mouldname_list = None; mouldname_list = 0; mouldname_list = []; count_end_list = []; rejection_list = []; count_start = 0; count_end = 0
            totalcount_start = []; totalcount_end = []; totalcount_shots = []; totalcount_goodpart = []; totalcount_sec = []; totalcount_rejection = []
            cummulativecount_goodpart = []; cummulativecount_sec = []; cummulativecount_rejection = []; total_mould  = []; cummulative_mould = []; kwh_energy = []; cummulativecount_kwh = []
            shift_to = shift_start
            while shift_to < shift_end:
                print("33333333333333333:", shift_to, shift_end)
                shift_from = shift_to
                db_date =  shift_to.date() 
                ### Rejection ###
                shift_to_rejection = datetime.strftime((shift_from - timedelta(seconds=1)), "%H:%M:%S")
                shift_fromdate_rejection =  shift_from.date()
                shift_from_rejection  = datetime.strftime((shift_from - timedelta(hours=1)), "%H:%M:%S")
                if shift_to_rejection == '23:59:59':
                   shift_fromdate_rejection = shift_fromdate_rejection - timedelta(days = 1)
                ######
                shift_to += timedelta(hours=1)
                str_shift_from = datetime.strftime(shift_from, "%H:%M:%S") 
                str_shift_to   = datetime.strftime((shift_to - timedelta(seconds=1)), "%H:%M:%S") 
                # #print(shift_to_rejection, shift_fromdate_rejection, str_shift_to, db_date, RejectionTotalCount)
                break_down_shift = breakdown.objects.filter(date = str(db_date), Machinename = machine['amMachinename'], time__range = [str_shift_from, str_shift_to]).values('time', 'MachineState', 'primaryreason').order_by('id')
                for break_data in break_down_shift:
                    break_down.append(break_data)

                all_dashboard_value = ProductionTable.objects.filter(
                    date=db_date,
                    time__range=(str_shift_from, str_shift_to),
                    Machinename = machine['amMachinename'],
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values().order_by('id')

                # of part production

                # distinctMould = list(set(p['Mouldname_id'] for p in all_dashboard_value))
                seen = set()
                distinctMould = [p['Mouldname_id'] for p in all_dashboard_value if not (p['Mouldname_id'] in seen or seen.add(p['Mouldname_id']))]

                # print("Machinename:", machine['amMachinename'], "distinctMould:", distinctMould)
                
                mouldname_list=[]
                if distinctMould !=  []:
                    for mould_id in distinctMould:

                        mould_instance = Mouldmodel.objects.get(id=mould_id)

                        mouldname = mould_instance.Mouldname

                        weight = mould_instance.weight

                        # Get all CycletimeSet values for the current mould_id
                        cycletime_set_values = [
                            p['CycletimeSet'] for p in all_dashboard_value if p['Mouldname_id'] == mould_id
                        ]

                        # Use the first distinct CycletimeSet value (or handle as needed)
                        if cycletime_set_values:
                            CycletimeSet.append(str(round(cycletime_set_values[0])))

                            # print("Machinename:", machine['amMachinename'], "mouldname:", mouldname, "CycletimeSet:", CycletimeSet)
                        
                        part_list.append(str(int(weight)))

                        mould_data = [p for p in all_dashboard_value if
                                       p['Mouldname_id'] == mould_id]


                        if mould_data:

                            first_record = mould_data[0]
                            last_record = mould_data[-1]

                            mould_start_time = first_record['time'] # Start time
                            mould_end_time = last_record['time']  # End time
                            
                            first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                            last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                            first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                            last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                            #########################################################################

                            try:
                                Rejection_CS =  first_record['RejectionParts']

                                # Rejection_CountStart = badpart.objects.filter(date = str(shift_fromdate_rejection) , Machinename = machine['amMachinename'], 
                                #                                             time__gte = shift_from_rejection, time__lte = shift_to_rejection,
                                #                                             # partcount__gt = 0, 
                                #                                             Mouldname_id = id).values('date', 'time', 'partcount', 'Mouldname_id').order_by('id')
                                # Rejection_CS =  Rejection_CountStart.last()['partcount']

                            except:
                                Rejection_CS = 0
                            try:
                                Rejetion_CE = last_record['RejectionParts']

                                # Rejection_COUNTSTART = badpart.objects.filter(date = str(db_date) , Machinename = machine['amMachinename'], 
                                #                                             time__gte = str_shift_from, time__lte = str_shift_to,
                                #                                             # partcount__gt = 0, 
                                #                                             Mouldname_id = id).values('date', 'time', 'partcount', 'Mouldname_id').order_by('id')
                                # Rejetion_CE = Rejection_COUNTSTART.last()['partcount']

                            except:
                                Rejetion_CE = 0
                            # #print(Rejection_CS, Rejetion_CE)
                            RejectionTotalCount = abs(Rejetion_CE - Rejection_CS)
                            if RejectionTotalCount != 0:
                                totalcount_rejection.append(RejectionTotalCount)
                            rejection_list.append(str(RejectionTotalCount))
                            totalshots_value = len(mould_data)
                            # cummulative_shots = totalshots_value + cummulative_shots
                            totalcount_shots.append(totalshots_value)
                            totalshots_list.append(str(totalshots_value))
                            goodparts_value = abs(totalshots_value - RejectionTotalCount)
                            totalcount_goodpart.append(goodparts_value)
                            goodpart_list.append(str(goodparts_value))

                            Count_Start = first_record['ProductionCountActual']

                            Count_End = last_record['ProductionCountActual']

                            #########################################################################
                            
                            basetime = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600

                            saw = breakdown.objects.filter(date = str(db_date), Machinename = machine['amMachinename'], 
                                                    time__range = [first_time, last_time], Mouldname_id=mould_id).values('date', 'time', 'Mouldname_id', 'MachineState', 'primaryreason').order_by('id')

                            total_idle_time = 0  # Initialize the sum

                            last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                            # Iterate through the breakdown data and calculate time differences
                            for last, bd in zip(saw, saw[1:]):
                                # If `MachineState = 0` for last, store its time but don't calculate yet
                                if last['MachineState'] == 0:
                                    # Capture the first occurrence of MachineState = 0
                                    if last_time_str is None:
                                        last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                                
                                # Only calculate the time difference when transitioning from 0 to 1
                                if last_time_str and bd['MachineState'] == 1:
                                    # Combine date and time for `bd`
                                    bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                                    # Parse the combined date and time
                                    last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                                    bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                                    # Calculate the time difference in seconds
                                    time_difference = (bd_time - last_time).total_seconds()

                                    # Print the intermediate values
                                    print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                                    # Accumulate the total time in seconds
                                    total_idle_time += time_difference

                                    # Reset last_time_str to None after calculating for this transition
                                    last_time_str = None
                            # print("total_idle_time:", total_idle_time)
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                            total_runhour += basetime - total_idle_time_hours                            
                            print("Machinename:", machine['amMachinename'], "mould_id:", mould_id, "mouldname:", mouldname, "total_idle_time_hours:", total_idle_time_hours, )

                            single_total_runhour = basetime - total_idle_time_hours   
                            single_total_seconds = int(single_total_runhour * 3600)
                            single_time_formatted = str(timedelta(seconds=single_total_seconds))

                            ##############################################
                            parent_dir = "Machines"
                            sub_dir1 = machine['amMachinename']
                            sub_dir2 = "2024-11-14"               #db_date  #2024-11-14

                            path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                            fileName = "actualenergy"

                            # Ensure path exists before attempting to open the file
                            if os.path.exists(path):
                                try:
                                    with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                                        file_content = file.read().strip().rstrip(',')
                                        entries = file_content.split(',')

                                        # output_data = []
                                        output_data = 0.0  # Initialize the sum
                                        first_time = datetime.strptime("17:00:00", "%H:%M:%S").time()
                                        last_time = datetime.strptime("18:00:00", "%H:%M:%S").time()

                                        # Process each entry and filter by time range
                                        for entry in entries:
                                            if '-' in entry:
                                                time_str, value = entry.split('-')
                                                try:
                                                    # Convert time_str to a time object
                                                    time_obj = datetime.strptime(time_str, "%H:%M:%S").time()

                                                    # first_time = "17:00:00"    #HI
                                                    # last_time = "18:00:00"
                                                    
                                                    # Now compare the parsed time with the first and last time
                                                    if first_time <= time_obj <= last_time:
                                                        output_data += float(value) 
                                                except ValueError:
                                                    print(f"Invalid time format in entry: {entry}")
                                            else:
                                                print(f"Invalid entry format: {entry}")
                                        # Format the output data in the desired list format
                                        
                                        # if output_data:
                                        if output_data > 0:
                                            output_data_str = round(output_data,2)
                                        else:
                                            output_data_str = 0   # "No data in time range"
                                except FileNotFoundError:
                                    output_data_str = 0  # "File not found"
                            else:
                                output_data_str = 0   # "Path does not exist"

                            # print("output_data_str:", output_data_str)
                            ##############################################

                            mouldname_list = []
                            mouldname_list.append(mouldname)
                            # sec_value = 0
                            try:
                                energy_index = output_data_str     #energy[energyindex]
                            except:
                                energy_index = 0

                            totalweight = totalshots_value * weight

                            try:
                                sec_value = round(float(energy_index)/(float(totalweight)/1000), 2)  #energy[energyindex]
                            except:
                                sec_value = 0

                            # print(f"totalshots_value: {totalshots_value}, weight: {weight}, totalweight: {totalweight}")


                            excel_map.append({
                            "Count_Start": str(Count_Start),
                            "Count_End": str(Count_End),
                            "from_time": mould_start_time,
                            "to_time": mould_end_time,
                            "total_shots": str(totalshots_value),
                            "Goodparts": str(goodparts_value),
                            "Moulds_list": mouldname,
                            "Run_hours": single_time_formatted,
                            "energy": energy_index,
                            "SEC": str(sec_value),
                            "Rejection": str(RejectionTotalCount)
                        })
                            # mouldname_setlist = mouldname  # Ensure the latest mould is updated

                            # last_mouldname = mouldname  # Update last mould name
                            # print("last mouldname: ", last_mouldname)
                            # mouldname_list = [last_mouldname]

                            # mouldname_setlist.add(mouldname)  # Use a set to avoid duplicates

                        else:
                            mouldname_list.append('No Mouldname found')

                        # print ("mouldname_list:", mouldname_list)
                    
                        # print ("mouldname_setlist:", mouldname_setlist)

                        count_start_list.append(str(Count_Start))
                        totalcount_start.append(Count_Start)
                        count_end_list.append(str(Count_End))
                        totalcount_end.append(Count_End)
                        # totalweight = totalshots_value * weight

                        kwh_energy.append(energy_index)
                        
                        # try:
                        #     sec_value = round(energy_index/(totalweight/1000), 2)  #energy[energyindex]
                        # except:
                        #     sec_value = 0

                        totalcount_sec.append(sec_value)
                        sec_list.append(str(sec_value))
                        
                        total_mould.append(mould_name)
                        
                        sec = ', '.join(sec_list)
                        
                        totalshots = ', '.join(totalshots_list)
                        
                        goodparts = ', '.join(goodpart_list)
                        # mouldnames = ', '.join(mouldname_setlist)
                        # mouldnames = ', '.join(list(mouldname_setlist))
                        count_start = ', '.join(count_start_list)
                        count_end   = ', '.join(count_end_list)
                        rejection   = ', '.join(rejection_list)
                else:   
                    totalshots = 0
                    goodparts = 0
                    sec = 0
                    # mould_list = []
                    part_weight = 0
                    totalweight = 0
                    runhour = 0  
                    rejection = 0
                    count_start = 0
                    count_end = 0
                mould_start_time = None
                mould_end_time = None
                # Handle case where no data exists
                if mould_start_time is None:                
                    mould_start_time = 'No Start Time'
                if mould_end_time is None:
                    mould_end_time = 'No End Time'        
                if mouldname_list:  # Check if there's at least one mould name
                    # print("mouldname_list :", mouldname_list)
                    mouldnames = mouldname_list[0]
                    # count_Start= count_start_list[-1]
                      # Get the last mould name
                else:
                    mouldnames = 'No Mouldname found'  # Fallback if there are no moulds
                
                [cummulative_mould.append(m) for m in total_mould]
                [cummulativecount_start.append(st) for st in totalcount_start]
                [cummulativecount_end.append(e) for e in totalcount_end]
                [cummulativecount_shots.append(sh) for sh in totalcount_shots]
                [cummulativecount_goodpart.append(g) for g in totalcount_goodpart]
                [cummulativecount_sec.append(sc) for sc in totalcount_sec]
                [cummulativecount_rejection.append(r) for r in totalcount_rejection]
                [cummulativecount_kwh.append(z) for z in kwh_energy]
                #print(energy[energyindex])
                # excel_map.append({"Count_Start":count_start, "Count_End":count_end, "from_time":shift_start,"to_time":shift_to, "total_shots":totalshots, "Goodparts":goodparts, "Moulds_list":mouldnames, "energy":energy[energyindex], "SEC":sec, "Rejection":rejection})
                count_start_list = []; count_end_list = []; totalshots_list = []; goodpart_list = []; rejection_list = []; sec_list = []
                totalcount_start = []; totalcount_end = []; totalcount_shots = []; totalcount_goodpart = []; totalcount_sec = []; totalcount_rejection = []; mouldname_list = []; mouldname_setlist = []; kwh_energy = []
                energyindex +=1

            ############################ Values Mapping into the Excel Sheet ##########################
            cummulativecount = [cummulativecount_kwh, cummulativecount_start, cummulativecount_end, cummulativecount_shots, cummulativecount_goodpart, cummulativecount_sec, cummulativecount_rejection]
            
            cs = list(set(CycletimeSet))
            s = list(set(mould_list))
            # print(s)
            try:
                # mname = reduce(lambda a, b : a+ "   ,   " +str(b), s)
                cyctime = reduce(lambda a, b : a+ "   ,   " +str(b), cs)
            except:
                # mname = None
                cyctime = None

            # #print(listToStr)
            row = 4; col = 3
            # work_sheet.write_merge(row, row, col, col+3, mname, style_bold) 
            work_sheet.write_merge(row-1, row-1, col+9, col+10, cyctime, style_bold) 
            row = 7; col = 1
            # print(excel_map)
            for j in excel_map:
                # print(j)
                # print("jjj: ",j)
                work_sheet.write(row, col, j['from_time'], style1)
                work_sheet.write(row, col+1, j['to_time'],style1)
                work_sheet.write(row, col+4, j['Moulds_list'], style1)
                work_sheet.write(row, col+5, j['Run_hours'], style1)
                work_sheet.write(row, col+7, j['Count_Start'], style1)
                work_sheet.write(row, col+8, j['Count_End'],style1)
                work_sheet.write(row, col+7, j['total_shots'],style1)
                work_sheet.write(row, col+8, j['Goodparts'],style1)
                work_sheet.write(row, col+4, j['energy'],style1)
                work_sheet.write(row, col+9, j['SEC'],style1)
                work_sheet.write(row, col+10, j['Rejection'],style1)
                row += 1
            col = 5
            # #print(cummulativecount)
            for total in cummulativecount:
                try:
                   re = reduce(lambda x,y:x+y,total)
                except:
                   re = 0
                work_sheet.write(row, col, re,style1)
                col += 1
            ################### Values are Not there ###############################
            r_none = row +1
            print("r none:", r_none)
            for r in range(r_none, r_none+3):
                for c in range(3,9):
                    work_sheet.write(r, c, None, style_bold)

            # for c in range(4,7):
            #     work_sheet.write(r_none+3, c, None, style_bold)

            # for c in range(3,8):
            #     work_sheet.write(r_none+7, c, None, style_bold)

            for c in range(1,9):
                work_sheet.write(r_none+3, c, None, style_bold)

            for r in range(r_none,r_none+7): 
                for c in range(10,12):
                    work_sheet.write(r, c, None, style_bold)
                
            for r in range(r_none+4, r_none+7):
                for c in range(3,10):
                    work_sheet.write(r, c, None, style_bold)

            ##############################################################################################################################
            r = row
            c = 1
            for data in ['TOTAL', 'PART WT.', 'RUNNER WT.', 'SHOT WT.','Raw Material Name','Grade','Batch No','LUMPS WT.','TOTAL RUNNER WT','TOTAL RUN HOURS','TOTAL DOWN HOURS']:
                if data != 'Raw Material Name' and data != 'Grade' and data != 'Batch No' and data != 'TOTAL RUNNER WT' and data != 'LUMPS WT.' and data != 'TOTAL RUN HOURS' and data != 'TOTAL DOWN HOURS':
                    work_sheet.write_merge(r, r, c, c+1, data , style_bold2)
                elif data != 'TOTAL' and data != 'PART WT.' and data != 'SHOT WT.'and data != 'RUNNER WT.' and data != 'TOTAL RUNNER WT' and data != 'LUMPS WT.' and data != 'TOTAL RUN HOURS' and data != 'TOTAL DOWN HOURS':
                    work_sheet.write_merge(r+1, r+1, c, c+1, data, style_bold2)
                    # work_sheet.write_merge(r, r, c, c+1, data, style_bold2)
                elif data != 'TOTAL'and data != 'PART WT.'and data != 'RUNNER WT.' and data != 'SHOT WT.' and data != 'Raw Material Name' and data!= 'Grade' and data != 'Batch No':
                    c=9
                    work_sheet.write_merge(r-6, r-6, c , c+1, data, style_bold2)  
                    # work_sheet.write(r, c, None, style_bold)
                r += 1
            # print("row:",r)
            r = r-6

            total_seconds = int(total_runhour * 3600)
            time_formatted = str(timedelta(seconds=total_seconds))

            work_sheet.write(r-2, c+2, time_formatted, style1)
            # print("row:", r, "col:",c)
            # print("col:",c)
            c = 9
            data_list = ['Operator Name/Id No', 'Signature', 'Shift. Engr. Sign']
            for data in data_list:
                # work_sheet.write_merge(r, r, c, c+1, data, style_bold2)
                work_sheet.write(r, c+1, data, style_bold2)
                r += 1
            # row length
            for row_width in range(1, r):
                work_sheet.row(row_width).height_mismatch = True
                work_sheet.row(row_width).height = 380
            return (r, break_down, cummulativecount_rejection)
        ########################################## REJECTION REPORTS ###########################################
        def rejection_report(row_value, break_down, RejectionCount, rejection_date):
            style  = xlwt.XFStyle()
            style1 = xlwt.XFStyle()
            style2 = xlwt.XFStyle()
            style3 = xlwt.XFStyle()
            # set alignment
            alignment       = xlwt.Alignment()
            alignment.horz  = xlwt.Alignment.HORZ_CENTER
            alignment.vert  = xlwt.Alignment.VERT_CENTER
            alignment.wrap      = 1
            style.alignment     = alignment
            style1.alignment    = alignment
            style2.alignment    = alignment
            style3.alignment    = alignment
            #Set Border
            border          = xlwt.Borders()
            border.left     = xlwt.Borders.THIN 
            border.right    = xlwt.Borders.THIN 
            border.top      = xlwt.Borders.THIN 
            border.bottom   = xlwt.Borders.THIN
            style1.borders  = border
            style2.borders  = border
            style3.borders  = border
            #style1
            pattern = xlwt.Pattern()
            pattern.pattern = xlwt.Pattern.SOLID_PATTERN
            pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
            style.pattern = pattern
            #Set Font Color
            font = xlwt.Font()
            font.colour_index=xlwt.Style.colour_map['red']
            font.name = 'Times New Roman'
            font.bold = True
            font.height = 250
            style3.font = font
            
            font = xlwt.Font()
            font.colour_index=xlwt.Style.colour_map['black']
            font.name = 'Times New Roman'
            font.bold = False
            font.height = 200
            style.font = font
            style1.font = font
            style2.font = font
            
            r= row_value + 1
            c=1
            work_sheet.row(r).height_mismatch = True
            work_sheet.row(r).height = 550
            work_sheet.write_merge(r, r, c, c+17,('REJECTION DETAILS'), style3)
            # Set Heading border
            header = ['DATE','SET UP','FLASH','SINK MARK','SILVER STREAKS','PIN MARK','SHORT FILL','BURN MARK','SCORING','BLACK MARK','WHITE MARK','JETTING\FLOW MARK','WELD LINES','SCRATCHES','SHINING','COLOUR MISMATCHING','OIL MARK','OTHERS']
            r=r+1
            c=1
            for i in header:
                work_sheet.row(r).height_mismatch = True
                work_sheet.row(r).height = 550
                if i == 'JETTING\FLOW MARK' or i == 'COLOUR MISMATCHING':
                   work_sheet.col(c).width = 6500
                else:
                    work_sheet.col(c).width = 5000
                work_sheet.write_merge(r, r+1, c, c, i,style_bold)
                c+=1
            
            row = r + 2; c = 1
            work_sheet.row(row).height_mismatch = True
            work_sheet.row(row).height = 550
            work_sheet.write(row, c, rejection_date,style_bold)
            # #print(RejectionCount, machine['amMachinename'])
            if RejectionCount != []:
                re = reduce(lambda x,y:x+y,RejectionCount)
                if re == 3:
                    work_sheet.write(row, c+1, re,style_bold)
                    for i in range(3, len(header)+1):
                        work_sheet.write(row, i, 0,style_bold)
                else:
                    work_sheet.write(row, c+1, 3, style_bold)
                    totalcount = (re - 3)
                    work_sheet.write(row, len(header), totalcount,style_bold)
                    for i in range(3, len(header)):
                        work_sheet.write(row, i, 0,style_bold)
            else:
                for i in range(2, len(header)+1):
                    work_sheet.write(row, i, 0,style_bold)
            ###############################################################################################
            row_ = r + 4 ; col = 1
            work_sheet.row(row_).height_mismatch = True
            work_sheet.row(row_).height = 550
            work_sheet.row(row_+1).height_mismatch = True
            work_sheet.row(row_+1).height = 550
            work_sheet.col(col).width   = 5000
            work_sheet.col(col+1).width = 5000
            work_sheet.col(col+2).width = 5000
            work_sheet.write_merge(row_, row_, col, col+2,'DOWNTIME', style_bold)
            work_sheet.write(row_+1, col, ('FROM'),style_bold)
            work_sheet.write(row_+1, col+1, ('TO'),style_bold)
            work_sheet.write(row_+1, col+2, ('REASON'),style_bold)
            row_ = r + 4; col = 1
            reasons_list = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure','Mould Change', 'Material Change', 'Operator Absence','Tool Problem']
            # #print(len(break_down))
            for dat0 in range(0, len(break_down)):
                if break_down[dat0]['MachineState'] == 0:
                    if break_down[dat0-1]['MachineState'] !=0:
                        for dat1 in range(dat0, len(break_down)):
                            if break_down[dat1]['MachineState'] == 1:
                                if reasons_list[break_down[dat1]['primaryreason']] != None:
                                    work_sheet.row(row_+2).height_mismatch = True
                                    work_sheet.row(row_+2).height = 550
                                    work_sheet.col(col).width   = 5000
                                    work_sheet.col(col+1).width = 5000
                                    work_sheet.col(col+2).width = 7000
                                    ##print(break_down[dat0]['time'], break_down[dat1]['time']) 
                                    work_sheet.write(row_+2, col, break_down[dat0]['time'], style1)
                                    work_sheet.write(row_+2, col+1, break_down[dat1]['time'], style1)
                                    # #print(reasons_list[break_down[dat1]['primaryreason']])
                                    work_sheet.write(row_+2,  col+2, reasons_list[break_down[dat1]['primaryreason']], style1)
                                    row_ += 1
                                break
            #####################################################################################################
        # #print(shift_datetime)                
        if now_data == shift_datetime[1]:
            # print('heelo')
            row_SHIFT = 3; col_SHIFT = 3
            shift_start = shift_datetime[0]
            shift_end   = shift_datetime[1]
            date_shift_time = datetime.strftime(datetime.today(), '%Y-%m-%d')  + '  &  ' + ("Shift_A")
            work_sheet.write_merge(row_SHIFT, row_SHIFT+1, col_SHIFT, col_SHIFT+7, date_shift_time, style_bold)
            row_value , break_down, RejectionCount = hourly_report(shift_start, shift_end)
            rejection_date = datetime.strftime((datetime.today() - timedelta(days=1)), '%Y-%m-%d')
            rejection_report(row_value, break_down, RejectionCount, rejection_date)

        if now_data == shift_datetime[3]:
            # print('heelo2')
            row_SHIFT = 3; col_SHIFT = 3
            shift_start = shift_datetime[2]
            shift_end   = shift_datetime[3]
            date_shift_time = datetime.strftime((datetime.today()), '%Y-%m-%d') + '  &  ' + ("Shift_B")
            work_sheet.write_merge(row_SHIFT, row_SHIFT+1, col_SHIFT, col_SHIFT+7, date_shift_time, style_bold)
            row_value , break_down, RejectionCount = hourly_report(shift_start, shift_end)
            rejection_date = datetime.strftime((datetime.today() - timedelta(days=1)), '%Y-%m-%d')
            rejection_report(row_value, break_down, RejectionCount, rejection_date)

        if now_data == shift_datetime[5]:
            # print('heelo3')
            row_SHIFT = 3; col_SHIFT = 3
            shift_start = shift_datetime[4]
            shift_end   = shift_datetime[5]
            date_shift_time = datetime.strftime((datetime.today()- timedelta(days=1)), '%Y-%m-%d') + '  &  ' + ("Shift_C")
            work_sheet.write_merge(row_SHIFT, row_SHIFT+1, col_SHIFT, col_SHIFT+7, date_shift_time, style_bold)
            row_value , break_down, RejectionCount = hourly_report(shift_start, shift_end)
            rejection_date = datetime.strftime((datetime.today() - timedelta(days=1)), '%Y-%m-%d')
            rejection_report(row_value, break_down, RejectionCount, rejection_date)
            
    _datetime = datetime.now()
    datetime_str = _datetime.strftime("%d-%m-%Y-%H-%M-%S")
    savepath = os.path.join(BASE_DIR,'Report','ShiftWise_Report' +datetime_str+'.xls')
    work_book.save(savepath)
    # return savepath 
    return HttpResponse ("ShiftWise_ReportGenerated")

# @csrf_exempt
# @periodic_task(run_every=(crontab(minute='*/1')))
def sendmail():
    # print('hiiiii')
    print("celery runnning")
    # savepath = report()
    shift_list = []
    now = datetime.now()
    # now = datetime(2024, 1, 20, 14, 00)
    current_time = now.strftime('%H:%M:%S')
    # print(current_time)
    shift_data = ShiftTimings.objects.values().last() 
    shift1end   = shift_data['shift1end'] 
    shift2end   = shift_data['shift2end']
    shift3end   = shift_data['shift3end'] 
    ### STORED THE SHIFT DATETIME.TIME DATA'S INTO THE SHIFT_LIST
    shift_list.append(shift1end)
    shift_list.append(shift2end)
    shift_list.append(shift3end)
    for data in shift_list:
        # print(data)
        # print(current_time[0:5], str(data)[0:5])
        if (current_time) == str(data):
            print("Report generating")
            reportfile = report(now)
                #'Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Mohankumar.Chinnasamy@motherson.com;praveen.srinivasan@motherson.com;Gokulraj.Rajasekaran@motherson.com;Gokul.Annadurai@motherson.com;u1ppc@int.motherson.com;Sivakumar.Radhakrishnan@motherson.com;Elayaraja.Muthukrishnan@motherson.com;jagadeesang@int.motherson.com;imgu1@int.motherson.com;processengineeringu1.matechennai@motherson.com'
            tomail='praveen.srinivasan@motherson.com;Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Gokulraj.Rajasekaran@motherson.com'
            sub='Houlry Wise and Rejection report for R-Connect'
            message = '''Dear Team, <br> 
                                Please find the Hourlywise and Rejection report for MATE UNIT - 1. 
                                <br>
                                <br>
                            Regards, <br>
                            R-Connect Team. 
                            <br>
                            <br> 
                            Note: This is an system generated mail.'''
            msg = MIMEMultipart('mixed')
            msg['Subject'] = sub
            msg['From'] = "R-Connect <no-reply@rconnect.com>"
            msg['To'] = tomail
            part2 = MIMEText(message, 'html')
            msg.attach(part2)
            part = MIMEBase('application','octet-stream')
            part.set_payload(open(reportfile, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="R-ConnectReport.xls"')
            msg.attach(part)
            smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
            smtpObj.sendmail('R-Connect <no-reply@rconnect.com>',tomail.split(';'),msg.as_string())
            smtpObj.quit()
            print('Mail send successfully')
            print("Mail Sent to ",tomail)
    return HttpResponse(" Hourly Wise and Rejection Report is Generated")