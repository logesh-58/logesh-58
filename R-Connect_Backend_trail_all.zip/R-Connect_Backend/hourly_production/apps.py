from django.apps import AppConfig


class HourlyProductionConfig(AppConfig):
    name = 'hourly_production'
