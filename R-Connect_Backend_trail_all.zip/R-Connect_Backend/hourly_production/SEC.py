from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import pandas as pd
from shiftmanagement.models import ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
from datetime import datetime, timedelta
from meter_data.models import Masterdatatable
from  functools import reduce

########################################### SEC CHART WISE AND TABLE WISE DATA ##############################################
@csrf_exempt
def sec_value(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        request_data = json.loads(request.body)
        start_date  = request_data['start']
        end_date    = request_data['end']
        machine_name = request_data['Mname']
        mouldname   = request_data['mldname']
        date_range = pd.date_range(start = start_date, end = end_date)
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start').last()['shift1start'].hour
        print("shift_starttime:", shift_starttime)
        # list_hrs = [[str(shift_starttime),'23:59:59'],['00:00:00', '23:59:59'],['00:00:01',str(shift_starttime)]]
        list_hrs = [[str(shift_starttime), '24'],['0', str(shift_starttime)]]
        mould_management = Mouldmodel.objects.get(Mouldname = mouldname)
        weight = mould_management.weight
        mouldid = mould_management.id
        average_total = 0
        time_range = None; next_date = None; next_range = None
        sec_value = []; sec_hrs = []; sec_table = []
        for date in date_range:
            if str(date.date()) == start_date:
                time_range = list_hrs[0]
                next_range = list_hrs[1]
            elif str(date.date()) == end_date:
                time_range = list_hrs[0]
            else:
                time_range = list_hrs[0]
                next_range = list_hrs[1]
            if time_range != None:
                for i in range(int(time_range[0]), int(time_range[1])):
                    hour = 'mth'+str(i - 5)+'ec'
                    try:
                      hourdata = (round(Masterdatatable.objects.filter(mtdate = date.date(), mtmtrname = machine_name).values(hour)[0][hour], 1))
                    except:
                      hourdata = 0
                    if i in range(0, 10):
                       time_str = ('0'+str(i)+':00:00', '0'+str(i)+':59:59')
                    else:
                       time_str = (str(i)+':00:00', str(i)+':59:59')
                    # print(time_str)
                    production_data = (ProductionTable.objects.filter(date = str(date.date()), 
                                                                    Machinename  = machine_name,
                                                                    Mouldname_id = mouldid,
                                                                    Plantname = Plantname, 
                                                                    MachineState__gt = 0, 
                                                                    ProductionCountActual__gte = 1,
                                                                    time__range = time_str
                                                                    ).count()) * weight
                    try:
                      SEC = round(hourdata/(production_data/1000), 2)
                    except:
                       SEC = 0
                    sec_value.append(float(SEC))
                    sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
                    sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})
            if next_range != None:
               for i in range(int(next_range[0]), int(next_range[1])):

                  hour = 'mth'+str(19 + i)+'ec'
                  try:
                     # hourdata = (round(Masterdatatable.objects.filter(mtdate = date.date() + timedelta(days = 1), mtmtrname = machine_name).values(hour)[0][hour], 1))
                     hourdata = (round(Masterdatatable.objects.filter(mtdate = date.date(), mtmtrname = machine_name).values(hour)[0][hour], 1))
                  except:
                     hourdata = 0
                  production_data = (ProductionTable.objects.filter(date = str(date.date() + timedelta(days = 1)), 
                                                                    Machinename  = machine_name,
                                                                    Mouldname_id = mouldid,
                                                                    Plantname = Plantname,
                                                                    MachineState__gt = 0,
                                                                    ProductionCountActual__gte = 1,
                                                                    time__range = (str(i)+':00:00', str(i)+':59:59')
                                                                    ).count()) * weight
                  print(hourdata,production_data)
                  
                  try:
                     SEC = round(hourdata/(production_data/1000), 2)
                  except:
                     SEC = 0
                  sec_value.append(float(SEC))
                  sec_hrs.append(str(date.date())+':'+str(i)+':00_' +str(i)+':59')
                  sec_table.append({"date":str(date.date()), "hour":str(i)+':00_' +str(i)+':59', "value":float(SEC)})
            next_date = None; next_range = None; time_range = None
        re = reduce(lambda x,y:x+y,sec_value)
        average_total = round(re/len(sec_hrs), 2)
        return JsonResponse ({"average_value": average_total, "sec_date_hour":sec_hrs, "sec_value":sec_value , "sec_table":sec_table}, safe = False)
