from django.http import JsonResponse
import json
import os
from datetime import datetime, timedelta
from shiftmanagement.models import ShiftTimings
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from django.db.models import Q, Sum, Max, Min, Count
from mouldmanagement.models import Mouldmodel
from analysis.views import machineArray

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'  

############################################    shifts     ########################################

@csrf_exempt
def insertpower(request):
    if request.method == 'POST':
        # Load the data, which is a list of dictionaries
        meterdata_list = json.loads(request.body)

        # Loop through each meter's data
        for meterdata in meterdata_list:
            # Extract the necessary fields
            plantname = meterdata.get('plantname')
            machine_name = meterdata.get('metername')

            MachinenamesArray = machineArray(plantname)

            if machine_name not in MachinenamesArray:
                print(f"Skipping {machine_name} as it is not in MachinenamesArray.")
                continue

            # Current datetime
            today = datetime.now()

            # Replace the date with 2023-10-05
            # today = today.replace(year=2023, month=10, day=5)

            # today = datetime(2024, 10, 10, 6, 0, 1, 143772)

            print("today:", today)

            shift_time = ShiftTimings.objects.filter(Plantname=plantname).values('shift1start').last()['shift1start']
                
            date = ''
            if today.hour >= shift_time.hour:
                date = str(today.date())
            else:
                date = str((today - timedelta(days=1)).date())
            
            # Create File
            try:
                parent_dir = "Machines"
                sub_dir1 = machine_name
                sub_dir2 = date
                
                path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                
                # Create the directories
                if os.path.exists(path):
                    print(f"Folder for {machine_name} on {date} is already available.")
                else:
                    os.makedirs(path, exist_ok=True)
                    if os.path.exists(path):
                        print(f"Folder for {machine_name} on {date} has been created.")
                
                # Write meter data to file
                fileWrite(meterdata, today, path, shift_time)

            except Exception as e:
                print(f"Error creating directory '{str(today.date())}': {e}")

        return JsonResponse({'status': 'success'}, status=200)  # Respond with success status
    
    return JsonResponse({'error': 'Invalid method'}, status=405)  # Handle invalid method



def fileWrite(meterdata, today, path, shift_time):
    current_time = today.time().strftime('%H:%M:%S')

    fileNames = "Raw_actualenergy"

    # Read the last value from the file
    try:
        with open(os.path.join(path, f"{fileNames}.txt"), "r") as file:
            last_value = file.read().strip().rstrip(',')
            print('last value:', last_value)
    except FileNotFoundError:
        last_value = ""

    # Get the last actual value
    actual_last = 0
    if last_value:
        last_values = last_value.split(",")
        last_entry = last_values[-1].split("-")[-1]
        actual_last = float(last_entry) if last_entry else 0

    # Check if current_time is equal to shift_time
    shift_time_str = shift_time.strftime('%H:%M:%S')
    temp_value = 0 if current_time == shift_time_str else actual_last

    print("shift_time:", shift_time_str)
    print("current_time:", current_time)

    fileName = "actualenergy"

    # Ensure meterdata is numeric
    meterdata_value = meterdata.get(fileName, 0)
    if isinstance(meterdata_value, str):
        try:
            meterdata_value = float(meterdata_value)
        except ValueError:
            meterdata_value = 0

    # Calculate the updated meter data
    if current_time == shift_time_str:
        meterdata_update = 0
    else:
        meterdata_update = meterdata_value - temp_value

    # Append the new value to the file
    with open(os.path.join(path, f"{fileName}.txt"), "a") as file:
        file.write(f"{current_time}-{meterdata_update:.2f},")

    with open(os.path.join(path, f"{fileNames}.txt"), "a") as file:
        file.write(f"{current_time}-{meterdata_value},")
    
    return True

################################################################################################################################

@csrf_exempt
def power_value(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        request_data = json.loads(request.body)
        date_str = request_data['date']  # '2023-04-26'
        machinename = request_data['machinename']
        mouldname = request_data['mouldname']

        ###########
        firstday_start = '06:00:00'
        firstday_end = '23:59:59'
        secondday_start = '00:00:00'
        secondday_end = '05:59:59'
        ###########

        response_data = []

        # Convert date string to datetime object
        current_date = datetime.strptime(date_str, '%Y-%m-%d')
        current_date_str = current_date.strftime('%Y-%m-%d')
        
        next_date = current_date + timedelta(days=1)
        next_date_str = next_date.strftime('%Y-%m-%d')

        mould_management = Mouldmodel.objects.get(Mouldname = mouldname)
        mouldid = mould_management.id
        print("mouldid:", mouldid)

        all_production_data = ProductionTable.objects.filter(
                    # date__range=[current_date_str, next_date_str],
                    Q(date=current_date_str, time__gte=firstday_start) |
                    Q(date=next_date_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename=machinename,
                    ProductionCountActual__gt=0,
                    Mouldname_id = mouldid,
                    MachineState=1
                ).values('Machinename', 'time', 'date', 'Mouldname_id').order_by('id')
    
        if all_production_data:
            dashboard_value = [p for p in all_production_data
                        ]
            
            if dashboard_value:
                first_time_str = dashboard_value[0]['time']
                last_time_str = dashboard_value[-1]['time']

                # first_time_str = "17:00:00"    #HI
                # last_time_str = "18:00:00"

                print("first_time_str:", first_time_str)
                print("last_time_str:", last_time_str)

                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()

                print("first_time:", first_time)
                print("last_time:", last_time)
                
                ##############################################
                parent_dir = "Machines"
                sub_dir1 = machinename
                sub_dir2 = current_date_str

                # sub_dir2 = "2024-10-09"
                
                path = os.path.join(parent_dir, sub_dir1, sub_dir2)
                fileName = "actualenergy"

                # Ensure path exists before attempting to open the file
                if os.path.exists(path):
                    try:
                        with open(os.path.join(path, f"{fileName}.txt"), "r") as file:
                            file_content = file.read().strip().rstrip(',')
                            entries = file_content.split(',')

                            output_data = []
                            # Process each entry and filter by time range
                            for entry in entries:
                                if '-' in entry:
                                    time_str, value = entry.split('-')
                                    try:
                                        # Convert time_str to a time object
                                        time_obj = datetime.strptime(time_str, "%H:%M:%S").time()
                                        
                                        # Now compare the parsed time with the first and last time
                                        if first_time <= time_obj <= last_time:
                                            output_data.append(entry)  # Add the valid entry to output
                                    except ValueError:
                                        print(f"Invalid time format in entry: {entry}")
                                else:
                                    print(f"Invalid entry format: {entry}")
                            # Format the output data in the desired list format
                            if output_data:
                                output_data_str = output_data
                                status = True
                            else:
                                output_data_str = "No data in time range"
                                status = False

                    except FileNotFoundError:
                        output_data_str = "File not found"
                        status = False
                else:
                    output_data_str = "Path does not exist"
                    status = False
            else:
                output_data_str = "No production data"
                status = False
        else:
            output_data_str = "No production data found"
            status = False

        # Construct the response for the current date
        response_data.append({
            "date": current_date_str,
            "Machine": machinename,
            "output_data": output_data_str if isinstance(output_data_str, list) else [output_data_str],
            "status": status
        })

        return JsonResponse(response_data, safe=False)

    return JsonResponse({"status": "failed"}, status=400)