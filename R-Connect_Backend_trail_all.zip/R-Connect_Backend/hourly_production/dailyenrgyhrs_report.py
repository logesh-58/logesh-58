from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
import xlwt
from RConnect.settings import BASE_DIR
import os
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from usermanagement.models import AddUser
from meter_data.models import Masterdatatable
from group_management.models import AddGroup
from django.db.models import Sum as add
from datetime import datetime , timedelta, date
from shiftmanagement.models import ShiftTimings
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from celery.schedules import crontab
# from celery.decorators import periodic_task
from mouldmanagement.models import Mouldmodel
from timeline.models import breakdown
# from celery import shared_task
from timeline.models import badpart
# @periodic_taskrun_every=(crontab(minute='*/1')))

# @csrf_exempt
def enryhrs():
    #add new colour to palette and set RGB colour value
    work_book = xlwt.Workbook(encoding='utf-8')
    xlwt.add_palette_colour("custom_colour", 0x11)
    work_book.set_colour_RGB(0x11, 188, 225, 158)
    Ws_1 = work_book.add_sheet('Energy_Report')
    Ws_1.show_grid = False
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()
    styletotal1 = xlwt.XFStyle()
    styletotal2 = xlwt.XFStyle()
    #Set alignment
    alignment       = xlwt.Alignment()
    alignment.horz  = xlwt.Alignment.HORZ_CENTER
    alignment.vert  = xlwt.Alignment.VERT_CENTER
    alignment.wrap      = 1
    style1.alignment    = alignment
    style1.alignment = alignment
    style1.alignment = alignment
    style2.alignment = alignment
    style3.alignment = alignment
    style2.alignment    = alignment
    styletotal1.alignment = alignment
    styletotal2.alignment = alignment
    #Set border
    border          = xlwt.Borders()
    border.left     = xlwt.Borders.THIN 
    border.right    = xlwt.Borders.THIN 
    border.top      = xlwt.Borders.THIN 
    border.bottom   = xlwt.Borders.THIN
    style1.borders  = border
    style1.borders = border
    style1.borders = border
    style2.borders = border
    style3.borders = border
    styletotal1.borders = border
    styletotal2.borders = border
    # pattern
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = xlwt.Style.colour_map['custom_colour']
    style2.pattern = pattern
    # pattern total
    pattern1 = xlwt.Pattern()
    pattern1.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern1.pattern_fore_colour = xlwt.Style.colour_map['tan']
    styletotal1.pattern = pattern1
    #Set Font Color
    # Set Font
    # Not Bold Letter
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['gray80']
    font.name = 'calibari'
    font.bold = True
    font.height = 200
    style2.font = font
    #style 3
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['black']
    font.name = 'calibri'
    font.bold = False
    font.height = 200
    style3.font = font
    # Bold Letter
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'calibri'
    font.bold = True
    font.height = 250
    style1.font = font
    #style total1
    font2 = xlwt.Font()
    font2.colour_index=xlwt.Style.colour_map['black']
    font2.name = 'calibri'
    font2.bold = True
    font2.height = 200
    styletotal1.font = font2
    #style total2
    font3 = xlwt.Font()
    font3.colour_index=xlwt.Style.colour_map['red']
    font3.name = 'calibri'
    font3.bold = True
    font3.height = 200
    styletotal2.font = font3
    #set custom color 
    # now you can use the colour in styles
    machinename_data = AddMachine.objects.values('amMachinename')
    style = xlwt.easyxf('font: bold 1, colour_index gray80; align: rotation 90; pattern: pattern solid, fore_colour custom_colour; align: wrap on, vert center, horiz center; border : bottom thin,right thin,top thin,left thin;')
    row  = 1; col =1 
    Ws_1.write_merge(row, row+1, col, col+27, 'Energy Consumption Report', style1)
    row = 4 ; col = 1
    for i in ['S.No', 'Plantname', 'Group', 'Total Energy']:Ws_1.write_merge(row, row+1, col, col, i, style2);col+=1
    Ws_1.row(row).height_mismatch  = True
    Ws_1.row(row).height = 500
    Ws_1.write_merge(row, row, col, col+23, "Houry Energy Consumption", style2)
    start_time = 6; end_time = 7; row += 1; col = 5; start_end = ''
    for j in ['06:00 - 07:00', '07:00 - 08:00', '08:00 - 09:00' ,'09:00 - 10:00', '10:00 - 11:00', '11:00 - 12:00', 
                '12:00 - 13:00', '13:00 - 14:00', '14:00 - 15:00', '15:00 - 16:00', '16:00 - 17:00', '17:00 - 18:00', '18:00 - 19:00',
                '19:00 - 20:00', '20:00 - 21:00', '21:00 - 22:00', '22:00 - 23:00', '23:00 - 00:00','00:00 - 01:00', '01:00 - 02:00',
                '02:00 - 03:00', '03:00 - 04:00', '04:00 - 05:00', '05:00 - 06:00']:
        Ws_1.row(row).height_mismatch  = True
        Ws_1.row(row).height = 1600
        Ws_1.write(row, col, j, style)
        start_time += 1; end_time += 1; col += 1
    yesterday_date = (datetime.today()).date()-timedelta(days=1)
    # yesterday_date = '2023-12-28'
    group_data = AddGroup.objects.values('agplantname')
    Plant_Name = AddUser.objects.last().udPlantname
    row = 6; col = 1;serial_count = 1; grp_list = []
    #increase the column width
    Ws_1.col(col).width   = 1500
    Ws_1.col(col+1).width = 2800
    Ws_1.col(col+2).width = 3700
    column_nm = ['mtenergycons', 'mth1ec', 'mth2ec', 'mth3ec', 'mth4ec','mth5ec','mth6ec','mth7ec', 'mth8ec', 'mth9ec', 'mth10ec'
                ,'mth11ec', 'mth12ec', 'mth13ec', 'mth14ec', 'mth15ec', 'mth16ec', 'mth17ec', 'mth18ec', 'mth19ec', 'mth20ec', 'mth21ec'
                ,'mth22ec', 'mth23ec', 'mth24ec']  
    for grup_nm in group_data:
        if grup_nm['agplantname'] != 'Incomer':
            Ws_1.row(row).height_mismatch  = True
            Ws_1.row(row).height = 500
            Ws_1.write(row, col, serial_count, style3)
            Ws_1.write(row, col+1, Plant_Name, style3)
            Ws_1.write(row, col+2, grup_nm['agplantname'], style3)
            grp_list.append(grup_nm['agplantname'])
            for column_data in column_nm:
                column_value = Masterdatatable.objects.filter(mtdate = yesterday_date
                                                    ,mtgrpname = grup_nm['agplantname']).aggregate(add(column_data))
                if col == 1:
                    Ws_1.col(col+3).width = 3700
                else:
                    Ws_1.col(col+3).width = 2000
                Ws_1.write(row, col+3, column_value[column_data + '__sum'], style3)
                col += 1
            row += 1; col = 1; serial_count += 1
    row = row; col = 1
    Ws_1.row(row).height_mismatch  = True
    Ws_1.row(row).height = 500
    Ws_1.write_merge(row, row, col, col+2, "Total", styletotal1)
    for column_data in column_nm:
        total_value = Masterdatatable.objects.filter(mtdate = yesterday_date
                                                ,mtgrpname__in = grp_list).aggregate(add(column_data))
        Ws_1.write(row, col+3, total_value[column_data + '__sum'], styletotal2)
        col += 1
    retrun_value = report(work_book, machinename_data)
    _datetime = datetime.now()
    datetime_str = _datetime.strftime("%d-%m-%Y-%H-%M-%S")
    savepath = os.path.join(BASE_DIR,'Report','Energy_Hourly'+datetime_str+'.xls')
    work_book.save(savepath)
    return savepath
    # return HttpResponse ("Report Generated")

def report(work_book, machinename_data):
    # print("report function is generated")
    for machine in machinename_data:
        # print(machine['amMachinename'])
        work_sheet = work_book.add_sheet(machine['amMachinename'])
        work_sheet.show_grid = False
        style  = xlwt.XFStyle()
        style1 = xlwt.XFStyle()
        style2 = xlwt.XFStyle()
        style3 = xlwt.XFStyle()
        style_bold = xlwt.XFStyle()
        style_header = xlwt.XFStyle()
        style_bold2 = xlwt.XFStyle()
        #set alignment
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap      = 1
        style.alignment     = alignment
        style1.alignment    = alignment
        style2.alignment    = alignment
        style3.alignment    = alignment
        style_bold2.alignment = alignment
        ######
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap = 1
        style_bold.alignment = alignment
        style_header.alignment = alignment
        #Set Border
        border          = xlwt.Borders()    
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style2.borders  = border
        style3.borders  = border
        ######
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN 
        border.top      = xlwt.Borders.THIN 
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style_bold.borders = border
        style_header.borders = border
        style_bold2.borders  = border
        #pattern
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
        style.pattern = pattern

        pattern1 = xlwt.Pattern()
        pattern1.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern1.pattern_fore_colour = xlwt.Style.colour_map['custom_colour']
        style_bold.pattern = pattern1

        pattern2 = xlwt.Pattern()
        pattern2.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern2.pattern_fore_colour = xlwt.Style.colour_map['tan']
        style_bold2.pattern = pattern2

        #Set Font Color
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['red']
        font.name = 'calibri'
        font.bold = True
        font.height = 250
        style3.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'calibri'
        font.bold = False
        font.height = 200
        style.font = font
        style1.font = font
        style2.font = font
        ####
        font = xlwt.Font()
        font.colour_index=xlwt.Style.colour_map['black']
        font.name = 'calibri'
        font.bold = True
        font.height = 200
        style_bold.font = font 
        style_bold2.font = font
        #################### Hourly Reports ###################
        shift_data = (ShiftTimings.objects.values().last())['shift1start']
        starttime = (datetime.strptime(str(shift_data), "%H:%M:%S")).hour
        excel_map = []; hrsArray = []
        
        today = datetime.now().date()
        yesterday = today - timedelta(days = 1)
        
        # today = '2023-12-29'
        # yesterday = '2023-12-28'

        for i in range(starttime,(24+starttime)):
            if(i>23):
                start = ('0'+str(i-24)+':00:00')
                end = ('0'+str(i-24)+':59:59')
                dict = {"date":today, "fromtime":start, "totime":end}
                # print(dict)
                hrsArray.append(dict)
            else:
                if i<= 9 :
                    start = ('0'+str(i)+':00:00')
                    end = ('0'+str(i)+':59:59')
                else:
                    start = (str(i)+':00:00')
                    end = (str(i)+':59:59')
                dict = {"date":yesterday, "fromtime":start, "totime":end}
                # print(dict)
                hrsArray.append(dict)
        #--------------------------------------------------------------------------------
        def hourly_report():     
            # print('Hourly Report')       
            ############################# Energy Value ###################
            # print(shift_datetime)
            ## Get the Energy Hurs & Value (24 hrs format)
            date_energyhurs = ((datetime.today()) - timedelta(days = 1)).date()
            # date_energyhurs = '2023-12-28'
            energy = []; cummulative_energy = 0
            for i in range(1,25):
                hour = 'mth'+str(i)+'ec'
                try:
                   hourdata = (round(Masterdatatable.objects.filter(mtdate = date_energyhurs, mtmtrname = machine['amMachinename']).values(hour)[0][hour], 1))
                   cummulative_energy = cummulative_energy + hourdata
                except:
                   hourdata = 0
                   cummulative_energy = cummulative_energy + hourdata
                energy.append(hourdata)
            # print(energy)
            ############################## HOURLY PRODUCTION REPORT ####################################
            # print(shift_start, shift_end)
            for col_width in range(1, 13+1):
                work_sheet.col(col_width).width = 5300
            for row_width in range(1, 6):
                work_sheet.row(row_width).height_mismatch  = True
                work_sheet.row(row_width).height = 380
            r=1
            c=1
            work_sheet.write_merge(r, r+1, c, c+9,('HOURLY PRODUCTION REPORT-INJECTION MOULDING-IMG'),style3)
            
            r=3
            c=1
            work_sheet.write(r,  c,  None ,style_bold)

            r=4
            c=1
            work_sheet.write_merge(r, r+1, c, c,'MOLD NAME', style_bold)

            r=3
            c=2
            Date = ((datetime.today()).date() - timedelta(days = 1))
            work_sheet.write_merge(r, r, c, c+1, ('DATE -   '+ str(Date)),style_bold)

            r=4
            c=2
            work_sheet.write_merge(r, r, c, c+1, 'TIME',style_bold)

            r=5
            c=2
            work_sheet.write(r, c, 'FROM', style_bold)
            work_sheet.write(r, c+1, 'TO', style_bold)
            # work_sheet.write(r-2, c+2, None, style_bold)
            work_sheet.write_merge(r-1, r, c+2, c+2, 'CYCLE TIME ACTUAL (Minutes)', style_bold)
            work_sheet.write_merge(r-2, r-2, c+2, c+5, 'SHIFT -' + 'A B C', style_bold)
            work_sheet.write_merge(r-1, r, c+3, c+3, 'TOTAL SHOTS', style_bold)
            work_sheet.write_merge(r-1, r, c+4, c+4, 'GOOD PATRS', style_bold)
            # work_sheet.write(r-2, c+2, None, style_bold)
            work_sheet.col(c+5).width = 3000
            work_sheet.write_merge(r-1, r, c+5, c+5, 'TOTAL PART WEIGHT (Grams)', style_bold)
            work_sheet.write_merge(r-2, r-2, c+6, c+7,  None, style_bold)
            work_sheet.write_merge(r-1, r, c+6, c+6, 'ENERGY CONS', style_bold)
            work_sheet.write_merge(r-1, r, c+7, c+7, 'SEC', style_bold)
            work_sheet.write(r-2, c+8, None, style_bold)
            work_sheet.col(c+8).width = 4500
            work_sheet.write_merge(r-1, r, c+8, c+8, 'MACHINE STOP REASON', style_bold)
            ##
            # Get the from time, to time, total parts, good parts, part weight, mould name, stop reason
            reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
            goodpart_kg = []; reason_list = []; machine_stopreason = '-'
            energyindex = 0; totalweight = 0; cummulative_runhour = 0; rejection_count = 0; cummulative_shots = 0; cummulative_goodparts = 0
            for hour in hrsArray:
                mould_name = [];mould_list=[]; part_list=[]; reason_list = []; sec_list = []; sec = 0; totalshots_list = []; goodpart_list = []; runhour = 0; runhour_list = []
                # print(hour)
                date = hour['date']
                fromTime = hour['fromtime']
                toTime = hour['totime']
                # print(date, fromTime, toTime)
                # try:
                distinctMould = list(ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = machine['amMachinename'], ProductionCountActual__gt = 0, MachineState = 1).values( 'Mouldname_id').distinct())
                # print(distinctMould)
                # print("totalshots :", totalshots)
                # except:
                    # totalshots = 0
                if distinctMould !=  []:
                    for mould in distinctMould:
                        id = mould['Mouldname_id']
                        mouldname = Mouldmodel.objects.get(id = id).Mouldname
                        weight = Mouldmodel.objects.get(id = id).weight
                        mould_list.append(mouldname)
                        part_list .append(str(int(weight)))
                        # print(weight)
                        totalshots_value = ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = machine['amMachinename'], ProductionCountActual__gt = 0, MachineState = 1, Mouldname_id = id).count()
                        cummulative_shots = totalshots_value + cummulative_shots
                        totalshots_list.append(str(totalshots_value))
                        try:
                            runhour_ = ProductionTable.objects.filter(date = date, time__range=(fromTime, toTime), Machinename = machine['amMachinename'], MachineState = 1, Mouldname_id = id).values('CycletimeActual', 'CycletimeSet')
                            # print(runhour)
                            for i in runhour_:
                                cycletime_set = i['CycletimeSet']
                                cycletime_actual = i['CycletimeActual']
                                # print("CycletimeActual",cycletime_actual, "CycletimeSet", cycletime_set)
                                if int(cycletime_actual) in range(1, int(cycletime_set * 2)+1):
                                #    print("CycletimeActual",cycletime_actual, "CycletimeSet", cycletime_set)
                                    cummulative_runhour = cummulative_runhour + int(cycletime_actual)
                                else:
                                    rejection_count = rejection_count + 1
                            runhour_value = round(cummulative_runhour / 60)
                            runhour_list.append(str(runhour_value))
                            # print("totalshots :", totalshots, "runhour :", runhour, "rejectioncount :", rejection_count)
                        except:
                            runhour_value = 0
                            runhour_list.append(str(runhour_value))
                            rejection_count = 0
                        goodparts_value = abs(totalshots_value - rejection_count)
                        cummulative_goodparts = goodparts_value + cummulative_goodparts
                        goodpart_list.append(str(goodparts_value))
                        totalweight = (ProductionTable.objects.filter(date=date, time__range=(fromTime, toTime), Machinename = machine['amMachinename'], ProductionCountActual__gt = 0, Mouldname__id = id, MachineState = 1).count()) * weight
                        try:
                            sec_value = round(energy[energyindex]/(totalweight/1000), 2)
                        except:
                            sec_value = 0
                        sec_list.append(str(sec_value))
                        cummulative_runhour = 0
                        
                    mould_name = ', '.join(mould_list)
                    part_weight = ', '.join(part_list)
                    # if len(part_weight) <= 5:
                    #     part_weight = int(part_weight)
                    sec = ', '.join(sec_list)
                    # if len(sec) <= 5:
                    #     part_weight = int(sec)
                    totalshots = ', '.join(totalshots_list)
                    # if len(totalshots) <= 5:
                    #     part_weight = int(totalshots)
                    goodparts = ', '.join(goodpart_list)
                    # if len(goodparts) <= 5:
                    #     part_weight = int(goodparts)
                    runhour = ', '.join(runhour_list)
                    # if len(runhour) <= 5:
                    #     part_weight = int(runhour)

                    # except:
                    #     totalshots = 0
                    #     goodparts = 0
                    #     sec = 0
                    #     mould_name = '-'
                    #     part_weight = 0
                    #     totalweight = 0

                else:
                    totalshots = 0
                    goodparts = 0
                    sec = 0
                    mould_name = '-'
                    part_weight = 0
                    totalweight = 0
                    runhour = 0

                # print("runhour :", runhour)
                # print(energy[energyindex])
                
                # print(date, fromTime, toTime, machine['amMachinename'])
                break_down = list(breakdown.objects.filter(date = str(date), time__range=(fromTime, toTime), Machinename = machine['amMachinename'], MachineState = 1).values('date','time', 'MachineState', 'primaryreason').order_by('id'))
                # print(break_down)
                reasons = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
                if list(break_down) != []:
                    # print(break_down)
                    for dat0 in range(0, len(break_down)):
                        if break_down[dat0]['MachineState'] == 0:
                            if break_down[dat0-1]['MachineState'] !=0:
                                for dat1 in range(dat0, len(break_down)):
                                    if break_down[dat1]['MachineState'] == 1:
                                        starttime =  break_down[dat0]['date'] + ' ' + break_down[dat0]['time']
                                        endtime   =  break_down[dat1]['date'] + ' ' + break_down[dat1]['time']
                                        frm_time = datetime.strptime(starttime, '%Y-%m-%d %H:%M:%S')
                                        to_time  = datetime.strptime(endtime, '%Y-%m-%d %H:%M:%S')
                                        idleminutes = (to_time - frm_time).total_seconds()
                                        if idleminutes >= 300 and break_down[dat1]['primaryreason'] != 0:
                                            # minutes = round((int(idleminutes)/60), 2)
                                            reason_list.append(reasons[break_down[dat1]['primaryreason']])
                                        break
                if reason_list != []:
                    machine_stopreason = ', '.join(reason_list)
                else:
                    machine_stopreason = '-'
                
                excel_map.append({"mould_name":mould_name, "from_time":fromTime,"to_time":toTime, "Run_Hour":runhour, "total_shots":(totalshots), "Goodparts":(goodparts),  "part_weight":(part_weight), "energy":energy[energyindex], "SEC":(sec), "stop_reason": machine_stopreason})
                energyindex +=1
                cummulative_runhour = 0; rejection_count = 0
            ## Mapping Excel Sheet
            # print("excel map")
            row = 6; col = 0
            for data_excel in excel_map:
                work_sheet.row(row).height_mismatch  = True
                work_sheet.row(row).height = 370
                work_sheet.write(row, col+1, data_excel['mould_name'], style1) 
                work_sheet.write(row, col+2, data_excel['from_time'], style1)
                work_sheet.write(row, col+3, data_excel['to_time'], style1)
                work_sheet.write(row, col+4, data_excel['Run_Hour'], style1)
                work_sheet.write(row, col+5, data_excel['total_shots'], style1)
                work_sheet.write(row, col+6, data_excel['Goodparts'], style1)
                work_sheet.write(row, col+7, data_excel['part_weight'], style1)
                work_sheet.write(row, col+8, data_excel['energy'], style1)
                work_sheet.write(row, col+9, data_excel['SEC'], style1)
                work_sheet.write(row, col+10, data_excel['stop_reason'], style1)
                # cummulative_shots = data_excel['total_shots'] + cummulative_shots ; cummulative_goodparts = data_excel['Goodparts'] + cummulative_goodparts
                row += 1
            col =  1
            work_sheet.row(row).height_mismatch  = True
            work_sheet.row(row).height = 370
            work_sheet.write_merge(row, row, col, col+3, 'Total', style_bold2)
            work_sheet.write(row, col+4, cummulative_shots, style_bold2)
            work_sheet.write(row, col+5, cummulative_goodparts, style_bold2)
            work_sheet.write(row, col+6, None, style_bold2)
            work_sheet.write(row, col+7, cummulative_energy, style_bold2)
            work_sheet.write(row, col+8, None, style_bold2)
            work_sheet.write(row, col+9, None, style_bold2)
        hourly_report()
        # break
    return "report created"

    # savepath = os.path.join(BASE_DIR,'Report','ProductionReport.xls')
    # work_book.save(savepath)    
    # return savepath  

# @periodic_task(run_every=crontab(hour=6, minute=5))
# @csrf_exempt
def sendmail():
    print("Report generating")
    savepath = enryhrs()
    # print(savepath)
    # 'Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Mohankumar.Chinnasamy@motherson.com;praveen.srinivasan@motherson.com;Gokulraj.Rajasekaran@motherson.com;Gokul.Annadurai@motherson.com;u1ppc@int.motherson.com'
    tomail='Balaji.Marikkannu@motherson.com;maintenanceUnit1.MateChennai@motherson.com;Mohankumar.Chinnasamy@motherson.com;praveen.srinivasan@motherson.com;Gokulraj.Rajasekaran@motherson.com;Gokul.Annadurai@motherson.com;u1ppc@int.motherson.com;Sivakumar.Radhakrishnan@motherson.com;Elayaraja.Muthukrishnan@motherson.com;jagadeesang@int.motherson.com;imgu1@int.motherson.com;processengineeringu1.matechennai@motherson.com'
    sub='Houlry Wise and Rejection report for R-Connect'
    message = '''Dear Team, <br> 
                    Please find the Hourlywise and Rejection report for MATE UNIT - 1. 
                    <br>
                    <br>
                Regards, <br>
                R-Connect Team. 
                <br>
                <br> 
                Note: This is an system generated mail.'''
    msg = MIMEMultipart('mixed')
    msg['Subject'] = sub
    msg['From'] = "R-Connect <no-reply@rconnect.com>"
    msg['To'] = tomail
    part2 = MIMEText(message, 'html')
    msg.attach(part2)
    part = MIMEBase('application','octet-stream')
    part.set_payload(open(savepath, "rb").read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="R-ConnectReport.xls"')
    msg.attach(part)
    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
    smtpObj.sendmail('R-Connect <no-reply@rconnect.com>',tomail.split(';'),msg.as_string())
    smtpObj.quit()
    print('Mail send successfully')
    print("Mail Sent to ",tomail)
    return HttpResponse (" Hourly Wise and Rejection Report is Generated")
