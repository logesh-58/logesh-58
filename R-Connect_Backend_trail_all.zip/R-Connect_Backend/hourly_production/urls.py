from django.urls import path , include
from hourly_production import shotwisereport, views, tasks, dailyenrgyhrs_report, PowerUP, SEC, SEC_AUG, NEW_REPORT, PowerUP_new, reporttesting, totalday

urlpatterns=[
    path('test/', tasks.sendmail, name = 'shift_wise'),
    # path('enrgyhrs/',dailyenrgyhrs_report.sendmail),
    path('enrgyhrs/',dailyenrgyhrs_report.enryhrs),
    # path('nenrgyhrs/',NEW_REPORT.report),             ###new
    path('nenrgyhrs/',reporttesting.report),             ###new
    path('cenrgyhrs/',totalday.enryhrs),      ###new
    path('power/',PowerUP.powerutilization),
    path('mouldname/', PowerUP.mould_name),
    path('mouldenergy/', PowerUP_new.insertpower),
    path('pup/', PowerUP_new.power_value),
    path('secvalue/', SEC_AUG.sec_value),
    # path('sectable/', SEC_AUG.sec_value_table)
]