from django.shortcuts import render
from django.http.response import JsonResponse
import json
from django.views.decorators.csrf import csrf_exempt
from meter_data.models import Masterdatatable
from general_settings.models import Timingtable

# Create your views here.
@csrf_exempt
def VirtualHourly(request):
    plntname=request.GET['plantname']
    timerow = Timingtable.objects.get(ttplntname=plntname)
    shift1time=timerow.tts1time
    # for i in timerow:
    #     shift1time=i['tts1time']
    # print(shift1time)
    if request.method == "POST":
        plntname=request.GET['plantname']
        data = json.loads(request.body)
        H_From = data["hvr_from"]
        H_To = data["hvr_to"]
        H_MName = data["hvr_mname"]
        # print(H_From,H_To,H_MName)
        MeterRow = Masterdatatable.objects.filter(mtdate__range=(H_From,H_To),mtmtrname=H_MName).order_by('mtdate')
        # print(MeterRow)
        hrly_data=[]
        heatmapArray = []
        for obj in MeterRow:
            print(obj.mtdate)
            # print(obj.mth1ec)
            my_dict={}
            for i in range(1,25):
                attr = "mth"+str(i)+"ec"
                if getattr(obj,attr) is None:
                    my_dict[i]=0.0
                else:
                    my_dict[i]=round(getattr(obj,attr),2)
            # print(my_dict)
            hrly_data.append({"Date":obj.mtdate,"h1":my_dict[1],"h2":my_dict[2],"h3":my_dict[3],"h4":my_dict[4]
                              ,"h5":my_dict[5],"h6":my_dict[6],"h7":my_dict[7],"h8":my_dict[8],"h9":my_dict[9]
                              ,"h10":my_dict[10],"h11":my_dict[11],"h12":my_dict[12],"h13":my_dict[13]
                              ,"h14":my_dict[14],"h15":my_dict[15],"h16":my_dict[16],"h17":my_dict[17],"h18":my_dict[18]
                              ,"h19":my_dict[19],"h20":my_dict[20],"h21":my_dict[21],"h22":my_dict[22]
                              ,"h23":my_dict[23],"h24":my_dict[24]})
            
            heatmapdata = []
            for i in range(1,25):
                heatmapdata.append(my_dict[i])
            heatmap_dict = {
                'Date': obj.mtdate,
                'Data': heatmapdata
            }
            heatmapArray.append(heatmap_dict)
        # print(hrly_data)
        return JsonResponse({"S1_Time":shift1time,"Hourly_Data":hrly_data, "heatmap": heatmapArray},safe=False)