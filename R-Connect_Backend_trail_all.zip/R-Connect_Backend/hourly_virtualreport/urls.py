from django.conf.urls import url
from hourly_virtualreport import views

urlpatterns=[
    url('virtualhourly/',views.VirtualHourly,name='virtualhourlyreport'),   
    # url('data/',views.ewoncheck,name='ewon_data') 
]