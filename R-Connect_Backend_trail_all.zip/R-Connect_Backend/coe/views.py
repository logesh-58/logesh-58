from django.shortcuts import render
from django.http import HttpResponse
from django.http.response import JsonResponse
from source_management.models import AddSource
from meter_data.models import Masterdatatable
from django.db.models.aggregates import Sum
import datetime
from datetime import timedelta
from django.views.decorators.csrf import csrf_exempt
import json
from costestimator.models import Cost_Solar , Cost_EB , Cost_DG
from peakhour_dashboard.models import PeakConfig
from datetime import datetime

# Create your views here.

@csrf_exempt
def costs(request):
    if request.method == 'POST':
            # data = json.loads(request.body)
            date = request.GET['date'] ; src_name = request.GET['sourcename']
            list = []
            if src_name == "DG":
                Masterdata_DG = Masterdatatable.objects.filter(mtdate = date ,  mtsrcname = src_name).values()
                DG_table = Cost_DG.objects.filter(dg_date =  date).values('dg_lit_cons','dg_desc')
                mth1ec_cst = 0 ; mth2ec_cst = 0; mth3ec_cst = 0; mth4ec_cst = 0; mth5ec_cst = 0; mth6ec_cst = 0; mth7ec_cst = 0; mth8ec_cst = 0; mth9ec_cst = 0; mth10ec_cst = 0
                mth11ec_cst = 0; mth12ec_cst = 0; mth13ec_cst = 0; mth14ec_cst = 0; mth15ec_cst = 0; mth16ec_cst = 0 ;mth17ec_cst = 0; mth18ec_cst = 0; mth19ec_cst = 0; mth20ec_cst = 0
                mth21ec_cst = 0; mth21ec_cst = 0; mth22ec_cst = 0; mth23ec_cst = 0;  mth24ec_cst = 0 
                for cst in DG_table:
                    DG_cst = cst['dg_lit_cons']
                    DG_Meter = cst['dg_desc']
                    for i in Masterdata_DG:
                        if DG_Meter == i['mtmtrname']:
                            mth1ec = i['mth1ec'] 
                            mth1ec_cst =  mth1ec*(i['mtenergycons'] / DG_cst) + mth1ec_cst
                            mth2ec = i['mth2ec']
                            mth2ec_cst =  mth2ec * (i['mtenergycons'] / DG_cst)  + mth2ec_cst
                            mth3ec = i['mth3ec']
                            mth3ec_cst =  mth3ec * (i['mtenergycons'] / DG_cst) + mth3ec_cst
                            mth4ec = i['mth4ec']
                            mth4ec_cst =  mth4ec * (i['mtenergycons'] / DG_cst) + mth4ec_cst
                            mth5ec = i['mth5ec']
                            mth5ec_cst =  mth5ec * (i['mtenergycons'] / DG_cst) + mth5ec_cst
                            mth6ec = i['mth6ec']
                            mth6ec_cst =  mth6ec * (i['mtenergycons'] / DG_cst)+ mth6ec_cst
                            mth7ec = i['mth7ec']
                            mth7ec_cst =  mth7ec * (i['mtenergycons'] / DG_cst)+ mth7ec_cst
                            mth8ec = i['mth8ec']
                            mth8ec_cst =  mth8ec *(i['mtenergycons'] / DG_cst)+ mth8ec_cst
                            mth9ec = i['mth9ec']
                            mth9ec_cst =  mth9ec * (i['mtenergycons'] / DG_cst) + mth9ec_cst
                            mth10ec = i['mth10ec']
                            mth10ec_cst = mth10ec *(i['mtenergycons'] / DG_cst) + mth10ec_cst
                            mth11ec = i['mth11ec']
                            mth11ec_cst = mth11ec * (i['mtenergycons'] / DG_cst) + mth11ec_cst
                            mth12ec = i['mth12ec']
                            mth12ec_cst = mth12ec * (i['mtenergycons'] / DG_cst)+ mth12ec_cst
                            mth13ec = i['mth13ec']
                            mth13ec_cst = mth13ec * (i['mtenergycons'] / DG_cst) + mth13ec_cst
                            mth14ec = i['mth14ec']
                            mth14ec_cst = mth14ec * (i['mtenergycons'] / DG_cst) + mth14ec_cst
                            mth15ec = i['mth15ec']
                            mth15ec_cst = mth15ec * (i['mtenergycons'] / DG_cst) + mth15ec_cst
                            mth16ec = i['mth16ec']
                            mth16ec_cst = mth16ec * (i['mtenergycons'] / DG_cst) + mth16ec_cst
                            mth17ec = i['mth17ec']
                            mth17ec_cst = mth17ec * (i['mtenergycons'] / DG_cst)+ mth17ec_cst
                            mth18ec = i['mth18ec']
                            mth18ec_cst = mth18ec * (i['mtenergycons'] / DG_cst) + mth18ec_cst
                            mth19ec = i['mth19ec']
                            mth19ec_cst = mth19ec * (i['mtenergycons'] / DG_cst) + mth19ec_cst
                            mth20ec = i['mth20ec']
                            mth20ec_cst = mth20ec * (i['mtenergycons'] / DG_cst) + mth20ec_cst
                            mth21ec = i['mth21ec']
                            mth21ec_cst = mth21ec * (i['mtenergycons'] / DG_cst) + mth21ec_cst
                            mth22ec = i['mth22ec']
                            mth22ec_cst = mth22ec * (i['mtenergycons'] / DG_cst) + mth22ec_cst
                            mth23ec = i['mth23ec']
                            mth23ec_cst = mth23ec * (i['mtenergycons'] / DG_cst) + mth23ec_cst
                            mth24ec = i['mth24ec']
                            mth24ec_cst = mth24ec * (i['mtenergycons'] / DG_cst) + mth24ec_cst

            if src_name == 'Solar Energy':
                Masterdata_Solar = Masterdatatable.objects.filter(mtdate = date ,  mtsrcname = src_name).values()
                try:
                    solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
                    print(solar_cst)
                except:
                    solar_cst = 0
                for i in Masterdata_Solar:  
                    mth1ec = i['mth1ec']
                    mth1ec_cst = mth1ec * solar_cst
                    mth2ec = i['mth2ec']
                    mth2ec_cst = mth2ec * solar_cst
                    mth3ec = i['mth3ec']
                    mth3ec_cst = mth3ec * solar_cst
                    mth4ec = i['mth4ec']
                    mth4ec_cst = mth4ec * solar_cst
                    mth5ec = i['mth5ec']
                    mth5ec_cst = mth5ec * solar_cst
                    mth6ec = i['mth6ec']
                    mth6ec_cst = mth6ec * solar_cst
                    mth7ec = i['mth7ec']
                    mth7ec_cst = mth7ec * solar_cst
                    mth8ec = i['mth8ec']
                    mth8ec_cst = mth8ec * solar_cst
                    mth9ec = i['mth9ec']
                    mth9ec_cst = mth9ec * solar_cst
                    mth10ec = i['mth10ec']
                    mth10ec_cst = mth10ec * solar_cst
                    mth11ec = i['mth11ec']
                    mth11ec_cst = mth11ec * solar_cst
                    mth12ec = i['mth12ec']
                    mth12ec_cst = mth12ec * solar_cst
                    mth13ec = i['mth13ec']
                    mth13ec_cst = mth13ec * solar_cst
                    mth14ec = i['mth14ec']
                    mth14ec_cst = mth14ec * solar_cst
                    mth15ec = i['mth15ec']
                    mth15ec_cst = mth15ec * solar_cst
                    mth16ec = i['mth16ec']
                    mth16ec_cst = mth16ec * solar_cst
                    mth17ec = i['mth17ec']
                    mth17ec_cst = mth17ec * solar_cst
                    mth18ec = i['mth18ec']
                    mth18ec_cst = mth18ec * solar_cst
                    mth19ec = i['mth19ec']
                    mth19ec_cst = mth19ec * solar_cst
                    mth20ec = i['mth20ec']
                    mth20ec_cst = mth20ec * solar_cst
                    mth21ec = i['mth21ec']
                    mth21ec_cst = mth21ec * solar_cst
                    mth22ec = i['mth22ec']
                    mth22ec_cst = mth22ec * solar_cst
                    mth23ec = i['mth23ec']
                    mth23ec_cst = mth23ec * solar_cst
                    mth24ec = i['mth24ec']
                    mth24ec_cst = mth24ec * solar_cst

            if src_name == 'Transformer1':
                    mth1ec_cst = 0 ; mth2ec_cst = 0; mth3ec_cst = 0; mth4ec_cst = 0; mth5ec_cst = 0; mth6ec_cst = 0; mth7ec_cst = 0; mth8ec_cst = 0; mth9ec_cst = 0; mth10ec_cst = 0
                    mth11ec_cst = 0; mth12ec_cst = 0; mth13ec_cst = 0; mth14ec_cst = 0; mth15ec_cst = 0; mth16ec_cst = 0 ;mth17ec_cst = 0; mth18ec_cst = 0; mth19ec_cst = 0; mth20ec_cst = 0
                    mth21ec_cst = 0; mth21ec_cst = 0; mth22ec_cst = 0; mth23ec_cst = 0;  mth24ec_cst = 0 
                    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
                    session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")
                    Masterdata_tranformer  = Masterdatatable.objects.filter(mtdate = date ,mtcategory="Secondary", mtgrpname='Incomer', mtsrcname = src_name).values()
                    for ms in Masterdata_tranformer:
                        for w in ms:
                            if w == "mth1ec":
                                mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                                count_1 = 1
                                # print(mth1ec)
                            if w == "mth2ec":
                                mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                                count_2 = 2
                                # print(mth2ec)
                            if w == "mth3ec":
                                mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                                count_3 = 3
                                # print(mth3ec)
                            if w == "mth4ec":
                                mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                                count_4 = 4
                                # print(mth4ec)
                            if w == "mth5ec":
                                mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                                count_5 = 5
                                # print(mth5ec)
                            if w == "mth6ec":
                                mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                                count_6 = 6
                                # print(mth6ec)
                            if w == "mth7ec":
                                mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                                count_7 = 7
                                # print(mth7ec)
                            if w == "mth8ec":
                                mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                                count_8 = 8
                                # print(mth8ec)
                            if w == "mth9ec":
                                mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                                count_9 = 9
                                # print(mth9ec)
                            if w == "mth10ec":
                                mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                                count_10 = 10
                                # print(mth10ec)
                            if w == "mth11ec":
                                mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                                count_11 = 11
                                # print(mth11ec)
                            if w == "mth12ec":
                                mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                                count_12 = 12
                                # print(mth12ec)
                            if w == "mth13ec":
                                mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                                count_13 = 13
                                # print(mth13ec)
                            if w == "mth14ec":
                                mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                                count_14 = 14
                                # print(mth14ec)
                            if w == "mth15ec":
                                mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                                count_15 = 15
                                # print(mth15ec)
                            if w == "mth16ec":
                                mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                                count_16 = 16
                                # print(mth16ec)
                            if w == "mth17ec":
                                mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                                count_17 = 17
                                # print(mth17ec)
                            if w == "mth18ec":
                                mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                                count_18 = 18
                                # print(mth18ec)
                            if w == "mth19ec":
                                mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                                count_19 = 19
                                # print(mth19ec)
                            if w == "mth20ec":
                                mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                                count_20 = 20
                                # print(mth20ec)
                            if w == "mth21ec":
                                mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                                count_21 = 21
                                # print(mth21ec)
                            if w == "mth22ec":
                                mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                                count_22 = 22
                                # print(mth22ec)
                            if w == "mth23ec":
                                mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                                count_23 = 23
                                # print(mth23ec)
                            if w == "mth24ec":
                                mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                                count_24 = 24
                                # print(mth24ec)
                    # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
                    pkstr = 0
                    pkend =  0 
                    vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
                    vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0; cost_eb = 0
                    for e in session_config:
                        pkstart = e['pkstart']
                        datetime_objects = datetime.combine(datetime.now() , pkstart) 
                        incr_onehur = datetime_objects + timedelta(hours=1) 
                        pkstart =  incr_onehur.time()
                        if pkstart ==  mth1ec:
                            # print("ps_mth1ec :",e["pkstart"])
                            pkstr = count_1
                        if pkstart == mth2ec:
                            # print("ps_mth2ec :",e['pkstart'])
                            pkstr = count_2
                        if pkstart== mth3ec:
                            # print("ps_mth3ec :",e['pkstart'])
                            pkstr = count_3
                        if pkstart == mth4ec:
                            # print("ps_mth4ec :",e['pkstart'])
                            pkstr = count_4
                        if pkstart == mth5ec:
                            # print("ps_mth5ec :",e['pkstart'])
                            pkstr = count_5
                        if pkstart == mth6ec:
                            # print("ps_mth6ec :",i['pkstart'])
                            pkstr = count_6
                        if pkstart == mth7ec:
                            # print("ps_mth7ec :",i['pkstart'])
                            pkstr = count_7
                        if pkstart == mth8ec:
                            # print("ps_mth8ec :",i['pkstart'])
                            pkstr = count_8
                        if pkstart == mth9ec:
                            # print("ps_mth9ec :",i['pkstart'])
                            pkstr = count_9
                        if pkstart == mth10ec:
                            # print("ps_mth10ec :",i['pkstart'])
                            pkstr = count_10
                        if pkstart == mth11ec:
                            # print("ps_mth11ec :",i['pkstart'])
                            pkstr = count_11
                        if pkstart == mth12ec:
                            # print("ps_mth12ec :",i['pkstart'])
                            pkstr = count_12
                        if pkstart == mth13ec:
                            # print("ps_mth13ec :",i['pkstart'])
                            pkstr = count_13
                        if pkstart == mth14ec:
                            # print("ps_mth14ec :",i['pkstart'])
                            pkstr = count_14
                        if pkstart == mth15ec:
                            # print("ps_mth15ec :",i['pkstart'])
                            pkstr = count_15
                        if pkstart == mth16ec:
                            # print("ps_mth16ec :",i['pkstart'])
                            pkstr = count_16
                        if pkstart == mth17ec:
                            # print("ps_mth17ec :",i['pkstart'])
                            pkstr = count_17
                        if pkstart == mth18ec:
                            # print("ps_mth18ec :",i['pkstart'])
                            pkstr = count_18
                        if pkstart == mth19ec:
                            # print("ps_mth19ec :",i['pkstart'])
                            pkstr = count_19 
                        if pkstart == mth20ec:
                            # print("ps_mth20ec :",i['pkstart'])
                            pkstr = count_20
                        if pkstart == mth21ec:
                            # print("ps_mth21ec :",i['pkstart'])
                            pkstr = count_21
                        if pkstart == mth22ec:
                            # print("ps_mth22ec :",i['pkstart'])
                            pkstr = count_22
                        if pkstart == mth23ec:
                            # print("ps_mth23ec :",i['pkstart'])
                            pkstr = count_23
                        if pkstart == mth24ec:
                            # print("ps_mth24ec :",i['pkstart'])
                            pkstr = count_2

                        #pkend
                        if e['pkend'] == mth1ec:
                            # print("pe_mth1ec :" , i['pkend'])
                            pkend = count_1
                        if e['pkend'] == mth2ec:
                            # print("pe_mth2ec :" , i['pkend'])
                            pkend = count_2
                        if e['pkend'] == mth3ec:
                            # print("pe_mth3ec :" , i['pkend'])
                            pkend = count_3
                        if e['pkend'] == mth4ec:
                            # print("pe_mth4ec :" , i['pkend'])
                            pkend = count_4
                        if e['pkend'] == mth5ec:
                            # print("pe_mth5ec :", i['pkend'])
                            pkend = count_5
                        if e['pkend'] == mth6ec:
                            # print("pe_mth6ec :", i['pkend'])
                            pkend = count_6
                        if e['pkend'] == mth7ec:
                            # print("pe_mth7ec :", i['pkend'])
                            pkend = count_7
                        if e['pkend'] == mth8ec:
                            # print("pe_mth8ec :", i['pkend'])
                            pkend = count_8
                        if e['pkend'] == mth9ec:
                            # print("pe_mth9ec :", i['pkend'])
                            pkend = count_9
                        if e['pkend'] == mth10ec:
                            # print("pe_mth10ec :", i['pkend'])
                            pkend = count_10
                        if e['pkend'] == mth11ec:
                            # print("pe_mth11ec :", i['pkend'])
                            pkend = count_11
                        if e['pkend'] == mth12ec:
                            # print("pe_mth12ec :", i['pkend'])
                            pkend = count_12
                        if e['pkend'] == mth13ec:
                            # print("pe_mth13ec :", i['pkend'])
                            pkend = count_13 
                        if e['pkend'] == mth14ec:
                            # print("pe_mth14ec :", i['pkend'])
                            pkend = count_14
                        if e['pkend'] == mth15ec:
                            # print("pe_mth15ec :", i['pkend'])
                            pkend = count_15 
                        if e['pkend'] == mth16ec:
                            # print("pe_mth16ec :", i['pkend'])
                            pkend = count_16
                        if e['pkend'] == mth17ec:
                            # print("pe_mth17ec :", i['pkend'])
                            pkend = count_17
                        if e['pkend'] == mth18ec:
                            # print("pe_mth18ec :", i['pkend'])
                            pkend = count_18 
                        if e['pkend'] == mth19ec:
                            # print("pe_mth19ec :", i['pkend'])
                            pkend = count_19 
                        if e['pkend'] == mth20ec:
                            # print("pe_mth20ec :", i['pkend'])
                            pkend = count_20
                        if e['pkend'] == mth21ec:
                            # print("pe_mth21ec :", i['pkend'])
                            pkend = count_21
                        if e['pkend'] == mth22ec:
                            # print("pe_mth22ec :", i['pkend'])
                            pkend = count_22 
                        if e['pkend'] == mth23ec:
                            # print("pe_mth23ec :", i['pkend'])
                            pkend = count_23 
                        if e['pkend'] == mth24ec:
                            # print("pe_mth24ec :", i['pkend'])
                            pkend = count_24 

                        # print(val , val_2)
                        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
                        m24ec='' 
                        # print(pkstr, pkend)
                        for n in range(pkstr, pkend):
                            if n == 1:
                                m1ec = 'mth1ec'
                                # print(m1ec)
                            if n == 2:
                                m2ec = 'mth2ec'
                                # print(m2ec)
                            if n == 3:
                                m3ec = 'mth3ec'
                                # print(m3ec)      
                            if n == 4:
                                m4ec = 'mth4ec'
                                # print(m4ec)
                            if n == 5:
                                m5ec = 'mth5ec'
                                # print(m5ec)
                            if n == 6:
                                m6ec = 'mth6ec'
                                # print(m6ec)
                            if n == 7:
                                m7ec = 'mth7ec'
                                # print(m7ec)
                            if n == 8:
                                m8ec = 'mth8ec'
                                # print(m8ec)
                            if n == 9:
                                m9ec = 'mth9ec'
                                # print(m9ec)
                            if n == 10:
                                m10ec = 'mth10ec'
                                # print(m10ec)
                            if n == 11:
                                m11ec = 'mth11ec'
                                # print(m11ec)
                            if n == 12:
                                m12ec = 'mth12ec'
                                # print(m12ec)
                            if n == 13:
                                m13ec = 'mth13ec'
                                # print(m13ec)
                            if n == 14:
                                m14ec = 'mth14ec'
                                # print(m14ec)
                            if n == 15:
                                m15ec = 'mth15ec'
                                # print(m15ec)
                            if n == 16:
                                m16ec = 'mth16ec'
                                # print(m16ec)
                            if n == 17:
                                m17ec = 'mth17ec'
                                # print(m17ec)
                            if n == 18:
                                m18ec = 'mth18ec'
                                # print(m18ec)
                            if n == 19:
                                m19ec = 'mth19ec'
                                # print(m19ec)
                            if n == 20:
                                m20ec = 'mth20ec'
                                # print(m20ec)
                            if n == 21:
                                m21ec = 'mth21ec'
                                # print(m21ec)
                            if n == 22:
                                m22ec = 'mth22ec'
                                # print(m22ec)
                            if n == 23:
                                m23ec = 'mth23ec'
                                # print(m23ec)
                            if n == 24:
                                m24ec = 'mth24ec'
                                # print(m24ec)
            
                        cost = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
                        for s in cost:
                            cost_eb = s['EB_SessionCost']
                        # print(e['pkstatus'])    
                        for q in Masterdata_tranformer:
                            # print(q['mtmtrname'])
                            for z in q:
                                # print(z)
                                if z == m1ec:
                                   vl_1  = q['mth1ec'] * cost_eb + vl_1 
                                if z == m2ec:
                                    vl_2 = q['mth2ec'] * cost_eb + vl_2  
                                if z == m3ec:
                                    vl_3 = q['mth3ec'] * cost_eb + vl_3 
                                if z == m4ec:
                                    vl_4  = q['mth4ec'] * cost_eb + vl_4
                                if z == m5ec:
                                    vl_5 = q['mth5ec'] * cost_eb + vl_5
                                if z == m6ec:
                                    vl_6 = q['mth6ec'] * cost_eb + vl_6 
                                if z == m7ec:
                                    vl_7 = q['mth7ec'] * cost_eb + vl_7
                                if z == m8ec:
                                    vl_8 = q['mth8ec'] * cost_eb + vl_8
                                if z == m9ec:
                                    vl_9 = q['mth9ec'] * cost_eb + vl_9
                                if z == m10ec:
                                    vl_10 = q['mth10ec'] * cost_eb + vl_10
                                if z == m11ec:
                                    vl_11 = q['mth11ec'] * cost_eb + vl_11
                                if z == m12ec:
                                    vl_12 = q['mth12ec'] * cost_eb + vl_12
                                if z == m13ec:
                                    vl_13 = q['mth13ec'] * cost_eb + vl_13
                                if z == m14ec:
                                    vl_14 = q['mth14ec'] * cost_eb + vl_14
                                if z == m15ec:
                                    vl_15 = q['mth15ec'] * cost_eb + vl_15
                                if z == m16ec:
                                    vl_16 = q['mth16ec'] * cost_eb + vl_16
                                if z == m17ec:
                                    vl_17 = q['mth17ec'] * cost_eb + vl_17
                                if z == m18ec:
                                    vl_18 = q['mth18ec'] * cost_eb + vl_18
                                if z == m19ec:
                                    vl_19 = q['mth19ec'] * cost_eb + vl_19
                                if z == m20ec:
                                    vl_20 = q['mth20ec'] * cost_eb + vl_20
                                if z == m21ec:
                                    vl_21 = q['mth21ec'] * cost_eb + vl_21
                                if z == m22ec:
                                    vl_22 = q['mth22ec'] * cost_eb + vl_22
                                if z == m23ec:
                                    vl_23 = q['mth23ec'] * cost_eb + vl_23
                                if z == m24ec:
                                    vl_24 = q['mth24ec'] * cost_eb + vl_24

                        mth1ec_cst = vl_1 ; mth2ec_cst = vl_2 ; mth3ec_cst = vl_3 ; mth4ec_cst = vl_4 ; mth5ec_cst = vl_5; mth6ec_cst = vl_6
                        mth7ec_cst = vl_7 ; mth8ec_cst = vl_8 ; mth9ec_cst = vl_9 ; mth10ec_cst = vl_10 ; mth11ec_cst = vl_11; mth12ec_cst = vl_12
                        mth13ec_cst = vl_13; mth14ec_cst = vl_14 ; mth15ec_cst = vl_15 ; mth16ec_cst = vl_16 ; mth17ec_cst = vl_17 ; mth18ec_cst = vl_18 
                        mth19ec_cst = vl_19; mth20ec_cst = vl_20 ; mth21ec_cst = vl_21 ; mth22ec_cst = vl_22 ; mth23ec_cst = vl_23 ; mth24ec_cst = vl_24 
            
            list.append(int(mth1ec_cst));list.append(int(mth2ec_cst));list.append(int(mth3ec_cst))
            list.append(int(mth4ec_cst));list.append(int(mth5ec_cst));list.append(int(mth6ec_cst))
            list.append(int(mth7ec_cst));list.append(int(mth8ec_cst));list.append(int(mth9ec_cst))
            list.append(int(mth10ec_cst));list.append(int(mth11ec_cst));list.append(int(mth12ec_cst))
            list.append(int(mth13ec_cst));list.append(int(mth14ec_cst));list.append(int(mth15ec_cst))
            list.append(int(mth16ec_cst));list.append(int(mth17ec_cst));list.append(int(mth18ec_cst))
            list.append(int(mth19ec_cst));list.append(int(mth20ec_cst));list.append(int(mth21ec_cst))
            list.append(int(mth22ec_cst));list.append(int(mth23ec_cst));list.append(int(mth24ec_cst))
            # print({"label":["06.00","07.00","08.00",
            #             "09.00","10.00","11.00","12.00",
            #             "13.00","14.00","15.00","16.00", 
            #             "17.00","18.00","19.00","20.00",
            #             "21.00","22.00","23.00","24.00",
            #             "01.00","02.00","03.00","04.00",
            #             "05.00"],"data":list})
            return JsonResponse ({"label":["06.00","07.00","08.00",
                        "09.00","10.00","11.00","12.00",
                        "13.00","14.00","15.00","16.00", 
                        "17.00","18.00","19.00","20.00",
                        "21.00","22.00","23.00","24.00",
                        "01.00","02.00","03.00","04.00",
                        "05.00"],"data":list} , safe=False)
            
    if request.method == 'GET':
        # data = json.loads(request.body)
        date = request.GET['date']
        list_cum = []
        srcname_dg = "DG"
        Masterdata_DG = Masterdatatable.objects.filter(mtdate = date ,  mtsrcname = srcname_dg).values()
        DG_table = Cost_DG.objects.filter(dg_date =  date).values('dg_lit_cons','dg_desc')
        mth1ec_cst = 0 ; mth2ec_cst = 0; mth3ec_cst = 0; mth4ec_cst = 0; mth5ec_cst = 0; mth6ec_cst = 0; mth7ec_cst = 0; mth8ec_cst = 0; mth9ec_cst = 0; mth10ec_cst = 0
        mth11ec_cst = 0; mth12ec_cst = 0; mth13ec_cst = 0; mth14ec_cst = 0; mth15ec_cst = 0; mth16ec_cst = 0 ;mth17ec_cst = 0; mth18ec_cst = 0; mth19ec_cst = 0; mth20ec_cst = 0
        mth21ec_cst = 0; mth21ec_cst = 0; mth22ec_cst = 0; mth23ec_cst = 0;  mth24ec_cst = 0 
        for cst in DG_table:
            DG_cst = cst['dg_lit_cons']
            DG_Meter = cst['dg_desc']
            for i in Masterdata_DG:
                if DG_Meter == i['mtmtrname']:
                    mth1ec = i['mth1ec'] 
                    mth1ec_cst =  mth1ec*(i['mtenergycons'] / DG_cst) + mth1ec_cst
                    mth2ec = i['mth2ec']
                    mth2ec_cst =  mth2ec * (i['mtenergycons'] / DG_cst)  + mth2ec_cst
                    mth3ec = i['mth3ec']
                    mth3ec_cst =  mth3ec * (i['mtenergycons'] / DG_cst) + mth3ec_cst
                    mth4ec = i['mth4ec']
                    mth4ec_cst =  mth4ec * (i['mtenergycons'] / DG_cst) + mth4ec_cst
                    mth5ec = i['mth5ec']
                    mth5ec_cst =  mth5ec * (i['mtenergycons'] / DG_cst) + mth5ec_cst
                    mth6ec = i['mth6ec']
                    mth6ec_cst =  mth6ec * (i['mtenergycons'] / DG_cst)+ mth6ec_cst
                    mth7ec = i['mth7ec']
                    mth7ec_cst =  mth7ec * (i['mtenergycons'] / DG_cst)+ mth7ec_cst
                    mth8ec = i['mth8ec']
                    mth8ec_cst =  mth8ec *(i['mtenergycons'] / DG_cst)+ mth8ec_cst
                    mth9ec = i['mth9ec']
                    mth9ec_cst =  mth9ec * (i['mtenergycons'] / DG_cst) + mth9ec_cst
                    mth10ec = i['mth10ec']
                    mth10ec_cst = mth10ec *(i['mtenergycons'] / DG_cst) + mth10ec_cst
                    mth11ec = i['mth11ec']
                    mth11ec_cst = mth11ec * (i['mtenergycons'] / DG_cst) + mth11ec_cst
                    mth12ec = i['mth12ec']
                    mth12ec_cst = mth12ec * (i['mtenergycons'] / DG_cst)+ mth12ec_cst
                    mth13ec = i['mth13ec']
                    mth13ec_cst = mth13ec * (i['mtenergycons'] / DG_cst) + mth13ec_cst
                    mth14ec = i['mth14ec']
                    mth14ec_cst = mth14ec * (i['mtenergycons'] / DG_cst) + mth14ec_cst
                    mth15ec = i['mth15ec']
                    mth15ec_cst = mth15ec * (i['mtenergycons'] / DG_cst) + mth15ec_cst
                    mth16ec = i['mth16ec']
                    mth16ec_cst = mth16ec * (i['mtenergycons'] / DG_cst) + mth16ec_cst
                    mth17ec = i['mth17ec']
                    mth17ec_cst = mth17ec * (i['mtenergycons'] / DG_cst)+ mth17ec_cst
                    mth18ec = i['mth18ec']
                    mth18ec_cst = mth18ec * (i['mtenergycons'] / DG_cst) + mth18ec_cst
                    mth19ec = i['mth19ec']
                    mth19ec_cst = mth19ec * (i['mtenergycons'] / DG_cst) + mth19ec_cst
                    mth20ec = i['mth20ec']
                    mth20ec_cst = mth20ec * (i['mtenergycons'] / DG_cst) + mth20ec_cst
                    mth21ec = i['mth21ec']
                    mth21ec_cst = mth21ec * (i['mtenergycons'] / DG_cst) + mth21ec_cst
                    mth22ec = i['mth22ec']
                    mth22ec_cst = mth22ec * (i['mtenergycons'] / DG_cst) + mth22ec_cst
                    mth23ec = i['mth23ec']
                    mth23ec_cst = mth23ec * (i['mtenergycons'] / DG_cst) + mth23ec_cst
                    mth24ec = i['mth24ec']
                    mth24ec_cst = mth24ec * (i['mtenergycons'] / DG_cst) + mth24ec_cst
        
        energycons_dg = (mth1ec_cst + mth2ec_cst + mth3ec_cst + mth4ec_cst + mth5ec_cst + mth6ec_cst + mth7ec_cst + mth8ec_cst + mth9ec_cst + mth10ec_cst +
                        mth11ec_cst + mth12ec_cst + mth13ec_cst + mth14ec_cst + mth15ec_cst + mth16ec_cst + mth17ec_cst + mth18ec_cst + mth19ec_cst + mth20ec_cst +
                        mth21ec_cst + mth21ec_cst + mth22ec_cst + mth23ec_cst + mth24ec_cst) 
        list_cum.append(energycons_dg)
        
        srcname_slr = "Solar Energy"
        Masterdata_Solar = Masterdatatable.objects.filter(mtdate = date ,  mtsrcname = srcname_slr).values()
        try:
            solar_cst = (Cost_Solar.objects.values('solar_cst').last())['solar_cst']
        except:
            solar_cst = 0
        for i in Masterdata_Solar:  
            mth1ec = i['mth1ec']
            mth1ec_cst = mth1ec * solar_cst
            mth2ec = i['mth2ec']
            mth2ec_cst = mth2ec * solar_cst
            mth3ec = i['mth3ec']
            mth3ec_cst = mth3ec * solar_cst
            mth4ec = i['mth4ec']
            mth4ec_cst = mth4ec * solar_cst
            mth5ec = i['mth5ec']
            mth5ec_cst = mth5ec * solar_cst
            mth6ec = i['mth6ec']
            mth6ec_cst = mth6ec * solar_cst
            mth7ec = i['mth7ec']
            mth7ec_cst = mth7ec * solar_cst
            mth8ec = i['mth8ec']
            mth8ec_cst = mth8ec * solar_cst
            mth9ec = i['mth9ec']
            mth9ec_cst = mth9ec * solar_cst
            mth10ec = i['mth10ec']
            mth10ec_cst = mth10ec * solar_cst
            mth11ec = i['mth11ec']
            mth11ec_cst = mth11ec * solar_cst
            mth12ec = i['mth12ec']
            mth12ec_cst = mth12ec * solar_cst
            mth13ec = i['mth13ec']
            mth13ec_cst = mth13ec * solar_cst
            mth14ec = i['mth14ec']
            mth14ec_cst = mth14ec * solar_cst
            mth15ec = i['mth15ec']
            mth15ec_cst = mth15ec * solar_cst
            mth16ec = i['mth16ec']
            mth16ec_cst = mth16ec * solar_cst
            mth17ec = i['mth17ec']
            mth17ec_cst = mth17ec * solar_cst
            mth18ec = i['mth18ec']
            mth18ec_cst = mth18ec * solar_cst
            mth19ec = i['mth19ec']
            mth19ec_cst = mth19ec * solar_cst
            mth20ec = i['mth20ec']
            mth20ec_cst = mth20ec * solar_cst
            mth21ec = i['mth21ec']
            mth21ec_cst = mth21ec * solar_cst
            mth22ec = i['mth22ec']
            mth22ec_cst = mth22ec * solar_cst
            mth23ec = i['mth23ec']
            mth23ec_cst = mth23ec * solar_cst
            mth24ec = i['mth24ec']
            mth24ec_cst = mth24ec * solar_cst

        energycons_solar = (mth1ec_cst + mth2ec_cst + mth3ec_cst + mth4ec_cst + mth5ec_cst + mth6ec_cst + mth7ec_cst + mth8ec_cst + mth9ec_cst + mth10ec_cst +
                        mth11ec_cst + mth12ec_cst + mth13ec_cst + mth14ec_cst + mth15ec_cst + mth16ec_cst + mth17ec_cst + mth18ec_cst + mth19ec_cst + mth20ec_cst +
                        mth21ec_cst + mth21ec_cst + mth22ec_cst + mth23ec_cst + mth24ec_cst) 
        list_cum.append(energycons_solar)
        
        srcname_trs = "Transformer1"
        mth1ec_cst = 0 ; mth2ec_cst = 0; mth3ec_cst = 0; mth4ec_cst = 0; mth5ec_cst = 0; mth6ec_cst = 0; mth7ec_cst = 0; mth8ec_cst = 0; mth9ec_cst = 0; mth10ec_cst = 0
        mth11ec_cst = 0; mth12ec_cst = 0; mth13ec_cst = 0; mth14ec_cst = 0; mth15ec_cst = 0; mth16ec_cst = 0 ;mth17ec_cst = 0; mth18ec_cst = 0; mth19ec_cst = 0; mth20ec_cst = 0
        mth21ec_cst = 0; mth21ec_cst = 0; mth22ec_cst = 0; mth23ec_cst = 0;  mth24ec_cst = 0 
        mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
        session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")
        Masterdata_tranformer  = Masterdatatable.objects.filter(mtdate = date , mtcategory="Secondary", mtgrpname='Incomer', mtsrcname = srcname_trs).values()
        for ms in Masterdata_tranformer:
            for w in ms:
                # print(w)
                if w == "mth1ec":
                    mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                    count_1 = 1
                    # print(mth1ec)
                if w == "mth2ec":
                    mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                    count_2 = 2
                    # print(mth2ec)
                if w == "mth3ec":
                    mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                    count_3 = 3
                    # print(mth3ec)
                if w == "mth4ec":
                    mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                    count_4 = 4
                    # print(mth4ec)
                if w == "mth5ec":
                    mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                    count_5 = 5
                    # print(mth5ec)
                if w == "mth6ec":
                    mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                    count_6 = 6
                    # print(mth6ec)
                if w == "mth7ec":
                    mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                    count_7 = 7
                    # print(mth7ec)
                if w == "mth8ec":
                    mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                    count_8 = 8
                    # print(mth8ec)
                if w == "mth9ec":
                    mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                    count_9 = 9
                    # print(mth9ec)
                if w == "mth10ec":
                    mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                    count_10 = 10
                    # print(mth10ec)
                if w == "mth11ec":
                    mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                    count_11 = 11
                    # print(mth11ec)
                if w == "mth12ec":
                    mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                    count_12 = 12
                    # print(mth12ec)
                if w == "mth13ec":
                    mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                    count_13 = 13
                    # print(mth13ec)
                if w == "mth14ec":
                    mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                    count_14 = 14
                    # print(mth14ec)
                if w == "mth15ec":
                    mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                    count_15 = 15
                    # print(mth15ec)
                if w == "mth16ec":
                    mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                    count_16 = 16
                    # print(mth16ec)
                if w == "mth17ec":
                    mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                    count_17 = 17
                    # print(mth17ec)
                if w == "mth18ec":
                    mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                    count_18 = 18
                    # print(mth18ec)
                if w == "mth19ec":
                    mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                    count_19 = 19
                    # print(mth19ec)
                if w == "mth20ec":
                    mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                    count_20 = 20
                    # print(mth20ec)
                if w == "mth21ec":
                    mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                    count_21 = 21
                    # print(mth21ec)
                if w == "mth22ec":
                    mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                    count_22 = 22
                    # print(mth22ec)
                if w == "mth23ec":
                    mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                    count_23 = 23
                    # print(mth23ec)
                if w == "mth24ec":
                    mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                    count_24 = 24
                    # print(mth24ec)
        # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
        pkstr = 0
        pkend =  0 
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0; cost_eb = 0
        for e in session_config:
            pkstart = e['pkstart']
            datetime_objects = datetime.combine(datetime.now() , pkstart) 
            incr_onehur = datetime_objects + timedelta(hours=1) 
            pkstart =  incr_onehur.time()
            if pkstart ==  mth1ec:
                # print("ps_mth1ec :",e["pkstart"])
                pkstr = count_1
            if pkstart == mth2ec:
                # print("ps_mth2ec :",e['pkstart'])
                pkstr = count_2
            if pkstart== mth3ec:
                # print("ps_mth3ec :",e['pkstart'])
                pkstr = count_3
            if pkstart == mth4ec:
                # print("ps_mth4ec :",e['pkstart'])
                pkstr = count_4
            if pkstart == mth5ec:
                # print("ps_mth5ec :",e['pkstart'])
                pkstr = count_5
            if pkstart == mth6ec:
                # print("ps_mth6ec :",i['pkstart'])
                pkstr = count_6
            if pkstart == mth7ec:
                # print("ps_mth7ec :",i['pkstart'])
                pkstr = count_7
            if pkstart == mth8ec:
                # print("ps_mth8ec :",i['pkstart'])
                pkstr = count_8
            if pkstart == mth9ec:
                # print("ps_mth9ec :",i['pkstart'])
                pkstr = count_9
            if pkstart == mth10ec:
                # print("ps_mth10ec :",i['pkstart'])
                pkstr = count_10
            if pkstart == mth11ec:
                # print("ps_mth11ec :",i['pkstart'])
                pkstr = count_11
            if pkstart == mth12ec:
                # print("ps_mth12ec :",i['pkstart'])
                pkstr = count_12
            if pkstart == mth13ec:
                # print("ps_mth13ec :",i['pkstart'])
                pkstr = count_13
            if pkstart == mth14ec:
                # print("ps_mth14ec :",i['pkstart'])
                pkstr = count_14
            if pkstart == mth15ec:
                # print("ps_mth15ec :",i['pkstart'])
                pkstr = count_15
            if pkstart == mth16ec:
                # print("ps_mth16ec :",i['pkstart'])
                pkstr = count_16
            if pkstart == mth17ec:
                # print("ps_mth17ec :",i['pkstart'])
                pkstr = count_17
            if pkstart == mth18ec:
                # print("ps_mth18ec :",i['pkstart'])
                pkstr = count_18
            if pkstart == mth19ec:
                # print("ps_mth19ec :",i['pkstart'])
                pkstr = count_19 
            if pkstart == mth20ec:
                # print("ps_mth20ec :",i['pkstart'])
                pkstr = count_20
            if pkstart == mth21ec:
                # print("ps_mth21ec :",i['pkstart'])
                pkstr = count_21
            if pkstart == mth22ec:
                # print("ps_mth22ec :",i['pkstart'])
                pkstr = count_22
            if pkstart == mth23ec:
                # print("ps_mth23ec :",i['pkstart'])
                pkstr = count_23
            if pkstart == mth24ec:
                # print("ps_mth24ec :",i['pkstart'])
                pkstr = count_2
            #pkend
            if e['pkend'] == mth1ec:
                # print("pe_mth1ec :" , i['pkend'])
                pkend = count_1
            if e['pkend'] == mth2ec:
                # print("pe_mth2ec :" , i['pkend'])
                pkend = count_2
            if e['pkend'] == mth3ec:
                # print("pe_mth3ec :" , i['pkend'])
                pkend = count_3
            if e['pkend'] == mth4ec:
                # print("pe_mth4ec :" , i['pkend'])
                pkend = count_4
            if e['pkend'] == mth5ec:
                # print("pe_mth5ec :", i['pkend'])
                pkend = count_5
            if e['pkend'] == mth6ec:
                # print("pe_mth6ec :", i['pkend'])
                pkend = count_6
            if e['pkend'] == mth7ec:
                # print("pe_mth7ec :", i['pkend'])
                pkend = count_7
            if e['pkend'] == mth8ec:
                # print("pe_mth8ec :", i['pkend'])
                pkend = count_8
            if e['pkend'] == mth9ec:
                # print("pe_mth9ec :", i['pkend'])
                pkend = count_9
            if e['pkend'] == mth10ec:
                # print("pe_mth10ec :", i['pkend'])
                pkend = count_10
            if e['pkend'] == mth11ec:
                # print("pe_mth11ec :", i['pkend'])
                pkend = count_11
            if e['pkend'] == mth12ec:
                # print("pe_mth12ec :", i['pkend'])
                pkend = count_12
            if e['pkend'] == mth13ec:
                # print("pe_mth13ec :", i['pkend'])
                pkend = count_13 
            if e['pkend'] == mth14ec:
                # print("pe_mth14ec :", i['pkend'])
                pkend = count_14
            if e['pkend'] == mth15ec:
                # print("pe_mth15ec :", i['pkend'])
                pkend = count_15 
            if e['pkend'] == mth16ec:
                # print("pe_mth16ec :", i['pkend'])
                pkend = count_16
            if e['pkend'] == mth17ec:
                # print("pe_mth17ec :", i['pkend'])
                pkend = count_17
            if e['pkend'] == mth18ec:
                # print("pe_mth18ec :", i['pkend'])
                pkend = count_18 
            if e['pkend'] == mth19ec:
                # print("pe_mth19ec :", i['pkend'])
                pkend = count_19 
            if e['pkend'] == mth20ec:
                # print("pe_mth20ec :", i['pkend'])
                pkend = count_20
            if e['pkend'] == mth21ec:
                # print("pe_mth21ec :", i['pkend'])
                pkend = count_21
            if e['pkend'] == mth22ec:
                # print("pe_mth22ec :", i['pkend'])
                pkend = count_22 
            if e['pkend'] == mth23ec:
                # print("pe_mth23ec :", i['pkend'])
                pkend = count_23 
            if e['pkend'] == mth24ec:
                # print("pe_mth24ec :", i['pkend'])
                pkend = count_24 

            # print(val , val_2)
            m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
            m24ec='' 
            # print(pkstr, pkend)
            for n in range(pkstr, pkend):
                if n == 1:
                    m1ec = 'mth1ec'
                    # print(m1ec)
                if n == 2:
                    m2ec = 'mth2ec'
                    # print(m2ec)
                if n == 3:
                    m3ec = 'mth3ec'
                    # print(m3ec)      
                if n == 4:
                    m4ec = 'mth4ec'
                    # print(m4ec)
                if n == 5:
                    m5ec = 'mth5ec'
                    # print(m5ec)
                if n == 6:
                    m6ec = 'mth6ec'
                    # print(m6ec)
                if n == 7:
                    m7ec = 'mth7ec'
                    # print(m7ec)
                if n == 8:
                    m8ec = 'mth8ec'
                    # print(m8ec)
                if n == 9:
                    m9ec = 'mth9ec'
                    # print(m9ec)
                if n == 10:
                    m10ec = 'mth10ec'
                    # print(m10ec)
                if n == 11:
                    m11ec = 'mth11ec'
                    # print(m11ec)
                if n == 12:
                    m12ec = 'mth12ec'
                    # print(m12ec)
                if n == 13:
                    m13ec = 'mth13ec'
                    # print(m13ec)
                if n == 14:
                    m14ec = 'mth14ec'
                    # print(m14ec)
                if n == 15:
                    m15ec = 'mth15ec'
                    # print(m15ec)
                if n == 16:
                    m16ec = 'mth16ec'
                    # print(m16ec)
                if n == 17:
                    m17ec = 'mth17ec'
                    # print(m17ec)
                if n == 18:
                    m18ec = 'mth18ec'
                    # print(m18ec)
                if n == 19:
                    m19ec = 'mth19ec'
                    # print(m19ec)
                if n == 20:
                    m20ec = 'mth20ec'
                    # print(m20ec)
                if n == 21:
                    m21ec = 'mth21ec'
                    # print(m21ec)
                if n == 22:
                    m22ec = 'mth22ec'
                    # print(m22ec)
                if n == 23:
                    m23ec = 'mth23ec'
                    # print(m23ec)
                if n == 24:
                    m24ec = 'mth24ec'
                    # print(m24ec)

            cost = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
            for s in cost:
                cost_eb = s['EB_SessionCost']
            # print(e['pkstatus'])    
            for q in Masterdata_tranformer:
                # print(q['mtmtrname'])
                for z in q:
                    # print(z)
                    if z == m1ec:
                        vl_1  = q['mth1ec'] * cost_eb + vl_1 
                    if z == m2ec:
                        vl_2 = q['mth2ec'] * cost_eb + vl_2  
                    if z == m3ec:
                        vl_3 = q['mth3ec'] * cost_eb + vl_3 
                    if z == m4ec:
                        vl_4  = q['mth4ec'] * cost_eb + vl_4
                    if z == m5ec:
                        vl_5 = q['mth5ec'] * cost_eb + vl_5
                    if z == m6ec:
                        vl_6 = q['mth6ec'] * cost_eb + vl_6 
                    if z == m7ec:
                        vl_7 = q['mth7ec'] * cost_eb + vl_7
                    if z == m8ec:
                        vl_8 = q['mth8ec'] * cost_eb + vl_8
                    if z == m9ec:
                        vl_9 = q['mth9ec'] * cost_eb + vl_9
                    if z == m10ec:
                        vl_10 = q['mth10ec'] * cost_eb + vl_10
                    if z == m11ec:
                        vl_11 = q['mth11ec'] * cost_eb + vl_11
                    if z == m12ec:
                        vl_12 = q['mth12ec'] * cost_eb + vl_12
                    if z == m13ec:
                        vl_13 = q['mth13ec'] * cost_eb + vl_13
                    if z == m14ec:
                        vl_14 = q['mth14ec'] * cost_eb + vl_14
                    if z == m15ec:
                        vl_15 = q['mth15ec'] * cost_eb + vl_15
                    if z == m16ec:
                        vl_16 = q['mth16ec'] * cost_eb + vl_16
                    if z == m17ec:
                        vl_17 = q['mth17ec'] * cost_eb + vl_17
                    if z == m18ec:
                        vl_18 = q['mth18ec'] * cost_eb + vl_18
                    if z == m19ec:
                        vl_19 = q['mth19ec'] * cost_eb + vl_19
                    if z == m20ec:
                        vl_20 = q['mth20ec'] * cost_eb + vl_20
                    if z == m21ec:
                        vl_21 = q['mth21ec'] * cost_eb + vl_21
                    if z == m22ec:
                        vl_22 = q['mth22ec'] * cost_eb + vl_22
                    if z == m23ec:
                        vl_23 = q['mth23ec'] * cost_eb + vl_23
                    if z == m24ec:
                        vl_24 = q['mth24ec'] * cost_eb + vl_24

            mth1ec_cst = vl_1 ; mth2ec_cst = vl_2 ; mth3ec_cst = vl_3 ; mth4ec_cst = vl_4 ; mth5ec_cst = vl_5; mth6ec_cst = vl_6
            mth7ec_cst = vl_7 ; mth8ec_cst = vl_8 ; mth9ec_cst = vl_9 ; mth10ec_cst = vl_10 ; mth11ec_cst = vl_11; mth12ec_cst = vl_12
            mth13ec_cst = vl_13; mth14ec_cst = vl_14 ; mth15ec_cst = vl_15 ; mth16ec_cst = vl_16 ; mth17ec_cst = vl_17 ; mth18ec_cst = vl_18 
            mth19ec_cst = vl_19; mth20ec_cst = vl_20 ; mth21ec_cst = vl_21 ; mth22ec_cst = vl_22 ; mth23ec_cst = vl_23 ; mth24ec_cst = vl_24 
        
        energycons_transformer = (mth1ec_cst + mth2ec_cst + mth3ec_cst + mth4ec_cst + mth5ec_cst + mth6ec_cst + mth7ec_cst + mth8ec_cst + mth9ec_cst + mth10ec_cst +
                        mth11ec_cst + mth12ec_cst + mth13ec_cst + mth14ec_cst + mth15ec_cst + mth16ec_cst + mth17ec_cst + mth18ec_cst + mth19ec_cst + mth20ec_cst +
                        mth21ec_cst + mth21ec_cst + mth22ec_cst + mth23ec_cst + mth24ec_cst) 
        list_cum.append(energycons_transformer)
        print({"label":["DG","Solar","TNEB"],"data":list_cum})
        return JsonResponse ({"label":["DG","Solar","TNEB"],"data":list_cum}, safe=False)
