from django.apps import AppConfig


class CoeConfig(AppConfig):
    name = 'coe'
