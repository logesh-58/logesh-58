from django.urls import path
from coe import views

urlpatterns=[  
    path('sourcecost/',views.costs)
]
