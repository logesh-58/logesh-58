from django.urls import path
from dailyreport import views, new_views

urlpatterns=[
    # path('dalilyreport/', views.data, name="productiondata"), # get particular event data
    path('dalilyreport/', new_views.data, name="productiondata"), # get particular event data
]
