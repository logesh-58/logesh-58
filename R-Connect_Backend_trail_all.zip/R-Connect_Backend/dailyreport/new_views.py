from django.shortcuts import render
from email.mime.base import MIMEBase
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
from django_celery_beat.models import PeriodicTask, CrontabSchedule
import json
from django.core.mail import EmailMessage
import smtplib
import math
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from django.db.models.aggregates import Sum
from datetime import datetime, time, timedelta, date

import os   
from RConnect.settings import BASE_DIR
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
import xlwt
from timeline.models import breakdown, badpart, timeline
from productiontable.serializers import ProductionTableSerializers
from machinemanagement.models import AddMachine
from productiontable.models import ProductionTable
from django.db.models import Q
from mouldmanagement.models import Mouldmodel
# Create your views here.

def shiftreport(data_list, date):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Production_Report.xls"'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Shiftwise report')
    style = xlwt.XFStyle()
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()

    #Set Alignment
    alignment = xlwt.Alignment()
    alignment.horz = xlwt.Alignment.HORZ_CENTER
    alignment.vert = xlwt.Alignment.VERT_CENTER
    alignment.wrap = 1
    style1.alignment = alignment
    style2.alignment = alignment
    style.alignment = alignment
    style3.alignment = alignment

    #Set Border
    border = xlwt.Borders()
    border.left = xlwt.Borders.THIN 
    border.right = xlwt.Borders.THIN 
    border.top = xlwt.Borders.THIN 
    border.bottom = xlwt.Borders.THIN 
    style.borders = border
    style1.borders = border
    style2.borders = border
    style3.borders = border

    #Set Background Color
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 22
    style.pattern = pattern

    #Set Font Color
    font = xlwt.Font()
    font.colour_index=xlwt.Style.colour_map['red']
    font.name = 'Time New Roman'
    font.bold = True
    font.height = 500
    style1.font = font

    font2 = xlwt.Font()
    font2.colour_index=xlwt.Style.colour_map['black']
    font2.name = 'Time New Roman'
    font2.bold = True
    font2.height = 300
    style2.font = font2

    font3 = xlwt.Font()
    font3.colour_index=xlwt.Style.colour_map['black']
    font3.name = 'Time New Roman'
    font3.bold = True
    font3.height = 175
    style.font = font3

    font4 = xlwt.Font()
    font4.colour_index=xlwt.Style.colour_map['black']
    font4.name = 'Time New Roman'
    font4.height = 175
    style3.font = font4
    #Set Date in FirstRowFirstColumn
    r = 0
    c = 0
    # ws.write_merge(r, r+2, c, c, ('Date: ' + str((datetime.datetime.now() - timedelta(days=1)).date())), style)
    ws.write_merge(r, r+2, c, c, ('Date: '+ date), style)
    #For Production parameters
    r = 3
    c = 0
    columns = ['Machinename', 'Mouldname', 'Shift', 'Start time', 'End time', 'Std Cycle time in Machine (sec)', 'Avg Cycletime (sec)', 'Recommended Set cycleTime' , 'Planned Machine Running Time (min)', 'Actual Machine Running Time (mins)', 'Target Production', 'Actual Production', 'Bad Parts', 'Machine IdleTime (mins)']
    for j, col in enumerate(columns):
        #Set cell width
        ws.col(c).width = 3200
        #Set cell height
        ws.row(r).height_mismatch = True
        ws.row(r).height = 900
        #Write in cell
        ws.write(r, c, col, style)
        c = c + 1
    #For OEE parameters
    r = 3
    OEE_c = c
    columns1 = ['Actual Running Time (mins)', 'Total time (mins)', 'AE', 'Target Production', 'Actual Production', 'PE', 'Good Parts', 'Actual Production', 'QE',]
    for j, col in enumerate(columns1):
        #Set cell width
        ws.col(OEE_c).width = 3200
        #Set cell height
        ws.row(r).height_mismatch = True
        ws.row(r).height = 900
        #Write in cell
        ws.write(r, OEE_c, col, style)
        OEE_c = OEE_c + 1

    #Add column for OEE
    r = 2
    #Set cell width
    ws.col(OEE_c).width = 3100
    #Set cell height
    ws.row(r).height_mismatch = True
    ws.row(r).height = 900
    ws.write_merge(r, r+1, OEE_c, OEE_c, 'OEE (%)', style2)

    # r = 2
    # #Set cell width
    # ws.col(OEE_c+1).width = 3100
    # #Set cell height
    # ws.row(r).height_mismatch = True
    # ws.row(r).height = 900
    # ws.write_merge(r, r+1, OEE_c+1, OEE_c+1, 'OEE % (Recommended CycletimeSet)', style2)

    #Add Main Heading
    r = 0
    c1 = 1
    ws.write_merge(r, r+1, c1, OEE_c, 'Production Report', style1)

    #Add Sub heading 1-i
    r = 2
    c1 = 1
    # columnlength = math.ceil(c/2)
    # for i in range(columnlength):
    ws.write_merge(r, r, c1, c-1, 'Production', style2)

    #Add Sub heading 1-ii
    r = 2
    c1 = 1
    # columnlength = math.ceil(c/2)
    column2 = ['Availability', 'Performance', 'Quality']
    for j, col in enumerate(column2):
        ws.write_merge(r, r, c, c+2, col, style2)
        c = c+3
    #Write data
    row = 4
    data_col = 0
    for i in data_list:
        for j in i:
            #Set cell width
            ws.col(data_col).width = 3100
            #Set cell height
            ws.row(row).height_mismatch = True
            ws.row(row).height = 700
            ws.write(row, data_col, j, style3)
            data_col += 1
        row += 1
        data_col = 0

    now = datetime.datetime.now()
    dt = now.strftime('%d-%m-%Y %H_%M_%S')
    # date = '05-10-2021'
    yesterday = (now.date() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    savepath = os.path.join("C:/Users/Admin/Documents/R-Connect","Report",'RConnect - DailyReport - '+(date)+'.xls')
    wb.save(savepath)
    return HttpResponse('Excel Generated')


@csrf_exempt
def data(request):
    if(request.method == 'POST'):
        Plantname = request.GET['Plantname']
        
        currentdate = datetime.strptime(json.loads(request.body)['date'], "%Y-%m-%d").date()
        # print("currentdate:", currentdate)

        # Calculate the next date using timedelta
        nextdate = (currentdate + timedelta(days=1)).strftime('%Y-%m-%d')
        # print("nextdate:", nextdate)

        shift_data = (ShiftTimings.objects.filter(Plantname=Plantname).values().last())['shift1start']
        # print("shift_data:", shift_data)

        MachinenamesArray = machineArray(Plantname)

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=currentdate, time__gte=shift_data) |
                    Q(date=nextdate, time__lte=shift_data),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('id', 'Machinename', 'time', 'date', 'MachineState', 'ProductionCountActual', 'Mouldname_id','CycletimeSet', 'CycletimeActual').order_by('id')
        
        # print("all_dashboard_value:", all_dashboard_value)
        # for entry in all_dashboard_value:
        #     print(entry)
        
        all_aggregated_data = ShiftProductiondata.objects.filter(
            sp_date=currentdate,
            sp_plantname=Plantname,
            sp_machinename__in=MachinenamesArray
        ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction', 'sp_mouldname_id').order_by('sp_id')

        # print("all_aggregated_data:", all_aggregated_data)

        all_RejectionParts_cal = badpart.objects.filter(
            Q(date=currentdate, time__gte=shift_data) |
            Q(date=nextdate, time__lte=shift_data),
            Plantname=Plantname,
            partcount__gt=0,
            Machinename__in=MachinenamesArray
        ).values('Machinename', 'date', 'time', 'partcount', 'id', 'Mouldname_id').order_by('id')

        # print("all_RejectionParts_cal:", all_RejectionParts_cal)

        all_breakdown_data = breakdown.objects.filter(
            Q(date=currentdate, time__gte=shift_data) |
            Q(date=nextdate, time__lte=shift_data),
            Machinename__in=MachinenamesArray,
            Plantname=Plantname
        ).values('Machinename', 'MachineState', 'time', 'date', 'Mouldname_id').order_by('id')

        # print("all_breakdown_data:", all_breakdown_data)
        # for entry in all_breakdown_data:
        #     print(entry)

        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        if shift_times:
            # Directly assign time values without using strptime
            first_shift_start = shift_times['shift1start']
            first_shift_end = shift_times['shift1end']
            second_shift_start = shift_times['shift2start']
            second_shift_end = shift_times['shift2end']
            third_shift_start = shift_times['shift3start']
            third_shift_end = shift_times['shift3end']
            
            # print("first_shift_start:", first_shift_start)
            # print("first_shift_end:", first_shift_end)
            # print("second_shift_start:", second_shift_start)
            # print("second_shift_end:", second_shift_end)
            # print("third_shift_start:", third_shift_start)
            # print("third_shift_end:", third_shift_end)
        else:
            print("No shift times available for the specified Plantname.")

        myarray   = []

        for machine in MachinenamesArray:

            distinctArray = list(set(p['Mouldname_id'] for p in all_dashboard_value if p['Machinename'] == machine))
            # print("machinename:",machine, distinctArray)
            for mould in distinctArray:
                
                mouldname = Mouldmodel.objects.get(id = mould).Mouldname
                # print("machine:", machine, "mouldname:", mouldname)

                tracktime = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            p['Mouldname_id'] == mould
                        ]
                
                first_record = tracktime[0]
                last_record = tracktime[-1]

                mfirst_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                mlast_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                
                # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600  ########

                ProductionTimeActual_minute = ((datetime.combine(last_date, mlast_time) - datetime.combine(first_date, mfirst_time)).total_seconds()) / 60
        
                # print("first_time:", first_time, "last_time:", last_time)

    ##################################################################
                # List to store shifts
                shifts = []
                
                for time in (mfirst_time, mlast_time):
                    # Determine the company shift
                    if first_shift_start <= time <= first_shift_end:
                        shift = 'A'
                    elif second_shift_start <= time <= second_shift_end:
                        shift = 'B'
                    elif time >= third_shift_start or time <= third_shift_end:
                        shift = 'C'
                    else:
                        shift = 0  # Set to 0 if it doesn’t match any shift

                    # Append shift to the list
                    shifts.append(shift)

                if shifts == ['A', 'C']:
                    shifts = ['A', 'B', 'C']
                else:
                    shifts = shifts

                # print("machine:", machine, "mouldname:", mouldname, "shift:", shifts)

    ##################################################################

                # Determine the company shift
                # if first_shift_start <= first_time <= first_shift_end:
                #     shift = 'A'
                # elif second_shift_start <= first_time <= second_shift_end:
                #     shift = 'B'
                # # Special case for shift C, which spans over midnight
                # elif first_time >= third_shift_start or first_time <= third_shift_end:
                #     shift = 'C'
                # else:
                #     shift = 0

                # print("machine:", machine, "mouldname:", mouldname, "shift:", shift)

    ##################################################################

                Cycletime_Set = first_record['CycletimeSet']
                # print("Cycletime_Set:", Cycletime_Set)

                total_cycle_time = sum(p['CycletimeActual'] for p in tracktime) if tracktime else 0
                # print("total_cycle_time:", total_cycle_time)

                lengthavg = len(tracktime)
                # print("lengthavg:", lengthavg)

                avg_cycle = total_cycle_time/lengthavg
                # print("avg_cycle:", avg_cycle)

                recommanded_cycle = math.ceil(avg_cycle / 5) * 5
                # print("recommanded_cycle:", recommanded_cycle)

                aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_mouldname_id'] == mould and r['sp_shift'] in shifts
                        ]
                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                mac_minutes = mac_hours * 60

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == machine and
                            e['Mouldname_id'] == mould
                        ]
                RejectionParts = len(RejectionParts_cal)

                saw = [k for k in all_breakdown_data if
                            k['Machinename'] == machine and
                            k['Mouldname_id'] == mould
                            and mfirst_time <= datetime.strptime(k['time'], "%H:%M:%S").time() <= mlast_time
                        ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None


                # total_idle_time_hours = total_idle_time / 3600                 ############

                total_idle_minutes = total_idle_time / 60

                print("machine:", machine, "mould:", mould, "mfirst_time:", mfirst_time, "mlast_time:", mlast_time, "total_idle_minutes:", total_idle_minutes)

                good_parts = lengthavg - RejectionParts

                total_ProductionTimeActual_minutes = ProductionTimeActual_minute - total_idle_minutes
                availability = (float(total_ProductionTimeActual_minutes) / mac_minutes) * 100 if mac_minutes != 0 else 0
                quality = (abs(lengthavg - RejectionParts) / lengthavg) * 100 if lengthavg != 0 else 0
                performance = (lengthavg / mac_counts) * 100 if mac_counts != 0 else 0
                oee = (availability / 100) * (performance / 100) * (quality / 100) * 100

                #--------------------Append With Dictionary ---------------------------------------
                mydict = {  
                            'Machinename'                   : machine, 
                            'Mouldname'                     : mouldname,
                            'Shift'                         : shifts,
                            'Starttime'                    : mfirst_time,
                            'Endtime'                      : mlast_time, 
                            'Cycletime_Set'           : Cycletime_Set,
                            'Cycletime_Actual'       : round(avg_cycle,2),
                            'Recommended_cycleTime'         : recommanded_cycle,
                            'Productiontime_Set'      : round(mac_minutes, 1),
                            'Productiontime_Actual'   : round(ProductionTimeActual_minute, 1),
                            'ProductionCount_Set'           : mac_counts,
                            'ProductionCount_Actual'        : int(lengthavg),
                            'RejectionParts'                      : RejectionParts,
                            'MachineIdletime'         : round(total_idle_minutes, 1),
                            'Actual_runtime'          : round(total_ProductionTimeActual_minutes, 1),
                            'Total_runtime'           : round(mac_minutes, 1),
                            'ae'                        : round(availability,2),
                            'Target_production'             : mac_counts,
                            'Actual_production'             : lengthavg,
                            'pe'                        : round(performance,2),
                            'Good_parts'                    : good_parts,
                            'Produced_parts'                : lengthavg,
                            'qe'                        : round(quality,2),
                            'oee'                       : round(oee,2)
                            }
                myarray.append(mydict)

        if(myarray != []):
            return JsonResponse(myarray, safe=False)
        else:
            return JsonResponse('No data available', safe=False)
