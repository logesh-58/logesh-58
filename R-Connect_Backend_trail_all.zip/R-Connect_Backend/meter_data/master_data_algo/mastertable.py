from rest_framework import serializers
from meter_data.models import Masterdatatable,Meterdata,Dailydatacache
from general_settings.models import Timingtable
# import datetime
from meter_data.serializers import MeterDatabaseSerializer,MasterTableDbSerializer
from django.utils import timezone
from meter_management.models import AddMeter
from meter_management.serializers import MeterManagementdbSerializer
import pytz
import smtplib
# from datetime import datetime
from datetime import timedelta, datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from decimal import Decimal
timezone.now()

def insertmasterdata(meterDatabase_data):
    timingtblrow = Timingtable.objects.get(ttid=1)
    dailyreporttime = timingtblrow.ttdaystarttime
    s1time = timingtblrow.tts1time
    s2time = timingtblrow.tts2time
    s3time = timingtblrow.tts3time

    offline_meter=[]
    online_meter=[]
    for meterDatabase_data_dict in meterDatabase_data:
        print("MasterDataTable writing to the db is running -- ", meterDatabase_data_dict["metername"])
        if(Dailydatacache.objects.filter(dcmtrname = meterDatabase_data_dict["metername"]).exists()):
            actenergy = meterDatabase_data_dict["actualenergy"]
            cachematch = Dailydatacache.objects.get(dcmtrname=meterDatabase_data_dict["metername"], )
            daystarteng = cachematch.dcevdaystart
            s1starteng = cachematch.dcs1start
            s2starteng = cachematch.dcs2start
            s3starteng = cachematch.dcs3start
            h1starteng = cachematch.dch1start
            h2starteng = cachematch.dch2start
            h3starteng = cachematch.dch3start
            h4starteng = cachematch.dch4start
            h5starteng = cachematch.dch5start
            h6starteng = cachematch.dch6start
            h7starteng = cachematch.dch7start
            h8starteng = cachematch.dch8start
            h9starteng = cachematch.dch9start
            h10starteng = cachematch.dch10start
            h11starteng = cachematch.dch11start
            h12starteng = cachematch.dch12start
            h13starteng = cachematch.dch13start
            h14starteng = cachematch.dch14start
            h15starteng = cachematch.dch15start
            h16starteng = cachematch.dch16start
            h17starteng = cachematch.dch17start
            h18starteng = cachematch.dch18start
            h19starteng = cachematch.dch19start
            h20starteng = cachematch.dch20start
            h21starteng = cachematch.dch21start
            h22starteng = cachematch.dch22start
            h23starteng = cachematch.dch23start
            h24starteng = cachematch.dch24start
            
            try:
                s1string = s1time.strftime('%H')
                s1hrint = int(s1string)
                current_time = datetime.now()
                # Subtract 2 hours from datetime object containing current time
                past_time = current_time - timedelta(hours=s1hrint)
                # Convert datetime object to string in specific format 
                past_time_str = past_time.strftime('%Y-%m-%d')
                print(past_time_str)
                matchrow = Masterdatatable.objects.get(mtmtrname=meterDatabase_data_dict["metername"],
                                                    mtdate=past_time_str)
            except Masterdatatable.DoesNotExist:
                matchrow = None
            if matchrow == None:
                if daystarteng == None:
                    energycons = 0.00
                else:
                    energycons = float(actenergy)-float(daystarteng)
                    roundedecons = 0 if energycons < 0 else round(energycons, 2)
                mtrrow = AddMeter.objects.get(ammetername=meterDatabase_data_dict["metername"])
                plntnme = mtrrow.amplantname
                srcnme = mtrrow.ammetersource
                catnme = mtrrow.ammetercategory
                grpval = mtrrow.ammetergroup
                #Inserting data to the MasterData Table
                if (meterDatabase_data_dict['metertype'] == 'HT_Meter'):
                    mastertabledbserializer = MasterTableDbSerializer(data={'mtdate':past_time_str, 'mtmtrname':meterDatabase_data_dict["metername"], 'mtevdaystart':daystarteng, 'mtgrpname':grpval, 'mtenergycons':roundedecons, 'mtplntlctn':plntnme, 'mtcategory':catnme, 'mtsrcname':srcnme, 'mtmaxdemands':meterDatabase_data_dict["kva"], 'mtmindemand':meterDatabase_data_dict["kva"], 'mtinsdemand':meterDatabase_data_dict["kva"], 'mtpwrfctr':meterDatabase_data_dict["powerfactor"], 'mtminpf':meterDatabase_data_dict["powerfactor"], 'mtmaxpf':meterDatabase_data_dict["powerfactor"], 'mttotalreactivepower':meterDatabase_data_dict["reactivepower"], 'mtrctpwr1':meterDatabase_data_dict["reactivepower1"], 'mtrctpwr2':meterDatabase_data_dict["reactivepower2"], 'mtrctpwr3':meterDatabase_data_dict["reactivepower3"], 'mtrealpwr1':meterDatabase_data_dict["realpower1"], 'mtrealpwr2':meterDatabase_data_dict["realpower2"], 'mtrealpwr3':meterDatabase_data_dict["realpower3"], 'mtaprtpwr1':meterDatabase_data_dict["apparentpower1"], 'mtaprtpwr2':meterDatabase_data_dict["apparentpower2"], 'mtaprtpwr3':meterDatabase_data_dict["apparentpower3"], 'mtlv1':meterDatabase_data_dict["linevoltage1"], 'mtlv2':meterDatabase_data_dict["linevoltage2"], 'mtlv3':meterDatabase_data_dict["linevoltage3"], 'mtlc1':meterDatabase_data_dict["linecurrent1"], 'mtlc2':meterDatabase_data_dict["linecurrent2"], 'mtlc3':meterDatabase_data_dict["linecurrent3"], 'mtTHDL1':meterDatabase_data_dict["THDV1"], 'mtTHDL2':meterDatabase_data_dict["THDV2"], 'mtTHDL3':meterDatabase_data_dict["THDV3"], 'mtTHDC1':meterDatabase_data_dict["THDC1"], 'mtTHDC2':meterDatabase_data_dict["THDC2"], 'mtTHDC3':meterDatabase_data_dict["THDC3"], 'mtTHDP1':meterDatabase_data_dict["THDP1"], 'mtTHDP2':meterDatabase_data_dict["THDP2"], 'mtTHDP3':meterDatabase_data_dict["THDP3"]
                                                                        },partial=True)
                    mastertabledbserializer.is_valid()
                    mastertabledbserializer.save()
                else:
                    mastertabledbserializer = MasterTableDbSerializer(data={'mtdate':past_time_str, 'mtmtrname':meterDatabase_data_dict["metername"], 'mtevdaystart':daystarteng, 'mtgrpname':grpval, 'mtenergycons':roundedecons, 'mtplntlctn':plntnme, 'mtcategory':catnme, 'mtsrcname':srcnme, 'mtmaxdemands':0, 'mtmindemand':0, 'mtinsdemand':0, 'mtpwrfctr':0, 'mtminpf':0, 'mtmaxpf':0, 'mttotalreactivepower':0, 'mtrctpwr1':0, 'mtrctpwr2':0, 'mtrctpwr3':0, 'mtrealpwr1':0, 'mtrealpwr2':0, 'mtrealpwr3':0, 'mtaprtpwr1':0, 'mtaprtpwr2':0, 'mtaprtpwr3':0, 
                    'mtlv1':0, 'mtlv2':0, 'mtlv3':0, 'mtlc1':0, 'mtlc2':0, 'mtlc3':0, 'mtTHDL1':0, 'mtTHDL2':0, 'mtTHDL3':0, 'mtTHDC1':0, 'mtTHDC2':0, 'mtTHDC3':0, 'mtTHDP1':0, 'mtTHDP2':0, 'mtTHDP3':0},partial=True)
                    mastertabledbserializer.is_valid()
                    mastertabledbserializer.save()
            
            else: 
                timingtblrow = Timingtable.objects.get(ttid=1)
                dailyreporttime = timingtblrow.ttdaystarttime
                s1time = timingtblrow.tts1time
                s2time = timingtblrow.tts2time
                s3time = timingtblrow.tts3time
                
                matchrow = Dailydatacache.objects.get(dcmtrname=meterDatabase_data_dict["metername"])
                curntshift = matchrow.dccrntshift
                curnthour = matchrow.dccrnthour
                curnttime = datetime.now().time()

                floatactec = float(actenergy)
                if daystarteng is None:
                    daystarteng=0
                energycons =  floatactec-float(daystarteng)
                mtrrow = AddMeter.objects.get(ammetername=meterDatabase_data_dict["metername"])
                plntnme = mtrrow.amplantname
                srcnme = mtrrow.ammetersource
                catnme = mtrrow.ammetercategory
                grpval = mtrrow.ammetergroup
                if (curntshift==1) and (actenergy!=0):
                    Masterdatatable.objects.filter(mtmtrname=meterDatabase_data_dict["metername"],
                                                mtdate=past_time_str).update(mtevdaystart=daystarteng)
                    s1ec=floatactec-float(s1starteng)
                    if (meterDatabase_data_dict['metertype'] == 'HT_Meter'):
                        sengcons(meterDatabase_data_dict["metername"],past_time_str,curntshift,s1ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["linevoltage"],meterDatabase_data_dict["avgcurrent"],meterDatabase_data_dict["powerfactor"],meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["frequency"],meterDatabase_data_dict["meterstatus"],meterDatabase_data_dict["kva"],meterDatabase_data_dict["reactivepower"],meterDatabase_data_dict["reactivepower1"],meterDatabase_data_dict["reactivepower2"],meterDatabase_data_dict["reactivepower3"],meterDatabase_data_dict["realpower1"],meterDatabase_data_dict["realpower2"],meterDatabase_data_dict["realpower3"],meterDatabase_data_dict["apparentpower1"],meterDatabase_data_dict["apparentpower2"],meterDatabase_data_dict["apparentpower3"],meterDatabase_data_dict["linevoltage1"],meterDatabase_data_dict["linevoltage2"],meterDatabase_data_dict["linevoltage3"],meterDatabase_data_dict["linecurrent1"],meterDatabase_data_dict["linecurrent2"],meterDatabase_data_dict["linecurrent3"],meterDatabase_data_dict["THDV1"],meterDatabase_data_dict["THDV2"],meterDatabase_data_dict["THDV3"],meterDatabase_data_dict["THDC1"],meterDatabase_data_dict["THDC2"],meterDatabase_data_dict["THDC3"],meterDatabase_data_dict["THDP1"],meterDatabase_data_dict["THDP2"],meterDatabase_data_dict["THDP3"],meterDatabase_data_dict["actualpower"])
                    else:
                        paramUpdate(meterDatabase_data_dict["metername"],past_time_str,curntshift,s1ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["meterstatus"])

                elif (curntshift==2) and (actenergy!=0):
                    s2ec=floatactec-float(s2starteng)
                    if (meterDatabase_data_dict['metertype'] == 'HT_Meter'):
                        sengcons(meterDatabase_data_dict["metername"],past_time_str,curntshift,s2ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["linevoltage"],meterDatabase_data_dict["avgcurrent"],meterDatabase_data_dict["powerfactor"],meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["frequency"],meterDatabase_data_dict["meterstatus"],meterDatabase_data_dict["kva"],meterDatabase_data_dict["reactivepower"],meterDatabase_data_dict["reactivepower1"],meterDatabase_data_dict["reactivepower2"],meterDatabase_data_dict["reactivepower3"],meterDatabase_data_dict["realpower1"],meterDatabase_data_dict["realpower2"],meterDatabase_data_dict["realpower3"],meterDatabase_data_dict["apparentpower1"],meterDatabase_data_dict["apparentpower2"],meterDatabase_data_dict["apparentpower3"],meterDatabase_data_dict["linevoltage1"],meterDatabase_data_dict["linevoltage2"],meterDatabase_data_dict["linevoltage3"],meterDatabase_data_dict["linecurrent1"],meterDatabase_data_dict["linecurrent2"],meterDatabase_data_dict["linecurrent3"],meterDatabase_data_dict["THDV1"],meterDatabase_data_dict["THDV2"],meterDatabase_data_dict["THDV3"],meterDatabase_data_dict["THDC1"],meterDatabase_data_dict["THDC2"],meterDatabase_data_dict["THDC3"],meterDatabase_data_dict["THDP1"],meterDatabase_data_dict["THDP2"],meterDatabase_data_dict["THDP3"],meterDatabase_data_dict["actualpower"])
                    else:
                        paramUpdate(meterDatabase_data_dict["metername"],past_time_str,curntshift,s2ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["meterstatus"])
                elif (curntshift==3) and (actenergy!=0):
                    s3ec=floatactec-float(s3starteng)
                    if (meterDatabase_data_dict['metertype'] == 'HT_Meter'):
                        sengcons(meterDatabase_data_dict["metername"],past_time_str,curntshift,s3ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["linevoltage"],meterDatabase_data_dict["avgcurrent"],meterDatabase_data_dict["powerfactor"],meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["frequency"],meterDatabase_data_dict["meterstatus"],meterDatabase_data_dict["kva"],meterDatabase_data_dict["reactivepower"],meterDatabase_data_dict["reactivepower1"],meterDatabase_data_dict["reactivepower2"],meterDatabase_data_dict["reactivepower3"],meterDatabase_data_dict["realpower1"],meterDatabase_data_dict["realpower2"],meterDatabase_data_dict["realpower3"],meterDatabase_data_dict["apparentpower1"],meterDatabase_data_dict["apparentpower2"],meterDatabase_data_dict["apparentpower3"],meterDatabase_data_dict["linevoltage1"],meterDatabase_data_dict["linevoltage2"],meterDatabase_data_dict["linevoltage3"],meterDatabase_data_dict["linecurrent1"],meterDatabase_data_dict["linecurrent2"],meterDatabase_data_dict["linecurrent3"],meterDatabase_data_dict["THDV1"],meterDatabase_data_dict["THDV2"],meterDatabase_data_dict["THDV3"],meterDatabase_data_dict["THDC1"],meterDatabase_data_dict["THDC2"],meterDatabase_data_dict["THDC3"],meterDatabase_data_dict["THDP1"],meterDatabase_data_dict["THDP2"],meterDatabase_data_dict["THDP3"],meterDatabase_data_dict["actualpower"])
                    else:
                        paramUpdate(meterDatabase_data_dict["metername"],past_time_str,curntshift,s3ec,energycons,plntnme,catnme,srcnme,meterDatabase_data_dict["actualenergy"],meterDatabase_data_dict["meterstatus"])

                s1string = s1time.strftime('%H')
                h1time = int(s1string)
                h2time = ((h1time-24) + 1) if h1time>=23 else (h1time + 1)
                h3time = ((h2time-24) + 1) if h2time>=23 else (h2time + 1)
                h4time = ((h3time-24) + 1) if h3time>=23 else (h3time + 1)
                h5time = ((h4time-24) + 1) if h4time>=23 else (h4time + 1)
                h6time = ((h5time-24) + 1) if h5time>=23 else (h5time + 1)
                h7time = ((h6time-24) + 1) if h6time>=23 else (h6time + 1)
                h8time = ((h7time-24) + 1) if h7time>=23 else (h7time + 1)
                h9time = ((h8time-24) + 1) if h8time>=23 else (h8time + 1)
                h10time = ((h9time-24) + 1) if h9time>=23 else (h9time + 1)
                h11time = ((h10time-24) + 1) if h10time>=23 else (h10time + 1)
                h12time = ((h11time-24) + 1) if h11time>=23 else (h11time + 1)
                h13time = ((h12time-24) + 1) if h12time>=23 else (h12time + 1)
                h14time = ((h13time-24) + 1) if h13time>=23 else (h13time + 1)
                h15time = ((h14time-24) + 1) if h14time>=23 else (h14time + 1)
                h16time = ((h15time-24) + 1) if h15time>=23 else (h15time + 1)
                h17time = ((h16time-24) + 1) if h16time>=23 else (h16time + 1)
                h18time = ((h17time-24) + 1) if h17time>=23 else (h17time + 1)
                h19time = ((h18time-24) + 1) if h18time>=23 else (h18time + 1)
                h20time = ((h19time-24) + 1) if h19time>=23 else (h19time + 1)
                h21time = ((h20time-24) + 1) if h20time>=23 else (h20time + 1)
                h22time = ((h21time-24) + 1) if h21time>=23 else (h21time + 1)
                h23time = ((h22time-24) + 1) if h22time>=23 else (h22time + 1)
                h24time = ((h23time-24) + 1) if h23time>=23 else (h23time + 1)
                curnttimestring = curnttime.strftime('%H')
                curnttimeint = int(curnttimestring)

                if ((h1time == curnttimeint) and (actenergy!=0)):
                    h1eng=floatactec-float(h1starteng)
                    curhr="mth1ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h1eng,energycons,meterDatabase_data_dict["meterstatus"])
                    
                elif ((h2time == curnttimeint) and (actenergy!=0)):
                    h2eng=floatactec-float(h2starteng)
                    curhr="mth2ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h2eng,energycons,meterDatabase_data_dict["meterstatus"])

                elif ((h3time == curnttimeint) and (actenergy!=0)): 
                    h3eng=floatactec-float(h3starteng)    
                    curhr="mth3ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h3eng,energycons,meterDatabase_data_dict["meterstatus"])

                elif ((h4time == curnttimeint) and (actenergy!=0)): 
                    h4eng=floatactec-float(h4starteng)    
                    curhr="mth4ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h4eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h5time == curnttimeint) and (actenergy!=0)): 
                    h5eng=floatactec-float(h5starteng)    
                    curhr="mth5ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h5eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h6time == curnttimeint) and (actenergy!=0)): 
                    h6eng=floatactec-float(h6starteng)    
                    curhr="mth6ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h6eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h7time == curnttimeint) and (actenergy!=0)): 
                    h7eng=floatactec-float(h7starteng)    
                    curhr="mth7ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h7eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h8time == curnttimeint) and (actenergy!=0)): 
                    h8eng=floatactec-float(h8starteng)    
                    curhr="mth8ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h8eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h9time == curnttimeint) and (actenergy!=0)): 
                    h9eng=floatactec-float(h9starteng)    
                    curhr="mth9ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h9eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h10time == curnttimeint) and (actenergy!=0)): 
                    h10eng=floatactec-float(h10starteng)    
                    curhr="mth10ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h10eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h11time == curnttimeint) and (actenergy!=0)): 
                    h11eng=floatactec-float(h11starteng)    
                    curhr="mth11ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h11eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h12time == curnttimeint) and (actenergy!=0)): 
                    h12eng=floatactec-float(h12starteng)    
                    curhr="mth12ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h12eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h13time == curnttimeint) and (actenergy!=0)): 
                    h13eng=floatactec-float(h13starteng)    
                    curhr="mth13ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h13eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h14time == curnttimeint) and (actenergy!=0)): 
                    h14eng=floatactec-float(h14starteng)    
                    curhr="mth14ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h14eng,energycons,meterDatabase_data_dict["meterstatus"])

                elif ((h15time == curnttimeint) and (actenergy!=0)): 
                    h15eng=floatactec-float(h15starteng)    
                    curhr="mth15ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h15eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h16time == curnttimeint) and (actenergy!=0)): 
                    h16eng=floatactec-float(h16starteng)    
                    curhr="mth16ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h16eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h17time == curnttimeint) and (actenergy!=0)): 
                    h17eng=floatactec-float(h17starteng)    
                    curhr="mth17ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h17eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h18time == curnttimeint) and (actenergy!=0)): 
                    h18eng=floatactec-float(h18starteng)    
                    curhr="mth18ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h18eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h19time == curnttimeint) and (actenergy!=0)): 
                    h19eng=floatactec-float(h19starteng)    
                    curhr="mth19ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h19eng,energycons,meterDatabase_data_dict["meterstatus"])  

                elif ((h20time == curnttimeint) and (actenergy!=0)): 
                    h20eng=floatactec-float(h20starteng)    
                    curhr="mth20ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h20eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h21time == curnttimeint) and (actenergy!=0)): 
                    h21eng=floatactec-float(h21starteng)    
                    curhr="mth21ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h21eng,energycons,meterDatabase_data_dict["meterstatus"])

                elif ((h22time == curnttimeint) and (actenergy!=0)): 
                    h22eng=floatactec-float(h22starteng)    
                    curhr="mth22ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h22eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h23time == curnttimeint) and (actenergy!=0)): 
                    h23eng=floatactec-float(h23starteng)    
                    curhr="mth23ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h23eng,energycons,meterDatabase_data_dict["meterstatus"]) 

                elif ((h24time == curnttimeint) and (actenergy!=0)): 
                    h24eng=floatactec-float(h24starteng)    
                    curhr="mth24ec"
                    hrengcons(meterDatabase_data_dict["metername"],past_time_str,curhr,h24eng,energycons,meterDatabase_data_dict["meterstatus"])       

                #Logic to check meter status and adding in list
                meter_status_data=Masterdatatable.objects.get(mtmtrname=meterDatabase_data_dict["metername"],
                                                        mtdate=past_time_str)
                crnt_mtr_status=meter_status_data.mtmtrstatus
                prev_mtr_status=meter_status_data.mtmtrprevstatus

                if crnt_mtr_status!=prev_mtr_status:
                    if crnt_mtr_status==0 or crnt_mtr_status==2:
                        offline_meter.append(meterDatabase_data_dict["metername"])
                        prev_mtr_status=crnt_mtr_status
                        Masterdatatable.objects.filter(mtmtrname=meterDatabase_data_dict["metername"],
                                                    mtdate=past_time_str).update(mtmtrprevstatus=crnt_mtr_status)
                    else:
                        online_meter.append(meterDatabase_data_dict["metername"])
                        prev_mtr_status=crnt_mtr_status
                        Masterdatatable.objects.filter(mtmtrname=meterDatabase_data_dict["metername"],
                                                    mtdate=past_time_str).update(mtmtrprevstatus=crnt_mtr_status)

        # mailtrigger(offline_meter,"Offline")
        # mailtrigger(online_meter,"Online")
        else:
            print('Meter Not available in Cache Data')

# def mailtrigger(meter_arr,on_off_check):
#     if on_off_check=="Online":
#         str_off_on = 'The meters listed below came back online. Kindly check in real-time and update'
#     elif on_off_check=="Offline":
#         str_off_on= 'The meters listed below are in Offline. Kindly check in real-time and update'
#     mtrcount=len(meter_arr)
#     if mtrcount!=0:
#         Workflowdata = WorkflowData.objects.all().order_by('wfid')
#         tomail=""

#         mailto = str(tomail)
#         sub = "Meter "+str(on_off_check)+"- Notification"
#         body = "Dear Team,<br>"+str(str_off_on)+"<br>"
#         i=1
#         for j in range(len(meter_arr)):
#             body=body+str(i)+". "+str(meter_arr[j])+"<br>"
#             i+=1
#         body=body+"<br> <b>Note: This is an auto-generated mail </b><br><br>"
#         body=body+"Regards,<br>"
#         body=body+"R-Energy Team.<br>"
#         msg = MIMEMultipart('alternative')
#         msg['Subject'] = sub
#         msg['From'] = "R-Energy <no-reply@r-energy.com>"
#         msg['To'] = mailto
#         part2 = MIMEText(body, 'html')
#         msg.attach(part2)
#         message = """From: R-Energy Team
#                     To: """+ mailto +""";
#                     Subject: """+ sub +"""
#                     """+ body +""".
#                     """
#         smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
#         smtpObj.sendmail('ntpdpmt1@int.motherson.com',mailto.split(';'),msg.as_string())    
#         smtpObj.quit() 

def sengcons(mname,dte,cshft,seng,eng,plntnme,catnme,srcnme,volt,crnt,pfctr,acteng,freq,mtrsts,kva,totalreactivepower,rctpwr1,rctpwr2,rctpwr3,realpwr1,realpwr2,realpwr3,aprtpwr1,aprtpwr2,aprtpwr3,lv1,lv2,lv3,lc1,lc2,lc3,vh1,vh2,vh3,ch1,ch2,ch3,ph1,ph2,ph3,pwr):
    shftnme = "mts"+str(cshft)+"ec"
    maximum_demands = Masterdatatable.objects.get(mtmtrname=mname, mtdate=dte).mtmaxdemands
    if Decimal(kva) > int(maximum_demands):
        maximum_demands = kva
    minimum_demands = Masterdatatable.objects.get(mtmtrname=mname, mtdate=dte).mtmindemand
    if (Decimal(kva) < int(minimum_demands)) or (int(minimum_demands) == 0):
        minimum_demands = kva
    max_pf = Masterdatatable.objects.get(mtmtrname=mname, mtdate=dte).mtmaxpf
    if float(pfctr) > float(max_pf):
        max_pf = pfctr
    min_pf = Masterdatatable.objects.get(mtmtrname=mname, mtdate=dte).mtminpf
    if (float(pfctr) < float(min_pf)) or (float(min_pf) == 0.0):
        min_pf = pfctr

    try:
        if (eng<0 or seng<0 and (mtrsts==0 or mtrsts==2)):
            Masterdatatable.objects.filter(mtmtrname=mname,
                                        mtdate=dte).update(mtmtrstatus=mtrsts)
        else:
            Masterdatatable.objects.filter(mtmtrname=mname, mtdate=dte).update(mtenergycons=eng,**{shftnme:seng},mtlastupdt=datetime.now(),mtplntlctn=plntnme,mtcategory=catnme,mtsrcname=srcnme,mtpeakvolt=volt,mtpeakcrnt=crnt,mtpwrfctr=pfctr,mtacteng=acteng,mtavgfreq=freq,mtmtrstatus=mtrsts,mtmaxdemands=maximum_demands,mttotalreactivepower=totalreactivepower,mtrctpwr1=rctpwr1,mtrctpwr2=rctpwr2,mtrctpwr3=rctpwr3,mtrealpwr1=realpwr1,mtrealpwr2=realpwr2,mtrealpwr3=realpwr3,mtaprtpwr1=aprtpwr1,mtaprtpwr2=aprtpwr2,mtaprtpwr3=aprtpwr3,mtlv1=lv1,mtlv2=lv2,mtlv3=lv3,mtlc1=lc1,mtlc2=lc2,mtlc3=lc3,mtTHDL1=vh1,mtTHDL2=vh2,mtTHDL3=vh3,mtTHDC1=ch1,mtTHDC2=ch2,mtTHDC3=ch3,mtTHDP1=ph1,mtTHDP2=ph2,mtTHDP3=ph3,mttotalpower=pwr,mtmindemand=minimum_demands,mtinsdemand=kva,mtminpf=min_pf,mtmaxpf=max_pf)
    except Exception as Error:
        print('Exception Error in Masterdatatable: ', Error)

def hrengcons(mname,dte,chr,hreng,eng,mtrsts):
    if (hreng<0 or eng<0 and (mtrsts==0 or mtrsts==2)):
        Masterdatatable.objects.filter(mtmtrname=mname,
                                        mtdate=dte).update(mtmtrstatus=mtrsts)
    else:
        Masterdatatable.objects.filter(mtmtrname=mname,
                                        mtdate=dte).update(mtenergycons=eng,**{chr:hreng},
                                                            mtlastupdt=datetime.now(),
                                                            mtmtrstatus=mtrsts)

def paramUpdate(mname,dte,cshft,seng,eng,plntnme,catnme,srcnme,acteng,mtrsts):
    shftnme = "mts"+str(cshft)+"ec"
    try:
        if (eng<0 or seng<0 and (mtrsts==0 or mtrsts==2)):
            Masterdatatable.objects.filter(mtmtrname=mname, mtdate=dte).update(mtmtrstatus=mtrsts)
        else:
            Masterdatatable.objects.filter(mtmtrname=mname, mtdate=dte).update(mtenergycons=eng,**{shftnme:seng},mtlastupdt=datetime.now(),mtplntlctn=plntnme,mtcategory=catnme,mtsrcname=srcnme,mtpeakvolt=0,mtpeakcrnt=0,mtpwrfctr=0,mtacteng=acteng,mtavgfreq=0,mtmtrstatus=mtrsts,mtmaxdemands=0,mttotalreactivepower=0,mtrctpwr1=0,mtrctpwr2=0,mtrctpwr3=0,mtrealpwr1=0,mtrealpwr2=0,mtrealpwr3=0,mtaprtpwr1=0,mtaprtpwr2=0,mtaprtpwr3=0,mtlv1=0,mtlv2=0,mtlv3=0,mtlc1=0,mtlc2=0,mtlc3=0,mtTHDL1=0,mtTHDL2=0,mtTHDL3=0,mtTHDC1=0,mtTHDC2=0,mtTHDC3=0,mtTHDP1=0,mtTHDP2=0,mtTHDP3=0,mttotalpower=0,mtmindemand=0,mtinsdemand=0,mtminpf=0,mtmaxpf=0)
    except Exception as Error:
        print('Exception Error in Masterdatatable: ', Error)