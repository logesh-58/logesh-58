import threading
from . import dailydatacache,mastertable,meterhealth,maxdemand

class Datacachethread(threading.Thread):

    def __init__(self,meterDatabase_data):
        self.meterDatabase_data=meterDatabase_data
        threading.Thread.__init__(self)
    
    def run(self):
        print("Thread Running")
        dailydatacache.insertcachedata(self.meterDatabase_data)
        mastertable.insertmasterdata(self.meterDatabase_data)
        meterhealth.insertmeterhealth(self.meterDatabase_data)
        maxdemand.max_demand(self.meterDatabase_data)