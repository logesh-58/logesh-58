from django.apps import AppConfig


class MeterDataConfig(AppConfig):
    name = 'meter_data'
