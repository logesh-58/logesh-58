from django.contrib import admin
from meter_data.models import Meterdata
# Register your models here.
admin.site.register(Meterdata)
