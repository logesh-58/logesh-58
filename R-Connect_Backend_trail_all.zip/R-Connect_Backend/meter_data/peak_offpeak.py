from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
from peakhour_dashboard.models import PeakConfig
from .models import Demand
import json
import pandas as pd
import calendar
from rest_framework.parsers import JSONParser

# Hey Code !
def today_yesterday(typ, date_, ph, nph):
    keys_peak = []; keys_npeak = []; get_value = None
    [keys_peak.append(keys)  for hr in ph for dct in DemandEMS.field_name for val in dct.values() if hr == val for keys in dct]
    [keys_npeak.append(keys)  for hr in nph for dct in DemandEMS.field_name for val in dct.values() if hr == val for keys in dct]
    def maximum(peak_nonpeak, date__):
        PNP = []
        for i in peak_nonpeak:
            get_value  = Demand.objects.filter(dm_date = date__).values(i)
            for dict in get_value:
                for keys in dict:
                    PNP.append(dict[keys])
        return PNP
    peak = maximum(keys_peak, date_) ; npeak = maximum(keys_npeak, date_)
    if peak != []: peak = max(peak) 
    else: peak = 0
    if npeak!= []: npeak = max(npeak)
    else: npeak = 0
    return peak, npeak

def last7days(dates, ph, nph):
    peak = []; offpeak = []; api_ = []
    for dte in dates:
        db_field = Demand.objects.filter(dm_date = str(dte.date())).values()
        if str(db_field) != "<QuerySet []>":
            for hr in ph:
                for dt in DemandEMS.field_name:
                    for keys in dt:
                        if dt[keys] == hr:
                            for i in db_field:
                                for j in i:
                                    if keys == j:
                                        peak.append(int((i[j])))
            for hr in nph:
                for dt in DemandEMS.field_name:
                    for keys in dt:
                        if dt[keys] == hr:
                            for i in db_field:
                                for j in i:
                                    if keys == j:
                                        offpeak.append(int((i[j])))
        else:
            peak.append(0); offpeak.append(0)
        api_.append({"date":str(dte.date()), "peak":max(peak), "npeak":max(offpeak)})
        peak = []; offpeak = []
    return api_

def last12month(dates, ph, nph):
    peak = []; offpeak = []; api_ = []
    for dte in dates:
        # print(dte['month'], dte['year'])
        db_field = Demand.objects.filter(dm_date__month = dte['month'], dm_date__year = dte['year']).values()
        # print(db_field)
        if str(db_field) != "<QuerySet []>":
            for hr in ph:
                for dt in DemandEMS.field_name:
                    for keys in dt:
                        if dt[keys] == hr:
                            for i in db_field:
                                for j in i:
                                    if keys == j:
                                        peak.append(int((i[j])))
            for hr in nph:
                for dt in DemandEMS.field_name:
                    for keys in dt:
                        if dt[keys] == hr:
                            for i in db_field:
                                for j in i:
                                    if keys == j:
                                        offpeak.append(int((i[j])))
        else:
            peak.append(0); offpeak.append(0)
        api_.append({"date":str(calendar.month_abbr[dte['month']] + "_" +str(dte['year'])), "peak":max(peak), "npeak":max(offpeak)})
        peak = []; offpeak = []
    return api_

class DemandEMS:
    field_name = [{"dm_h1":6}, {"dm_h2":7}, {"dm_h3":8},{"dm_h4":9},{"dm_h5":10},{"dm_h6":11},{"dm_h7":12},{"dm_h8":13},{"dm_h9":14},{"dm_h10":15},{"dm_h11":16},{"dm_h12":17},
                  {"dm_h13":18}, {"dm_h14":19}, {"dm_h15":20}, {"dm_h16":21}, {"dm_h17":22}, {"dm_h18":23}, {"dm_h19":0}, {"dm_h20":1}, {"dm_h21":2}, {"dm_h22":3},{"dm_h23":4}, {"dm_h24":5}]
    def date_time(self, date_time):
        DemandEMS.shift_datetime = []; shift_int = []; DemandEMS.current_datetime = datetime.now(); nextday_date = DemandEMS.current_datetime + timedelta(days=1)
        for string in date_time:
            dttme_obj = datetime.strptime(str(string), "%H:%M:%S") 
            shift_int.append(int(dttme_obj.hour))

        def Dummy():
            i = 0
            # print(len(shift_list))
            while i<len(date_time):
                if shift_int[i] <= shift_int[i+1]:
                    datetime_objects_from = datetime.combine(DemandEMS.current_datetime , date_time[i])
                    datetime_objects_to   = datetime.combine(DemandEMS.current_datetime , date_time[i+1])
                    DemandEMS.shift_datetime.append(datetime_objects_from)
                    DemandEMS.shift_datetime.append(datetime_objects_to)
                else:
                    datetime_objects_from = datetime.combine(DemandEMS.current_datetime , date_time[i])
                    datetime_objects_to   = datetime.combine(nextday_date , date_time[i+1])
                    DemandEMS.shift_datetime.append(datetime_objects_from)
                    DemandEMS.shift_datetime.append(datetime_objects_to)
                i+=2
        Dummy() 
    # print(shift_datetime)
    def hours(self, timelist):
        DemandEMS.hur = []
        for dct in range(0, len(timelist), 2):
            start_time = timelist[dct]; end_time = timelist[dct+1]
            while start_time <= end_time:
                DemandEMS.hur.append(start_time.hour)
                start_time = start_time + timedelta(hours = 1)
    
    def demand(self, Type, peakhur, Npeak_hur):
        if Type == 'Today':
            DemandEMS.field_date = DemandEMS.current_datetime
            date_  = DemandEMS.field_date
            DemandEMS.peak, DemandEMS.npeak = today_yesterday(Type, date_, peakhur, Npeak_hur)

        elif Type == 'Yesterday':
            DemandEMS.field_date = DemandEMS.current_datetime - timedelta(days=1)
            date_  = DemandEMS.field_date
            DemandEMS.peak, DemandEMS.npeak = today_yesterday(Type, date_, peakhur, Npeak_hur)

        if Type == 'last7days':
            # V Demand.objects.filter(dm_date = DemandEMS.current_datetime).values(v)
            # print(Value)
            DemandEMS.peakhur = []; DemandEMS.offpeak = []; DemandEMS.date  = []
            DemandEMS.field_date = DemandEMS.current_datetime
            start_date = DemandEMS.field_date - timedelta(days = 7)
            end_date   = DemandEMS.field_date - timedelta(days = 1)
            iterate_dates = pd.date_range(start = start_date, end = end_date)
            DemandEMS.api_ = last7days(iterate_dates, peakhur, Npeak_hur)

        if Type == 'This Month':
            DemandEMS.field_date = DemandEMS.current_datetime
            current_year  = DemandEMS.field_date.year
            current_month = DemandEMS.field_date.month
            end_date = None
            start_date = datetime(current_year, current_month , 1).strftime("%Y-%m-%d")
            if current_month == 12:
                end_date = datetime(current_year, current_month, 31).strftime("%Y-%m-%d")
            else:
               end_date = (datetime(current_year, current_month + 1, 1) + timedelta(days=-1)).strftime("%Y-%m-%d")
            iterate_dates = pd.date_range(start = start_date, end = end_date)
            DemandEMS.api_ = last7days(iterate_dates, peakhur, Npeak_hur)

        if Type == 'last30days':
           DemandEMS.field_date = DemandEMS.current_datetime
           start_date = DemandEMS.field_date
           end_date   = start_date - timedelta(days = 30)
           start_date = datetime.strftime(start_date, "%Y-%m-%d") ; end_date = datetime.strftime(end_date, "%Y-%m-%d")
           iterate_dates = pd.date_range(start = end_date, end = start_date)
           DemandEMS.api_ = last7days(iterate_dates, peakhur, Npeak_hur)
        
        if Type == 'This Year':
            DemandEMS.field_date = DemandEMS.current_datetime
            current_month = DemandEMS.field_date.month
            current_year  = DemandEMS.field_date.year
            # print(current_month)
            cur_mon = []; last_mon = []; year = []
            for month in range(1,13):
                if month <= current_month:
                    cur_mon.append({"month": month, "year": current_year})
            DemandEMS.api_ = last12month(cur_mon, peakhur, Npeak_hur)
            
        if Type == 'This Week':
            DemandEMS.field_date = DemandEMS.current_datetime
            dt = DemandEMS.field_date
            start_date = dt - timedelta(days=dt.weekday())
            end_date = start_date + timedelta(days=6)
            iterate_dates = pd.date_range(start = start_date, end = end_date)
            DemandEMS.api_ = last7days(iterate_dates, peakhur, Npeak_hur)
        
        if Type == 'last12months':
            DemandEMS.field_date = DemandEMS.current_datetime 
            current_month = DemandEMS.field_date.month
            current_year  = DemandEMS.field_date.year
            # print(current_month)
            cur_mon = []; last_mon = []; year = []
            for month in range(1,13):
                if month <= current_month:
                    cur_mon.append(month)
            for yr in cur_mon:
                year.append({"month": yr, "year": current_year})
            previous_year = current_year - 1
            for month in range(1,13):
                if month not in cur_mon:
                    last_mon.append({"month": month, "year": previous_year})
            year_month = last_mon + year
            DemandEMS.api_ = last12month(year_month, peakhur, Npeak_hur)

@csrf_exempt
def PeakOffPeak(request):
    if request.method == 'POST':
        plant_name = request.GET['plantname']
        Type = JSONParser().parse(request)['type']
        # plant_name = request.GET['PlantName']
        peak_time = []; offpeak_time = []
        session_time = PeakConfig.objects.values('pkstatus', 'pkstart', 'pkend')
        for pt in session_time:
            # print(pt)
            if pt['pkstatus'] == 'Peak':
                # pt['pkstart']
                peak_time.append(pt['pkstart'])
                peak_time.append(pt['pkend'])
            else:
                offpeak_time.append(pt['pkstart'])
                offpeak_time.append(pt['pkend'])
        # print(peak_time, '\n', offpeak_time)
        # peak_hours = []
        # print(peak_time)
        obj1 = DemandEMS()
        obj1.date_time(peak_time)
        peak_datetimeobj = DemandEMS.shift_datetime
        obj1.hours(peak_datetimeobj)
        peak_hours = list(set(DemandEMS.hur))
        # print("Peak Time", list(set(DemandEMS.hur)))
        Hour_Wise = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
        Npeak_hours = []
        [Npeak_hours.append(item) for item in Hour_Wise if item not in peak_hours]
        # print(peak_hours, Npeak_hours)
        obj1.demand(Type, peak_hours, Npeak_hours) 
        if Type == 'Today' or Type == 'Yesterday' :
            api_peak    = DemandEMS.peak
            api_offpeak = DemandEMS.npeak 
            api_date   = DemandEMS.field_date.date()
            return JsonResponse([{"type": Type, "data":[{"date":api_date, 'peak':api_peak, "npeak":api_offpeak}]} ], safe=False)
        if Type == 'last7days' or Type == 'This Month' or Type == 'last30days' or Type == 'This Week' or Type == 'last12months' or Type == 'This Year':
           dct = DemandEMS.api_
           return JsonResponse([{"type": Type, "data":dct}], safe = False)
