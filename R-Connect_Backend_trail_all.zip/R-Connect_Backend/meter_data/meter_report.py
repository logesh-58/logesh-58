import xlwt
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os   
from RConnect.settings import BASE_DIR
from meter_management.models import AddMeter
from datetime import datetime , timedelta
import pandas as pd
from meter_data.models import MeterStatus
import json

#Create Your Code Here..!
# @csrf_exempt
def meterhealth():
    wb = xlwt.Workbook(encoding='utf-8')
    Metername_data = AddMeter.objects.distinct('ammetername').values('ammetername')
    for metername in Metername_data:
        ws = wb.add_sheet(metername['ammetername'])
        ws.show_grid = False
        style1 =xlwt.XFStyle()
        style2 = xlwt.easyxf('align: rotation 90, vert center, horiz center')
        styleON = xlwt.XFStyle()
        styleOFF = xlwt.XFStyle()
        style3   = xlwt.XFStyle()
        #Set Alignment
        alignment       = xlwt.Alignment()
        alignment.horz  = xlwt.Alignment.HORZ_CENTER
        alignment.vert  = xlwt.Alignment.VERT_CENTER
        alignment.wrap   = 1
        style1.alignment = alignment
        styleON.alignment = alignment
        styleOFF.alignment = alignment
        style3.alignment   = alignment
        #Set border
        border          = xlwt.Borders()
        border.left     = xlwt.Borders.THIN 
        border.right    = xlwt.Borders.THIN
        border.top      = xlwt.Borders.THIN
        border.bottom   = xlwt.Borders.THIN
        style1.borders  = border
        style2.borders  = border
        styleON.borders = border
        styleOFF.borders = border
        style3.borders   = border
        #Set Background Color
        #style1&2_pattern
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['white']
        style1.pattern = pattern
        style2.pattern = pattern
        style3.pattern = pattern
        #styleON
        patternON = xlwt.Pattern()
        patternON.pattern = xlwt.Pattern.SOLID_PATTERN
        patternON.pattern_fore_colour = xlwt.Style.colour_map['bright_green']
        styleON.pattern = patternON
        #styleOFF
        patternOFF = xlwt.Pattern()
        patternOFF.pattern = xlwt.Pattern.SOLID_PATTERN
        patternOFF.pattern_fore_colour = xlwt.Style.colour_map['red']
        styleOFF.pattern = patternOFF
        #Set Font Colo
        #font1
        font1 = xlwt.Font()
        font1.colour_index=xlwt.Style.colour_map['red']
        font1.name = 'Atlanta'
        font1.bold = True
        font1.italic = False
        font1.height = 300
        style1.font = font1
        #font2
        font2 = xlwt.Font()
        font2.colour_index=xlwt.Style.colour_map['black']
        font2.name = 'Atlanta'
        font2.bold = False
        font2.italic = False
        font2.height = 175
        style2.font = font2
        styleON.font = font2
        styleOFF.font = font2
        style3.font   = font2
        row = 1; col = 2
        ws.write_merge(row, row+1, col, col+23, "Meter Health Report - "+ metername['ammetername'] , style1)
        row = 5; col = 2
        hours_list = ['07:00:00','08:00:00','09:00:00','10:00:00','11:00:00','12:00:00','13:00:00','14:00:00','15:00:00',
                      '16:00:00','17:00:00','18:00:00','19:00:00','20:00:00','21:00:00','22:00:00','23:00:00','00:00:00','01:00:00',
                      '02:00:00','03:00:00','04:00:00','05:00:00','06:00:00']
        for hur_data in hours_list:
            ws.row(row).height_mismatch = True
            ws.row(row).height = 1350
            ws.col(col).width = 1500
            ws.write(row, col, hur_data, style2)
            col+=1
        #take month wise start date to current date
        date = (datetime.today()).date()
        month_curdate  = date
        month_srtdate = (month_curdate.replace(day=1))
        # print(month_srtdate, month_curdate)
        srtdate_curdate = pd.date_range(start=month_srtdate, end=month_curdate)
        # print(srtdate_curdate)
        row = 6; col = 1
        ccol = 2
        for stcur_data in srtdate_curdate:
            ws.col(col).width = 3500
            ws.row(row).height_mismatch = True
            ws.row(row).height = 530
            ws.write(row, col, str(stcur_data.date()), style3)
            month_date = stcur_data.date()
            # print(month_date)
            for dict in MeterStatus.objects.filter(ms_date = str(month_date), ms_metername = metername['ammetername']).values():
                # print(dict)
                for keys in dict:
                    if keys != 'ms_id' and keys != 'ms_date' and keys != 'ms_metername' and keys != 'ms_lastupdate':   
                        # print(keys, dict[keys])
                        if dict[keys] == 1:
                            # print(keys)
                            ws.write(row, ccol, "ON", styleON)
                        else:
                            ws.write(row, ccol,"OFF", styleOFF)
                        ccol+=1
            ccol = 2
            row+=1
        # break
    savepath = os.path.join(BASE_DIR,'Report','MeterHealthReport.xls')
    wb.save(savepath)
    return savepath

@csrf_exempt
def healthhours(request):
    if request.method == 'POST':
        stauts_list  = []; hourls_list = []; cumulative_hours = []
        request_data = json.loads(request.body)
        meter_status = MeterStatus.objects.filter(ms_date = request_data['date']).values().order_by('ms_id')
        for data in meter_status:
            for keys in data:
                if ( keys != 'ms_id' and keys != 'ms_date' and keys != 'ms_metername' and keys != 'ms_lastupdate' 
                    and keys != 'ms_h19' and keys != 'ms_h20'and keys != 'ms_h21' and keys != 'ms_h22' and keys!= 'ms_h23' and keys!='ms_h24'): 
                     hourls_list.append(data[keys])
                    #  print(keys)
            
            for keys in data:
                if ( keys == 'ms_h19' or keys == 'ms_h20'or keys == 'ms_h21' or keys == 'ms_h22' or keys == 'ms_h23' or keys=='ms_h24'): 
                #    print(keys)
                   cumulative_hours.append(data[keys])
            for add_data in cumulative_hours:
                hourls_list.append(add_data)
            if hourls_list!=[] and cumulative_hours != []:
               stauts_list.append({"metername":data['ms_metername'], "health": hourls_list})
            hourls_list = []; cumulative_hours = []
        return JsonResponse({"status":stauts_list, "date":['06:00:00', '07:00:00', '08:00:00','09:00:00', '10:00:00', '11:00:00', '12:00:00', '13:00:00', '14:00:00',
                             '15:00:00','16:00:00', '17:00:00', '18:00:00', '19:00:00', '20:00:00', '21:00:00', '22:00:00', '23:00:00', '24:00:00']}, safe=True)