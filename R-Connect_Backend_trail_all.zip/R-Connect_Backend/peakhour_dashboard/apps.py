from django.apps import AppConfig


class PeakhourDashboardConfig(AppConfig):
    name = 'peakhour_dashboard'
