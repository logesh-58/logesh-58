from django.db import models

# Create your models here.
class Timingtable(models.Model):
    ttid = models.AutoField(primary_key=True)
    ttcode = models.CharField(max_length=255,default=False,null=True)
    ttplntname = models.CharField(max_length=255,default=False,null=True)
    ttdaystarttime = models.TimeField(null=True)
    tts1time = models.TimeField(null=True)
    tts2time = models.TimeField(null=True)
    tts3time = models.TimeField(null=True)
    ttlastupdate = models.DateTimeField(auto_now_add=True,null=True)
    ttcreatedby = models.CharField(max_length=255,default=False,null=True)
    ttmodifiedby = models.CharField(max_length=255,default=False,null=True)
