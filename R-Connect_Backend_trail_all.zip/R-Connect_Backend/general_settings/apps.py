from django.apps import AppConfig


class GeneralSettingsConfig(AppConfig):
    name = 'general_settings'
