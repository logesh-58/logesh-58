from django.conf.urls import url
from general_settings import views

urlpatterns =[
    url('generalconfig/',views.generalset,name='general_config')
]