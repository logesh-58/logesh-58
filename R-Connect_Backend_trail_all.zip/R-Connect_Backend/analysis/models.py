# from django.db import models
# from mouldmanagement.models import Mouldmodel
# # Create your models here.
# class Analysis(models.Model):
#     id = models.AutoField(primary_key=True)
#     Date = models.DateField(default=False, null=True)
#     Time = models.CharField(max_length=255, default=False, null=True)
#     Day = models.CharField(max_length=255, default=False, null=True)
#     Machinename = models.CharField(max_length=255,null=True,default=False)
#     Mouldname = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
#     Target = models.IntegerField(default=False, null=True)
#     Actual = models.IntegerField(default=False, null=True)
