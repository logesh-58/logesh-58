from django.urls import path
from .import views, analysis

urlpatterns = [
    # path('daywise/', views.daywise,name="daywise"),
    path('daywisemachines/', views.daywisemachines,name="daywise"),
    # path('weekwise/', views.weekwise,name="daywise"),
    path('weekwisemachines/', views.weekwiseMachines,name="daywise"),
    # path('weekdaychart/', views.weekdaychart,name="daywise"),
    # path('dayefficiency/', views.dayefficiencydata,name="dayefficiency"),
    # path('weekefficiency/', views.weekefficiencydata,name="daywise"),
    path('overallefficiency/', views.overallefficiencydata,name="daywise"),
    path('daywiseMouldefficiency/', views.daywisemouldeffdata,name="daywise"),
    path('weekwisemachineefficiency/', views.weekwisemachineefficiency,name="daywise"),

    path('daywise/', analysis.daywise,name="daywise"),
    path('weekwise/', analysis.weekwise,name="daywise"),
    path('weekdaychart/', analysis.weekdaychart,name="daywise"),

]
