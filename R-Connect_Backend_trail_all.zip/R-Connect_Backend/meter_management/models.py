from django.db import models
from django.db.models.base import Model


# Create your models here.
class AddMeter(models.Model):
    # group_choice=(
    #             ('IMG','IMG'),
    #             ('Non-Production','Non-Production'),
    #             ('Paintshop','Paintshop')
    # )
    amid = models.AutoField(primary_key=True)
    ammetername = models.CharField(max_length=255,default=False,null=True)
    ammetercode = models.CharField(max_length=255,default=False,null=True)
    ammetergroup = models.CharField(max_length=255,default=False,null=True)
    ammetersource = models.CharField(max_length=255,default=False,null=True)
    ammetercategory = models.CharField(max_length=255,default=False,null=True)
    ammeterlocation = models.CharField(max_length=255,default=False,null=True)
    amplantname = models.CharField(max_length=255,default=False,null=True)
    amconsiderbool = models.BooleanField(default=False,null=True)