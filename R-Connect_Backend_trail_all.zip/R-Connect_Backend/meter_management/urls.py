from django.conf.urls import url
from meter_management import views

urlpatterns=[
    url('metermanagement/',views.addmeter,name='meter_management'),    
]