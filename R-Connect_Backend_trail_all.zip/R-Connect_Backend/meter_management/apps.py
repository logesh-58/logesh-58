from django.apps import AppConfig


class MeterManagementConfig(AppConfig):
    name = 'meter_management'
