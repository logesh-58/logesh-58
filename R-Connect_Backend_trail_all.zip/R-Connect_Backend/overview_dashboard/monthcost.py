from peakhour_dashboard.models import PeakConfig 
import pandas as pd
from datetime import datetime , timedelta
from meter_data.models import Masterdatatable
from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse, HttpResponse
from costestimator.models import Cost_DG, Cost_EB, Cost_Solar, Cost_Wind


#######################################################################################################################
##################################  TOTAL COST FOR DAILY WISE ENERGY CONSUMPTION REPORT ###############################
#######################################################################################################################

def totalcost():
    # print("Daily Wise Consumption")
    coe = "Transformer1"
    mastertable_transformer = Masterdatatable.objects.filter(mtsrcname = coe, mtcategory="Secondary", mtgrpname='Incomer').values('mtmtrname','mtenergycons','mtdate').order_by('mtdate')
    total = 0
    date = (datetime.today()).date()
    cur_date  = date
    # print(cur_date)
    srt_date = (cur_date.replace(day=1))
    # print(srt_date)
    dly_date = pd.date_range(start=srt_date, end=cur_date)
    for dte in dly_date:
        dly_dte = (dte.date())
        # print(dly_dte)
        for t in mastertable_transformer:
            if t['mtdate'] == dly_dte:
            #     global a
                total = t['mtenergycons'] + total
    # print("Total_Consumption :" , total)
    current_date = datetime.now() 
    mastertble_trans = Masterdatatable.objects.filter(mtsrcname = coe,mtdate = current_date).values('mtmtrname','mtdate','mth1ec','mth2ec','mth3ec','mth4ec','mth5ec','mth6ec',
                                                                                        'mth7ec','mth8ec','mth9ec','mth10ec','mth11ec','mth12ec','mth13ec',
                                                                                        'mth14ec','mth15ec','mth16ec','mth17ec','mth18ec','mth19ec','mth20ec',
                                                                                        'mth21ec','mth22ec','mth23ec','mth24ec')
    # print(mastertble)
    count_1= 0;count_2 = 0; count_3 = 0; count_4 = 0; count_5 =0; count_6 = 0; count_7 = 0; count_8 = 0; count_9 = 0; count_10 = 0; count_11 = 0; count_12 = 0
    mth1ec='';mth2ec='';mth3ec='';mth4ec='';mth5ec ='';mth6ec='';mth7ec='';mth8ec='';mth9ec='';mth10ec='';mth11ec='';mth12ec='';mth13ec='';mth14ec='';mth15ec='';mth16ec='';mth17ec='';mth18ec='';mth19ec='';mth20ec='';mth21ec='';mth22ec='';mth23ec = '';mth24ec=''
    session_config = PeakConfig.objects.values("pkstatus","pkstart","pkend")
    for ms in mastertble_trans:
        # print(i['mtmtrname'])
        for w in ms:
            # print(w)
            if w == "mth1ec":
                mth1ec = datetime.strptime("7:00:00","%H:%M:%S").time()
                count_1 = 1
                # print(mth1ec)
            if w == "mth2ec":
                mth2ec = datetime.strptime("8:00:00","%H:%M:%S").time()
                count_2 = 2
                # print(mth2ec)
            if w == "mth3ec":
                mth3ec = datetime.strptime("9:00:00","%H:%M:%S").time()
                count_3 = 3
                # print(mth3ec)
            if w == "mth4ec":
                mth4ec = datetime.strptime("10:00:00","%H:%M:%S").time()
                count_4 = 4
                # print(mth4ec)
            if w == "mth5ec":
                mth5ec = datetime.strptime("11:00:00","%H:%M:%S").time()
                count_5 = 5
                # print(mth5ec)
            if w == "mth6ec":
                mth6ec = datetime.strptime("12:00:00","%H:%M:%S").time()
                count_6 = 6
                # print(mth6ec)
            if w == "mth7ec":
                mth7ec = datetime.strptime("13:00:00","%H:%M:%S").time()
                count_7 = 7
                # print(mth7ec)
            if w == "mth8ec":
                mth8ec = datetime.strptime("14:00:00","%H:%M:%S").time()
                count_8 = 8
                # print(mth8ec)
            if w == "mth9ec":
                mth9ec = datetime.strptime("15:00:00","%H:%M:%S").time()
                count_9 = 9
                # print(mth9ec)
            if w == "mth10ec":
                mth10ec = datetime.strptime("16:00:00","%H:%M:%S").time()
                count_10 = 10
                # print(mth10ec)
            if w == "mth11ec":
                mth11ec = datetime.strptime("17:00:00","%H:%M:%S").time()
                count_11 = 11
                # print(mth11ec)
            if w == "mth12ec":
                mth12ec = datetime.strptime("18:00:00","%H:%M:%S").time()
                count_12 = 12
                # print(mth12ec)
            if w == "mth13ec":
                mth13ec = datetime.strptime("19:00:00","%H:%M:%S").time()
                count_13 = 13
                # print(mth13ec)
            if w == "mth14ec":
                mth14ec = datetime.strptime("20:00:00","%H:%M:%S").time()
                count_14 = 14
                # print(mth14ec)
            if w == "mth15ec":
                mth15ec = datetime.strptime("21:00:00","%H:%M:%S").time()
                count_15 = 15
                # print(mth15ec)
            if w == "mth16ec":
                mth16ec = datetime.strptime("22:00:00","%H:%M:%S").time()
                count_16 = 16
                # print(mth16ec)
            if w == "mth17ec":
                mth17ec = datetime.strptime("23:00:00","%H:%M:%S").time()
                count_17 = 17
                # print(mth17ec)
            if w == "mth18ec":
                mth18ec = datetime.strptime("00:00:00","%H:%M:%S").time()
                count_18 = 18
                # print(mth18ec)
            if w == "mth19ec":
                mth19ec = datetime.strptime("1:00:00","%H:%M:%S").time()
                count_19 = 19
                # print(mth19ec)
            if w == "mth20ec":
                mth20ec = datetime.strptime("2:00:00","%H:%M:%S").time()
                count_20 = 20
                # print(mth20ec)
            if w == "mth21ec":
                mth21ec = datetime.strptime("3:00:00","%H:%M:%S").time()
                count_21 = 21
                # print(mth21ec)
            if w == "mth22ec":
                mth22ec = datetime.strptime("4:00:00","%H:%M:%S").time()
                count_22 = 22
                # print(mth22ec)
            if w == "mth23ec":
                mth23ec = datetime.strptime("5:00:00","%H:%M:%S").time()
                count_23 = 23
                # print(mth23ec)
            if w == "mth24ec":
                mth24ec = datetime.strptime("6:00:00","%H:%M:%S").time()
                count_24 = 24
                # print(mth24ec)
    # print(mth1ec , mth2ec , mth3ec , mth4ec, mth5ec , mth6ec, mth7ec, mth8ec, mth9ec, mth10ec, mth11ec, mth12ec, mth13ec, mth14ec, mth15ec, mth16ec, mth17ec, mth18ec, mth19ec, mth20ec, mth21ec, mth22ec, mth23ec, mth24ec)
    val = 0
    val_2 =  0 
    total_cos = 0
    for e in session_config:
        pkstart = e['pkstart']
        datetime_objects = datetime.combine(current_date , pkstart) 
        incr_onehur = datetime_objects + timedelta(hours=1) 
        pkstart =  incr_onehur.time()
        if pkstart ==  mth1ec:
            # print("ps_mth1ec :",e["pkstart"])
            val = count_1
        if pkstart == mth2ec:
            # print("ps_mth2ec :",e['pkstart'])
            val = count_2
        if pkstart== mth3ec:
            # print("ps_mth3ec :",e['pkstart'])
            val = count_3
        if pkstart == mth4ec:
            # print("ps_mth4ec :",e['pkstart'])
            val = count_4
        if pkstart == mth5ec:
            # print("ps_mth5ec :",e['pkstart'])
            val = count_5
        if pkstart == mth6ec:
            # print("ps_mth6ec :",i['pkstart'])
            val = count_6
        if pkstart == mth7ec:
            # print("ps_mth7ec :",i['pkstart'])
            val = count_7
        if pkstart == mth8ec:
            # print("ps_mth8ec :",i['pkstart'])
            val = count_8
        if pkstart == mth9ec:
            # print("ps_mth9ec :",i['pkstart'])
            val = count_9
        if pkstart == mth10ec:
            # print("ps_mth10ec :",i['pkstart'])
            val = count_10
        if pkstart == mth11ec:
            # print("ps_mth11ec :",i['pkstart'])
            val = count_11
        if pkstart == mth12ec:
            # print("ps_mth12ec :",i['pkstart'])
            val = count_12
        if pkstart == mth13ec:
            # print("ps_mth13ec :",i['pkstart'])
            val = count_13
        if pkstart == mth14ec:
            # print("ps_mth14ec :",i['pkstart'])
            val = count_14
        if pkstart == mth15ec:
            # print("ps_mth15ec :",i['pkstart'])
            val = count_15
        if pkstart == mth16ec:
            # print("ps_mth16ec :",i['pkstart'])
            val = count_16
        if pkstart == mth17ec:
            # print("ps_mth17ec :",i['pkstart'])
            val = count_17
        if pkstart == mth18ec:
            # print("ps_mth18ec :",i['pkstart'])
            val = count_18
        if pkstart == mth19ec:
            # print("ps_mth19ec :",i['pkstart'])
            val = count_19 
        if pkstart == mth20ec:
            # print("ps_mth20ec :",i['pkstart'])
            val = count_20
        if pkstart == mth21ec:
            # print("ps_mth21ec :",i['pkstart'])
            val = count_21
        if pkstart == mth22ec:
            # print("ps_mth22ec :",i['pkstart'])
            val = count_22
        if pkstart == mth23ec:
            # print("ps_mth23ec :",i['pkstart'])
            val = count_23
        if pkstart == mth24ec:
            # print("ps_mth24ec :",i['pkstart'])
            val = count_24

        #pkend
        if e['pkend'] == mth1ec:
            # print("pe_mth1ec :" , i['pkend'])
            val_2 = count_1
        if e['pkend'] == mth2ec:
            # print("pe_mth2ec :" , i['pkend'])
            val_2 = count_2
        if e['pkend'] == mth3ec:
            # print("pe_mth3ec :" , i['pkend'])
            val_2 = count_3
        if e['pkend'] == mth4ec:
            # print("pe_mth4ec :" , i['pkend'])
            val_2 = count_4
        if e['pkend'] == mth5ec:
            # print("pe_mth5ec :", i['pkend'])
            val_2 = count_5
        if e['pkend'] == mth6ec:
            # print("pe_mth6ec :", i['pkend'])
            val_2 = count_6
        if e['pkend'] == mth7ec:
            # print("pe_mth7ec :", i['pkend'])
            val_2 = count_7
        if e['pkend'] == mth8ec:
            # print("pe_mth8ec :", i['pkend'])
            val_2 = count_8
        if e['pkend'] == mth9ec:
            # print("pe_mth9ec :", i['pkend'])
            val_2 = count_9
        if e['pkend'] == mth10ec:
            # print("pe_mth10ec :", i['pkend'])
            val_2 = count_10
        if e['pkend'] == mth11ec:
            # print("pe_mth11ec :", i['pkend'])
            val_2 = count_11
        if e['pkend'] == mth12ec:
            # print("pe_mth12ec :", i['pkend'])
            val_2 = count_12
        if e['pkend'] == mth13ec:
            # print("pe_mth13ec :", i['pkend'])
            val_2 = count_13 
        if e['pkend'] == mth14ec:
            # print("pe_mth14ec :", i['pkend'])
            val_2 = count_14
        if e['pkend'] == mth15ec:
            # print("pe_mth15ec :", i['pkend'])
            val_2 = count_15 
        if e['pkend'] == mth16ec:
            # print("pe_mth16ec :", i['pkend'])
            val_2 = count_16
        if e['pkend'] == mth17ec:
            # print("pe_mth17ec :", i['pkend'])
            val_2 = count_17
        if e['pkend'] == mth18ec:
            # print("pe_mth18ec :", i['pkend'])
            val_2 = count_18 
        if e['pkend'] == mth19ec:
            # print("pe_mth19ec :", i['pkend'])
            val_2 = count_19 
        if e['pkend'] == mth20ec:
            # print("pe_mth20ec :", i['pkend'])
            val_2 = count_20
        if e['pkend'] == mth21ec:
            # print("pe_mth21ec :", i['pkend'])
            val_2 = count_21
        if e['pkend'] == mth22ec:
            # print("pe_mth22ec :", i['pkend'])
            val_2 = count_22 
        if e['pkend'] == mth23ec:
            # print("pe_mth23ec :", i['pkend'])
            val_2 = count_23 
        if e['pkend'] == mth24ec:
            # print("pe_mth24ec :", i['pkend'])
            val_2 = count_24 

        # print(val , val_2)
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';
        m24ec=''
        for n in range(val, val_2+1):
            if n == 1:
                m1ec = 'mth1ec'
                # print(m1ec)
            if n == 2:
                m2ec = 'mth2ec'
                # print(m2ec)
            if n == 3:
                m3ec = 'mth3ec'
                # print(m3ec)      
            if n == 4:
                m4ec = 'mth4ec'
                # print(m4ec)
            if n == 5:
                m5ec = 'mth5ec'
                # print(m5ec)
            if n == 6:
                m6ec = 'mth6ec'
                # print(m6ec)
            if n == 7:
                m7ec = 'mth7ec'
                # print(m7ec)
            if n == 8:
                m8ec = 'mth8ec'
                # print(m8ec)
            if n == 9:
                m9ec = 'mth9ec'
                # print(m9ec)
            if n == 10:
                m10ec = 'mth10ec'
                # print(m10ec)
            if n == 11:
                m11ec = 'mth11ec'
                # print(m11ec)
            if n == 12:
                m12ec = 'mth12ec'
                # print(m12ec)
            if n == 13:
                m13ec = 'mth13ec'
                # print(m13ec)
            if n == 14:
                m14ec = 'mth14ec'
                # print(m14ec)
            if n == 15:
                m15ec = 'mth15ec'
                # print(m15ec)
            if n == 16:
                m16ec = 'mth16ec'
                # print(m16ec)
            if n == 17:
                m17ec = 'mth17ec'
                # print(m17ec)
            if n == 18:
                m18ec = 'mth18ec'
                # print(m18ec)
            if n == 19:
                m19ec = 'mth19ec'
                # print(m19ec)
            if n == 20:
                m20ec = 'mth20ec'
                # print(m20ec)
            if n == 21:
                m21ec = 'mth21ec'
                # print(m21ec)
            if n == 22:
                m22ec = 'mth22ec'
                # print(m22ec)
            if n == 23:
                m23ec = 'mth23ec'
                # print(m23ec)
            if n == 24:
                m24ec = 'mth24ec'
                # print(m24ec)
            
        vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
        vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
               
        mastertble_daily_wise = Masterdatatable.objects.filter(mtsrcname = 'Transformer1', mtcategory="Secondary", mtgrpname='Incomer').all().values()
        total_cost = 0 
        for dte in dly_date:
            dly_dte = (dte.date())
            for q_sess in mastertble_daily_wise:
                if q_sess['mtdate'] == dly_dte:
                    for z in q_sess:
                        if z == m1ec:
                            if q_sess['mth1ec'] == None:
                                vl_1 = 0 + vl_1
                            else:
                               vl_1  = q_sess['mth1ec'] + vl_1
                            #    print(vl_1)
                        if z == m2ec:
                            if q_sess['mth2ec'] == None:
                                vl_2 = 0 + vl_2
                            else:
                               vl_2  = q_sess['mth2ec'] + vl_2
                            #    print(vl_2)
                        if z == m3ec:
                            if q_sess['mth3ec'] == None:
                                vl_3= 0 + vl_3
                            else:
                               vl_3  = q_sess['mth3ec'] + vl_3
                            #    print(vl_3)
                        if z == m4ec:
                            if q_sess['mth4ec'] == None:
                                vl_4 = 0 + vl_4
                            else:
                               vl_4  = q_sess['mth4ec']  + vl_4
                            #    print(vl_4) 
                        if z == m5ec:
                            if q_sess['mth5ec'] == None:
                                vl_5 = 0 + vl_5
                            else:
                               vl_5  = q_sess['mth5ec'] + vl_5
                            #    print(vl_5)
                        if z == m6ec:
                            if q_sess['mth6ec'] == None:
                                vl_6 = 0 + vl_6
                            else:
                               vl_6  = q_sess['mth6ec'] + vl_6
                            #    print(vl_6)
                        if z == m7ec:
                            if q_sess['mth7ec'] == None:
                                vl_7 = 0 + vl_7
                            else:
                               vl_7  = q_sess['mth7ec'] + vl_7
                            #    print(vl_7)
                        if z == m8ec:
                            if q_sess['mth8ec'] == None:
                                vl_8 = 0 + vl_8
                            else:
                               vl_8  = q_sess['mth8ec'] + vl_8
                            #    print(vl_8)
                        if z == m9ec:
                            if q_sess['mth9ec'] == None:
                                vl_9 = 0 + vl_9
                            else:
                               vl_9  = q_sess['mth9ec'] + vl_9
                            #    print(vl_9)
                        if z == m10ec:
                            if q_sess['mth10ec'] == None:
                                vl_10 = 0 + vl_10
                            else:
                               vl_10  = q_sess['mth10ec'] + vl_10
                            #    print(vl_10)
                        if z == m11ec:
                            if q_sess['mth11ec'] == None:
                                vl_11 = 0 + vl_11
                            else:
                               vl_11  = q_sess['mth11ec'] + vl_11
                            #    print(vl_11)
                        if z == m12ec:
                            if q_sess['mth12ec'] == None:
                                vl_12 = 0 + vl_12
                            else:
                               vl_12  = q_sess['mth12ec'] + vl_12
                            #    print(vl_12)
                        if z == m13ec:
                            if q_sess['mth13ec'] == None:
                                vl_13 = 0 + vl_13
                            else:
                               vl_13  = q_sess['mth13ec'] + vl_13
                            #    print(vl_13)
                        if z == m14ec:
                            if q_sess['mth14ec'] == None:
                                vl_14 = 0 + vl_14
                            else:
                               vl_14  = q_sess['mth14ec'] + vl_14
                            #    print(vl_14)
                        if z == m15ec:
                            if q_sess['mth15ec'] == None:
                                vl_15 = 0 + vl_15
                            else:
                               vl_15  = q_sess['mth15ec'] + vl_15
                            #    print(vl_15)
                        if z == m16ec:
                            if q_sess['mth16ec'] == None:
                                vl_16 = 0 + vl_16
                            else:
                               vl_16  = q_sess['mth16ec'] + vl_16
                            #    print(vl_16)
                        if z == m17ec:
                            if q_sess['mth17ec'] == None:
                                vl_17 = 0 + vl_17
                            else:
                               vl_17  = q_sess['mth17ec'] + vl_17
                            #    print(vl_17)
                        if z == m18ec:
                            if q_sess['mth18ec'] == None:
                                vl_18 = 0 + vl_18
                            else:
                               vl_18  = q_sess['mth18ec'] + vl_18
                            #    print(vl_18)
                        if z == m19ec:
                            if q_sess['mth19ec'] == None:
                                vl_19 = 0 + vl_19
                            else:
                               vl_19  = q_sess['mth19ec'] + vl_19
                            #    print(vl_19)
                        if z == m20ec:
                            if q_sess['mth20ec'] == None:
                                vl_20 = 0 + vl_20
                            else:
                               vl_20 = q_sess['mth20ec'] + vl_20
                            #    print(vl_20)
                        if z == m21ec:
                            if q_sess['mth21ec'] == None:
                                vl_21 = 0 + vl_21
                            else:
                               vl_21  = q_sess['mth21ec'] + vl_21
                            #    print(vl_21)
                        if z == m22ec:
                            if q_sess['mth22ec'] == None:
                                vl_22 = 0 + vl_22
                            else:
                               vl_22  = q_sess['mth22ec'] + vl_22
                            #    print(vl_22)
                        if z == m23ec:
                            if q_sess['mth23ec'] == None:
                                vl_23 = 0 + vl_23
                            else:
                               vl_23  = q_sess['mth23ec'] + vl_23
                            #    print(vl_23)
                        if z == m24ec:
                            if q_sess['mth24ec'] == None:
                                vl_24 = 0 + vl_24
                            else:
                               vl_24 = q_sess['mth24ec'] + vl_24
                            #    print(vl_24)  
            
            Add = vl_1 + vl_2 + vl_3 + vl_4 + vl_5 + vl_6 + vl_7 + vl_8 + vl_9 + vl_10  + vl_11 + vl_12 + vl_13 + vl_14 + vl_15 + vl_16 + vl_17 + vl_18 +vl_19 + vl_20 + vl_21 + vl_22 + vl_23 + vl_24
            # print(dly_dte ,  Add)
            vl_1 = 0; vl_2 = 0; vl_3 = 0; vl_4 = 0; vl_5 = 0; vl_6 = 0; vl_7 = 0; vl_8 = 0; vl_9 =0; vl_10=0; vl_11=0; vl_12=0; vl_13=0; vl_14=0; vl_15=0; vl_16=0
            vl_17=0; vl_18=0; vl_19=0; vl_20=0; vl_21=0; vl_21=0; vl_22=0; vl_23=0; vl_24=0
            total_cost = total_cost + Add
             
        cost_eb = Cost_EB.objects.filter(EB_Session = e['pkstatus']).values('EB_SessionCost')
        total = 0
        if cost_eb:
          for cst in cost_eb:
            total = cst['EB_SessionCost'] * total_cost
        else:
            total = 0

        total_cos = total + total_cos
         
        m1ec = '';m2ec='';m3ec='';m4ec=''; m5ec='';m6ec='';m7ec='';m8ec='';m9ec='';m10ec='';m11ec='';m12ec='';m13ec='';m14ec='';m15ec='';m16ec='';m17ec='';m18ec='';m19ec='';m20ec='';m21ec='';m22ec='';m23ec='';m24ec=''
    
    # print("Total_Cost :" , total_cos)
    return (round(total_cos, 0))