from django.apps import AppConfig


class OverviewDashboardConfig(AppConfig):
    name = 'overview_dashboard'
