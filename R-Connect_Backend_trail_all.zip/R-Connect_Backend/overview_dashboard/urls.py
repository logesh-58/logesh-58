from django.conf.urls import url
from overview_dashboard import views

urlpatterns=[
    url('overviewdashboard/',views.overviewdata,name='overviewdashboard'),   
]