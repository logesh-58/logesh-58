from django.conf.urls import url 
from mtrstatus_mail import views

urlpatterns = [
    url('testmtrstatus/',views.MeterStatusMail,name='MeterStatusMail')
]
