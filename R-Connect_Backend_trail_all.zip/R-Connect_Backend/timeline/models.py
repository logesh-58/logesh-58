from django.db import models
from django.contrib.postgres.fields import ArrayField
from mouldmanagement.models import Mouldmodel

# Create your models here.
class timeline(models.Model):
    id                  = models.AutoField(primary_key=True)
    date                = models.CharField(max_length=255, default=False, null=True)
    lasttime            = models.CharField(max_length=255, default=False, null=True)
    Plantname           = models.CharField(max_length=255, default=False, null=True)
    Machinename         = models.CharField(max_length=255, default=False, null=True)
    Mouldname           = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    machinetype         = models.CharField(max_length=255,default=False,null=True)
    operation           = models.CharField(max_length=255, default=False, null=True)
    totalparts          = models.IntegerField(default=False, null=True)
    moldchangetime      = models.CharField(max_length=255, default=False, null=True)
    moldchangenumber    = models.IntegerField(default=False, null=True)
    productionhour      = models.CharField(max_length=255, default=False, null=True)
    nonproductionhour   = models.CharField(max_length=255, default=False, null=True)
    time                = ArrayField(models.CharField(max_length=255), default=False, null=True)
    status              = ArrayField(models.CharField(max_length=255), default=False, null=True)
    reason              = ArrayField(models.CharField(max_length=255), default=False, null=True)
    value               = ArrayField(models.CharField(max_length=255), default=False, null=True)
    cause               = ArrayField(models.CharField(max_length=255), default=False, null=True)
    name                = ArrayField(models.CharField(max_length=255), default=False, null=True)

class breakdown(models.Model):
    id                  = models.AutoField(primary_key=True)
    date                = models.CharField(max_length=255, default=False, null=True)
    time                = models.CharField(max_length=255, default=False, null=True)
    Plantname           = models.CharField(max_length=255, default=False, null=True)
    Machinename         = models.CharField(max_length=255, default=False, null=True)
    Mouldname           = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    MachineState        = models.IntegerField(null=True, default=False)
    primaryreason       = models.IntegerField(null=True, default=False)
    rootcause           = models.CharField(max_length=255, default=False, null=True)

class badpart(models.Model):
    id                  = models.AutoField(primary_key=True)
    date                = models.CharField(max_length=255, default=False, null=True)
    time                = models.CharField(max_length=255, default=False, null=True)
    Machinename         = models.CharField(max_length=255, default=False, null=True)
    Mouldname           = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    partcount           = models.IntegerField(null=True, default=False)
    reason              = models.IntegerField(null=True, default=False)
    Plantname           = models.CharField(max_length=255, default=False, null=True)