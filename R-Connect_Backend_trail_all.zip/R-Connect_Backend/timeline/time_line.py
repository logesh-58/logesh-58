from mouldmanagement.models import Mouldmodel
from productiontable.views import name
from django.shortcuts import render
from workflow.models import Tickets
from machinemanagement.models import AddMachine
import datetime
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import badpart, breakdown, timeline
from .serializers import RejectionPartsSerializers, breakdownSerializers, timelineSerializers
import json
from productiontable.models import ProductionTable
from shiftmanagement.models import ShiftTimings
from celery.schedules import crontab
# from celery.task import periodic_task
from analysis.views import machineArray
from usermanagement.models import AddUser
from django.db.models import Q

def shiftStarttime(Plantname):
    shiftstarttime = datetime.datetime.now().time()
    for i in (ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')):    shiftstarttime = i['shift1start']
    return shiftstarttime

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------- Breakdown --------------------------------

def breakdownReason(reasonnumber):
    reasonarray = ['Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
    # reasonarray = ['Mold Change', 'Tool Change', 'Material Change', 'Maintenance', 'Production', 'Operator']
    # print(reasonnumber - 1)
    # print(reasonarray[reasonnumber - 1])
    return reasonarray[reasonnumber - 1]

def diffTime(i, previoustime, currenttime, down_time):
    dict = {
        'id'            : i['id'], 
        'date'          : i['date'], 
        'difftime'      : str(down_time), 
        'Machinename'   : i['Machinename'], 
        'Mouldname'      : i['Mouldname'],  
        'MachineState'  : i['MachineState'], 
        'primaryreason' : breakdownReason(i['primaryreason']),
        'rootcause'     : i['rootcause'],
        'starttime'     : (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')).time(),
        'endtime'       : (datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')).time()
    }
    return dict

def fetchDowntimeData(today,nextDate, daystart, machinename, Plantname):
    breakdowndata           = breakdown.objects.filter(Q(date = today, time__gte = daystart, Machinename = machinename, Plantname = Plantname) | Q (date = nextDate, time__lte = daystart, Machinename = machinename, Plantname = Plantname)).all().order_by('id')
    # print(type(breakdowndata))
    breakdown_serialdata    = breakdownSerializers(breakdowndata, many=True)
    # print(type(breakdown_serialdata))
    # print(type(breakdown_serialdata.data))
    previousstate = -1; previoustime = ''
    currentstate = -1; currenttime = ''
    flag = 0
    DataArray = []; dict = None
    for i in (breakdown_serialdata.data):
        # print(i)
        currentstate = i['MachineState']
        currenttime  = i['date'] + " " + i['time'] 
        Mouldname_data = Mouldmodel.objects.filter(id = i['Mouldname']).values('Mouldname')
        # print(i['Mouldname'])
        for molddata in Mouldname_data:
            i['Mouldname'] = molddata['Mouldname']
        if(flag == 0):
            previousstate = currentstate
            previoustime  = currenttime
            flag = 1
        # print(previoustime, previousstate, currentstate, currenttime)
        if(previousstate == 0 and currentstate == 1):
            # if((previousstate != currentstate) and (previousstate < currentstate)):
            difftime = ((datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')) - (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')))
            if int(difftime.total_seconds()) >= 300:
               dict = diffTime(i, previoustime, currenttime, difftime)
               DataArray.append(dict)
        previousstate = currentstate
        previoustime  = currenttime
        # break
    return DataArray

@csrf_exempt
def data(request):
    if(request.method == 'POST'):
        inputDate = (json.loads(request.body))['date']
        Plantname = request.GET['Plantname']
        Prd_strtime = shiftStarttime(Plantname)
        nextDate = str((datetime.datetime.strptime(inputDate, '%Y-%m-%d') + datetime.timedelta(days = 1)).date())
        MasterMachineArray = machineArray(Plantname)
        dict =[]; machines = []; mouldchange = []
        # MasterMachineArray = ['3200T']
        for Machine in MasterMachineArray:
            downtime = fetchDowntimeData(inputDate, nextDate, Prd_strtime, Machine, Plantname)
            try:
                TimeArray   = []; StatusArray = []; ReasonArray = []; CauseArray = []; mouldflagid = 0; nonproductionseconds = 0
                #-------------------------
                #Get Machine Start and end time for calc production and non production time
                MStartTime = ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0) |
                                                                Q (date = nextDate, time__lte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0)).values('time').first()['time']
                MEndTime   = ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0)| Q (date = nextDate, time__lte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0)).values('time').last()['time']
                hur = datetime.datetime.strptime(MEndTime, '%H:%M:%S').hour
                TotalProdCount = ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0) | Q (date = nextDate, time__lte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0)).count()
                if  hur >= 0 and hur < 6:
                    end_time = nextDate + " " + MEndTime
                    start_time = inputDate + " " + MStartTime
                else:
                    end_time = inputDate + " " + MEndTime
                    start_time = inputDate + " " + MStartTime
                TotalRunSeconds = (datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S') - datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')).total_seconds()
                # print(MStartTime, MEndTime, TotalRunSeconds, TotalProdCount)
                # print(TotalProdCount)
                #-------------------------
                #Get machines produced mold names and sort it using lamda function
                try:
                    sorted_getmold = (list(ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 1, MachineState__gte = 0)| Q (date = nextDate, time__lte = Prd_strtime, Machinename = Machine, ProductionCountActual__gte = 1, MachineState__gte = 0)).values('id', 'Mouldname_id').order_by('id')))
                except:
                    sorted_getmold = []
        #             # print(sorted_getmold)
        #             #Get distinct mold from sorted mold
        #         timeflag = 0; moldflag = 0
                # print(sorted_getmold)
                uniquesortedmold = []; tempcount = 0; currmoldid = 0; idarray = []
                for mold in sorted_getmold:
                    currmold = mold['Mouldname_id']
                    currmoldid = mold['id']
                    if(tempcount == 0):
                        prevmold = mold['Mouldname_id']
                        prevmoldid = mold['id']
                        uniquesortedmold.append(mold['Mouldname_id'])
                        idarray.append(prevmoldid)
                        tempcount = 1
                    if(tempcount ==1):
                        if(currmold != prevmold):
                            uniquesortedmold.append(mold['Mouldname_id'])
                            idarray.append(prevmoldid)
                            idarray.append(currmoldid)
                    prevmold = currmold
                    prevmoldid = currmoldid
                idarray.append(currmoldid)
                # print(idarray)
                # print(uniquesortedmold)                             
                index = 0
                # print(uniquesortedmold)
                for Mouldname_id in uniquesortedmold:
                    Mouldname   = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')[0]['Mouldname']
                    if(mouldflagid == 0):
                        mouldflagid = Mouldname_id
                        # print(Mouldname)
                        StartTime   = (ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Mouldname_id = Mouldname_id, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0) |
                                                                Q (date = nextDate, time__lte = Prd_strtime, Mouldname_id = Mouldname_id, MachineState__gte = 0 , Machinename = Machine, ProductionCountActual__gte = 0)).values('time').first())['time']
                        EndTime     = (ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Mouldname_id = Mouldname_id, MachineState__gte = 0 , Machinename = Machine, ProductionCountActual__gte = 0) |
                                                                Q (date = nextDate, time__lte = Prd_strtime, Mouldname_id = Mouldname_id, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0)).values('time').last())['time']
                        TimeArray.append(StartTime)
                        # print(StartTime, type(StartTime))
                        datetime_obj = datetime.datetime.strptime(StartTime, '%H:%M:%S')
                        date_ = inputDate
                        if datetime_obj.hour in range(0, 6):
                            date_ = nextDate
                        stratproductioncount = ProductionTable.objects.filter(date = date_, time = StartTime, Mouldname_id = Mouldname_id, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                        StatusArray.append(Mouldname + '   '+ '('+str(stratproductioncount) +')')
                        # print("production start :",start_time,  Mouldname_id, stratproductioncount, Machine)
                        ReasonArray.append('Production Commenced')
                        CauseArray.append(0)

                    elif (mouldflagid != Mouldname_id):
                        # print(mouldflagid, index)
                        StartTime   = ((list(ProductionTable.objects.filter(id = idarray[2*index -1]).values('time')))[0])['time']
                        EndTime     = ((list(ProductionTable.objects.filter(id = idarray[2*index]).values('time')))[0])['time']
                        # print(StartTime, EndTime)
                        TimeArray.append(str(StartTime + ' - ' + EndTime))
                        # print(StartTime, EndTime)
                        # StatusArray.append('Machine Idle')
                        # print(Mouldmodel.objects.get(id = Mouldname_id).Mouldname)
                        if len(uniquesortedmold) > 1:
                            global mould_change
                            index = uniquesortedmold.index(Mouldname_id)
                            pervious_mould = uniquesortedmold[index - 1]
                            pervious_mouldname = Mouldmodel.objects.get(id = pervious_mould).Mouldname
                            current_mouldname  = Mouldmodel.objects.get(id = Mouldname_id).Mouldname
                            datetime_obj = datetime.datetime.strptime(EndTime, '%H:%M:%S')
                            date_ = inputDate
                            if datetime_obj.hour in range(0, 6):    
                                date_ = nextDate
                                time6to24 = ProductionTable.objects.filter(date = inputDate, time__range = ('06:00:00', StartTime), Mouldname_id = pervious_mould, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                                time0to5 = ProductionTable.objects.filter(date = date_, time__range = ('00:00:00', EndTime), Mouldname_id = pervious_mould, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                                previousproductioncount = time6to24 + time0to5
                                nextproductioncount = ProductionTable.objects.filter(date = date_, time =  str(EndTime), Mouldname_id = Mouldname_id, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                            else:
                                previousproductioncount = ProductionTable.objects.filter(date = date_, time__range = ('06:00:00', StartTime), Mouldname_id = pervious_mould, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                                nextproductioncount = ProductionTable.objects.filter(date = date_, time = str(EndTime), Mouldname_id = Mouldname_id, MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                            #print(date_, StartTime, EndTime, Machine, Mouldname_id)
                            #print(previousproductioncount, nextproductioncount)
                            mould_change = pervious_mouldname + '   '+'('+ str(previousproductioncount) + ')'+' - ' + current_mouldname + '  ' +'('+ str(nextproductioncount) +')'
                        # print(mould_change, Mouldname_id, StartTime)
                        StatusArray.append(mould_change)
                        ReasonArray.append('Mould Change')
                        CauseArray.append(1)
                        mouldflagid = Mouldname_id

                    for data in downtime:
                        # print(data['Mouldname'], Mouldname)
                        # print(data)
                        if(data['Mouldname'] == Mouldname):
                            TimeArray.append((str(data['starttime']) + ' - ' + str(data['endtime'])))
                            StatusArray.append('Machine Idle')
                            ReasonArray.append(data['primaryreason'])
                            CauseArray.append(2)
                            nonproductionseconds += (datetime.datetime.strptime(data['difftime'], "%H:%M:%S") - datetime.datetime(1900, 1, 1)).total_seconds()
                    ################## Alarm #########################
                    Alarm = ProductionTable.objects.filter(Q(date = inputDate, time__gte = Prd_strtime, Mouldname_id = Mouldname_id, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0) |
                                                                Q (date = nextDate, time__lte = Prd_strtime, Mouldname_id = Mouldname_id, Machinename = Machine, ProductionCountActual__gte = 0, MachineState__gte = 0)).values()
                    currentcount = 1; previouscount = 0
                    for alm in Alarm:
                        currentcount = alm['Alarm']
                        if currentcount == 1:
                            start_time = alm['time']
                            previouscount = currentcount
                        elif previouscount != currentcount:
                            end_time = alm['time']
                            previouscount = currentcount
                            TimeArray.append(str(start_time + "-" + end_time))
                            StatusArray.append('Cycletime Time Actual')
                            ReasonArray.append('Alarm')
                            CauseArray.append(2)
                    #######################################################   
                    index += 1
                EndTime = ProductionTable.objects.filter(id = idarray[-1]).values('time', 'MachineState')
                mouldname = Mouldmodel.objects.filter(id = uniquesortedmold[-1]).values('Mouldname')[0]['Mouldname']
                datetime_obj = datetime.datetime.strptime(EndTime[0]['time'], '%H:%M:%S')
                date_ = inputDate
                if datetime_obj.hour in range(0, 6):
                    date_ = nextDate
                    # print(uniquesortedmold[-1])
                    time6to24 = ProductionTable.objects.filter(date = inputDate, time__range = ('06:00:00', '23:59:59'), Mouldname_id = uniquesortedmold[-1], MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 1).count()
                    time0to5  = ProductionTable.objects.filter(date = date_, time__range = ('00:00:00', EndTime[0]['time']), Mouldname_id = uniquesortedmold[-1], MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 1).count()
                    productioncountend = time6to24 + time0to5
                else:
                    productioncountend = ProductionTable.objects.filter(date = inputDate, time__range = ('06:00:00', EndTime[0]['time']), Mouldname_id = uniquesortedmold[-1], MachineState__gte = 0, Machinename = Machine, ProductionCountActual__gte = 0).count()
                TimeArray.append((EndTime[0]['time']))
                # print(productioncountend, EndTime[0]['time'], uniquesortedmold[-1])
                StatusArray.append(mouldname + '  ' +'('+ str(productioncountend)+')')
                if inputDate == str((datetime.datetime.today()).date()):
                    ReasonArray.append("Production Underway")
                else:
                    ReasonArray.append("Production Concluded")
                CauseArray.append(3)
                machinemode = EndTime[0]['MachineState']
                nonproductionhour = datetime.timedelta(seconds=nonproductionseconds)
                productionhour = datetime.timedelta(seconds=TotalRunSeconds - nonproductionseconds)
                # print(TimeArray)
                # print(StatusArray)
                # print(ReasonArray)
                # print(CauseArray)
                if(timeline.objects.filter(date = inputDate, Machinename = Machine).exists()):
                    timeline.objects.filter(date = inputDate, Machinename = Machine).update(Mouldname_id = Mouldname_id, time = TimeArray, lasttime= MEndTime, status = StatusArray, reason = ReasonArray, cause = CauseArray, productionhour=str(productionhour), operation = machinemode,
                                                                                            nonproductionhour=str(nonproductionhour), moldchangenumber=len(uniquesortedmold), totalparts= TotalProdCount)
                else:
                    inst = timeline(date = inputDate, Plantname = Plantname, Machinename = Machine, Mouldname_id = Mouldname_id, time = TimeArray, status = StatusArray, reason = ReasonArray,
                                    value = [], cause = CauseArray, name = [], lasttime= MEndTime, machinetype='assets/LK.png', operation = machinemode, totalparts=1500, moldchangenumber=len(uniquesortedmold),  moldchangetime='01:00:00', 
                                    productionhour=str(productionhour), nonproductionhour=str(nonproductionhour))
                    inst.save()
                # print(nextDate)
                # tdata = timeline.objects.filter(date = nextDate, Plantname = Plantname).values('id', 'Machinename').order_by('id')
                # machine= []
                # for i in tdata:
                #     machine.append(i['Machinename'])
                reason=[]; dict = {}
                mdata = timeline.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine).values('Machinename','productionhour', 'nonproductionhour', 'time', 'status', 'reason', 'name', 'value', 'cause', 'machinetype', 'operation')
                for j in mdata:
                    mname = j['Machinename']; time = j['time']; status = j['status']; reason = j['reason']; prdhr = j['productionhour'];  nprdhr = j['nonproductionhour']
                    cause = j['cause']; sel_machine = j['machinetype']; operation = j['operation']
                    time_line = []
                    # try:
                    for x in range(0, len(time)):
                        #if reason[x] == 'Mould Change':
                        time_line.append({"time":time[x],"status":status[x],"reason":reason[x],"cause":cause[x]})
                # machinevalue.append({"Machinename": mname, "productionhrs":prdhr, "nonproductionhrs":nprdhr, "selectedmachine":sel_machine, "operation":operation, "log":time_line})
                machines.append({"Machinename": mname, "productionhrs":prdhr, "nonproductionhrs":nprdhr, "selectedmachine":sel_machine, "operation":operation, "log":time_line})
                dict = {'mcstatusdashboard':{"machines": machines}}
            except:
                pass
            # break
        return JsonResponse(dict, safe=False)