from django.urls import path
from .import views, time_line, new_timeline, correct_code

urlpatterns = [
    path('timeline/', time_line.data,name="timeline"),
    path('breakdown/', views.breakdowndata,name="timeline"),
    path('badpart/', views.RejectionPartsdata,name="timeline"),
    # path('machineAlert/', views.machineAlert,name="machineAlert"),

    path('timelines/', new_timeline.data,name="timeline"),
]
