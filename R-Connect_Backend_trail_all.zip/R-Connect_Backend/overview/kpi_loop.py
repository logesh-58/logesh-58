from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
from dateutil.relativedelta import relativedelta
##########################################  16-09-2024  ##################################################

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'  

############################################    shifts     ########################################

@csrf_exempt
def kpi_loops(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        select_metrics = DateReq.get('select_metrics')
        select_range = DateReq.get('select_range')
        startdate = DateReq.get('startdate')
        enddate = DateReq.get('enddate')
        monthwise = DateReq.get('monthwise')
        yearwise = DateReq.get('yearwise')
        select_wise = DateReq.get('select_wise')
        select_machine = DateReq.get('select_machine')

        selected_machines = DateReq.get('selected_machines')
        
        response_data = []

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        if select_metrics == "OEE":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_hours:", mac_hours)
                        print("mac_counts:", mac_counts)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            print("first_time_str:", first_time_str)
                            print("last_time_str:", last_time_str)
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                        print("ProductionCountActual:", ProductionCountActual)

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)
                        print("RejectionParts:", RejectionParts)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]
                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                        print("total_idle_time_hours:", total_idle_time_hours)
                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            # print("mac_hours:", mac_hours)
                            # print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                # first_time_str = dashboard_value[0]['time']
                                # last_time_str = dashboard_value[-1]['time']
                                
                                # first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                # last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                # if last_time < first_time:
                                #     ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                # else:
                                #     ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                
                                first_record = dashboard_value[0]
                                last_record = dashboard_value[-1]

                                first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                                last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                                first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                                last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                                print("first_time:", first_time)
                                print("last_time:", last_time)

                                print("first_date:", first_date)
                                print("last_date:", last_date)
                                
                                ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                                
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            # print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                            print("Machine:", select_machine, "total_ProductionTimeActual_hour:", total_ProductionTimeActual_hour)
                            print("Machine:", select_machine, "total_ProductionCountActual:", total_ProductionCountActual)
                            print("Machine:", select_machine, "total_RejectionParts:", total_RejectionParts)
                            print("Machine:", select_machine, "total_hours:", total_hours)
                            print("Machine:", select_machine, "total_counts:", total_counts)
                            print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_hours:", mac_hours)
                        print("mac_counts:", mac_counts)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current month
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        mas_total_idle_time_hours = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                # print("mac_hours:", mac_hours)
                                # print("mac_counts:", mac_counts)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    # first_time_str = dashboard_value[0]['time']
                                    # last_time_str = dashboard_value[-1]['time']
                                    
                                    # first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    # last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    # if last_time < first_time:
                                    #     ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    # else:
                                    #     ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600

                                    first_record = dashboard_value[0]
                                    last_record = dashboard_value[-1]

                                    first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                                    first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                                    last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()

                                    # print("first_time:", first_time)
                                    # print("last_time:", last_time)

                                    # print("first_date:", first_date)
                                    # print("last_date:", last_date)
                                    
                                    ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600

                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                # print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                                mas_total_idle_time_hours += total_idle_time_hours

                        print("Machine:", select_machine, "ProductionTimeActual_hour:", ProductionTimeActual_hour)
                        print("Machine:", select_machine, "total_idle_time_hours:", mas_total_idle_time_hours)

                        print("Machine:", select_machine, "total_ProductionTimeActual_hour:", total_ProductionTimeActual_hour)
                        print("Machine:", select_machine, "total_ProductionCountActual:", total_ProductionCountActual)
                        print("Machine:", select_machine, 'total_RejectionParts: ', total_RejectionParts)
                        print("Machine:", select_machine, "total_hours:", total_hours)
                        print("Machine:", select_machine, "total_counts:", total_counts)
                        print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                print("mac_hours:", mac_hours)
                                print("mac_counts:", mac_counts)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        oee = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OEE": round(oee, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
#--------------------------------------------------- OEE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "OOE":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                print("pre_startdate_str:", pre_startdate_str)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)
                print("nex_enddate_str:", nex_enddate_str)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        
                        shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_counts:", mac_counts)

                        print("machine:", select_machine, "shift:", shift)

                        if shift == 'A':
                            mac_hours = 8
                        elif shift == 'B':
                            mac_hours = 16
                        elif shift == 'C':
                            mac_hours = 24
                        else:
                            mac_hours = 0

                        print("machine:", select_machine, "mac_hours:", mac_hours)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            print(first_time_str)
                            last_time_str = dashboard_value[-1]['time']
                            print(last_time_str)
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                            print("ProductionCountActual:", ProductionCountActual)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            # print("mac_counts:", mac_counts)

                            # print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            # print("machine:", select_machine, "mac_hours:", mac_hours)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            # print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        # print("Machine:", select_machine, "ProductionTimeActual_hour:", ProductionTimeActual_hour)
                        # print("Machine:", select_machine, "total_idle_time_hours:", total_idle_time_hours)

                        # print("Machine:", select_machine, "total_ProductionTimeActual_hour:", total_ProductionTimeActual_hour)
                        # print("Machine:", select_machine, "total_ProductionCountActual:", total_ProductionCountActual)
                        # print("Machine:", select_machine, 'total_RejectionParts: ', total_RejectionParts)
                        print("Machine:", select_machine, "total_hours:", total_hours)
                        # print("Machine:", select_machine, "total_counts:", total_counts)
                        print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_counts:", mac_counts)

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                
            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        
                        shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_counts:", mac_counts)

                        print("machine:", select_machine, "shift:", shift)

                        if shift == 'A':
                            mac_hours = 8
                        elif shift == 'B':
                            mac_hours = 16
                        elif shift == 'C':
                            mac_hours = 24
                        else:
                            mac_hours = 0

                        print("machine:", select_machine, "mac_hours:", mac_hours)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            # print("mac_counts:", mac_counts)

                            # print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            # print("machine:", select_machine, "mac_hours:", mac_hours)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            # print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        print("Machine:", select_machine, "total_hours:", total_hours)
                        # print("Machine:", select_machine, "total_counts:", total_counts)
                        print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_counts:", mac_counts)

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            # print("mac_counts:", mac_counts)

                            # print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            # print("machine:", select_machine, "mac_hours:", mac_hours)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            # print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        print("Machine:", select_machine, "total_hours:", total_hours)
                        print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current month
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                
                                shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                print("mac_counts:", mac_counts)

                                print("machine:", select_machine, "shift:", shift)

                                if shift == 'A':
                                    mac_hours = 8
                                elif shift == 'B':
                                    mac_hours = 16
                                elif shift == 'C':
                                    mac_hours = 24
                                else:
                                    mac_hours = 0

                                print("machine:", select_machine, "mac_hours:", mac_hours)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                
                                shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                print("mac_counts:", mac_counts)

                                print("machine:", select_machine, "shift:", shift)

                                if shift == 'A':
                                    mac_hours = 8
                                elif shift == 'B':
                                    mac_hours = 16
                                elif shift == 'C':
                                    mac_hours = 24
                                else:
                                    mac_hours = 0

                                print("machine:", select_machine, "mac_hours:", mac_hours)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        ooe = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "OOE": round(ooe, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
#--------------------------------------------------- OOE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "TEEP":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = 24
                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_hours:", mac_hours)
                        print("mac_counts:", mac_counts)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            print("first_time_str:", first_time_str)
                            print("last_time_str:", last_time_str)
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                        print("ProductionCountActual:", ProductionCountActual)

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)
                        print("RejectionParts:", RejectionParts)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = 24
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            # print("mac_hours:", mac_hours)
                            # print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            # print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        print("Machine:", select_machine, "total_hours:", total_hours)
                        print("##################################################################")

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:
                
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = 24
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                
            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = 24
                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        print("mac_hours:", mac_hours)
                        print("mac_counts:", mac_counts)

                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            ProductionCountActual = len(dashboard_value)
                        else:
                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                        RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == select_machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                        RejectionParts = len(RejectionParts_cal)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                        performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                        quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = 24
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:
                
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = 24
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                
            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                pre_startdate_str = startdate - timedelta(days=1)
                print("pre_startdate_str:", pre_startdate_str)
                nex_enddate_str = enddate + timedelta(days=1)
                print("nex_enddate_str:", nex_enddate_str)

                # Retrieve and store all data for the date range
                all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = 24
                            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                            print("mac_hours:", mac_hours)
                            print("mac_counts:", mac_counts)

                            ProductionTimeActual_hour = 0
                            ProductionCountActual = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                ProductionCountActual = len(dashboard_value)
                            else:
                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                            RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine and
                                ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                 (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                            ]
                            RejectionParts = len(RejectionParts_cal)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                            total_ProductionCountActual += ProductionCountActual
                            total_RejectionParts += RejectionParts

                            total_hours += mac_hours
                            total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current month
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = 24
                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                print("mac_hours:", mac_hours)
                                print("mac_counts:", mac_counts)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:
                
                        total_hours = 0
                        total_counts = 0

                        total_ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                        total_RejectionParts = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = 24
                                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                                print("mac_hours:", mac_hours)
                                print("mac_counts:", mac_counts)

                                ProductionTimeActual_hour = 0
                                ProductionCountActual = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    ProductionCountActual = len(dashboard_value)
                                else:
                                    ProductionTimeActual_hour = 0
                                    ProductionCountActual = 0

                                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                    e['Machinename'] == select_machine and
                                    ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                    (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                                ]
                                RejectionParts = len(RejectionParts_cal)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                                total_ProductionCountActual += ProductionCountActual
                                total_RejectionParts += RejectionParts

                                total_hours += mac_hours
                                total_counts += mac_counts

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                        quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                        performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                        teep = (availability * performance * quality) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "TEEP": round(teep, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                
#--------------------------------------------------- TEEP COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Uptime":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":
                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        
                        shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                        print("machine:", select_machine, "shift:", shift)

                        if shift == 'A':
                            mac_hours = 8
                        elif shift == 'B':
                            mac_hours = 16
                        elif shift == 'C':
                            mac_hours = 24
                        else:
                            mac_hours = 0

                        print("machine:", select_machine, "mac_hours:", mac_hours)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        key = mac_hours - total_idle_time_hours

                        uptime = (key / 24) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            key = mac_hours - total_idle_time_hours

                            total_hours += key

                        uptime = (total_hours / (24 * total_days)) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            key = mac_hours - total_idle_time_hours

                            total_hours += key

                        uptime = (total_hours / (24 * total_days)) * 100

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        
                        shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                        print("machine:", select_machine, "shift:", shift)

                        if shift == 'A':
                            mac_hours = 8
                        elif shift == 'B':
                            mac_hours = 16
                        elif shift == 'C':
                            mac_hours = 24
                        else:
                            mac_hours = 0

                        print("machine:", select_machine, "mac_hours:", mac_hours)

                        saw = [k for k in all_breakdown_data if
                            k['Machinename'] == select_machine and
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        key = mac_hours - total_idle_time_hours

                        uptime = (key / 24) * 100

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            key = mac_hours - total_idle_time_hours

                            total_hours += key

                        uptime = (total_hours / (24 * total_days)) * 100
                        
                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            key = mac_hours - total_idle_time_hours

                            total_hours += key

                        uptime = (total_hours / (24 * total_days)) * 100
                        
                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                year_days = (enddate - startdate).days + 1  
                print("year_days:", year_days)

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

                all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            
                            shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                            print("machine:", select_machine, "shift:", shift)

                            if shift == 'A':
                                mac_hours = 8
                            elif shift == 'B':
                                mac_hours = 16
                            elif shift == 'C':
                                mac_hours = 24
                            else:
                                mac_hours = 0

                            print("machine:", select_machine, "mac_hours:", mac_hours)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            key = mac_hours - total_idle_time_hours

                            total_hours += key

                        uptime = (total_hours / (24 * total_days)) * 100

                        # Construct the response for the current month
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:
                        total_hours = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                
                                shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                                print("machine:", select_machine, "shift:", shift)

                                if shift == 'A':
                                    mac_hours = 8
                                elif shift == 'B':
                                    mac_hours = 16
                                elif shift == 'C':
                                    mac_hours = 24
                                else:
                                    mac_hours = 0

                                print("machine:", select_machine, "mac_hours:", mac_hours)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                key = mac_hours - total_idle_time_hours

                                total_hours += key

                        uptime = (total_hours / (24 * year_days)) * 100
                        
                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                
                                shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                                print("machine:", select_machine, "shift:", shift)

                                if shift == 'A':
                                    mac_hours = 8
                                elif shift == 'B':
                                    mac_hours = 16
                                elif shift == 'C':
                                    mac_hours = 24
                                else:
                                    mac_hours = 0

                                print("machine:", select_machine, "mac_hours:", mac_hours)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                key = mac_hours - total_idle_time_hours

                                total_hours += key

                        uptime = (total_hours / (24 * year_days)) * 100
                        
                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Uptime": round(uptime, 2)
                        })

                    return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Uptime COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Availability":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
                
                all_dashboard_value = ProductionTable.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        MachineState=1
                    ).values('Machinename', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                        ProductionTimeActual_hour = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            print("first_time_str:", first_time_str)
                            print("last_time_str:", last_time_str)
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = 0

                        print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                        # Fetch breakdown data
                        saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        print("total_idle_time_hours:", total_idle_time_hours)
                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) * 100 if mac_hours > 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_ProductionTimeActual_hour = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            ProductionTimeActual_hour = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                print("first_time_str:", first_time_str)
                                print("last_time_str:", last_time_str)
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = 0

                            print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                            total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_ProductionTimeActual_hour = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            ProductionTimeActual_hour = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                print("first_time_str:", first_time_str)
                                print("last_time_str:", last_time_str)
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = 0

                            print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                            total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                

            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
                
                all_dashboard_value = ProductionTable.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        MachineState=1
                    ).values('Machinename', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                        
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                        ProductionTimeActual_hour = 0

                        if dashboard_value:
                            first_time_str = dashboard_value[0]['time']
                            last_time_str = dashboard_value[-1]['time']
                            print("first_time_str:", first_time_str)
                            print("last_time_str:", last_time_str)
                            
                            first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                            last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                            
                            if last_time < first_time:
                                ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = 0

                        print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                        # Fetch breakdown data
                        saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        print("total_idle_time_hours:", total_idle_time_hours)
                        total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours

                        availability = (float(total_ProductionTimeActual_hour) / mac_hours) * 100 if mac_hours > 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        total_ProductionTimeActual_hour = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            ProductionTimeActual_hour = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                print("first_time_str:", first_time_str)
                                print("last_time_str:", last_time_str)
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = 0

                            print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                            total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        total_ProductionTimeActual_hour = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            ProductionTimeActual_hour = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                print("first_time_str:", first_time_str)
                                print("last_time_str:", last_time_str)
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = 0

                            print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                            total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)

            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
                
                all_dashboard_value = ProductionTable.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        MachineState=1
                    ).values('Machinename', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0

                        total_ProductionTimeActual_hour = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            dashboard_value = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                 (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]
                            
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            ProductionTimeActual_hour = 0

                            if dashboard_value:
                                first_time_str = dashboard_value[0]['time']
                                last_time_str = dashboard_value[-1]['time']
                                print("first_time_str:", first_time_str)
                                print("last_time_str:", last_time_str)
                                
                                first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                
                                if last_time < first_time:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                            else:
                                ProductionTimeActual_hour = 0

                            print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                 (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                            total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current month
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:

                        total_hours = 0

                        total_ProductionTimeActual_hour = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                                ProductionTimeActual_hour = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    print("first_time_str:", first_time_str)
                                    print("last_time_str:", last_time_str)
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = 0

                                print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                                total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0

                        total_ProductionTimeActual_hour = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                                
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                                ProductionTimeActual_hour = 0

                                if dashboard_value:
                                    first_time_str = dashboard_value[0]['time']
                                    last_time_str = dashboard_value[-1]['time']
                                    print("first_time_str:", first_time_str)
                                    print("last_time_str:", last_time_str)
                                    
                                    first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                                    last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                                    
                                    if last_time < first_time:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                    else:
                                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                                else:
                                    ProductionTimeActual_hour = 0

                                print("ProductionTimeActual_hour:", ProductionTimeActual_hour)

                                saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour

                                total_hours += mac_hours

                        availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date and machine
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Availability": round(availability, 2)
                        })

                    return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Availability COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Utilization_rate":
            if select_range == "Date_Range":
                # Convert the date strings to datetime objects
                startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
                enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate_str - startdate_str).days + 1

                pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
                nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate_str + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                        timely = 24

                        # Fetch breakdown data
                        saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        print("total_idle_time_hours:", total_idle_time_hours)

                        total_ProductionTimeActual_hour = mac_hours - total_idle_time_hours


                        utilization_rate = (total_ProductionTimeActual_hour / timely) * 100 if total_ProductionTimeActual_hour != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        time = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            timely = 24

                            # Fetch breakdown data
                            saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            print("total_idle_time_hours:", total_idle_time_hours)

                            key = mac_hours - total_idle_time_hours

                            total_hours += key
                            time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        time = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate_str + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            timely = 24

                            # Fetch breakdown data
                            saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            print("total_idle_time_hours:", total_idle_time_hours)

                            key = mac_hours - total_idle_time_hours

                            total_hours += key
                            time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)

            elif select_range == "Monthwise":
                # Convert monthwise to datetime object (start date of the month)
                startdate = datetime.strptime(monthwise, "%Y-%m-%d")

                # Calculate the end date by adding one month and subtracting one day
                if startdate.month == 12:
                    enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
                else:
                    enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

                # Convert the date strings to datetime objects
                startdate_str = startdate.strftime("%Y-%m-%d")
                enddate_str = enddate.strftime("%Y-%m-%d")

                # Calculate the total days in the range
                total_days = (enddate - startdate).days + 1

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
                

                if select_wise == "Individual":

                    # Iterate over each day in the date range
                    for day_offset in range(total_days):
                        current_date = startdate + timedelta(days=day_offset)
                        current_date_str = current_date.strftime('%Y-%m-%d')
                        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                        # Filter stored data for the current day and the shift boundaries specific to the machine
                        aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                        ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                        timely = 24

                        # Fetch breakdown data
                        saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                        #  .total_seconds()     # .seconds
                        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
                        print("total_idle_time:", total_idle_time)
                        # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                        print("total_idle_time_hours:", total_idle_time_hours)

                        total_ProductionTimeActual_hour = mac_hours - total_idle_time_hours


                        utilization_rate = (total_ProductionTimeActual_hour / timely) * 100 if total_ProductionTimeActual_hour != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "date": current_date_str,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":
                    for select_machine in MachinenamesArray:
                        total_hours = 0
                        time = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            timely = 24

                            # Fetch breakdown data
                            saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            print("total_idle_time_hours:", total_idle_time_hours)

                            key = mac_hours - total_idle_time_hours

                            total_hours += key
                            time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        time = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            timely = 24

                            # Fetch breakdown data
                            saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            print("total_idle_time_hours:", total_idle_time_hours)

                            key = mac_hours - total_idle_time_hours

                            total_hours += key
                            time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)

            elif select_range == "Yearwise":

                # Convert yearwise to datetime object (start date of the year)
                startdate = datetime.strptime(yearwise, "%Y-%m-%d")
                print("startdate:", startdate)

                enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)
                print("enddate:", enddate)

                pre_startdate_str = startdate - timedelta(days=1)
                nex_enddate_str = enddate + timedelta(days=1)

                # Retrieve and store all data for the date range
                all_aggregated_data = ShiftProductiondata.objects.filter(
                        Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
                all_breakdown_data = breakdown.objects.filter(
                        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                if select_wise == "Individual":

                    for month_offset in range(12):
                        # Start date of the current month
                        month_startdate = startdate + relativedelta(months=month_offset)
                        # End date of the current month (last day of the month)
                        month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                        current_month_name = month_startdate.strftime('%B')

                        # Loop through each day in the current month
                        total_days = (month_enddate - month_startdate).days + 1

                        total_hours = 0
                        time = 0

                        # Iterate over each day in the date range
                        for day_offset in range(total_days):
                            current_date = month_startdate + timedelta(days=day_offset)
                            current_date_str = current_date.strftime('%Y-%m-%d')
                            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                            # Filter stored data for the current day and the shift boundaries specific to the machine
                            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                            ]
                            mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                            timely = 24

                            # Fetch breakdown data
                            saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                            #  .total_seconds()     # .seconds
                            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
                            print("total_idle_time:", total_idle_time)
                            # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                            total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                            print("total_idle_time_hours:", total_idle_time_hours)

                            key = mac_hours - total_idle_time_hours

                            total_hours += key
                            time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Month": current_month_name,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)

                elif select_wise == "All_Machines":

                    for select_machine in MachinenamesArray:

                        total_hours = 0
                        time = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                                timely = 24

                                # Fetch breakdown data
                                saw = [k for k in all_breakdown_data if
                                        k['Machinename'] == select_machine and
                                        ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                    ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                print("total_idle_time_hours:", total_idle_time_hours)

                                key = mac_hours - total_idle_time_hours

                                total_hours += key
                                time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)
                
                #--------------------------------
                elif select_wise == "selected_machines":
                    for select_machine in selected_machines:

                        total_hours = 0
                        time = 0

                        # Loop through 12 months
                        for month_offset in range(12):
                            # Start date of the current month
                            month_startdate = startdate + relativedelta(months=month_offset)
                            # End date of the current month (last day of the month)
                            month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

                            current_month_name = month_startdate.strftime('%B')

                            # Loop through each day in the current month
                            total_days = (month_enddate - month_startdate).days + 1

                            # Iterate over each day in the date range
                            for day_offset in range(total_days):
                                current_date = month_startdate + timedelta(days=day_offset)
                                current_date_str = current_date.strftime('%Y-%m-%d')
                                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                                # Filter stored data for the current day and the shift boundaries specific to the machine
                                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                                ]
                                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                                timely = 24

                                # Fetch breakdown data
                                saw = [k for k in all_breakdown_data if
                                        k['Machinename'] == select_machine and
                                        ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                    ]

                                #  .total_seconds()     # .seconds
                                total_idle_time = sum(
                                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                                )
                                print("total_idle_time:", total_idle_time)
                                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                                print("total_idle_time_hours:", total_idle_time_hours)

                                key = mac_hours - total_idle_time_hours

                                total_hours += key
                                time += timely

                        utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                        # Construct the response for the current date
                        response_data.append({
                            "select_metrics": select_metrics,
                            "select_range": select_range,
                            "select_wise": select_wise,
                            "Machine": select_machine,
                            "Utilization_rate": round(utilization_rate, 2)
                        })

                    return JsonResponse(response_data, safe=False)


#--------------------------------------------------- Utilization_rate COMPLETED ---------------------------------------------------------#