from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
##########################################  Today  ##################################################

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'                    #    SHIFT TIMES

ist_timezone = pytz.timezone('Asia/Kolkata')

# Get the current time in IST
# timenow_ist = datetime.now(ist_timezone).time()
timenow_ist_str = "23:59:24"
timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

print("Current IST time:", timenow_ist)

time_start_A = time(0, 0, 0)
time_end_A = time(5, 59, 59)

##########################################################

@csrf_exempt
def utilization(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')
        
        response_data = []

        MachinenamesArray = machineArray(Plantname)

        # Function to calculate utilization rate
        def calculate_utilization(startdate, days):
            total_hours = 0
            time = 0
            for day_offset in range(days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
                
                for machine in MachinenamesArray:
                    timely = 24
                    aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                        ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    #######################
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                    ########################

                    key = mac_hours - total_idle_time_hours

                    total_hours += key
                    time += timely
                    print("total_hours:", total_hours)
                    print("time:", time)

            utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0
            return utilization_rate

        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            utilization_rate = calculate_utilization(startdate, 1)
            response_data.append({
                "parameter": "today",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For Yesterday
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            utilization_rate = calculate_utilization(startdate, 1)
            response_data.append({
                "parameter": "yesterday",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For This Week
        if for_thisweek == "This week":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            utilization_rate = calculate_utilization(startdate, 7)
            response_data.append({
                "parameter": "this week",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For This Year (assuming you meant "This Month" by this)
        if for_thisyear == "This month":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            utilization_rate = calculate_utilization(startdate, total_days)
            response_data.append({
                "parameter": "this month",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # If no valid keys are provided in the payload
        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
    
####################################### Utilization_Rate Completed #############################################################

@csrf_exempt
def uptime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        def calculate_total_hours(startdate, days, Plantname, MachinenamesArray):

            total_hours = 0
            
            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)

                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                for machine in MachinenamesArray:

                    aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                                ]
                                
                    shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                    print("machine:", machine, "shift:", shift)

                    if shift == 'A':
                        mac_hours = 8
                    elif shift == 'B':
                        mac_hours = 16
                    elif shift == 'C':
                        mac_hours = 24
                    else:
                        mac_hours = 0

                    print("machine:", machine, "mac_hours:", mac_hours)

                    #######################
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                    ########################

                    key = mac_hours - total_idle_time_hours

                    total_hours += key

            return total_hours

        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            total_hours = calculate_total_hours(startdate, 1, Plantname, MachinenamesArray)

            time_hour = (total_hours/24) * 100
            
            response_data.append({
                "parameter": "today",
                "uptime": round(time_hour, 2)
            })
    
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            total_hours = calculate_total_hours(startdate, 1, Plantname, MachinenamesArray)

            time_hour = (total_hours/24) * 100
            
            response_data.append({
                "parameter": "yesterday",
                "uptime": round(time_hour, 2)
            })

        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            total_days = (enddate - startdate).days + 1

            total_hours = calculate_total_hours(startdate, total_days, Plantname, MachinenamesArray)

            time_hour = (total_hours/(24*total_days)) * 100

            response_data.append({
                "parameter": "this week",
                "uptime": round(time_hour, 2)
            })

        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            ################################################################

            total_hours = calculate_total_hours(startdate, total_days, Plantname, MachinenamesArray)

            time_hour = (total_hours/(24*total_days)) * 100

            response_data.append({
                "parameter": "this month",
                "uptime": round(time_hour, 2)
            })

        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
###################################################### uptime Completed ####################################################

@csrf_exempt                                  
def availability(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)

        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        def get_availability(startdate, days):

            total_hours, total_ProductionTimeActual_hour = 0, 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                for machine in MachinenamesArray:

                    # Fetch production data
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                    

                    aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                        ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0

                    if dashboard_value:
                        first_time_str = dashboard_value[0]['time']
                        last_time_str = dashboard_value[-1]['time']
                        print("first_time_str:", first_time_str)
                        print("last_time_str:", last_time_str)
                        
                        first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                        last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                        
                        if last_time < first_time:
                            ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600

                    else:
                        ProductionTimeActual_hour = 0

                    # Fetch breakdown data
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                    total_hours += mac_hours

            return (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0


        # Process each case
        if for_today == "Today":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            ################################################################

            availability = get_availability(startdate, 1)
            response_data.append({"parameter": "today", "availability": round(availability, 2)})

        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            ################################################################

            availability = get_availability(startdate, 1)
            response_data.append({"parameter": "yesterday", "availability": round(availability, 2)})

        if for_thisweek == "This week":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            ################################################################

            availability = get_availability(startdate, 7)
            response_data.append({"parameter": "this week", "availability": round(availability, 2)})

        if for_thisyear == "This month":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            ################################################################

            total_days = (enddate - startdate).days + 1
            availability = get_availability(startdate, total_days)
            response_data.append({"parameter": "this month", "availability": round(availability, 2)})

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
    
############################################# Availability Completed #################################################
    
@csrf_exempt
def oeefun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        # Helper function to calculate machine OEE
        def get_oee(startdate, days):
            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0
            
            for day_offset in range(days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                for machine in MachinenamesArray:

                    # Fetch production data
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                    

                    aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                        ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        first_time_str = dashboard_value[0]['time']
                        last_time_str = dashboard_value[-1]['time']
                        print("first_time_str:", first_time_str)
                        print("last_time_str:", last_time_str)
                        
                        first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                        last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                        
                        if last_time < first_time:
                            ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                    RejectionParts = len(RejectionParts_cal)
                    print("RejectionParts:", RejectionParts)

                    # Fetch breakdown data
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                    
                    Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                    total_ProductionCountActual += ProductionCountActual

                    total_RejectionParts += RejectionParts

                    total_hours += mac_hours
                    total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            oee = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            # return availability, performance, quality
            return {
                "OEE": round(oee, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }


        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            oee = get_oee(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            oee = get_oee(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For This Week
        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            oee = get_oee(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For This Month
        if for_thisyear == "This month":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            total_days = (enddate - startdate).days + 1
            oee = get_oee(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
################################################# OEE Completed #################################################

@csrf_exempt
def ooefun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        # Helper function to calculate machine OOE
        def get_ooe(startdate, days):

            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                for machine in MachinenamesArray:

                    # Fetch production data
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                    

                    aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                        ]
                    
                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                    print("machine:", machine, "shift:", shift)

                    if shift == 'A':
                        mac_hours = 8
                    elif shift == 'B':
                        mac_hours = 16
                    elif shift == 'C':
                        mac_hours = 24
                    else:
                        mac_hours = 0

                    print("machine:", machine, "mac_hours:", mac_hours)

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        first_time_str = dashboard_value[0]['time']
                        last_time_str = dashboard_value[-1]['time']
                        print("first_time_str:", first_time_str)
                        print("last_time_str:", last_time_str)
                        
                        first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                        last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                        
                        if last_time < first_time:
                            ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                    RejectionParts = len(RejectionParts_cal)
                    print("RejectionParts:", RejectionParts)

                    # Fetch breakdown data
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                    total_ProductionCountActual += ProductionCountActual
                    total_RejectionParts += RejectionParts
                    total_hours += mac_hours
                    print("total_hours:", total_hours)
                    total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            return {
                "OOE": round(ooe, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }
        

        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            ooe = get_ooe(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            ooe = get_ooe(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For This Week
        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            ooe = get_ooe(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For This Month
        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            total_days = (enddate - startdate).days + 1
            ooe = get_ooe(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
####################################################################### OOE Completed ############################

@csrf_exempt
def teepfun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        # Helper function to calculate machine OEE
        def get_teep(startdate, days):

            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # Fetch production data
                for machine in MachinenamesArray:

                    # Fetch production data
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == machine and
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]
                    

                    aggregated_data = [r for r in all_aggregated_data if
                            r['sp_machinename'] == machine and r['sp_date'] == current_date_str
                        ]
                    
                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    mac_hours = 24

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        first_time_str = dashboard_value[0]['time']
                        last_time_str = dashboard_value[-1]['time']
                        print("first_time_str:", first_time_str)
                        print("last_time_str:", last_time_str)
                        
                        first_time = datetime.strptime(first_time_str, "%H:%M:%S").time()
                        last_time = datetime.strptime(last_time_str, "%H:%M:%S").time()
                        
                        if last_time < first_time:
                            ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        else:
                            ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                            e['Machinename'] == machine and
                            ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                                (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                        ]
                    RejectionParts = len(RejectionParts_cal)
                    print("RejectionParts:", RejectionParts)

                    # Fetch breakdown data
                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == machine and
                                    ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                        (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = sum(
                        (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                        for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                    )
                    print("total_idle_time:", total_idle_time)
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                    total_ProductionCountActual += ProductionCountActual
                    total_RejectionParts += RejectionParts
                    total_hours += mac_hours
                    total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            teep = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            return {
                "TEEP": round(teep, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }


        # For Today
        if for_today == "Today":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            teep = get_teep(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=1)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            teep = get_teep(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For This Week
        if for_thisweek == "This week":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)
            ################################################################
            # Convert the date strings to datetime objects
            enddate = startdate + timedelta(days=6)
            print("week_enddate:", enddate)

            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            teep = get_teep(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For This Month
        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ################################################################
            pre_startdate_str = startdate - timedelta(days=1)
            nex_enddate_str = enddate + timedelta(days=1)

            all_aggregated_data = ShiftProductiondata.objects.filter(
                    Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            
            all_dashboard_value = ProductionTable.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    MachineState=1
                ).values('Machinename', 'time', 'date').order_by('id')
            
            all_RejectionParts_cal = badpart.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray
                ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
            ################################################################

            total_days = (enddate - startdate).days + 1
            teep = get_teep(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
####################################################################### TEEP Completed ############################

