from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
##########################################  Today  ##################################################

@csrf_exempt
def utilization(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')
        
        response_data = []

        # Cache machine names and shift timings
        MachinenamesArray = cache.get_or_set(f'machines_{Plantname}', lambda: machineArray(Plantname))
        shift_starttime = cache.get_or_set(f'shift_start_{Plantname}', lambda: ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start'])

        def calculate_machine_kpi(machine, startdate, days):
            total_hours, total_ProductionTimeActual_hour = 0, 0
            for day_offset in range(days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                shift_start_datetime = datetime.combine(current_date, shift_starttime)
                shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # Fetch production data
                dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Plantname=Plantname,
                    Machinename=machine,
                    MachineState=1
                ).values('time')

                first_time_str = dashboard_value.first()
                last_time_str = dashboard_value.last()

                mac_hours = sum(sd['sp_totalproductiontime'] for sd in ShiftProductiondata.objects.filter(
                    sp_date=current_date_str,
                    sp_plantname=Plantname,
                    sp_machinename=machine
                ).values('sp_totalproductiontime')) or 0

                ProductionTimeActual_hour = 0
                if first_time_str and last_time_str:
                    first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                    last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()
                    if last_time < first_time:
                        ProductionTimeActual_hour = ((datetime.combine(current_date + timedelta(days=1), last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                    else:
                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600

                # Fetch breakdown data
                saw = [bd for bd in breakdown.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Machinename=machine,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date') if bd['Machinename'] == machine]

                # Calculate total idle time
                total_idle_time = sum(
                    (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).seconds
                    for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                )

                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_hours += mac_hours

            return total_hours, total_ProductionTimeActual_hour

        def get_kpi(startdate, days):
            total_hours, total_ProductionTimeActual_hour = 0, 0
            with ThreadPoolExecutor() as executor:
                results = executor.map(lambda machine: calculate_machine_kpi(machine, startdate, days), MachinenamesArray)
                for machine_total_hours, machine_total_ProductionTimeActual_hour in results:
                    total_hours += machine_total_hours
                    total_ProductionTimeActual_hour += machine_total_ProductionTimeActual_hour
            return (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

        # Process each case
        if for_today == "Today":
            # startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
            ################

            ist_timezone = pytz.timezone('Asia/Kolkata')

            # Get the current time in IST
            # timenow_ist = datetime.now(ist_timezone).time()
            timenow_ist_str = "23:59:24"
            timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

            print("Current IST time:", timenow_ist)

            time_start_A = time(0, 0, 0)
            time_end_A = time(5, 59, 59)

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)
            kpi = get_kpi(startdate, 1)
            response_data.append({"parameter": "today", "kpi": round(kpi, 2)})

        if for_yesterday == "Yesterday":
            startdate = datetime.strptime("2023-04-25", "%Y-%m-%d")
            kpi = get_kpi(startdate, 1)
            response_data.append({"parameter": "yesterday", "kpi": round(kpi, 2)})

        if for_thisweek == "This week":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
            startdate = today_date - timedelta(days=today_date.weekday())
            kpi = get_kpi(startdate, 7)
            response_data.append({"parameter": "this week", "kpi": round(kpi, 2)})

        if for_thisyear == "This month":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1
            kpi = get_kpi(startdate, total_days)
            response_data.append({"parameter": "this month", "kpi": round(kpi, 2)})

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)