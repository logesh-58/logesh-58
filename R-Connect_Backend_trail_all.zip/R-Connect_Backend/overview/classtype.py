from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
from itertools import groupby
##########################################  Today  ##################################################

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'                    #    SHIFT TIMES

ist_timezone = pytz.timezone('Asia/Kolkata')

# Get the current time in IST
# timenow_ist = datetime.now(ist_timezone).time()
timenow_ist_str = "23:59:24"
timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

print("Current IST time:", timenow_ist)

time_start_A = time(0, 0, 0)
time_end_A = time(5, 59, 59)

##########################################################

@csrf_exempt
def utilization(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')
        
        response_data = []

        MachinenamesArray = machineArray(Plantname)
        length_arr = len(MachinenamesArray)
        print("length_arr:", length_arr)

        ###############################################################
        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        
        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        ###############################################################

        # Function to calculate utilization rate
        def calculate_utilization(startdate, days):
            total_hours = 0
            time = 0
            for day_offset in range(days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                # print("current_date_str:", current_date_str)
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
                
                # for machine in MachinenamesArray:
                timely = 24
                aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                    ]
                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                #######################
                saw = [k for k in all_breakdown_data if
                                k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                ########################

                key = mac_hours - total_idle_time_hours

                total_hours += key
                time += timely * length_arr
                print("total_hours:", total_hours)
                print("time:", time)

            utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0
            return utilization_rate

        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            utilization_rate = calculate_utilization(startdate, 1)
            response_data.append({
                "parameter": "today",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For Yesterday
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            utilization_rate = calculate_utilization(startdate, 1)
            response_data.append({
                "parameter": "yesterday",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For This Week
        if for_thisweek == "This week":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)

            utilization_rate = calculate_utilization(startdate, 7)
            response_data.append({
                "parameter": "this week",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # For This Year (assuming you meant "This Month" by this)
        if for_thisyear == "This month":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            utilization_rate = calculate_utilization(startdate, total_days)
            response_data.append({
                "parameter": "this month",
                "Utilization_Rate": round(utilization_rate, 2)
            })

        # If no valid keys are provided in the payload
        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
    
####################################### Utilization_Rate Completed #############################################################

@csrf_exempt
def uptime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        ########################################################
        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        
        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        #########################################################

        def calculate_total_hours(startdate, days):

            total_hours = 0
            
            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)

                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # for machine in MachinenamesArray:

                aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                            ]
                            
                # Get the maximum shift value from the filtered data

                # mac_hours = 0                                             # this also correct
                # aggregated_data.sort(key=lambda x: x['sp_machinename'])
                # for machine, group in groupby(aggregated_data, key=lambda x: x['sp_machinename']):
                #     max_shift = max(r['sp_shift'] for r in group)
                #     if max_shift == 'A':
                #         mac_hours += 8
                #     elif max_shift == 'B':
                #         mac_hours += 16
                #     elif max_shift == 'C':
                #         mac_hours += 24
                # print( "mac_hours:", mac_hours)

                mac_hours = 0
                machine_shifts = {machine: max((r['sp_shift'] for r in aggregated_data if r['sp_machinename'] == machine), default=0) 
                                for machine in MachinenamesArray}
                
                for shift in machine_shifts.values():
                    if shift == 'A':
                        mac_hours += 8
                    elif shift == 'B':
                        mac_hours += 16
                    elif shift == 'C':
                        mac_hours += 24

                #######################
                saw = [k for k in all_breakdown_data if
                                k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                ########################

                key = mac_hours - total_idle_time_hours

                total_hours += key

            return total_hours

        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            total_hours = calculate_total_hours(startdate, 1)

            time_hour = (total_hours/24) * 100
            
            response_data.append({
                "parameter": "today",
                "uptime": round(time_hour, 2)
            })
    
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            total_hours = calculate_total_hours(startdate, 1)

            time_hour = (total_hours/24) * 100
            
            response_data.append({
                "parameter": "yesterday",
                "uptime": round(time_hour, 2)
            })

        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)

            total_hours = calculate_total_hours(startdate, 7)

            time_hour = (total_hours/(24*7)) * 100

            response_data.append({
                "parameter": "this week",
                "uptime": round(time_hour, 2)
            })

        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            total_hours = calculate_total_hours(startdate, total_days)

            time_hour = (total_hours/(24*total_days)) * 100

            response_data.append({
                "parameter": "this month",
                "uptime": round(time_hour, 2)
            })

        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
###################################################### uptime Completed ####################################################

@csrf_exempt                                  
def availability(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)

        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        ###########################################################
        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date').order_by('id')
        ###########################################################

        def get_availability(startdate, days):

            total_hours, total_ProductionTimeActual_hour = 0, 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # Fetch production data for all machines in MachinenamesArray
                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] in MachinenamesArray and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                        (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
                
                # Aggregate data for all machines in MachinenamesArray
                aggregated_data = [r for r in all_aggregated_data if
                                    r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                                ]
                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                ProductionTimeActual_hour = 0

                # Process dashboard_value for each machine
                if dashboard_value:
                    machine_data = {}
                    for p in dashboard_value:
                        machine = p['Machinename']
                        if machine not in machine_data:
                            machine_data[machine] = []
                        machine_data[machine].append(p)

                    for machine, values in machine_data.items():
                        first_record = values[0]
                        last_record = values[-1]

                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                                                    
                        ProductionTimeActual_hour += ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600

                # Fetch breakdown data for all machines in MachinenamesArray
                saw = [k for k in all_breakdown_data if
                                        k['Machinename'] in MachinenamesArray and
                                        ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                            (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                                    ]

                # Calculate total idle time
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                
                # Convert idle time to hours and calculate adjusted production time
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_hours += mac_hours

            # Return availability as percentage
            return (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0


        # Process each case
        if for_today == "Today":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                # print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                # print("date2:", startdate)

            availability = get_availability(startdate, 1)
            response_data.append({"parameter": "today", "availability": round(availability, 2)})

        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                # print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                # print("yesterday_startdate2:", startdate)

            availability = get_availability(startdate, 1)
            response_data.append({"parameter": "yesterday", "availability": round(availability, 2)})

        if for_thisweek == "This week":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            # print("week_startdate:", startdate)

            availability = get_availability(startdate, 7)
            response_data.append({"parameter": "this week", "availability": round(availability, 2)})

        if for_thisyear == "This month":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            availability = get_availability(startdate, total_days)
            response_data.append({"parameter": "this month", "availability": round(availability, 2)})

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
    
############################################# Availability Completed #################################################
    
@csrf_exempt
def oeefun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        ########################################################################
        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        
        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
        ########################################################################

        # Helper function to calculate machine OEE
        def get_oee(startdate, days):
            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0
            
            for day_offset in range(days):
                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # for machine in MachinenamesArray:

                # Fetch production data
                dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] in MachinenamesArray and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                

                aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                    ]
                mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                ProductionTimeActual_hour = 0
                ProductionCountActual = 0

                # Process dashboard_value for each machine
                if dashboard_value:
                    machine_data = {}
                    for p in dashboard_value:
                        machine = p['Machinename']
                        if machine not in machine_data:
                            machine_data[machine] = []
                        machine_data[machine].append(p)

                    for machine, values in machine_data.items():
                        first_record = values[0]
                        last_record = values[-1]

                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                                                    
                        ProductionTimeActual_hour += ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                    ProductionCountActual = len(dashboard_value)
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0
                
                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                RejectionParts = len(RejectionParts_cal)
                print("RejectionParts:", RejectionParts)

                # Fetch breakdown data
                saw = [k for k in all_breakdown_data if
                                k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                
                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_ProductionCountActual += ProductionCountActual

                total_RejectionParts += RejectionParts

                total_hours += mac_hours
                total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            oee = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            # return availability, performance, quality
            return {
                "OEE": round(oee, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }


        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            oee = get_oee(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            oee = get_oee(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For This Week
        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)

            oee = get_oee(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        # For This Month
        if for_thisyear == "This month":
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            oee = get_oee(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "OEE": oee["OEE"],
                "availability": oee["availability"],
                "quality": oee["quality"],
                "performance": oee["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
################################################# OEE Completed #################################################

@csrf_exempt
def ooefun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)

        ###################################################################
        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
        ###################################################################

        # Helper function to calculate machine OOE
        def get_ooe(startdate, days):

            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # for machine in MachinenamesArray:

                # Fetch production data
                dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] in MachinenamesArray and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                

                aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                    ]
                
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                # Get the maximum shift value from the filtered data

                # mac_hours = 0                                                 # this also correct
                # aggregated_data.sort(key=lambda x: x['sp_machinename'])
                # for machine, group in groupby(aggregated_data, key=lambda x: x['sp_machinename']):
                #     max_shift = max(r['sp_shift'] for r in group)
                #     if max_shift == 'A':
                #         mac_hours += 8
                #     elif max_shift == 'B':
                #         mac_hours += 16
                #     elif max_shift == 'C':
                #         mac_hours += 24
                # print( "mac_hours:", mac_hours)

                mac_hours = 0
                machine_shifts = {machine: max((r['sp_shift'] for r in aggregated_data if r['sp_machinename'] == machine), default=0) 
                                for machine in MachinenamesArray}
                
                for shift in machine_shifts.values():
                    if shift == 'A':
                        mac_hours += 8
                    elif shift == 'B':
                        mac_hours += 16
                    elif shift == 'C':
                        mac_hours += 24

                ProductionTimeActual_hour = 0
                ProductionCountActual = 0

                # Process dashboard_value for each machine
                if dashboard_value:
                    machine_data = {}
                    for p in dashboard_value:
                        machine = p['Machinename']
                        if machine not in machine_data:
                            machine_data[machine] = []
                        machine_data[machine].append(p)

                    for machine, values in machine_data.items():
                        first_record = values[0]
                        last_record = values[-1]

                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                                                    
                        ProductionTimeActual_hour += ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                    ProductionCountActual = len(dashboard_value)
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                RejectionParts = len(RejectionParts_cal)
                print("RejectionParts:", RejectionParts)

                # Fetch breakdown data
                saw = [k for k in all_breakdown_data if
                                k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_ProductionCountActual += ProductionCountActual
                total_RejectionParts += RejectionParts
                total_hours += mac_hours
                print("total_hours:", total_hours)
                total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            return {
                "OOE": round(ooe, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }
        

        # For Today
        if for_today == "Today":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            ooe = get_ooe(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":

            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            ooe = get_ooe(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For This Week
        if for_thisweek == "This week":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)

            ooe = get_ooe(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        # For This Month
        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            ooe = get_ooe(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "OOE": ooe["OOE"],
                "availability": ooe["availability"],
                "quality": ooe["quality"],
                "performance": ooe["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
####################################################################### OOE Completed ############################

@csrf_exempt
def teepfun(request):
    if request.method == 'POST':
        try:
            Plantname = request.GET['Plantname']
            DateReq = json.loads(request.body)
        except (KeyError, json.JSONDecodeError):
            return JsonResponse({"error": "Invalid input"}, status=400)

        # Extract flags from request
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')

        response_data = []

        MachinenamesArray = machineArray(Plantname)
        length_arr = len(MachinenamesArray)
        print("length_arr:", length_arr)

        ###############################################

        today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        pre_startdate = startdate - timedelta(days=1)
        nex_enddate = enddate + timedelta(days=1)

        pre_startdate_str = pre_startdate.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=pre_startdate_str, sp_date__lte=nex_enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
        ###############################################

        # Helper function to calculate machine OEE
        def get_teep(startdate, days):

            total_hours, total_ProductionTimeActual_hour, total_ProductionCountActual, total_counts = 0, 0, 0, 0
            total_RejectionParts = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')
                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # Fetch production data
                dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] in MachinenamesArray and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                

                aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] in MachinenamesArray and r['sp_date'] == current_date_str
                    ]
                
                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                mac_hours = 24 * length_arr

                ProductionTimeActual_hour = 0
                ProductionCountActual = 0

                # Process dashboard_value for each machine
                if dashboard_value:
                    machine_data = {}
                    for p in dashboard_value:
                        machine = p['Machinename']
                        if machine not in machine_data:
                            machine_data[machine] = []
                        machine_data[machine].append(p)

                    for machine, values in machine_data.items():
                        first_record = values[0]
                        last_record = values[-1]

                        first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                                                    
                        ProductionTimeActual_hour += ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                    ProductionCountActual = len(dashboard_value)
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                RejectionParts = len(RejectionParts_cal)
                print("RejectionParts:", RejectionParts)

                # Fetch breakdown data
                saw = [k for k in all_breakdown_data if
                                k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None
                
                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_ProductionCountActual += ProductionCountActual
                total_RejectionParts += RejectionParts
                total_hours += mac_hours
                total_counts += mac_counts

            availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            performance = (total_ProductionCountActual / total_counts) * 100 if total_counts != 0 else 0
            teep = (availability / 100) * (performance / 100) * (quality / 100) * 100 if total_hours != 0 else 0
            return {
                "TEEP": round(teep, 2),
                "availability": round(availability, 2),
                "quality": round(quality, 2),
                "performance": round(performance, 2)
            }


        # For Today
        if for_today == "Today":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
                print("date1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")
                print("date2:", startdate)

            teep = get_teep(startdate, 1)
            # response_data.append({"parameter": "today", "OEE": oee})
            response_data.append({
                "parameter": "today",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For Yesterday
        if for_yesterday == "Yesterday":
            
            if time_start_A <= timenow_ist <= time_end_A:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=2)
                print("yesterday_startdate1:", startdate)
            else:
                startdate = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1) # Replace with dynamic date
                print("yesterday_startdate2:", startdate)

            teep = get_teep(startdate, 1)
            # response_data.append({"parameter": "yesterday", "OEE": oee})
            response_data.append({
                "parameter": "yesterday",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For This Week
        if for_thisweek == "This week":
            
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date - timedelta(days=today_date.weekday())
            print("week_startdate:", startdate)

            teep = get_teep(startdate, 7)
            # response_data.append({"parameter": "this week", "OEE": oee})
            response_data.append({
                "parameter": "this week",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        # For This Month
        if for_thisyear == "This month":

            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  # Replace with dynamic date
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            teep = get_teep(startdate, total_days)
            # response_data.append({"parameter": "this month", "OEE": oee})
            response_data.append({
                "parameter": "this month",
                "TEEP": teep["TEEP"],
                "availability": teep["availability"],
                "quality": teep["quality"],
                "performance": teep["performance"]
            })

        if not response_data:
            return JsonResponse({"error": "No valid input received"}, status=400)

        return JsonResponse(response_data, safe=False)
####################################################################### TEEP Completed ############################

