from django.urls import path, include
from .views import overviewfun, overviewfunyes, overviewfunthisweek, overviewfunthismon
from .TEEPoverview import teepoverviewfun, teepoverviewfunyes, teepoverviewfunthisweek, teepoverviewfunthismon
from .OOEoverview import ooeoverviewfun, ooeoverviewfunyes, ooeoverviewfunthisweek, ooeoverviewfunthismon
from .Availabilityoverview import avioverviewfun, avioverviewfunyes, avioverviewfunthisweek, avioverviewfunthismon
# from .classtype import utilization, uptime, availability, oeefun, ooefun, teepfun                       ### correct jai
from .classtype_new import utilization, uptime, availability, oeefun, ooefun, teepfun
# from .classtype_loop_oct import utilization, uptime, availability, oeefun, ooefun, teepfun
# from .classtype_loop import utilization, uptime, availability, oeefun, ooefun, teepfun
# from .utilizationover import utiloverviewfun, utiloverviewfunyes, utiloverviewfunthisweek, utiloverviewfunthismon
from .Kpi_analysis import kpi_history
from .kpi_loop import kpi_loops
from .new_try import new_try # mould_count, totalfg, total_production
#overviewdash
#from .prefetch_dash import production_dashboards, totalfg, total_production, mould_count
#cloverviewfun
urlpatterns = [
   path('utilization', utilization),
   path('uptime', uptime),
   path('availability', availability),
   path('oeefun', oeefun),
   path('ooefun', ooefun),
   path('teepfun', teepfun),
   path('kpi_history', kpi_history),
   # path('kpi_take', kpi_loops),
   path('new_try', new_try),

   # path('totalfg', totalfg),
   # path('totalpd', total_production),
   # path('mould_count', mould_count),

   # path('overviewdash', cloverviewfun),
   
] 