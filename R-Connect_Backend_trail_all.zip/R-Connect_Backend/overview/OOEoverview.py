from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max
from analysis.views import machineArray
from timeline.models import breakdown

@csrf_exempt
def ooeoverviewfun(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        startdate = "2023-04-26"  # Replace with dynamic date if needed
        print("startdate:", startdate)
        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        print("startdate_str:", startdate_str)

        current_date = startdate_str
        current_date_str = current_date.strftime('%Y-%m-%d')

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
        next_day = current_date + timedelta(days=1)

        total_hours = 0
        total_counts = 0

        # Initialize cumulative totals
        total_ProductionTimeActual_hour = 0
        total_ProductionCountActual = 0
        total_RejectionParts = 0

        for machine in MachinenamesArray:

            dashboard_value = ProductionTable.objects.filter(
                Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                Plantname=Plantname,
                Machinename=machine,
                MachineState=1
            ).values('time', 'ProductionCountActual', 'Mouldname_id')

            first_time_str = dashboard_value.first()
            last_time_str = dashboard_value.last()

            aggregated_data = ShiftProductiondata.objects.filter(
                sp_date=current_date_str,
                sp_plantname=Plantname,
                sp_machinename=machine
            ).aggregate(count_set=Sum('sp_totalproduction'), total_hours=Max('sp_shift'))

            mac_counts = aggregated_data['count_set'] or 0

            shift = aggregated_data['total_hours']

            print("machine:", machine, "shift:", shift)

            if shift == 'A':
                mac_hours = 8
            elif shift == 'B':
                mac_hours = 16
            elif shift == 'C':
                mac_hours = 24
            else:
                mac_hours = 0

            if first_time_str and last_time_str:
                first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

                if last_time < first_time:
                    ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                    print("testcase1")
                else:
                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                    print("testcase2")
                ProductionCountActual = dashboard_value.count()
            else:
                ProductionTimeActual_hour = 0
                ProductionCountActual = 0

            saw = breakdown.objects.filter(
                        Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                        Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                        Machinename=machine,
                        Plantname=Plantname
                    ).values('time', 'MachineState')

            # Calculate total idle time
            total_idle_times = []
            last_idle_end_time = None

            for entry in sorted(saw, key=lambda x: x['time']):
                entry_time = datetime.strptime(entry['time'], '%H:%M:%S')
                
                if entry['MachineState'] == 0:  # Idle state
                    if last_idle_end_time is not None:
                        # Calculate idle time between end of last idle period and start of current idle period
                        idle_time = (entry_time - last_idle_end_time).seconds
                        total_idle_times.append(idle_time)
                    # Update the end of the idle period
                    last_idle_end_time = entry_time
                elif entry['MachineState'] == 1:  # Non-idle state
                    if last_idle_end_time is not None:
                        # If there was an idle period ongoing, record it
                        idle_time = (entry_time - last_idle_end_time).seconds
                        total_idle_times.append(idle_time)
                        last_idle_end_time = None
            
            # Sum all recorded idle times
            total_idle_time = sum(total_idle_times)
            print("total_idle_time:", total_idle_time)

            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time

            # Update cumulative totals
            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
            total_ProductionCountActual += ProductionCountActual
            # Assuming RejectionParts is fetched elsewhere or is part of dashboard_value:
            total_RejectionParts = 0 
            total_hours += mac_hours
            print("total hours:", total_hours, machine)
            total_counts += mac_counts
            print("###################################################")
        # Calculate cumulative metrics for all machines
        availability = (float(total_ProductionTimeActual_hour) / (total_hours)) * 100

        # Avoid division by zero for quality calculation
        if total_ProductionCountActual != 0:
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100
        else:
            quality = 0

        performance = (total_ProductionCountActual / (total_counts)) * 100 if total_counts != 0 else 0

        # Calculate the overall OEE
        try:
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100
        except ZeroDivisionError:
            ooe = 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "today",
            "availability": availability,
            "quality": quality,
            "performance": performance,
            "OOE": ooe
        })

        return JsonResponse(response_data, safe=False)
    

@csrf_exempt
def ooeoverviewfunyes(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        startdate = "2023-04-26"  # Replace with dynamic date if needed
        print("startdate:", startdate)
        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        print("startdate_str:", startdate_str)

        # current_date = startdate_str
        current_date = startdate_str - timedelta(days=1)
        print("current_date", current_date)
        current_date_str = current_date.strftime('%Y-%m-%d')

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
        next_day = current_date + timedelta(days=1)
        print("next_day:", next_day)

        total_hours = 0
        total_counts = 0

        # Initialize cumulative totals
        total_ProductionTimeActual_hour = 0
        total_ProductionCountActual = 0
        total_RejectionParts = 0

        for machine in MachinenamesArray:
            print(machine)

            dashboard_value = ProductionTable.objects.filter(
                Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                Plantname=Plantname,
                Machinename=machine,
                MachineState=1
            ).values('time', 'ProductionCountActual', 'Mouldname_id')
            print("hello1")
            first_time_str = dashboard_value.first()
            last_time_str = dashboard_value.last()

            aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=current_date_str,
                    sp_plantname=Plantname,
                    sp_machinename=machine
                ).aggregate(count_set=Sum('sp_totalproduction'), total_hours=Max('sp_shift'))

            mac_counts = aggregated_data['count_set'] or 0

            shift = aggregated_data['total_hours']

            print("machine:", machine, "shift:", shift)

            if shift == 'A':
                mac_hours = 8
            elif shift == 'B':
                mac_hours = 16
            elif shift == 'C':
                mac_hours = 24
            else:
                mac_hours = 0

            if first_time_str and last_time_str:
                first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()
                print("hello2")
                if last_time < first_time:
                    ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                    print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                else:
                    ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                    print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                ProductionCountActual = dashboard_value.count()
            else:
                ProductionTimeActual_hour = 0
                ProductionCountActual = 0

            saw = breakdown.objects.filter(
                        Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                        Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                        Machinename=machine,
                        Plantname=Plantname
                    ).values('time', 'MachineState')

            # Calculate total idle time
            total_idle_times = []
            last_idle_end_time = None

            for entry in sorted(saw, key=lambda x: x['time']):
                entry_time = datetime.strptime(entry['time'], '%H:%M:%S')
                
                if entry['MachineState'] == 0:  # Idle state
                    if last_idle_end_time is not None:
                        # Calculate idle time between end of last idle period and start of current idle period
                        idle_time = (entry_time - last_idle_end_time).seconds
                        total_idle_times.append(idle_time)
                    # Update the end of the idle period
                    last_idle_end_time = entry_time
                elif entry['MachineState'] == 1:  # Non-idle state
                    if last_idle_end_time is not None:
                        # If there was an idle period ongoing, record it
                        idle_time = (entry_time - last_idle_end_time).seconds
                        total_idle_times.append(idle_time)
                        last_idle_end_time = None
            
            # Sum all recorded idle times
            total_idle_time = sum(total_idle_times)
            print("total_idle_time:", total_idle_time)

            Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time

            # Update cumulative totals
            total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
            total_ProductionCountActual += ProductionCountActual
            # Assuming RejectionParts is fetched elsewhere or is part of dashboard_value:
            total_RejectionParts = 0 
            total_hours += mac_hours
            total_counts += mac_counts

        # Calculate cumulative metrics for all machines
        availability = (float(total_ProductionTimeActual_hour) / (total_hours)) * 100 if total_hours != 0 else 0

        # Avoid division by zero for quality calculation
        if total_ProductionCountActual != 0:
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100
        else:
            quality = 0

        performance = (total_ProductionCountActual / (total_counts)) * 100 if total_counts != 0 else 0

        # Calculate the overall OEE
        try:
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100
        except ZeroDivisionError:
            ooe = 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "yesterday",
            "availability": availability,
            "quality": quality,
            "performance": performance,
            "OOE": ooe
        })

        return JsonResponse(response_data, safe=False)
    
@csrf_exempt
def ooeoverviewfunthisweek(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        # Get today's date
        today_date = "2023-04-26"

        today_date = datetime.strptime(today_date, "%Y-%m-%d")

        # Calculate the start of the week (Monday)
        startdate = today_date - timedelta(days=today_date.weekday())

        # Calculate the end of the week (Sunday)
        enddate = startdate + timedelta(days=6)

        print("startdate:", startdate)
        print("enddate:", enddate)

        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        # startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        # enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

        total_days = (enddate - startdate).days + 1
        print('total_days:', total_days)

        total_hours = 0
        total_counts = 0

        total_ProductionTimeActual_hour = 0
        total_ProductionCountActual = 0
        total_RejectionParts = 0

        for day_offset in range(total_days):
            # current_date = startdate_str
            current_date = startdate + timedelta(days=day_offset)
            print("current_date:", current_date)
            current_date_str = current_date.strftime('%Y-%m-%d')

            shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
            shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
            next_day = current_date + timedelta(days=1)
            print("next_day:", next_day)

            for machine in MachinenamesArray:

                dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Plantname=Plantname,
                    Machinename=machine,
                    MachineState=1
                ).values('time', 'ProductionCountActual', 'Mouldname_id')

                first_time_str = dashboard_value.first()
                last_time_str = dashboard_value.last()

                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=current_date_str,
                    sp_plantname=Plantname,
                    sp_machinename=machine
                ).aggregate(count_set=Sum('sp_totalproduction'), total_hours=Max('sp_shift'))

                mac_counts = aggregated_data['count_set'] or 0

                shift = aggregated_data['total_hours']

                print("machine:", machine, "shift:", shift)

                if shift == 'A':
                    mac_hours = 8
                elif shift == 'B':
                    mac_hours = 16
                elif shift == 'C':
                    mac_hours = 24
                else:
                    mac_hours = 0

                if first_time_str and last_time_str:
                    first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                    last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

                    if last_time < first_time:
                        ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase1")
                    else:
                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase2")
                    ProductionCountActual = dashboard_value.count()
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0
                    
                saw = breakdown.objects.filter(
                        Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                        Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                        Machinename=machine,
                        Plantname=Plantname
                    ).values('time', 'MachineState')

                # Calculate total idle time
                total_idle_times = []
                last_idle_end_time = None

                for entry in sorted(saw, key=lambda x: x['time']):
                    entry_time = datetime.strptime(entry['time'], '%H:%M:%S')
                    
                    if entry['MachineState'] == 0:  # Idle state
                        if last_idle_end_time is not None:
                            # Calculate idle time between end of last idle period and start of current idle period
                            idle_time = (entry_time - last_idle_end_time).seconds
                            total_idle_times.append(idle_time)
                        # Update the end of the idle period
                        last_idle_end_time = entry_time
                    elif entry['MachineState'] == 1:  # Non-idle state
                        if last_idle_end_time is not None:
                            # If there was an idle period ongoing, record it
                            idle_time = (entry_time - last_idle_end_time).seconds
                            total_idle_times.append(idle_time)
                            last_idle_end_time = None
                
                # Sum all recorded idle times
                total_idle_time = sum(total_idle_times)
                print("total_idle_time:", total_idle_time)

                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time

                # Update cumulative totals
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_ProductionCountActual += ProductionCountActual
                # Assuming RejectionParts is fetched elsewhere or is part of dashboard_value:
                total_RejectionParts = 0 
                total_counts += mac_counts
                total_hours += mac_hours

        # Calculate cumulative metrics for all machines
        availability = (float(total_ProductionTimeActual_hour) / (total_hours)) * 100

        # Avoid division by zero for quality calculation
        if total_ProductionCountActual != 0:
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100
        else:
            quality = 0

        performance = (total_ProductionCountActual / (total_counts)) * 100 if total_counts != 0 else 0

        # Calculate the overall OEE
        try:
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100
        except ZeroDivisionError:
            ooe = 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "this week",
            "availability": availability,
            "quality": quality,
            "performance": performance,
            "OOE": ooe
        })

        return JsonResponse(response_data, safe=False)
    

@csrf_exempt
def ooeoverviewfunthismon(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        # Get today's date
        today_date = "2023-04-26"

        today_date = datetime.strptime(today_date, "%Y-%m-%d")

        # Calculate the first day of the month (start date)
        startdate = today_date.replace(day=1)
        print("startdate:", startdate)

        # Calculate the last day of the month (end date)
        # First, move to the next month, then subtract one day to get the last day of the current month
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        print("enddate:", enddate)

        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        # startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        # enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

        total_days = (enddate - startdate).days + 1
        print('total_days:', total_days)

        total_hours = 0
        total_counts = 0

        total_ProductionTimeActual_hour = 0
        total_ProductionCountActual = 0
        total_RejectionParts = 0

        for day_offset in range(total_days):
            # current_date = startdate_str
            current_date = startdate + timedelta(days=day_offset)
            print("current_date:", current_date)
            current_date_str = current_date.strftime('%Y-%m-%d')

            shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
            shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
            next_day = current_date + timedelta(days=1)
            print("next_day:", next_day)

            for machine in MachinenamesArray:

                dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Plantname=Plantname,
                    Machinename=machine,
                    MachineState=1
                ).values('time', 'ProductionCountActual', 'Mouldname_id')

                first_time_str = dashboard_value.first()
                last_time_str = dashboard_value.last()

                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=current_date_str,
                    sp_plantname=Plantname,
                    sp_machinename=machine
                ).aggregate(count_set=Sum('sp_totalproduction'), total_hours=Max('sp_shift'))

                mac_counts = aggregated_data['count_set'] or 0

                shift = aggregated_data['total_hours']

                print("machine:", machine, "shift:", shift)

                if shift == 'A':
                    mac_hours = 8
                elif shift == 'B':
                    mac_hours = 16
                elif shift == 'C':
                    mac_hours = 24
                else:
                    mac_hours = 0

                if first_time_str and last_time_str:
                    first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                    last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

                    if last_time < first_time:
                        ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase1")
                    else:
                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase2")
                    ProductionCountActual = dashboard_value.count()
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                saw = breakdown.objects.filter(
                        Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                        Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                        Machinename=machine,
                        Plantname=Plantname
                    ).values('time', 'MachineState')

                # Calculate total idle time
                total_idle_times = []
                last_idle_end_time = None

                for entry in sorted(saw, key=lambda x: x['time']):
                    entry_time = datetime.strptime(entry['time'], '%H:%M:%S')
                    
                    if entry['MachineState'] == 0:  # Idle state
                        if last_idle_end_time is not None:
                            # Calculate idle time between end of last idle period and start of current idle period
                            idle_time = (entry_time - last_idle_end_time).seconds
                            total_idle_times.append(idle_time)
                        # Update the end of the idle period
                        last_idle_end_time = entry_time
                    elif entry['MachineState'] == 1:  # Non-idle state
                        if last_idle_end_time is not None:
                            # If there was an idle period ongoing, record it
                            idle_time = (entry_time - last_idle_end_time).seconds
                            total_idle_times.append(idle_time)
                            last_idle_end_time = None
                
                # Sum all recorded idle times
                total_idle_time = sum(total_idle_times)
                print("total_idle_time:", total_idle_time)

                Cr_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time

                # Update cumulative totals
                total_ProductionTimeActual_hour += Cr_ProductionTimeActual_hour
                total_ProductionCountActual += ProductionCountActual
                # Assuming RejectionParts is fetched elsewhere or is part of dashboard_value:
                total_RejectionParts = 0 
                total_counts += mac_counts
                total_hours += mac_hours

        # Calculate cumulative metrics for all machines
        availability = (float(total_ProductionTimeActual_hour) / (total_hours)) * 100

        # Avoid division by zero for quality calculation
        if total_ProductionCountActual != 0:
            quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100
        else:
            quality = 0

        performance = (total_ProductionCountActual / (total_counts)) * 100 if total_counts != 0 else 0

        # Calculate the overall OEE
        try:
            ooe = (availability / 100) * (performance / 100) * (quality / 100) * 100
        except ZeroDivisionError:
            ooe = 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "this month",
            "availability": availability,
            "quality": quality,
            "performance": performance,
            "OOE": ooe
        })

        return JsonResponse(response_data, safe=False)