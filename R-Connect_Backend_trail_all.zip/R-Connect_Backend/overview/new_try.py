from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
import pytz
from dashboard.models import Dashboard
from mouldmanagement.models import Mouldmodel
##########################################  Today  ##################################################

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'                    #    SHIFT TIMES

ist_timezone = pytz.timezone('Asia/Kolkata')

# Get the current time in IST
# timenow_ist = datetime.now(ist_timezone).time()
timenow_ist_str = "23:59:24"
timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

print("Current IST time:", timenow_ist)

time_start_A = time(0, 0, 0)
time_end_A = time(5, 59, 59)

##########################################################

@csrf_exempt
def new_try(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')
        
        response_data = []

        MachinenamesArray = machineArray(Plantname)
        length_arr = len(MachinenamesArray)

        ########################################################

        if time_start_A <= timenow_ist <= time_end_A:
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
        else:
            today_date = datetime.strptime("2023-04-26", "%Y-%m-%d")

        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        pre_startdate_str = (startdate - timedelta(days=1)).strftime('%Y-%m-%d')

        nex_enddate_str = (enddate + timedelta(days=1)).strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                sp_date__range=[pre_startdate_str,nex_enddate_str],
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date', 'MachineState', 'CycletimeActual').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount').order_by('id')
        
        all_mould_value = Dashboard.objects.filter(
            Plantname=Plantname, Machinename__in=MachinenamesArray
        ).values('Machinename', 'Mouldname_id', 'ProductionCountActual', 'machinestatus').order_by('id')
        
        ########################################################

        # Function to calculate utilization rate
        def all_function(startdate, days):

            time = 24 * length_arr * days
            total_total_idle_time_hours = 0
            total_util_mac_hours = 0
            total_mac_counts = 0
            Cr_ProductionTimeActual_hour = 0
            total_ProductionCountActual = 0
            total_RejectionParts = 0
            total_uptime_mac_hours = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # teep_mac_hours = 24 * length_arr

                # Fetch production data for all machines in MachinenamesArray
                dashboard_value = [p for p in all_dashboard_value if
                                    # p['Machinename'] in MachinenamesArray and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                        (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]

                ProductionTimeActual_hour = 0
                ProductionCountActual = 0
                # Process dashboard_value for each machine
                if dashboard_value:
                    # machine_data = {}
                    # for p in dashboard_value:
                    #     machine = p['Machinename']
                    #     if machine not in machine_data:
                    #         machine_data[machine] = []
                    #     machine_data[machine].append(p)

                    # for machine, values in machine_data.items():
                        # first_record = values[0]
                        # last_record = values[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                                                    
                        # ProductionTimeActual_hour += ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                    ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                    ProductionCountActual = len(dashboard_value)
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                aggregated_data = [r for r in all_aggregated_data if
                        # r['sp_machinename'] in MachinenamesArray and 
                        r['sp_date'] == current_date_str
                    ]
                util_mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                uptime_mac_hours = 0
                machine_shifts = {machine: max((r['sp_shift'] for r in aggregated_data if r['sp_machinename'] == machine), default=0) 
                                for machine in MachinenamesArray}
                
                for shift in machine_shifts.values():
                    if shift == 'A':
                        uptime_mac_hours += 8
                    elif shift == 'B':
                        uptime_mac_hours += 16
                    elif shift == 'C':
                        uptime_mac_hours += 24

                #######################

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        # e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                RejectionParts = len(RejectionParts_cal)

                saw = [k for k in all_breakdown_data if
                                # k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Print the intermediate values
                        # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None

                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                ########################

                total_total_idle_time_hours += total_idle_time_hours

                total_util_mac_hours += util_mac_hours

                total_uptime_mac_hours += uptime_mac_hours

                total_mac_counts += mac_counts

                # time += teep_mac_hours

                Cr_ProductionTimeActual_hour += ProductionTimeActual_hour

                total_ProductionCountActual += ProductionCountActual

                total_RejectionParts += RejectionParts

            #calculate utilization
            utilization_total_hours = total_util_mac_hours - total_total_idle_time_hours
            utilization_rate = (utilization_total_hours / time) * 100

            #calculate uptime
            uptime_total_hours = total_uptime_mac_hours - total_total_idle_time_hours
            uptime = ((uptime_total_hours/(24 * days)) * 100)/length_arr

            #calculate availability
            # total_ProductionTimeActual_hour = Cr_ProductionTimeActual_hour - total_total_idle_time_hours
            total_ProductionTimeActual_hour = float(Cr_ProductionTimeActual_hour) - total_total_idle_time_hours
            oee_availability = (float(total_ProductionTimeActual_hour) / total_util_mac_hours) * 100 if total_util_mac_hours != 0 else 0

            #calculate oee
            oee_quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            oee_performance = (total_ProductionCountActual / total_mac_counts) * 100 if total_mac_counts != 0 else 0
            oee = (oee_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100 

            #calculate ooe
            ooe_availability = (float(total_ProductionTimeActual_hour) / total_uptime_mac_hours) * 100 if total_uptime_mac_hours != 0 else 0
            ooe = (ooe_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100

            #calculate teep
            teep_availability = (float(total_ProductionTimeActual_hour) / time) * 100 if time != 0 else 0
            teep = (teep_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100

            return {
                "Utilization_Rate": round(utilization_rate, 2),
                "uptime": round(uptime, 2),
                "availability": round(oee_availability, 2),
                "OEE": round(oee, 2),
                "oee_availability": round(oee_availability, 2),
                "oee_quality": round(oee_quality, 2),
                "oee_performance": round(oee_performance, 2),
                "OOE": round(ooe, 2),
                "ooe_availability": round(ooe_availability, 2),
                "ooe_quality": round(oee_quality, 2),
                "ooe_performance": round(oee_performance, 2),
                "TEEP": round(teep, 2),
                "teep_availability": round(teep_availability, 2),
                "teep_quality": round(oee_quality, 2),
                "teep_performance": round(oee_performance, 2)
            }
     

        if for_today == "Today":

            main_function = all_function(today_date, 1)

            response_data.append({
                "parameter": "today",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_yesterday == "Yesterday":

            startdate = today_date - timedelta(days=1)

            main_function = all_function(startdate, 1)

            response_data.append({
                "parameter": "yesterday",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_thisweek == "This week":
            
            startdate = today_date - timedelta(days=today_date.weekday())

            main_function = all_function(startdate, 7)

            response_data.append({
                "parameter": "this week",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_thisyear == "This month":
            
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            main_function = all_function(startdate, total_days)

            response_data.append({
                "parameter": "this month",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })


        current_date_str = today_date.strftime('%Y-%m-%d')
        next_day_str = (today_date + timedelta(days=1)).strftime('%Y-%m-%d')
        
        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(seconds=1)

        last_dashboard_value = [p for p in all_dashboard_value if
                                    # p['Machinename'] in MachinenamesArray and
                                    ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                        (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                                ]
        
        rejection_data = [e for e in all_RejectionParts_cal if
                        # e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
        
        all_aggregated_data = [r for r in all_aggregated_data if
                        # r['sp_machinename'] in MachinenamesArray and 
                        r['sp_date'] == current_date_str
                    ]

        current_hour_start = shift_start_datetime
        while current_hour_start < shift_end_datetime:
            next_hour_start = current_hour_start + timedelta(hours=1)
            hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
            hour_range_end_str = (next_hour_start - timedelta(seconds=1)).strftime('%H:%M:%S')

            total_ProductionCountActual = 0
            total_RejectionParts = 0

            date = current_date_str if current_hour_start.time() >= time(6, 0, 0) else next_day_str

            filtered_production = [p for p in last_dashboard_value if 
                                    # p['Machinename'] in MachinenamesArray and 
                                    p['date'] == date and 
                                    hour_range_start_str <= p['time'] <= hour_range_end_str]
            
            filtered_rejection = [r for r in rejection_data if 
                                    # r['Machinename'] in MachinenamesArray and 
                                    r['date'] == date and 
                                    hour_range_start_str <= r['time'] <= hour_range_end_str]

            total_ProductionCountActual = len(filtered_production)
            total_RejectionParts = len(filtered_rejection)

            good_parts = total_ProductionCountActual - total_RejectionParts
            ########
            if good_parts < 0:
                parts = 0
            else:
                parts = good_parts
            ########
            response_data.append({
                "time": f"{hour_range_start_str} to {hour_range_end_str}",
                "total parts": total_ProductionCountActual,
                "good parts": parts,
                "bad parts": total_RejectionParts
            })

            current_hour_start = next_hour_start

        for machine_name in MachinenamesArray:

            if len([v for v in last_dashboard_value if v['date'] == current_date_str and v['Machinename'] == machine_name and v['time'] >= firstday_start]) != 0:

                dashboard_value = [r for r in all_mould_value if r['Machinename'] == machine_name]
                
                Mouldname_ids = dashboard_value[-1]['Mouldname_id'] if dashboard_value else 0

                # print("machine_name:", machine_name, "Mouldname_id:", Mouldname_ids)

                Mouldname = Mouldmodel.objects.get(id=Mouldname_ids).Mouldname

                mould_ProductionCountActual = dashboard_value[-1]['ProductionCountActual'] if dashboard_value else 0
                # mould_ProductionCountActual = len(last_dashboard_value) if last_dashboard_value else 0

                machine_status  = dashboard_value[-1]['machinestatus'] if dashboard_value else 0

            else:

                mould_ProductionCountActual = 0

                Mouldname = "No Data Found!"

                machine_status = "false"

            # Filter stored data for the current day and the shift boundaries specific to the machine
            dashboard_value = [p for p in last_dashboard_value if
                p['Machinename'] == machine_name
            ]

            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == machine_name
                            ]

            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            ProductionCountActual = 0

            if dashboard_value:
                ProductionCountActual = len(dashboard_value)
            else:
                ProductionCountActual = 0

            # Construct the response for the current date
            response_data.append({
                "Machine": machine_name,
                "mould_production_count": mould_ProductionCountActual,
                "Mouldname": Mouldname,
                "Machine_status": machine_status,
                "Current_production_count": ProductionCountActual,
                "Production_count_set": mac_counts
            })

        # If no valid keys are provided in the payload
        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
    
######################################################################################################################################

# @csrf_exempt
# def mould_count(request):
#     if request.method == "GET":
#         Plantname = request.GET['Plantname']

#         response_data = []

#         MachinenamesArray = machineArray(Plantname)

#         ###########
#         firstday_start = '06:00:00'
#         firstday_end = '23:59:59'
#         secondday_start = '00:00:00'
#         secondday_end = '05:59:59'
#         ###########

#         ###############################################################################
#         ist_timezone = pytz.timezone('Asia/Kolkata')

#         # Get the current time in IST
#         timenow_ist_str = "23:59:24"
#         timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

#         time_start_A = time(0, 0, 0)
#         time_end_A = time(5, 59, 59)

#         if time_start_A <= timenow_ist <= time_end_A:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d") - timedelta(days=1)
#         else:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
#         ###############################################################################

#         next_date = current_date + timedelta(days=1)

#         # Use strftime to convert the datetime object to a string if needed
#         startdate_str = current_date.strftime("%Y-%m-%d")
#         next_date_str = next_date.strftime("%Y-%m-%d")

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

#         shift_start_datetime = datetime.strptime(startdate_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#         shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(seconds=1)

#         last_dashboard_value = ProductionTable.objects.filter(
#                             Q(date=startdate_str, time__gte=firstday_start) |
#                             Q(date=next_date_str, time__lte=secondday_end),
#                             Plantname=Plantname,
#                             Machinename__in=MachinenamesArray,
#                             ProductionCountActual__gt=0,
#                             MachineState=1
#                         ).values('Machinename', 'time', 'date', 'Mouldname_id', 'MachineState').order_by('id')
        
#         rejection_data = badpart.objects.filter(
#                     Q(date=startdate_str, time__gte=firstday_start) |
#                     Q(date=next_date_str, time__lte=secondday_end),
#                     Plantname=Plantname,
#                     partcount__gt=0,
#                     Machinename__in=MachinenamesArray
#                 ).values('date', 'time', 'Machinename', 'partcount').order_by('id')
        
#         all_aggregated_data = ShiftProductiondata.objects.filter(
#                 sp_date=startdate_str,
#                 sp_plantname=Plantname,
#                 sp_machinename__in=MachinenamesArray
#             ).values('sp_machinename', 'sp_date', 'sp_totalproduction').order_by('sp_id')

#         all_mould_value = Dashboard.objects.filter(
#             Plantname=Plantname, Machinename__in=MachinenamesArray
#         ).values('Machinename', 'Mouldname_id', 'ProductionCountActual', 'machinestatus').order_by('id')

#         current_hour_start = shift_start_datetime

#         while current_hour_start < shift_end_datetime:
#             next_hour_start = current_hour_start + timedelta(hours=1)
#             hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
#             hour_range_end_str = (next_hour_start - timedelta(seconds=1)).strftime('%H:%M:%S')

#             total_ProductionCountActual = 0
#             total_RejectionParts = 0

#             date = startdate_str if current_hour_start.time() >= time(6, 0, 0) else next_date_str

#             filtered_production = [p for p in last_dashboard_value if 
#                                     p['Machinename'] in MachinenamesArray and 
#                                     p['date'] == date and 
#                                     hour_range_start_str <= p['time'] <= hour_range_end_str and
#                                     p['MachineState'] == 1]
            
#             filtered_rejection = [r for r in rejection_data if 
#                                     r['Machinename'] in MachinenamesArray and 
#                                     r['date'] == date and 
#                                     hour_range_start_str <= r['time'] <= hour_range_end_str]

#             total_ProductionCountActual = len(filtered_production)
#             total_RejectionParts = len(filtered_rejection)

#             good_parts = total_ProductionCountActual - total_RejectionParts
#             ########
#             if good_parts < 0:
#                 parts = 0
#             else:
#                 parts = good_parts
#             ########
#             response_data.append({
#                 "time": f"{hour_range_start_str} to {hour_range_end_str}",
#                 "total parts": total_ProductionCountActual,
#                 "good parts": parts,
#                 "bad parts": total_RejectionParts
#             })

#             current_hour_start = next_hour_start

#         for machine_name in MachinenamesArray:

#             if len([v for v in last_dashboard_value if v['date'] == startdate_str and v['Machinename'] == machine_name and v['time'] >= firstday_start]) != 0:

#                 dashboard_value = [r for r in all_mould_value if r['Machinename'] == machine_name]
                
#                 Mouldname_ids = dashboard_value[-1]['Mouldname_id'] if dashboard_value else 0

#                 print("machine_name:", machine_name, "Mouldname_id:", Mouldname_ids)

#                 Mouldname = Mouldmodel.objects.get(id=Mouldname_ids).Mouldname

#                 mould_ProductionCountActual = dashboard_value[-1]['ProductionCountActual'] if dashboard_value else 0

#                 machine_status  = dashboard_value[-1]['machinestatus'] if dashboard_value else 0

#             else:

#                 mould_ProductionCountActual = 0

#                 Mouldname = "No Data Found!"

#                 machine_status = "false"

#             # Filter stored data for the current day and the shift boundaries specific to the machine
#             dashboard_value = [p for p in last_dashboard_value if
#                 p['Machinename'] == machine_name
#             ]

#             aggregated_data = [r for r in all_aggregated_data if
#                                 r['sp_machinename'] == machine_name
#                             ]

#             mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

#             ProductionCountActual = 0

#             if dashboard_value:
#                 ProductionCountActual = len(dashboard_value)
#             else:
#                 ProductionCountActual = 0

#             # Construct the response for the current date
#             response_data.append({
#                 "date": startdate_str,
#                 "Machine": machine_name,
#                 "mould_production_count": mould_ProductionCountActual,
#                 "Mouldname": Mouldname,
#                 "Machine_status": machine_status,
#                 "Current_production_count": ProductionCountActual,
#                 "Production_count_set": mac_counts
#             })

#         return JsonResponse(response_data, safe=False)
    
# @csrf_exempt
# def totalfg(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']  # SEPARATE TIME AI GENERATED CODE

#         MachinenamesArray = machineArray(Plantname)

#         #############
#         ###########
#         firstday_start = '06:00:00'
#         firstday_end = '23:59:59'
#         secondday_start = '00:00:00'
#         secondday_end = '05:59:59'
#         ###########

#         ###############################################################################
#         ist_timezone = pytz.timezone('Asia/Kolkata')

#         # Get the current time in IST
#         # timenow_ist = datetime.now(ist_timezone).time()
#         timenow_ist_str = "23:59:24"
#         timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

#         time_start_A = time(0, 0, 0)
#         time_end_A = time(5, 59, 59)

#         if time_start_A <= timenow_ist <= time_end_A:
#             # current_date = (datetime.today()).date()
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
#         else:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
#         ###############################################################################

#         next_date = current_date + timedelta(days=1)

#         # Use strftime to convert the datetime object to a string if needed
#         current_date_str = current_date.strftime("%Y-%m-%d")
#         next_day_str = next_date.strftime("%Y-%m-%d")
#         ############

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']

#         shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#         shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(seconds=1)

#         # Pre-fetch data for all machines and all time ranges in a single query
#         production_data = ProductionTable.objects.filter(
#                             Q(date=current_date_str, time__gte=firstday_start) |
#                             Q(date=next_day_str, time__lte=secondday_end),
#                             Plantname=Plantname,
#                             Machinename__in=MachinenamesArray,
#                             ProductionCountActual__gt=0,
#                             MachineState=1
#                         ).values('date', 'time', 'Machinename', 'MachineState').order_by('id')

#         rejection_data = badpart.objects.filter(
#                     Q(date=current_date_str, time__gte=firstday_start) |
#                     Q(date=next_day_str, time__lte=secondday_end),
#                     Plantname=Plantname,
#                     partcount__gt=0,
#                     Machinename__in=MachinenamesArray
#                 ).values('date', 'time', 'Machinename', 'partcount').order_by('id')

#         response_data = []
#         current_hour_start = shift_start_datetime

#         while current_hour_start < shift_end_datetime:
#             next_hour_start = current_hour_start + timedelta(hours=1)
#             hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
#             hour_range_end_str = (next_hour_start - timedelta(seconds=1)).strftime('%H:%M:%S')

#             total_ProductionCountActual = 0
#             total_RejectionParts = 0

#             date = current_date_str if current_hour_start.time() >= time(6, 0, 0) else next_day_str

#             filtered_production = [p for p in production_data if 
#                                     p['Machinename'] in MachinenamesArray and 
#                                     p['date'] == date and 
#                                     hour_range_start_str <= p['time'] <= hour_range_end_str and
#                                     p['MachineState'] == 1]
            
#             filtered_rejection = [r for r in rejection_data if 
#                                     r['Machinename'] in MachinenamesArray and 
#                                     r['date'] == date and 
#                                     hour_range_start_str <= r['time'] <= hour_range_end_str]

#             total_ProductionCountActual = len(filtered_production)
#             total_RejectionParts = len(filtered_rejection)

#             good_parts = total_ProductionCountActual - total_RejectionParts
#             ########
#             if good_parts < 0:
#                 parts = 0
#             else:
#                 parts = good_parts
#             ########
#             response_data.append({
#                 "parameter": "today",
#                 "time": f"{hour_range_start_str} to {hour_range_end_str}",
#                 "total parts": total_ProductionCountActual,
#                 "good parts": parts,
#                 "bad parts": total_RejectionParts
#             })

#             current_hour_start = next_hour_start

#         return JsonResponse(response_data, safe=False)
    
# @csrf_exempt
# def total_production(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']

#         response_data = []

#         # Cache machine names and shift timings
#         MachinenamesArray = machineArray(Plantname)

#         ###########
#         firstday_start = '06:00:00'
#         firstday_end = '23:59:59'
#         secondday_start = '00:00:00'
#         secondday_end = '05:59:59'
#         ###########

#         ###############################################################################
#         ist_timezone = pytz.timezone('Asia/Kolkata')

#         # Get the current time in IST
#         # timenow_ist = datetime.now(ist_timezone).time()
#         timenow_ist_str = "23:59:24"
#         timenow_ist = datetime.strptime(timenow_ist_str, "%H:%M:%S").time()

#         time_start_A = time(0, 0, 0)
#         time_end_A = time(5, 59, 59)

#         if time_start_A <= timenow_ist <= time_end_A:
#             # current_date = (datetime.today()).date()
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")  - timedelta(days=1)
#         else:
#             current_date = datetime.strptime("2023-04-26", "%Y-%m-%d")
#         ###############################################################################

#         next_date = current_date + timedelta(days=1)

#         # Use strftime to convert the datetime object to a string if needed
#         startdate_str = current_date.strftime("%Y-%m-%d")
#         next_date_str = next_date.strftime("%Y-%m-%d")

#         all_aggregated_data = ShiftProductiondata.objects.filter(
#                 sp_date=startdate_str,
#                 sp_plantname=Plantname,
#                 sp_machinename__in=MachinenamesArray
#             ).values('sp_machinename', 'sp_date', 'sp_totalproduction').order_by('sp_id')

#         all_dashboard_value = ProductionTable.objects.filter(
#                             Q(date=startdate_str, time__gte=firstday_start) |
#                             Q(date=next_date_str, time__lte=secondday_end),
#                             Plantname=Plantname,
#                             Machinename__in=MachinenamesArray,
#                             ProductionCountActual__gt=0,
#                             MachineState=1
#                         ).values('Machinename', 'time', 'date').order_by('id')

#         for select_machine in MachinenamesArray:

#             # Filter stored data for the current day and the shift boundaries specific to the machine
#             dashboard_value = [p for p in all_dashboard_value if
#                 p['Machinename'] == select_machine
#             ]

#             aggregated_data = [r for r in all_aggregated_data if
#                                 r['sp_machinename'] == select_machine
#                             ]

#             mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

#             ProductionCountActual = 0

#             if dashboard_value:
#                 ProductionCountActual = len(dashboard_value)
#             else:
#                 ProductionCountActual = 0

#             # Construct the response for the current date
#             response_data.append({
#                 "date": startdate_str,
#                 "Machine": select_machine,
#                 "Current_production_count": ProductionCountActual,
#                 "Production_count_set": mac_counts
#             })

#         return JsonResponse(response_data, safe=False)