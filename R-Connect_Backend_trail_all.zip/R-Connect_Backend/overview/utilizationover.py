from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum
from analysis.views import machineArray
from timeline.models import breakdown

@csrf_exempt
def utiloverviewfun(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        startdate = "2023-04-26"  # Replace with dynamic date if needed
        print("startdate:", startdate)
        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        print("startdate_str:", startdate_str)

        current_date = startdate_str
        current_date_str = current_date.strftime('%Y-%m-%d')

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
        next_day = current_date + timedelta(days=1)

        time = 0

        # Initialize cumulative totals
        total_hours = 0

        for machine in MachinenamesArray:
            timely = 24
            mac_hours = ShiftProductiondata.objects.filter(
                        sp_date=current_date_str,
                        sp_plantname=Plantname,
                        sp_machinename=machine
                    ).aggregate(total_hours=Sum('sp_totalproductiontime'))['total_hours'] or 0

            print("machinename:", machine, "mac_hours:", mac_hours)

            total_hours += mac_hours
            print("total hours:", total_hours, machine)
            print("###################################################")
            time += timely
        # Calculate cumulative metrics for all machines
        Utilization_Rate = (total_hours / time) * 100 if total_hours != 0 else 0


        # Append the cumulative data to response
        response_data.append({
            "parameter": "today",
            "Utilization_Rate": Utilization_Rate
        })

        return JsonResponse(response_data, safe=False)
    

@csrf_exempt
def utiloverviewfunyes(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        startdate = "2023-04-25"  # Replace with dynamic date if needed
        print("startdate:", startdate)
        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        print("startdate_str:", startdate_str)

        # current_date = startdate_str
        current_date = startdate_str - timedelta(days=1)
        print("current_date", current_date)
        current_date_str = current_date.strftime('%Y-%m-%d')

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
        next_day = current_date + timedelta(days=1)
        print("next_day:", next_day)

        time = 0
        total_hours = 0

        for machine in MachinenamesArray:
            timely = 24
            mac_hours = ShiftProductiondata.objects.filter(
                        sp_date=current_date_str,
                        sp_plantname=Plantname,
                        sp_machinename=machine
                    ).aggregate(total_hours=Sum('sp_totalproductiontime'))['total_hours'] or 0

            print("machinename:", machine, "mac_hours:", mac_hours)

            total_hours += mac_hours
            print("total hours:", total_hours, machine)
            print("###################################################")
            time += timely
        # Calculate cumulative metrics for all machines
        Utilization_Rate = (total_hours / time) * 100 if total_hours != 0 else 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "yesterday",
            "Utilization_Rate": Utilization_Rate
        })

        return JsonResponse(response_data, safe=False)
    
@csrf_exempt
def utiloverviewfunthisweek(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        # Get today's date
        today_date = "2023-04-26"

        today_date = datetime.strptime(today_date, "%Y-%m-%d")

        # Calculate the start of the week (Monday)
        startdate = today_date - timedelta(days=today_date.weekday())

        # Calculate the end of the week (Sunday)
        enddate = startdate + timedelta(days=6)

        print("startdate:", startdate)
        print("enddate:", enddate)

        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        # startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        # enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

        total_days = (enddate - startdate).days + 1
        print('total_days:', total_days)

        time = 0

        total_hours = 0
        

        for day_offset in range(total_days):
            # current_date = startdate_str
            current_date = startdate + timedelta(days=day_offset)
            print("current_date:", current_date)
            current_date_str = current_date.strftime('%Y-%m-%d')

            shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
            shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
            next_day = current_date + timedelta(days=1)
            print("next_day:", next_day)

            for machine in MachinenamesArray:
                timely = 24
                mac_hours = ShiftProductiondata.objects.filter(
                        sp_date=current_date_str,
                        sp_plantname=Plantname,
                        sp_machinename=machine
                    ).aggregate(total_hours=Sum('sp_totalproductiontime'))['total_hours'] or 0

                print("machinename:", machine, "mac_hours:", mac_hours)

                total_hours += mac_hours
                print("total hours:", total_hours, machine)
                print("###################################################")
                time += timely
        # Calculate cumulative metrics for all machines
        Utilization_Rate = (total_hours / time) * 100 if total_hours != 0 else 0

        # Append the cumulative data to response
        response_data.append({
            "parameter": "this week",
            "Utilization_Rate": Utilization_Rate
        })

        return JsonResponse(response_data, safe=False)
    

@csrf_exempt
def utiloverviewfunthismon(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        # Get today's date
        today_date = "2023-04-26"

        today_date = datetime.strptime(today_date, "%Y-%m-%d")

        # Calculate the first day of the month (start date)
        startdate = today_date.replace(day=1)
        print("startdate:", startdate)

        # Calculate the last day of the month (end date)
        # First, move to the next month, then subtract one day to get the last day of the current month
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        print("enddate:", enddate)

        MachinenamesArray = machineArray(Plantname)
        print(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        # startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        # enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

        total_days = (enddate - startdate).days + 1
        print('total_days:', total_days)

        total_hours = 0

        time = 0

        for day_offset in range(total_days):
            # current_date = startdate_str
            current_date = startdate + timedelta(days=day_offset)
            print("current_date:", current_date)
            current_date_str = current_date.strftime('%Y-%m-%d')

            shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
            shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
            next_day = current_date + timedelta(days=1)
            print("next_day:", next_day)

            for machine in MachinenamesArray:
                timely = 24
                mac_hours = ShiftProductiondata.objects.filter(
                        sp_date=current_date_str,
                        sp_plantname=Plantname,
                        sp_machinename=machine
                    ).aggregate(total_hours=Sum('sp_totalproductiontime'))['total_hours'] or 0

                print("machinename:", machine, "mac_hours:", mac_hours)

                total_hours += mac_hours
                print("total hours:", total_hours, machine)
                print("###################################################")
                time += timely
        # Calculate cumulative metrics for all machines
        Utilization_Rate = (total_hours / time) * 100 if total_hours != 0 else 0


        # Append the cumulative data to response
        response_data.append({
            "parameter": "this month",
            "Utilization_Rate": Utilization_Rate
        })

        return JsonResponse(response_data, safe=False)