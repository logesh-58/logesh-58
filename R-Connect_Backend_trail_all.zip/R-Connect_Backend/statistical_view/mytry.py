import datetime
from timeline.models import breakdown
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
import json
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
import pandas as pd
from dateutil import relativedelta
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.db.models import Q, Sum, F, ExpressionWrapper, fields, DurationField, FloatField, Q, Min, Max, F, Func, Count, Prefetch
from datetime import datetime, timedelta
from django.utils.dateparse import parse_time
from decimal import Decimal
###################################################################################################

firstday_start = '06:00:00'
firstday_end = '23:59:59'
secondday_start = '00:00:00'
secondday_end = '05:59:59'  

############################################    shifts     ########################################

@csrf_exempt
def historical_fun(request):
    Plantname = request.GET.get('Plantname')

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')
    select_machine = DateReq.get('machinename')

    # Cache machine names and shift timings
    MachinenamesArray = machineArray(Plantname)

    startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

    total_days = (enddate_str - startdate_str).days + 1

    ################################

    pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
    nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

    all_dashboard_value = ProductionTable.objects.filter(
        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
        Plantname=Plantname,
        Machinename=select_machine,
        MachineState=1
    ).values('Machinename', 'CycletimeActual', 'time', 'date').order_by('id')

    all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename=select_machine,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

    ################################
    #last
    response_data = []

    for day_offset in range(total_days):
        current_date = startdate_str + timedelta(days=day_offset)
        current_date_str = current_date.strftime('%Y-%m-%d')
        
        # Define next day for range
        next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

        total_seconds = 1 * 24 * 60 * 60

        # Query the ProductionTable for entries for the current date
        dayresult = [p for p in all_dashboard_value if
                            ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                        ]

        total_cycle_time = sum(p['CycletimeActual'] for p in dayresult) if dayresult else 0
        print("total_cycle_time:", total_cycle_time)

        # Append data for each machine
        utilization = [
            round((total_cycle_time / total_seconds) * 100),  # Utilization
            0,  # Idle time (to be calculated below)
            0   # Nonproductive time (to be calculated below)
        ]

        # Calculate total idle time for current date
        saw = [k for k in all_breakdown_data if
                            ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                        ]

        #  .total_seconds()     # .seconds
        total_idle_time = sum(
                            (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                            for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                        )
        print("total_idle_time:", total_idle_time)

        val1 = Decimal(total_seconds) - (Decimal(total_cycle_time) + Decimal(total_idle_time))
        val2 = round((val1/total_seconds)*100)

        utilization[1] = round((total_idle_time / total_seconds) * 100)  # Idle time in percentage
        utilization[2] = round(val2)  # Nonproductive time

        # Construct the response for the current date
        response_data.append({
            "date": current_date_str,
            "Machine": select_machine,
            "Utilization": utilization
        })

    return JsonResponse(response_data, safe=False)

##########################################################################################################################################

@csrf_exempt
def statistical_fun(request):
    Plantname = request.GET.get('Plantname')
    MachinenamesArray = machineArray(Plantname)
    print(MachinenamesArray)

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')

    # Convert the date strings to datetime objects
    startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

    # Calculate the difference in days
    total_days = (enddate_str - startdate_str).days + 1
    print('total_days:', total_days)

    total_seconds = total_days * 24 * 60 * 60
    print("total_seconds:", total_seconds)

    nextday = (datetime.strptime(enddate, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')

    ################################

    pre_startdate_str = datetime.strptime(startdate, "%Y-%m-%d") - timedelta(days=1)
    nex_enddate_str = datetime.strptime(enddate, "%Y-%m-%d") + timedelta(days=1)

    all_dashboard_value = ProductionTable.objects.filter(
        Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
        Plantname=Plantname,
        Machinename__in=MachinenamesArray,
        MachineState=1
    ).values('Machinename', 'CycletimeActual', 'time', 'date').order_by('id')

    all_breakdown_data = breakdown.objects.filter(
                    Q(date__gte=pre_startdate_str, date__lte=nex_enddate_str),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

    ################################

    response_data = []

    for select_machine in MachinenamesArray:

        stat_total_cycle_time = 0
        stat_total_idle_time = 0

        for day_offset in range(total_days):
            current_date = startdate_str + timedelta(days=day_offset)
            current_date_str = current_date.strftime('%Y-%m-%d')
            
            # Define next day for range
            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            # Query the ProductionTable for entries between the start and end datetime
            dayresult = [p for p in all_dashboard_value if
                                p['Machinename'] == select_machine and
                                ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                                    (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                            ]

            total_cycle_time = sum(p['CycletimeActual'] for p in dayresult) if dayresult else 0


            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == select_machine and
                                ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                                    (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                            ]

            #  .total_seconds()     # .seconds
            total_idle_time = sum(
                                (datetime.strptime(bd['time'], "%H:%M:%S") - datetime.strptime(last['time'], "%H:%M:%S")).total_seconds()
                                for last, bd in zip(saw, saw[1:]) if last['MachineState'] == 0 and bd['MachineState'] == 1
                            )
            print("total_idle_time:", total_idle_time)

            ######################################################

            stat_total_cycle_time += total_cycle_time

            stat_total_idle_time += total_idle_time

            ######################################################

        val1 = Decimal(total_seconds) - (Decimal(stat_total_cycle_time) + Decimal(stat_total_idle_time))
        val2 = round((val1 / total_seconds) * 100)

        machine_data = {
            "Machine": select_machine,
            "Utilization": [
                round((stat_total_cycle_time / total_seconds) * 100),  # TotalCycleTimeActual
                round((stat_total_idle_time / total_seconds) * 100),   # TotalIdleTime
                val2  # Nonprod
            ]
        }
        response_data.append(machine_data)

    return JsonResponse(response_data, safe=False)