import datetime
from timeline.models import breakdown
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
import json
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
import pandas as pd
from dateutil import relativedelta
from django.db.models import Q, Sum, F, Count, Prefetch
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.db.models import Sum, F, ExpressionWrapper, DurationField, FloatField
from django.db.models import Sum, F, Q, Min, Max, Count
from decimal import Decimal
from django.db.models import Q, Sum, F, ExpressionWrapper, fields
from datetime import datetime, timedelta
from django.utils.dateparse import parse_time
from django.db.models import Q, Min, Max, F, Func
from decimal import Decimal


# #Create Your Code Here...!
# @csrf_exempt
# def statistical_fun(request):
#     Plantname = request.GET.get('Plantname')
#     MachinenamesArray = machineArray(Plantname)
#     print(MachinenamesArray)

#     DateReq = json.loads(request.body)
#     startdate = DateReq.get('startdate')
#     enddate = DateReq.get('enddate')
    
#     print(startdate)
#     print(enddate)
    
#     for machine in MachinenamesArray:
#         # Query the ProductionTable for entries between the start and end dates
#         btwdates = ProductionTable.objects.filter(date__gte=startdate, Machinename=machine, MachineState == 1, date__lte=enddate).values('ProductionCountActual').count()
#         print(btwdates)
#         print("_______________")
#         # Create a dictionary to pass to JsonResponse
#         response_data = {
#             'MachinenamesArray': MachinenamesArray,
#         }
    
#     return JsonResponse(response_data, safe=False)


@csrf_exempt
def statistical_fun(request):
    Plantname = request.GET.get('Plantname')
    MachinenamesArray = machineArray(Plantname)
    print(MachinenamesArray)

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')

    ############################
    # Convert the date strings to datetime objects
    startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

    # Calculate the difference in days
    total_days = (enddate_str - startdate_str).days + 1

    print('total_days:', total_days)

    total_seconds = total_days*24*60*60
    print("total_seconds:", total_seconds)
    ################################
    
    shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
    
    # Combine startdate and shift_starttime to create a datetime object
    shift_start_datetime = datetime.strptime(startdate + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
    shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1) # 24-hour shift duration
    
    nextday = (datetime.strptime(enddate, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    
    print("startdate:", startdate)
    print("enddate:", enddate)
    print("nextday:", nextday)
    print("shift_start_datetime:", shift_start_datetime.time())
    print("shift_end_datetime:", shift_end_datetime.time())
    
    response_data = {
        'MachinenamesArray': MachinenamesArray,
        'MachineData': []
    }

    for machine in MachinenamesArray:
        # Query the ProductionTable for entries between the start and end datetime
        day1result = ProductionTable.objects.filter(
            date__range=[startdate, nextday],
            time__range=[shift_start_datetime.time(), '23:59:59'],
            Machinename=machine,
            MachineState=1
        ).aggregate(total_cycle_time=Sum('CycletimeActual'))

        day2result = ProductionTable.objects.filter(
            date__range=[startdate, nextday],
            time__range=['00:00:00', shift_end_datetime.time()],
            Machinename=machine,
            MachineState=1
        ).aggregate(total_cycle_time=Sum('CycletimeActual'))
        
        total_cycle_time = (day1result['total_cycle_time'] or 0) + (day2result['total_cycle_time'] or 0)
        
        # print("total_cycle_time")
        print("_______________")
        totalCycle = total_cycle_time
        # Append data for each machine
        response_data['MachineData'].append({
            'MachineName': machine,
            'TotalCycleTimeActual': round((total_cycle_time/total_seconds)*100)
        })
        print(machine)
        idle1result = list(breakdown.objects.filter( date__range=[startdate, nextday],Machinename=machine, 
                                               time__range=[shift_start_datetime.time(), '23:59:59']).values('time', 'MachineState'))
        idle2result = list(breakdown.objects.filter( date__range=[startdate, nextday],Machinename=machine, 
                                               time__range=['00:00:00', shift_end_datetime.time()]).values('time', 'MachineState'))
        # print(idle1result + idle2result)
        #ji
        # if idle1result.MachineState__range [0,1]:
        #     remi1 = breakdown.objects.filter( date__range=[startdate, nextday],Machinename=machine, 
        #                                        time__range=[shift_start_datetime.time(), '23:59:59']
        #                                        ).aaggregate(time_between=sum('time'))
        #     print(remi1)
        # Calculate the total idle time for MachineState = 0
        total_idle_time = 0
        current_idle_start = None
        
        for record in idle1result + idle2result:
            record_time = datetime.strptime(record['time'], '%H:%M:%S')
            if record['MachineState'] == 0:
                if current_idle_start is None:
                    current_idle_start = record_time
            elif record['MachineState'] == 1 and current_idle_start is not None:
                idle_end = record_time
                if idle_end < current_idle_start:
                    # Handle crossing midnight
                    idle_end += timedelta(days=1)
                idle_duration = (idle_end - current_idle_start).total_seconds()
                total_idle_time += idle_duration
                print(f"start_idle: {current_idle_start.time()}")
                print(f"end_idle: {idle_end.time()}")
                print(f"idle_duration: {idle_duration}")
                current_idle_start = None
        
        # Handle case where the last state was idle
        if current_idle_start is not None:
            idle_end = datetime.strptime('23:59:59', '%H:%M:%S')
            if idle_end < current_idle_start:
                # Handle crossing midnight
                idle_end += timedelta(days=1)
            total_idle_time += (idle_end - current_idle_start).total_seconds()
        totalIdel = total_idle_time
        response_data['MachineData'][-1]['TotalIdleTime'] = round((total_idle_time/total_seconds)*100)  # Total idle time in seconds
        val1 = Decimal(total_seconds) - (Decimal(totalCycle) + Decimal(totalIdel))
        val2 = round((val1/total_seconds)*100)
        response_data['MachineData'][-1]['Nonprod'] = val2
        print(f"Total idle time for {machine}: {total_idle_time} seconds")

        ###################################################################
        # total_days = startdate - enddate
        # print('total_days:', total_days)
    
    return JsonResponse(response_data)

#***********************************************************************************************************************************

@csrf_exempt
def historical_fun(request):
    Plantname = request.GET.get('Plantname')

    DateReq = json.loads(request.body)
    startdate = DateReq.get('startdate')
    enddate = DateReq.get('enddate')
    MachinenamesArray = DateReq.get('machinename')
    print(MachinenamesArray)

    ############################
    # Convert the date strings to datetime objects
    startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
    enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

    # Calculate the difference in days
    total_days = (enddate_str - startdate_str).days + 1

    print('total_days:', total_days)

    total_seconds = total_days*24*60*60
    print("total_seconds:", total_seconds)
    ################################
    
    shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
    
    # Combine startdate and shift_starttime to create a datetime object
    shift_start_datetime = datetime.strptime(startdate + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
    shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1) # 24-hour shift duration
    
    nextday = (datetime.strptime(enddate, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    
    print("startdate:", startdate)
    print("enddate:", enddate)
    print("nextday:", nextday)
    print("shift_start_datetime:", shift_start_datetime.time())
    print("shift_end_datetime:", shift_end_datetime.time())
    
    response_data = {
        'MachinenamesArray': MachinenamesArray,
        'MachineData': []
    }

    # if MachinenamesArray:
    # Query the ProductionTable for entries between the start and end datetime
    day1result = ProductionTable.objects.filter(
        date__range=[startdate, nextday],
        time__range=[shift_start_datetime.time(), '23:59:59'],
        Machinename=MachinenamesArray,
        MachineState=1
    ).aggregate(total_cycle_time=Sum('CycletimeActual'))

    day2result = ProductionTable.objects.filter(
        date__range=[startdate, nextday],
        time__range=['00:00:00', shift_end_datetime.time()],
        Machinename=MachinenamesArray,
        MachineState=1
    ).aggregate(total_cycle_time=Sum('CycletimeActual'))
    
    total_cycle_time = (day1result['total_cycle_time'] or 0) + (day2result['total_cycle_time'] or 0)
    
    # print("total_cycle_time")
    print("_______________")
    totalCycle = total_cycle_time
    # Append data for each machine
    response_data['MachineData'].append({
        'MachineName': MachinenamesArray,
        'TotalCycleTimeActual': round((total_cycle_time/total_seconds)*100)
    })
    print(MachinenamesArray)
    idle1result = list(breakdown.objects.filter( date__range=[startdate, nextday],Machinename=MachinenamesArray, 
                                            time__range=[shift_start_datetime.time(), '23:59:59']).values('time', 'MachineState'))
    idle2result = list(breakdown.objects.filter( date__range=[startdate, nextday],Machinename=MachinenamesArray, 
                                            time__range=['00:00:00', shift_end_datetime.time()]).values('time', 'MachineState'))
    # print(idle1result + idle2result)
    #ji
    # if idle1result.MachineState__range [0,1]:
    #     remi1 = breakdown.objects.filter( date__range=[startdate, nextday],Machinename=machine, 
    #                                        time__range=[shift_start_datetime.time(), '23:59:59']
    #                                        ).aaggregate(time_between=sum('time'))
    #     print(remi1)
    # Calculate the total idle time for MachineState = 0
    total_idle_time = 0
    current_idle_start = None
    
    for record in idle1result + idle2result:
        record_time = datetime.strptime(record['time'], '%H:%M:%S')
        if record['MachineState'] == 0:
            if current_idle_start is None:
                current_idle_start = record_time
        elif record['MachineState'] == 1 and current_idle_start is not None:
            idle_end = record_time
            if idle_end < current_idle_start:
                # Handle crossing midnight
                idle_end += timedelta(days=1)
            idle_duration = (idle_end - current_idle_start).total_seconds()
            total_idle_time += idle_duration
            print(f"start_idle: {current_idle_start.time()}")
            print(f"end_idle: {idle_end.time()}")
            print(f"idle_duration: {idle_duration}")
            current_idle_start = None
    
    # Handle case where the last state was idle
    if current_idle_start is not None:
        idle_end = datetime.strptime('23:59:59', '%H:%M:%S')
        if idle_end < current_idle_start:
            # Handle crossing midnight
            idle_end += timedelta(days=1)
        total_idle_time += (idle_end - current_idle_start).total_seconds()
    totalIdel = total_idle_time
    response_data['MachineData'][-1]['TotalIdleTime'] = round((total_idle_time/total_seconds)*100)  # Total idle time in seconds
    val1 = Decimal(total_seconds) - (Decimal(totalCycle) + Decimal(totalIdel))
    val2 = round((val1/total_seconds)*100)
    response_data['MachineData'][-1]['Nonprod'] = val2
    print(f"Total idle time for {MachinenamesArray}: {total_idle_time} seconds")

        ###################################################################
        # total_days = startdate - enddate
        # print('total_days:', total_days)
    
    return JsonResponse(response_data)