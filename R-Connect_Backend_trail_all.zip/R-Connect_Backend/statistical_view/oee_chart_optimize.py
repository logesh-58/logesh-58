from timeline.models import timeline
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from productiontable.models import ProductionTable
import json
from datetime import datetime, timedelta, time
import time
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from django.db.models import Q, Min, Max, Count, F, Sum
from django.db.models import Sum, Count, F, ExpressionWrapper, DurationField, Case, When, FloatField
from dashboard.models import Dashboard
import pandas as pd
from analysis.views import machineArray, checkwithConfigMachines
from django.utils.dateparse import parse_datetime


# @csrf_exempt
# def oee_chart(request):
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']

#         DateReq = json.loads(request.body)
#         startdate = DateReq.get('startdate')
#         enddate = DateReq.get('enddate')
#         machine_name = DateReq.get('machinename')

#         startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
#         enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

#         total_days = (enddate_str - startdate_str).days + 1

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
#         response_data = []

#         for day_offset in range(total_days):
#             current_date = startdate_str + timedelta(days=day_offset)
#             current_date_str = current_date.strftime('%Y-%m-%d')

#             shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#             shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

#             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
#             next_day = current_date + timedelta(days=1)

#             total_hours = 1 * 24

#             dashboard_value = ProductionTable.objects.filter(
#                 Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
#                 Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
#                 Plantname=Plantname,
#                 Machinename=machine_name,
#                 MachineState=1
#             ).values('time', 'ProductionCountActual', 'Mouldname_id')

#             mouldname_ids = dashboard_value.values_list('Mouldname_id', flat=True).distinct()

#             mouldnames = []
#             oee_mld_values = []

#             total_ProductionTimeActual_hour = 0
#             total_ProductionCountActual = 0
#             total_RejectionParts = 0

#             for mouldname_id in mouldname_ids:
#                 Mouldname = Mouldmodel.objects.get(id=mouldname_id).Mouldname
#                 mouldnames.append(Mouldname)

#                 dashboard_value_mould = dashboard_value.filter(Mouldname_id=mouldname_id)

#                 first_time_str = dashboard_value_mould.first()
#                 last_time_str = dashboard_value_mould.last()

#                 if first_time_str and last_time_str:
#                     first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
#                     last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

#                     if last_time < first_time:
#                         # If last time is before the first time, it means the production time has crossed midnight.
#                         ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
#                         print("hiiiiii1")
#                     else:
#                         ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
#                         print("hiiiiii2")
#                     ProductionCountActual = dashboard_value_mould.count()
#                 else:
#                     ProductionTimeActual_hour = 0
#                     ProductionCountActual = 0

#                 RejectionParts_mld = 0  # Assuming RejectionParts_mld is 0 for simplicity

#                 try:
#                     oee_mld = ((float(ProductionTimeActual_hour) / total_hours) * (ProductionCountActual / 3000) * (abs(ProductionCountActual - RejectionParts_mld) / ProductionCountActual)) * 100
#                 except ZeroDivisionError:
#                     oee_mld = 0

#                 oee_mld_values.append(oee_mld)

#                 # Update totals for overall OEE calculation
#                 total_ProductionTimeActual_hour += ProductionTimeActual_hour
#                 total_ProductionCountActual += ProductionCountActual
#                 total_RejectionParts += RejectionParts_mld

#             # Calculate the overall OEE
#             try:
#                 oee = ((float(total_ProductionTimeActual_hour) / total_hours) * (total_ProductionCountActual / 3000) * (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual)) * 100
#             except ZeroDivisionError:
#                 oee = 0

#             response_data.append({
#                 "date": current_date_str,
#                 "Machine": machine_name,
#                 "OEE": oee,
#                 "Mouldname": ', '.join(mouldnames),
#                 "oee_mld": oee_mld_values
#             })

#         return JsonResponse(response_data, safe=False)
        #ji done
########################################################################################################

@csrf_exempt
def oee_chart(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        DateReq = json.loads(request.body)
        selection_fd = DateReq.get('selection')
        fromdate = DateReq.get('fromdate')
        todate = DateReq.get('todate')
        year_fd = DateReq.get('year')
        startdate = DateReq.get('startdate')
        enddate = DateReq.get('enddate')
        machine_name = DateReq.get('machinename')

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        if selection_fd == "Date_Range":

            startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

            total_days = (enddate_str - startdate_str).days + 1

            for day_offset in range(total_days):
                current_date = startdate_str + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
                shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
                next_day = current_date + timedelta(days=1)

                total_hours = 1 * 24

                dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Plantname=Plantname,
                    Machinename=machine_name,
                    MachineState=1
                ).values('time', 'ProductionCountActual', 'Mouldname_id')


                total_ProductionTimeActual_hour = 0
                total_ProductionCountActual = 0
                total_RejectionParts = 0


                first_time_str = dashboard_value.first()
                last_time_str = dashboard_value.last()

                if first_time_str and last_time_str:
                    first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                    last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

                    if last_time < first_time:
                        # If last time is before the first time, it means the production time has crossed midnight.
                        ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase1")
                    else:
                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase2")
                    ProductionCountActual = dashboard_value.count()
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    

                # Update totals for overall OEE calculation
                total_ProductionTimeActual_hour = ProductionTimeActual_hour
                total_ProductionCountActual = ProductionCountActual
                total_RejectionParts = 0

                # Calculate the overall OEE
                try:
                    oee = ((float(total_ProductionTimeActual_hour) / total_hours) * (total_ProductionCountActual / 3000) * (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual)) * 100
                except ZeroDivisionError:
                    oee = 0

                response_data.append({
                    "date": current_date_str,
                    "Machine": machine_name,
                    "OEE": oee
                })

        elif selection_fd == "Month_Wise":

            startdate_str = datetime.strptime(fromdate, "%Y-%m-%d")
            enddate_str = datetime.strptime(todate, "%Y-%m-%d")

            total_days = (enddate_str - startdate_str).days + 1

            for day_offset in range(total_days):
                current_date = startdate_str + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
                shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
                next_day = current_date + timedelta(days=1)

                total_hours = 1 * 24

                dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__range=[shift_start_datetime.time(), '23:59:59']) |
                    Q(date=next_day_str, time__range=['00:00:00', shift_end_datetime.time()]),
                    Plantname=Plantname,
                    Machinename=machine_name,
                    MachineState=1
                ).values('time', 'ProductionCountActual', 'Mouldname_id')


                total_ProductionTimeActual_hour = 0
                total_ProductionCountActual = 0
                total_RejectionParts = 0


                first_time_str = dashboard_value.first()
                last_time_str = dashboard_value.last()

                if first_time_str and last_time_str:
                    first_time = datetime.strptime(first_time_str['time'], "%H:%M:%S").time()
                    last_time = datetime.strptime(last_time_str['time'], "%H:%M:%S").time()

                    if last_time < first_time:
                        # If last time is before the first time, it means the production time has crossed midnight.
                        ProductionTimeActual_hour = ((datetime.combine(next_day, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase1")
                    else:
                        ProductionTimeActual_hour = ((datetime.combine(current_date, last_time) - datetime.combine(current_date, first_time)).total_seconds()) / 3600
                        print("testcase2")
                    ProductionCountActual = dashboard_value.count()
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    

                # Update totals for overall OEE calculation
                total_ProductionTimeActual_hour = ProductionTimeActual_hour
                total_ProductionCountActual = ProductionCountActual
                total_RejectionParts = 0

                # Calculate the overall OEE
                try:
                    oee = ((float(total_ProductionTimeActual_hour) / total_hours) * (total_ProductionCountActual / 3000) * (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual)) * 100
                except ZeroDivisionError:
                    oee = 0

                response_data.append({
                    "date": current_date_str,
                    "Machine": machine_name,
                    "OEE": oee
                })

        
        elif selection_fd == "Year_Wise":
            print("Year_Wise")

        return JsonResponse(response_data, safe=False)