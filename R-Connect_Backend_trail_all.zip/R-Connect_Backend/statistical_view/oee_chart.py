from timeline.models import timeline
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from productiontable.models import ProductionTable
import json
from datetime import datetime, timedelta, time
import time
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from django.db.models import Sum as add
from dashboard.models import Dashboard
import pandas as pd
from analysis.views import machineArray, checkwithConfigMachines
from django.utils.dateparse import parse_datetime


# @csrf_exempt
# def oee_chart(request):
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']

#         DateReq = json.loads(request.body)
#         startdate = DateReq.get('startdate')
#         enddate = DateReq.get('enddate')
#         machine_name = DateReq.get('machinename')

#         startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
#         enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

#         total_days = (enddate_str - startdate_str).days + 1
#         print('total_days:', total_days)

#         shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
#         response_data = []

#         for day_offset in range(total_days):
#             current_date = startdate_str + timedelta(days=day_offset)
#             current_date_str = current_date.strftime('%Y-%m-%d')

#             shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
#             shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

#             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
#             next_day = (current_date + timedelta(days=1))

#             print("current_date_str:", current_date_str, "next_day_str:", next_day_str, "day_offset:", day_offset, "starttime:", shift_start_datetime.time(), "endtime", shift_end_datetime.time())
#             print("____________________")
#             total_hours = 1 * 24

#             dashboard_value1 = ProductionTable.objects.filter(
#                 date=current_date_str,
#                 time__range=[shift_start_datetime.time(), '23:59:59'],
#                 Plantname=Plantname,
#                 Machinename=machine_name,
#                 MachineState=1
#             ).values('time', 'ProductionCountActual', 'Mouldname_id')

#             dashboard_value2 = ProductionTable.objects.filter(
#                 date=next_day_str,
#                 time__range=['00:00:00', shift_end_datetime.time()],
#                 Plantname=Plantname,
#                 Machinename=machine_name,
#                 MachineState=1
#             ).values('time', 'ProductionCountActual', 'Mouldname_id')

#             mouldname_ids = dashboard_value1.values_list('Mouldname_id', flat=True).distinct().union(
#                 dashboard_value2.values_list('Mouldname_id', flat=True).distinct())

#             # Initialize lists for Mouldname and oee_mld
#             mouldname_list = []
#             oee_mld_list = []

#             for mouldname_id in mouldname_ids:
#                 Mouldname = Mouldmodel.objects.get(id=mouldname_id).Mouldname
#                 mouldname_list.append(Mouldname)

#                 first_time_str_mld_1 = dashboard_value1.filter(Mouldname_id=mouldname_id).first()
#                 last_time_str_mld_1 = dashboard_value1.filter(Mouldname_id=mouldname_id).last()

#                 first_time_str_mld_2 = dashboard_value2.filter(Mouldname_id=mouldname_id).first()
#                 last_time_str_mld_2 = dashboard_value2.filter(Mouldname_id=mouldname_id).last()

#                 first_time_mld_1 = datetime.strptime(first_time_str_mld_1['time'], "%H:%M:%S").time() if first_time_str_mld_1 else None
#                 last_time_mld_1 = datetime.strptime(last_time_str_mld_1['time'], "%H:%M:%S").time() if last_time_str_mld_1 else None

#                 first_time_mld_2 = datetime.strptime(first_time_str_mld_2['time'], "%H:%M:%S").time() if first_time_str_mld_2 else None
#                 last_time_mld_2 = datetime.strptime(last_time_str_mld_2['time'], "%H:%M:%S").time() if last_time_str_mld_2 else None

#                 ProductionTimeActual_hour1_mld = ((datetime.combine(current_date, last_time_mld_1) - datetime.combine(current_date, first_time_mld_1)).total_seconds()) / 3600 if first_time_mld_1 and last_time_mld_1 else 0
#                 ProductionCountActual1_mld = dashboard_value1.filter(Mouldname_id=mouldname_id).count()

#                 ProductionTimeActual_hour2_mld = ((datetime.combine(next_day, last_time_mld_2) - datetime.combine(next_day, first_time_mld_2)).total_seconds()) / 3600 if first_time_mld_2 and last_time_mld_2 else 0
#                 ProductionCountActual2_mld = dashboard_value2.filter(Mouldname_id=mouldname_id).count()

#                 ProductionTimeActual_hour_mld = ProductionTimeActual_hour1_mld + ProductionTimeActual_hour2_mld
#                 ProductionCountActual_mld = ProductionCountActual1_mld + ProductionCountActual2_mld
#                 RejectionParts_mld = 0  # Assuming RejectionParts_mld is 0 for simplicity

#                 try:
#                     oee_mld = ((float(ProductionTimeActual_hour_mld) / total_hours) * (ProductionCountActual_mld / 3000) * (abs(ProductionCountActual_mld - RejectionParts_mld) / ProductionCountActual_mld)) * 100
#                 except ZeroDivisionError:
#                     oee_mld = 0

#                 oee_mld_list.append(oee_mld)

#             # Calculate the overall OEE
#             first_time_str1 = dashboard_value1.first()['time'] if dashboard_value1.exists() else None
#             last_time_str1 = dashboard_value1.last()['time'] if dashboard_value1.exists() else None

#             first_time_str2 = dashboard_value2.first()['time'] if dashboard_value2.exists() else None
#             last_time_str2 = dashboard_value2.last()['time'] if dashboard_value2.exists() else None

#             if first_time_str1 and last_time_str1:
#                 first_time1 = datetime.strptime(first_time_str1, "%H:%M:%S").time()
#                 last_time1 = datetime.strptime(last_time_str1, "%H:%M:%S").time()
#                 ProductionTimeActual_hour1 = ((datetime.combine(current_date, last_time1) - datetime.combine(current_date, first_time1)).total_seconds()) / 3600
#                 ProductionCountActual1 = dashboard_value1.count()
#             else:
#                 ProductionTimeActual_hour1 = 0
#                 ProductionCountActual1 = 0

#             if first_time_str2 and last_time_str2:
#                 first_time2 = datetime.strptime(first_time_str2, "%H:%M:%S").time()
#                 last_time2 = datetime.strptime(last_time_str2, "%H:%M:%S").time()
#                 ProductionTimeActual_hour2 = ((datetime.combine(next_day, last_time2) - datetime.combine(next_day, first_time2)).total_seconds()) / 3600
#                 ProductionCountActual2 = dashboard_value2.count()
#             else:
#                 ProductionTimeActual_hour2 = 0
#                 ProductionCountActual2 = 0

#             ProductionTimeActual_hour = ProductionTimeActual_hour1 + ProductionTimeActual_hour2
#             ProductionCountActual = ProductionCountActual1 + ProductionCountActual2
#             RejectionParts = 0

#             try:
#                 oee = ((float(ProductionTimeActual_hour) / total_hours) * (ProductionCountActual / 3000) * (abs(ProductionCountActual - RejectionParts) / ProductionCountActual)) * 100
#             except ZeroDivisionError:
#                 oee = 0

#             response_data.append({
#                 "date": current_date_str,
#                 "Machine": machine_name,
#                 "OEE": oee,
#                 "Mouldname": mouldname_list,
#                 "oee_mld": oee_mld_list
#             })

#         return JsonResponse(response_data, safe=False)
        

#########################
@csrf_exempt
def oee_chart(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        DateReq = json.loads(request.body)
        startdate = DateReq.get('startdate')
        enddate = DateReq.get('enddate')
        machine_name = DateReq.get('machinename')

        startdate_str = datetime.strptime(startdate, "%Y-%m-%d")
        enddate_str = datetime.strptime(enddate, "%Y-%m-%d")

        total_days = (enddate_str - startdate_str).days + 1
        print('total_days:', total_days)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start').last()['shift1start']
        response_data = []

        for day_offset in range(total_days):
            current_date = startdate_str + timedelta(days=day_offset)
            current_date_str = current_date.strftime('%Y-%m-%d')

            shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime), '%Y-%m-%d %H:%M:%S')
            shift_end_datetime = shift_start_datetime + timedelta(hours=24) - timedelta(minutes=1)

            next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')
            next_day = (current_date + timedelta(days=1))

            print("current_date_str:", current_date_str, "next_day_str:", next_day_str, "day_offset:", day_offset, "starttime:", shift_start_datetime.time(), "endtime", shift_end_datetime.time())
            print("____________________")
            total_hours = 1 * 24

            dashboard_value1 = ProductionTable.objects.filter(
                date=current_date_str,
                time__range=[shift_start_datetime.time(), '23:59:59'],
                Plantname=Plantname,
                Machinename=machine_name,
                MachineState=1
            ).values('time', 'ProductionCountActual', 'Mouldname_id')

            dashboard_value2 = ProductionTable.objects.filter(
                date=next_day_str,
                time__range=['00:00:00', shift_end_datetime.time()],
                Plantname=Plantname,
                Machinename=machine_name,
                MachineState=1
            ).values('time', 'ProductionCountActual', 'Mouldname_id')

            mouldname_ids = dashboard_value1.values_list('Mouldname_id', flat=True).distinct().union(
                dashboard_value2.values_list('Mouldname_id', flat=True).distinct())

            mouldnames = []
            oee_mld_values = []

            total_ProductionTimeActual_hour = 0
            total_ProductionCountActual = 0
            total_RejectionParts = 0

            for mouldname_id in mouldname_ids:
                Mouldname = Mouldmodel.objects.get(id=mouldname_id).Mouldname
                mouldnames.append(Mouldname)

                first_time_str_mld_1 = dashboard_value1.filter(Mouldname_id=mouldname_id).first()
                # print("first_time_str_mld_1:", first_time_str_mld_1)
                last_time_str_mld_1 = dashboard_value1.filter(Mouldname_id=mouldname_id).last()

                first_time_str_mld_2 = dashboard_value2.filter(Mouldname_id=mouldname_id).first()
                last_time_str_mld_2 = dashboard_value2.filter(Mouldname_id=mouldname_id).last()
                # print("last_time_str_mld_2:", last_time_str_mld_2)

                first_time_mld_1 = datetime.strptime(first_time_str_mld_1['time'], "%H:%M:%S").time() if first_time_str_mld_1 else None
                print("first_time_mld_1:", first_time_mld_1)
                last_time_mld_1 = datetime.strptime(last_time_str_mld_1['time'], "%H:%M:%S").time() if last_time_str_mld_1 else None
                print("last_time_mld_1:", last_time_mld_1)
                first_time_mld_2 = datetime.strptime(first_time_str_mld_2['time'], "%H:%M:%S").time() if first_time_str_mld_2 else None
                last_time_mld_2 = datetime.strptime(last_time_str_mld_2['time'], "%H:%M:%S").time() if last_time_str_mld_2 else None
                print("first_time_mld_2:", first_time_mld_2)
                print("last_time_mld_2:", last_time_mld_2)
                ProductionTimeActual_hour1_mld = ((datetime.combine(current_date, last_time_mld_1) - datetime.combine(current_date, first_time_mld_1)).total_seconds()) / 3600 if first_time_mld_1 and last_time_mld_1 else 0
                print("ProductionTimeActual_hour1_mld:", ProductionTimeActual_hour1_mld)
                ProductionCountActual1_mld = dashboard_value1.filter(Mouldname_id=mouldname_id).count()

                ProductionTimeActual_hour2_mld = ((datetime.combine(next_day, last_time_mld_2) - datetime.combine(next_day, first_time_mld_2)).total_seconds()) / 3600 if first_time_mld_2 and last_time_mld_2 else 0
                print("ProductionTimeActual_hour2_mld:", ProductionTimeActual_hour2_mld)
                ProductionCountActual2_mld = dashboard_value2.filter(Mouldname_id=mouldname_id).count()

                ProductionTimeActual_hour_mld = ProductionTimeActual_hour1_mld + ProductionTimeActual_hour2_mld
                print("ProductionTimeActual_hour_mld:", ProductionTimeActual_hour_mld)
                ProductionCountActual_mld = ProductionCountActual1_mld + ProductionCountActual2_mld
                RejectionParts_mld = 0  # Assuming RejectionParts_mld is 0 for simplicity
                print("__________________________________________________________________________________________")
                try:
                    oee_mld = ((float(ProductionTimeActual_hour_mld) / total_hours) * (ProductionCountActual_mld / 3000) * (abs(ProductionCountActual_mld - RejectionParts_mld) / ProductionCountActual_mld)) * 100
                except ZeroDivisionError:
                    oee_mld = 0

                oee_mld_values.append(oee_mld)

                # Update totals for overall OEE calculation
                total_ProductionTimeActual_hour += ProductionTimeActual_hour_mld
                total_ProductionCountActual += ProductionCountActual_mld
                total_RejectionParts += RejectionParts_mld

            # Calculate the overall OEE
            try:
                oee = ((float(total_ProductionTimeActual_hour) / total_hours) * (total_ProductionCountActual / 3000) * (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual)) * 100
            except ZeroDivisionError:
                oee = 0

            response_data.append({
                "date": current_date_str,
                "Machine": machine_name,
                "OEE": oee,
                "Mouldname": ', '.join(mouldnames),
                "oee_mld": oee_mld_values
            })

        return JsonResponse(response_data, safe=False)
