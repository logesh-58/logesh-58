
import datetime
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
import json
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
import pandas as pd
from dateutil import relativedelta
from django.db.models import Q, Sum, F, Count, Prefetch
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.db.models import Sum, F, ExpressionWrapper, DurationField, FloatField
from django.db.models import Sum, F, Q, Min, Max, Count
from decimal import Decimal
from django.db.models import Q, Sum, F, ExpressionWrapper, fields
from datetime import timedelta

def value(request, Plantname, MachineArray):
    request_data = json.loads(request.body)
    from_date = str(datetime.datetime.strptime((request_data['startdate']), "%Y-%m-%d").date())
    to_date  = str(datetime.datetime.strptime((request_data['enddate']), "%Y-%m-%d").date())
    shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start').last()['shift1start']
    # Parse the dates from strings into datetime objects
    iterate_dates = pd.date_range(start=from_date, end=to_date)
    next_date  = datetime.datetime.strftime(((datetime.datetime.strptime(to_date, '%Y-%m-%d')) + datetime.timedelta(days=1)) , '%Y-%m-%d')
    from_date = from_date + ' ' +str(shift_starttime)
    to_date   = next_date + ' ' +str(shift_starttime)
    # print(type(from_date))
    date1 = datetime.datetime.strptime(from_date, '%Y-%m-%d %H:%M:%S')
    date2 = datetime.datetime.strptime(to_date, '%Y-%m-%d %H:%M:%S')
    # Calculate the difference between the two dates
    difference = relativedelta.relativedelta(date2, date1)
    # print("differece", difference.days*24*60)
    # Shift Start Time
    # print(Plantname)
    # print(shift_start_time)
    distinctArray =  []
    list_hrs = [[str(shift_starttime),'23:59:59'],['00:00:01',str(shift_starttime)]]
    for machine in MachineArray:
        for d in iterate_dates:
            data = datetime.datetime.strftime(d.date() , '%Y-%m-%d')
            global fromtotime_cur, fromtotime_nex, date_cur, date_nex
            if (data == from_date ):
                date_cur    = data
                date_nex    = str(d.date() + datetime.timedelta(days = 1))
                fromtotime_cur = (list_hrs[0][0], list_hrs[0][1])
                fromtotime_nex = (list_hrs[1][0], list_hrs[1][1])

            elif ((data) == to_date):
                date_cur    = data
                date_nex    = str(d.date() + datetime.timedelta(days = 1))
                fromtotime_cur = (list_hrs[0][0], list_hrs[0][1])
                fromtotime_nex = (list_hrs[1][0], list_hrs[1][1])

            else:
                date_cur    = data
                date_nex    = str(d.date() + datetime.timedelta(days = 1))
                fromtotime_cur = (list_hrs[0][0], list_hrs[0][1])
                fromtotime_nex = (list_hrs[1][0], list_hrs[1][1])
            
            mouldnameid = ProductionTable.objects.filter(Q(date = date_cur, time__range = fromtotime_cur, Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0) | 
                Q(date = date_nex, time__range = fromtotime_nex, Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0)).values('Mouldname_id').distinct('Mouldname_id')
            # print(mouldnameid)
            for mouldid in mouldnameid:
                filter_production = ProductionTable.objects.filter(Q(date = date_cur, time__range = fromtotime_cur, Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0, Mouldname_id = mouldid['Mouldname_id']) | 
                    Q(date = date_nex, time__range = fromtotime_nex, Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0, Mouldname_id = mouldid['Mouldname_id'])).values('id', 'ProductionCountActual', 'Machinename', 'Mouldname_id', 'date')
                getdata_firstid  = filter_production.first()
                getdata_lastid   = filter_production.last()
                distinctArray.append({'fid': getdata_firstid['id'], 'lid':getdata_lastid['id'], 'Machinename': machine, 'Mouldname': mouldid['Mouldname_id'], 'date':getdata_lastid['date']})
        # break
    # print(distinctArray)
    return distinctArray, shift_starttime, Plantname, difference, iterate_dates

class parent:
    def main(**kwagrs):
        array = kwagrs['dist_list']
        shift_starttime = kwagrs['shift_time']
        Plantname = kwagrs['plnt_nm']
        difference = kwagrs['nofdy']
        dummy = kwagrs['dmy_value']
        machinename = kwagrs['machine_name']
        # print(array, shift_starttime, Plantname, difference)
        myarray = []
        for i in array:
            fidcount = 0
            Machinename = i['Machinename']; Mouldname = i['Mouldname']; fid = i['fid']; lid = i['lid']
            # ---------------- Get the running time of the mold-----------------------------------------
            firsttime = '00:00:00'; lasttime = '00:00:00'; runningtime = 0; actualcount = 0
            firsttime = (list(ProductionTable.objects.filter(id = fid).values('time'))[0])['time']
            lasttime = (list(ProductionTable.objects.filter(id = lid).values('time'))[0])['time']
            # -- Get the actual count value --
            try: 
                countnumbers = ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('id').count()
                # print("countnumbers :",countnumbers)
            except: countnumbers = 0
            # print('Count Numbers = ', countnumbers)
            try: 
                actualcount = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('ProductionCountActual').last())['ProductionCountActual']
                # print("actualcount :", actualcount)
            except Exception as e: 
                # print(Machinename, e)
                actualcount = 0
            
            fidcount = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
            # print('fidcount = ', fidcount)
            fidtime = (datetime.datetime.strptime(((list(ProductionTable.objects.filter(id=fid).values('time'))[0])['time']), '%H:%M:%S')).hour

            # print('ActualCount = ', actualcount)
            if(fidtime == shift_starttime.hour):
                if(fidcount > 1 and fidcount <= actualcount):
                    actualcount = (actualcount - fidcount) + 1

            if(firsttime < lasttime): runningtime = (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')).total_seconds()
            elif(firsttime == lasttime): runningtime = 0
            else: runningtime = ((datetime.datetime.strptime('23:59:59', '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')) + (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime('00:00:01', '%H:%M:%S'))).total_seconds()
            # print('Running time (sec)', runningtime)
            pcycletimeSumval    = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).aggregate(Sum('CycletimeActual')))["CycletimeActual__sum"]
            try: 
                firstval = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
                # print('Fistval = ', firstval)
                if(firstval == 1 and (countnumbers == actualcount)):
                    CycletimeActual = round((pcycletimeSumval/actualcount), 1) 
                else:
                    CycletimeActual = round((pcycletimeSumval/countnumbers), 1) 
            except Exception as e:
                # print('Cycletime exception error = ', e)
                CycletimeActual = 0
            # ------------------------ productiontime set and actual calculation -------------------------------------
            # print(runningtime)
            actualruntime   = float(round(runningtime/60, 1))
            # ------------------------ OEE parameters calculation -------------------------------------
            idletime = float(round((actualruntime - float((CycletimeActual * actualcount)/60)),1))
            if(idletime < 0):
                idletime = 0         
            #--------------------Append With Dictionary ---------------------------------------
            mydict = {  'Machinename'                   : Machinename, 
                        'MachineIdletime (Min)'         : round(idletime, 1),
                        'Actual runtime (Min)'          : round(actualruntime, 1),
                        'date'                          : i['date']
                        }
            # print(Machinename, idletime, actualruntime)
            myarray.append(mydict)
        # print(myarray)
        ############################### PERCENTAGE CALCULATION #######################################
        # print(difference.days)
        if dummy == 'cummulative_data':
            total_time = (difference.days*24*60)
            total_actualvalue = 0; total_idlevalue = 0; tempry_arry = []
            for machine in machinename:
                for data in myarray:
                    if machine == data['Machinename']:
                        total_idlevalue = (data['MachineIdletime (Min)'] + total_idlevalue)
                        total_actualvalue   = (data['Actual runtime (Min)']  + total_actualvalue)
                actual_percentage = (int(total_actualvalue) / total_time)*100 ; idle_percentage = (int(total_idlevalue) / total_time)*100
                machineoff_percentage = ((total_time - int(total_actualvalue) - int(total_idlevalue) ) / total_time )*100
                tempry_arry.append({"Machine":machine, "Utilization":[round(machineoff_percentage), round(idle_percentage),round(actual_percentage)]})
                total_idlevalue = 0; total_actualvalue = 0; machineoff_percentage = 0; actual_percentage = 0; idle_percentage = 0
                # break
            return tempry_arry
        
        if dummy == 'daily data':
            return myarray

#Create Your Code Here...!
@csrf_exempt
def statistical_fun(request):
    dummy = 'cummulative_data'
    Plantname = request.GET['Plantname']
    MachinenamesArray = machineArray(Plantname)
    list, time, plant_nme, days, iter_date = value(request, Plantname, MachinenamesArray)
    obj = parent.main(dist_list = list, shift_time = time, plnt_nm = plant_nme, nofdy = days, dmy_value = dummy, machine_name = MachinenamesArray)
    return JsonResponse(obj, safe=False)

@csrf_exempt
def productivity_view(request):
    dummy = "daily data"
    machine_name = json.loads(request.body)['machinename']
    Plantname = request.GET['Plantname']
    machinearray = [machine_name]
    list, time, plant_nme, days, iter_date = value(request, Plantname, machinearray)
    obj = parent.main(dist_list = list, shift_time = time, plnt_nm = plant_nme, nofdy = days, dmy_value = dummy,  machine_name = machinearray)
    difference = days
    my_array   = obj
    # print(my_array)
    total_time = (difference.days*24*60)
    # print(total_time)
    # print(total_time)
    total_actualvalue = 0; total_idlevalue = 0;  daily_list = []
    for z in iter_date:
        daily_date = datetime.datetime.strftime(z.date() , "%Y-%m-%d")
        for x in my_array:
            if x['date'] == daily_date:
                total_idlevalue = (x['MachineIdletime (Min)'] + total_idlevalue)
                total_actualvalue   = (x['Actual runtime (Min)']  + total_actualvalue)
        # print(total_actualvalue, total_actualvalue)
        # print("total time:", total_time)
        try:
           actual_percentage = (int(total_actualvalue) / total_time)*100
        except:
           actual_percentage = 0
        try:
            idle_percentage = (int(total_idlevalue) / total_time)*100
        except:
            idle_percentage = 0
        try:
            machineoff_percentage = ((total_time - int(total_actualvalue) - int(total_idlevalue) ) / total_time )*100
        except:
            machineoff_percentage  = 0
        # print(actual_percentage, idle_percentage, machineoff_percentage)
        daily_list.append({"date": daily_date, "Machine":machine_name, "Utilization":[round(machineoff_percentage), round(idle_percentage),round(actual_percentage)]})
        # print({"date": daily_date, "Machine":machine_name, "Utilization":[round(actual_percentage), round(idle_percentage),round(machineoff_percentage)]})
        total_idlevalue = 0; total_actualvalue = 0; machineoff_percentage = 0; actual_percentage = 0; idle_percentage = 0
    return JsonResponse(daily_list, safe=False)

#**************************************************************************************************************************************