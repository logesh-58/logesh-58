import datetime
from analysis.views import machineArray
from django.views.decorators.csrf import csrf_exempt
from django.http.response import  HttpResponse, JsonResponse
import json
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
import pandas as pd
from dateutil import relativedelta

#Create Your Code Here...!
@csrf_exempt
def statistical_fun(request):
    Plantname = request.GET['plantname']
    request_data = json.loads(request.body)
    from_date = request_data['from_date']
    to_date   = request_data['to_date']
    # Parse the dates from strings into datetime objects
    date1 = datetime.datetime.strptime(from_date, '%d-%m-%Y')
    # print(date1)
    date2 = (datetime.datetime.strptime(to_date, '%d-%m-%Y') + datetime.timedelta(days=1))
    # print(date2)
    # Calculate the difference between the two dates
    difference = relativedelta.relativedelta(date2, date1)
    next_date  = datetime.datetime.strftime(((datetime.datetime.strptime(to_date, '%d-%m-%Y')) + datetime.timedelta(days=1)) , '%d-%m-%Y')
    iterate_dates = pd.date_range(start=from_date, end=next_date)
    # print(iterate_dates)
    shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
    for i in shift_starttime:
        shift_starttime = i['shift1start']
    MachinenamesArray = machineArray(Plantname)
    distinctArray =  []
    myarray   = []
    list_hrs = [[str(shift_starttime),'23:59:59'],['00:00:01','23:59:59'],['00:00:01',str(shift_starttime)]]
    for machine in MachinenamesArray:
        # print(machine)
        flag = 0; count = 0; prevcount = 0; firstid = 0; lastid = 0; prevmold = ''
        for d in iterate_dates:
            data = datetime.datetime.strftime(d.date() , '%d-%m-%Y')
            # print(data)
            global fromtime, totime, date_
            if (data == from_date ): date_    = data; fromtime = list_hrs[0][0] ; totime = list_hrs[0][1]
            elif ((data) == next_date): date_  = data; fromtime = list_hrs[2][0] ; totime = list_hrs[2][1]
            else: date_  = data; fromtime = list_hrs[1][0] ; totime = list_hrs[1][1]
            # print((date_))
            # print(fromtime, totime)
            getdatas = ProductionTable.objects.filter(date = date_, time__range = (fromtime, totime), Machinename = machine, MachineState__gt = 0, ProductionCountActual__gt = 0).values('id', 'ProductionCountActual', 'Machinename', 'Mouldname_id', 'date').order_by('id')
            # print(getdatas)
            for i in getdatas:
                # global Mouldname_id, Machinename
                id = i['id']; count = int(i['ProductionCountActual']); Mouldname_id =  i['Mouldname_id']; Machinename = i['Machinename']
                if(flag == 0): prevcount = count; firstid = id; flag = 1
                if(prevcount <= count): lastid = id
                if(prevcount > count or (prevmold != Mouldname_id and (prevmold != '' and Mouldname_id != ''))):
                    distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold , 'date':i['date']}; distinctArray.append(distinctDict); lastid = id; firstid = id
                    # print(distinctDict)
                prevcount = count; prevmold = Mouldname_id; lastid = id
            # break
        if(Machinename and Mouldname_id != ''):
            distinctDict = { 'fid': firstid, 'lid':lastid, 'Machinename': Machinename, 'Mouldname': prevmold , 'date':i['date']}; distinctArray.append(distinctDict)
            # print(distinctDict)
        Machinename = ''; Mouldname_id = ''
        # print(distinctArray)
        # break
    # print(distinctArray)
    for i in distinctArray:
        # print(i)
        fidcount = 0
        Machinename = i['Machinename']; Mouldname = i['Mouldname']; fid = i['fid']; lid = i['lid']
        # print('Machinename, id =', Machinename, fid, lid)
        # ---------------- Get the running time of the mold-----------------------------------------
        flag = 0; firsttime = '00:00:00'; lasttime = '00:00:00'; prevmold = ''; runningtime = 0; actualcount = 0
        firsttime = (list(ProductionTable.objects.filter(id = fid).values('time'))[0])['time']
        # print(firsttime)
        # print(firsttime)
        lasttime = (list(ProductionTable.objects.filter(id = lid).values('time'))[0])['time']
        # print(lasttime)
        # print(lasttime)
        # -- Get the actual count value --
        try: 
            countnumbers = ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('id').count()
            # print("countnumbers :",countnumbers)
        except: countnumbers = 0
        # print('Count Numbers = ', countnumbers)
        try: 
            actualcount = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).values('ProductionCountActual').last())['ProductionCountActual']
            # print("actualcount :", actualcount)
        except Exception as e: 
            # print(Machinename, e)
            actualcount = 0
        
        fidcount = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
        # print('fidcount = ', fidcount)
        fidtime = (datetime.datetime.strptime(((list(ProductionTable.objects.filter(id=fid).values('time'))[0])['time']), '%H:%M:%S')).hour
        # print('fidtime = ', Machinename, Mouldname, fidtime)

        # print('ActualCount = ', actualcount)
        if(fidtime == shift_starttime.hour):
            # print('start time hour same')
            if(fidcount > 1 and fidcount <= actualcount):
                actualcount = (actualcount - fidcount) + 1
            # print('sub count = ', actualcount)
        # print(actualcount, Machinename)

        if(firsttime < lasttime): runningtime = (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')).total_seconds()
        elif(firsttime == lasttime): runningtime = 0
        else: runningtime = ((datetime.datetime.strptime('23:59:59', '%H:%M:%S') - datetime.datetime.strptime(firsttime, '%H:%M:%S')) + (datetime.datetime.strptime(lasttime, '%H:%M:%S') - datetime.datetime.strptime('00:00:01', '%H:%M:%S'))).total_seconds()
        # print('Running time (sec)', runningtime)
        pcycletimeSumval    = (ProductionTable.objects.filter(id__range = (fid, lid), Plantname= Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1, MachineState__gt = 0).aggregate(Sum('CycletimeActual')))["CycletimeActual__sum"]
        try: 
            firstval = (list(ProductionTable.objects.filter(id=fid).values('ProductionCountActual'))[0])['ProductionCountActual']
            # print('Fistval = ', firstval)
            if(firstval == 1 and (countnumbers == actualcount)):
                CycletimeActual = round((pcycletimeSumval/actualcount), 1) 
            else:
                CycletimeActual = round((pcycletimeSumval/countnumbers), 1) 
        except Exception as e:
            # print('Cycletime exception error = ', e)
            CycletimeActual = 0
        # ------------------------ productiontime set and actual calculation -------------------------------------
        # print(runningtime)
        actualruntime   = float(round(runningtime/60, 1))
        # ------------------------ OEE parameters calculation -------------------------------------
        idletime = float(round((actualruntime - float((CycletimeActual * actualcount)/60)),1))
        if(idletime < 0):
            idletime = 0         
        #--------------------Append With Dictionary ---------------------------------------
        mydict = {  'Machinename'                   : Machinename, 
                    'MachineIdletime (Min)'         : round(idletime, 1),
                    'Actual runtime (Min)'          : round(actualruntime, 1),
                    }
        myarray.append(mydict)
    # print(myarray)
    ############################### PERCENTAGE CALCULATION #######################################
    # print(difference.days)
    total_time = (difference.days*24*60)
    # print(total_time)
    total_actualvalue = 0; total_idlevalue = 0; tempry_arry = []
    for machine in MachinenamesArray:
        for data in myarray:
            # print(data)
            if machine == data['Machinename']:
                total_idlevalue = (data['MachineIdletime (Min)'] + total_idlevalue)
                total_actualvalue   = (data['Actual runtime (Min)']  + total_actualvalue)
        actual_percentage = (int(total_actualvalue) / total_time)*100 ; idle_percentage = (int(total_idlevalue) / total_time)*100
        machineoff_percentage = ((total_time - int(total_actualvalue) - int(total_idlevalue) ) / total_time )*100
        tempry_arry.append({"Machine":machine, "Utilization":[round(actual_percentage, 1), round(idle_percentage, 1),round(machineoff_percentage, 1)]})
        total_idlevalue = 0; total_actualvalue = 0; machineoff_percentage = 0; actual_percentage = 0; idle_percentage = 0
        # break
    return JsonResponse(tempry_arry, safe=False)

@csrf_exempt
def productivity_view(request):
    class parent:
        def main(request):
            print(request.method)
            return "Request hello"
    obj = parent.main(request)
    return HttpResponse(obj)
    