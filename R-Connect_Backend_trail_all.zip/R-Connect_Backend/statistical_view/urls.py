from django.urls import path, include
from . import optimize_code
from . import mytry
from . import oee_chart, oee_chart_optimize

urlpatterns = [
   # path('statistical/', mytry.statistical_fun, name = 'Statistical_View'),
   # path('productivity/', mytry.historical_fun, name = 'Statistical_View'),

   path('statistical/', optimize_code.statistical_fun, name = 'Statistical_View'),
   path('productivity/', optimize_code.historical_fun, name = 'Statistical_View'),

] 