from django.apps import AppConfig


class GroupManagementConfig(AppConfig):
    name = 'group_management'
