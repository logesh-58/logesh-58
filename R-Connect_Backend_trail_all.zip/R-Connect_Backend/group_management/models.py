from django.db import models

# Create your models here.
class AddGroup(models.Model):
    agid = models.AutoField(primary_key=True)
    agplantname = models.CharField(max_length=255,default=False,null=True)
    aggroupname = models.CharField(max_length=255,default=False,null=True)
    aggroupcode = models.CharField(max_length=255,default=False,null=True)