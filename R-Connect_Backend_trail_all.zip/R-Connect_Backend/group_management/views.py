from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import group_management
from django.shortcuts import render
from group_management.models import AddGroup
from group_management.serializers import GroupManagementDbSerializer
from rest_framework.parsers import JSONParser
# Create your views here.
@csrf_exempt
def addgroup(request):
    plntname=request.GET['plantname']
    if request.method == "GET":
        groupmanagementdata=AddGroup.objects.filter(agplantname=plntname).values()
        groupserializeddata=GroupManagementDbSerializer(groupmanagementdata,many=True)
        print("Get Running")
        return JsonResponse(groupserializeddata.data,safe=False)
    elif request.method == "POST":
        print("POST Running")
        groupmanagement_Dbdata =  JSONParser().parse(request)
        grpname = groupmanagement_Dbdata["aggroupcode"]
        getrow = AddGroup.objects.all()
        count=0
        for s in getrow:
            # print(s.aggroupcode)
            if grpname == s.aggroupcode:
                count=count+1

        if count == 0:        
            sourcemanagementSerializer = GroupManagementDbSerializer(data=groupmanagement_Dbdata, partial=True)
            if sourcemanagementSerializer.is_valid():
                sourcemanagementSerializer.save()
                AddGroup.objects.filter(aggroupcode=groupmanagement_Dbdata["aggroupcode"]).update(agplantname=plntname)
            return JsonResponse("Group Management data saved to the db successfully",safe=False)
        else:
            return JsonResponse("Group Code Already exist",safe=False)

    elif request.method=="PUT":
        groupmanagement_Dbdata =  JSONParser().parse(request)
        AddGroup.objects.filter(aggroupcode=groupmanagement_Dbdata["aggroupcode"]).update(aggroupname=groupmanagement_Dbdata["aggroupname"])

        return JsonResponse("Group Management data updated to the db successfully",safe=False)

    elif request.method=="DELETE":
        Dbdata= JSONParser().parse(request)
            # print(Dbdata["code"])
        AddGroup.objects.filter(aggroupcode=Dbdata["code"]).delete()

        return JsonResponse("Group Record Deleted Successfully",safe=False)

def delete(request,aggroupcode):
    print(request,aggroupcode)
    return JsonResponse("Data deleted successfully",safe=False)