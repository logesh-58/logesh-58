from rest_framework import serializers
from group_management.models import AddGroup

class GroupManagementDbSerializer(serializers.ModelSerializer):
    class Meta:
        model=AddGroup
        fields=['agid',
                'agplantname',
                'aggroupname',
                'aggroupcode']
