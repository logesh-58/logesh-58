from django.apps import AppConfig


class MasterAdministratorConfig(AppConfig):
    name = 'master_administrator'
