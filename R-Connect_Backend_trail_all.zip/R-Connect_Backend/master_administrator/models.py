from django.db import models

# Create your models here.
class AddMasterAdministrator(models.Model):
    amaid = models.AutoField(primary_key=True)
    amamaxedgedevice = models.IntegerField(default=False,null=True)
    amamaxmeters = models.IntegerField(default=False,null=True)
    amamaxusers = models.IntegerField(default=False,null=True)
    amaplantname = models.CharField(max_length=255,default=False,null=True)
    amacreatedon = models.DateTimeField(default=False,null=True)
    amlasteditedon = models.DateTimeField(default=False,null=True)