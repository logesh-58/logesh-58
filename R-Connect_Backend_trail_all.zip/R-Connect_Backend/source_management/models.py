from django.db import models
from django.db.models.base import Model

# Create your models here.
class AddSource(models.Model):
    asid = models.AutoField(primary_key=True)
    assourcename = models.CharField(max_length=255,default=False,null=True)
    asplantname = models.CharField(max_length=255,default=False,null=True)
    assourcecode = models.CharField(max_length=255,default=False,null=True)
    assourcecapacity = models.DecimalField(max_digits=20,decimal_places=1, blank=True, null=True)
    assourceunit = models.CharField(max_length=255,default=False,null=True)