from django.db.models.base import Model
from rest_framework import serializers
from source_management.models import AddSource

class SourceManagementDbSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddSource
        fields = ['asid',
                  'assourcename',
                  'asplantname',
                  'assourcecode',
                  'assourcecapacity']