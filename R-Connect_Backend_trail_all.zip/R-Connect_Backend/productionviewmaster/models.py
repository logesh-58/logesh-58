from django.db import models
from mouldmanagement.models import Mouldmodel

# Create your models here.
class productionviewmaster(models.Model):
    id           = models.AutoField(primary_key=True)
    date         = models.CharField(max_length=255, default=False, null=True)
    time         = models.CharField(max_length=255, default=False, null=True)
    Plantname    = models.CharField(max_length=255, default=False, null=True)
    Machinename  = models.CharField(max_length=255, default=False, null=True)
    Mouldname    = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    shift        = models.CharField(max_length=255, default=False, null=True)
    shift1actual = models.IntegerField(default=False, null=True)
    shift2actual = models.IntegerField(default=False, null=True)
    shift3actual = models.IntegerField(default=False, null=True)
    shift1target = models.IntegerField(default=False, null=True)
    shift2target = models.IntegerField(default=False, null=True)
    shift3target = models.IntegerField(default=False, null=True)

    
class Moldcount(models.Model):
    id          = models.AutoField(primary_key=True)
    date        = models.CharField(max_length=255, default=False, null=True)
    Plantname   = models.CharField(max_length=255, default=False, null=True)
    Mouldname   = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    moldcount   = models.IntegerField(default=False, null=True)

# class shiftstatus(models.Model):
#     id = models.AutoField(primary_key=True)
#     date        = models.CharField(max_length=255, default=False, null=True)
#     Machinename = models.CharField(max_length=255, default=False, null=True)
#     Plantname   = models.CharField(max_length=255, default=False, null=True)
#     shift1total = models.IntegerField(default=False, null=True)
#     shift2total = models.IntegerField(default=False, null=True)
#     shift3total = models.IntegerField(default=False, null=True)
#     shift1target = models.IntegerField(default=False, null=True)
#     shift2target = models.IntegerField(default=False, null=True)
#     shift3target = models.IntegerField(default=False, null=True)
    