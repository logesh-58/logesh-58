import xlwt
from datetime import datetime, date
import calendar
import os
from REnergy.settings import BASE_DIR
from django.http import HttpResponse, JsonResponse
from costestimator.models import Cost_CNG, Cost_LPG, Cost_DG, Cost_PNG, Cost_Petrol, cost_water, Cost_Wind
from meter_data.models import Masterdatatable
from django.db.models.aggregates import Sum
from source_management.models import AddSource
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import json
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def CarbonReport():
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet1 = workbook.add_sheet('Scope 1')
    worksheet2 = workbook.add_sheet('Scope 2')
    worksheet3 = workbook.add_sheet('Scope 3')
    worksheet4 = workbook.add_sheet('Water details')
    worksheet5 = workbook.add_sheet('Electricity & Cost Details')
    worksheet6 = workbook.add_sheet('I-IV Consumption & Waste Dis.')
    worksheet7 = workbook.add_sheet('VIII - Goods transport')
    worksheet8 = workbook.add_sheet('V - VII Employee Commuting')
    worksheet1.show_grid = False
    worksheet2.show_grid = False
    worksheet3.show_grid = False
    worksheet4.show_grid = False
    worksheet5.show_grid = False
    worksheet6.show_grid = False
    worksheet7.show_grid = False
    worksheet8.show_grid = False
    
    style1 = xlwt.XFStyle()
    style2 = xlwt.XFStyle()
    style3 = xlwt.XFStyle()
    style4 = xlwt.XFStyle()
    style5 = xlwt.XFStyle()
    style6 = xlwt.XFStyle()
    style7 = xlwt.XFStyle()
    style8 = xlwt.XFStyle()
    style9 = xlwt.XFStyle()
    style10 = xlwt.XFStyle()
    style11 = xlwt.XFStyle()
    style12 = xlwt.XFStyle()
    
    alignment = xlwt.Alignment()
    alignment1 = xlwt.Alignment()
    alignment.wrap = 1
    alignment1.wrap = 1
    alignment.horz = xlwt.Alignment.HORZ_CENTER
    alignment1.vert = xlwt.Alignment.VERT_CENTER
    alignment.vert = xlwt.Alignment.VERT_CENTER
    style1.alignment = alignment
    style2.alignment = alignment
    style3.alignment = alignment
    style4.alignment = alignment
    style5.alignment = alignment
    style6.alignment = alignment
    style7.alignment = alignment
    style8.alignment = alignment
    style9.alignment = alignment
    style10.alignment = alignment1
    style11.alignment = alignment1
    style12.alignment = alignment
    
    border1 = xlwt.Borders()
    border1.left = border1.THIN
    border1.right = border1.THIN
    border1.top = border1.THIN
    border1.bottom = border1.THIN
    style1.borders = border1
    style2.borders = border1
    style3.borders = border1
    style4.borders = border1
    style5.borders = border1
    style6.borders = border1
    style7.borders = border1
    style8.borders = border1
    style9.borders = border1
    style10.borders = border1
    style11.borders = border1
    style12.borders = border1
    
    pattern1 = xlwt.Pattern()
    pattern1.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern1.pattern_fore_colour = xlwt.Style.colour_map['red']
    style1.pattern = pattern1
    
    pattern2 = xlwt.Pattern()
    pattern2.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern2.pattern_fore_colour = xlwt.Style.colour_map['tan']
    style3.pattern = pattern2
    
    pattern3 = xlwt.Pattern()
    pattern3.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern3.pattern_fore_colour = xlwt.Style.colour_map['lime']
    style7.pattern = pattern3
    
    pattern4 = xlwt.Pattern()
    pattern4.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern4.pattern_fore_colour = xlwt.Style.colour_map['ice_blue']
    style8.pattern = pattern4
    style9.pattern = pattern4
    style11.pattern = pattern4
    style12.pattern = pattern4
    
    pattern5 = xlwt.Pattern()
    pattern5.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern5.pattern_fore_colour = xlwt.Style.colour_map['blue_gray']
    style12.pattern = pattern5
    
    font1 = xlwt.Font()
    font1.name = 'Atlanta'
    font1.colour_index = xlwt.Style.colour_map['white']
    font1.bold = True
    font1.height = 180
    style1.font = font1
    
    font2 = xlwt.Font()
    font2.name = 'Atlanta'
    font2.bold = True
    font2.height = 180
    font2.colour_index = xlwt.Style.colour_map['red']
    style2.font = font2
    
    font3 = xlwt.Font()
    font3.name = 'Atlanta'
    font3.bold = True
    font3.height = 180
    style3.font = font3
    
    font4 = xlwt.Font()
    font4.name = 'Atlanta'
    font4.height = 180
    style4.font = font4
    style8.font = font4
    style10.font = font4
    
    font5 = xlwt.Font()
    font5.name = 'Atlanta'
    font5.bold = True
    font5.height = 180
    style5.font = font5
    style7.font = font5
    style9.font = font5
    style11.font = font5
    style12.font = font5
    
    font6 = xlwt.Font()
    font6.name = 'Atlanta'
    font6.height = 180
    font6.colour_index = xlwt.Style.colour_map['blue']
    style6.font = font6
    
    ######################################################################  SHEET 1 ############################################################################################
    
    worksheet1.write_merge(0, 0, 0, 5, 'Environment Sustainability Data Responsibility - Scope 1', style1)
    worksheet1.row(0).height_mismatch = True
    worksheet1.row(0).height = 500
    worksheet1.write(1, 0, 'Name of Champion', style5)
    worksheet1.row(1).height_mismatch = True
    worksheet1.row(1).height = 500
    worksheet1.col(0).width = 6000
    worksheet1.write(2, 0, 'E-mail address', style5)
    worksheet1.row(2).height_mismatch = True
    worksheet1.row(2).height = 500
    worksheet1.write_merge(1, 1, 1, 5, '', style6)
    worksheet1.write_merge(2, 2, 1, 5, '', style6)
    worksheet1.write_merge(3, 3, 0, 42, 'Scope 1 Emissions : Fuel consumption, Process emissions,  Water Conservation', style2)
    worksheet1.row(3).height_mismatch = True
    worksheet1.row(3).height = 530
    worksheet1.write(4, 0, 'SCOPE 1 Emission', style3)
    worksheet1.row(4).height_mismatch = True
    worksheet1.row(4).height = 600
    worksheet1.row(5).height_mismatch = True
    worksheet1.row(5).height = 600
    worksheet1.write(5, 0, 'Source', style3)
    worksheet1.write_merge(6, 10, 0, 0, 'Fuel Combustion', style4)
    worksheet1.write_merge(11, 13, 0, 0, 'Process emission Released', style4)
    worksheet1.write(14, 0, 'Ground Water consumption (In-House)', style4)
    worksheet1.write_merge(15, 16, 0, 0, 'Carbon sink', style4)
    worksheet1.write_merge(4, 5, 1, 1, 'Fuel Type', style3)
    worksheet1.col(1).width = 5000
    worksheet1.write_merge(4, 5, 2, 2, 'Purpose', style3)
    worksheet1.col(2).width = 4000
    worksheet1.write_merge(4, 5, 3, 3, 'Units', style3)
    worksheet1.col(24).width = 5000
    worksheet1.col(23).width = 2500
    worksheet1.col(22).width = 2500
    worksheet1.col(3).width = 4000
    worksheet1.write_merge(4, 4, 4, 16, 'Consumption, Used, Disposed, etc', style3)
    worksheet1.write_merge(4, 4, 17, 21, 'Consumption Past Years', style3)
    worksheet1.write_merge(4, 4, 25, 37, 'Co2 eq calculation', style3)
    worksheet1.write_merge(4, 4, 38, 42, 'Co2 equ calculation Past Years', style3)
    worksheet1.set_panes_frozen(True)
    worksheet1.set_vert_split_pos(4)
    worksheet1.set_horz_split_pos(6)
    worksheet2.set_panes_frozen(True)
    worksheet2.set_vert_split_pos(5)
    worksheet2.set_horz_split_pos(6)
    worksheet3.set_panes_frozen(True)
    worksheet3.set_vert_split_pos(5)
    worksheet3.set_horz_split_pos(6)
    
    array5 = ['Name of GHG', 'GHG CO2e', 'Units']
    col2 = 22
    for list6 in array5:
        worksheet1.write_merge(4, 5, col2, col2, list6, style3)
        worksheet2.write_merge(4, 5, col2 + 1, col2 + 1, list6, style3)
        worksheet3.write_merge(4, 5, col2 + 1, col2 + 1, list6, style3)
        col2 += 1
    
    row1 = 6
    array1 = ['Diesel', 'Petrol', 'LPG', 'CNG', 'PNG', 'Air conditioning', 'Process Chillers / HVAC', 'Fire extinguisher CO2', 'Fresh Water', 'Trees planted', 'Water Charging (Rain Water Harvesting)']
    for list1 in array1:
        worksheet1.write(row1, 1, list1, style4)
        worksheet1.row(row1).height_mismatch = True
        worksheet1.row(row1).height = 640
        row1 += 1
        
    row2 = 6
    array2 = ['Fuel burnt', 'Fuel burnt', 'Fuel burnt', 'Fuel burnt', 'Fuel burnt', 'HCFC-22 (R-22)', 'HCFC-134a (R134a)', 'CO2 make up', 'Process & Domestic', 'General', 'General']
    for list2 in array2:
        worksheet1.write(row2, 2, list2, style4)
        row2 += 1
        
    row3 = 6
    array3 = ['Litres', 'Litres', 'Litres', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'kL', 'Nos', 'kL']
    for list3 in array3:
        worksheet1.write(row3, 3, list3, style4)
        row3 += 1
    
    month_cons = []  
    month_emission = []  
    current_date = datetime.now()
    current_month = current_date.month
    current_year = current_date.year
    previous_year = current_year - 1
    next_year = current_year + 1
    start_month = 4
    end_month = 3
    
    for list2 in range(4, 13):
        x = datetime(current_year, list2, 1).strftime("%b'%y")
        month_cons.append(x)
        month_emission.append(x)
    for list3 in range(1, 4):
        y = datetime(next_year, list3, 1).strftime("%b'%y")
        month_cons.append(y)
        month_emission.append(y)
    
    col1 = 4
    for list4 in month_cons:
        worksheet1.write(5, col1, 'Cons. ' + list4, style3)
        worksheet2.write(5, col1 + 1, 'Cons. ' + list4, style3)
        worksheet3.write(5, col1 + 1, 'Cons. ' + list4, style3)
        worksheet4.write(2, col1 - 2, list4, style3)
        worksheet5.write(2, col1 - 2, list4, style3)
        worksheet5.col(col1 - 2).width = 3000
        col1 += 1
    worksheet1.write(5, 16, 'Total ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    worksheet2.write(5, 17, 'Total ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    worksheet3.write(5, 17, 'Total ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    worksheet4.write(2, 14, 'YTM ' + str(current_year)[-2:] + ' - ' + str(next_year)[-2:], style3)
    worksheet5.write(2, 14, 'YTM ' + str(current_year)[-2:] + ' - ' + str(next_year)[-2:], style3)
    worksheet5.col(14).width = 3000
    for list5 in range(1, 6):
        worksheet1.write(5, 16 + list5, 'Total Cons ' + str(current_year - list5) + ' - ' + str(next_year - list5)[-2:], style3)
        worksheet2.write(5, 17 + list5, 'Total Cons ' + str(current_year - list5) + ' - ' + str(next_year - list5)[-2:], style3)
        worksheet3.write(5, 17 + list5, 'Total Cons ' + str(current_year - list5) + ' - ' + str(next_year - list5)[-2:], style3)
        worksheet4.write(2, 14 + list5, str(current_year - list5) + ' - ' + str(next_year - list5)[-2:], style3)
        worksheet5.write(2, 14 + list5, str(current_year - list5) + ' - ' + str(next_year - list5)[-2:], style3)
        worksheet5.col(14 + list5).width = 3000
    
    col3 = 25
    for list8 in month_emission:
        worksheet1.write(5, col3, 'Emission - ' + list8, style3)
        worksheet2.write(5, col3 + 1, 'Emission - ' + list8, style3)
        worksheet3.write(5, col3 + 1, 'Emission - ' + list8, style3)
        col3 += 1
    worksheet1.write(5, 37, 'Total Emission ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    worksheet2.write(5, 38, 'Total Emission ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    worksheet3.write(5, 38, 'Total Emission ' + str(current_year) + ' - ' + str(next_year)[-2:], style3)
    for list9 in range(1, 6):
        worksheet1.write(5, 37 + list9, 'Total Emission ' + str(current_year - list9) + ' - ' + str(next_year - list9)[-2:], style3)
        worksheet2.write(5, 38 + list9, 'Total Emission ' + str(current_year - list9) + ' - ' + str(next_year - list9)[-2:], style3)
        worksheet3.write(5, 38 + list9, 'Total Emission ' + str(current_year - list9) + ' - ' + str(next_year - list9)[-2:], style3)
    
    row4 = 6
    array4 = ['CO2', 'CO2', 'CO2', 'CO2', 'CO2', 'HFC', 'HFC', 'CO2', 'CO2', 'CO2', 'CO2']
    for list7 in array4:
        worksheet1.write(row4 , 22, list7, style4)
        row4 += 1
        
    row5 = 6
    array6 = [2.6, 2.32, 2.19, 0.614, 0.056, 1810, 1300, 1, 0.59, -2, -0.59]
    for list8 in array6:
        worksheet1.write(row5, 23, list8, style4)
        row5 += 1
        
    row6 = 6
    array7 = ['Kg CO2 / L', 'Kg CO2 / L', 'Kg CO2 / L', 'Kg CO2 / kg', 'Kg CO2 / kg', 'Kg CO2 equ / kG', 'Kg CO2 equ / kG', 'Kg CO2 / kG', 'Kg CO2 equ / kL', 'Kg CO2 / Tree', 'Kg CO2 eq / kL']
    for list8 in array7:
        worksheet1.write(row6, 24, list8, style4)
        row6 += 1

    #Diesel
    yearlycons_diesel = []
    yearlyemis_diesel = []
    for month1 in range(1, 13):
        if month1 > 3:
            try:
                costdg = Cost_DG.objects.filter(dg_date__year = current_year, dg_date__month = month1).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                consumption_diesel = (round(costdg['dg_lit_cons__sum']))
                yearlycons_diesel.append(consumption_diesel)
                emission_diesel = round(consumption_diesel * 2.6)
                yearlyemis_diesel.append(emission_diesel)
                worksheet1.write(6, month1, consumption_diesel, style4)
                worksheet1.write(6, month1 + 21, emission_diesel, style4)
            except:
                worksheet1.write(6, month1, ('-'), style4)
                worksheet1.write(6, month1 + 21, ('-'), style4)
        else:
            try:
                costdg = Cost_DG.objects.filter(dg_date__year = next_year, dg_date__month = month1).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                consumption_diesel = (round(costdg['dg_lit_cons__sum']))
                yearlycons_diesel.append(consumption_diesel)
                emission_diesel = round(consumption_diesel * 2.6)
                yearlyemis_diesel.append(emission_diesel)
                worksheet1.write(6, month1 + 12, consumption_diesel, style4)
                worksheet1.write(6, month1 + 33, emission_diesel, style4)
            except:
                worksheet1.write(6, month1 + 12, ('-'), style4)
                worksheet1.write(6, month1 + 33, ('-'), style4)
    worksheet1.write(6, 16, (sum(yearlycons_diesel)), style4)
    worksheet1.write(6, 37, sum(yearlyemis_diesel), style4)
    for month1 in range(1, 6):
        start_date = datetime(current_year - month1, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - month1, end_month, 31).strftime("%Y-%m-%d")
        costdg = Cost_DG.objects.filter(dg_date__range = (start_date, end_date)).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
        try:
            worksheet1.write(6, 16 + month1, round(costdg['dg_lit_cons__sum']), style4)
            worksheet1.write(6, 37 + month1, round(round(costdg['dg_lit_cons__sum']) * 2.6), style4)
        except:
            worksheet1.write(6, 16 + month1, 0, style4)
            worksheet1.write(6, 37 + month1, 0, style4)
            
        
        
    #Petrol
    yearlycons_petrol = []
    yearlyemis_petrol = []
    for month2 in range(1, 13):
        if month2 > 3:
            try:
                costpt = Cost_Petrol.objects.filter(pt_date__year = current_year, pt_date__month = month2).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                consumption_petrol = (round(costpt['pt_lit_cons__sum']))
                yearlycons_petrol.append(consumption_petrol)
                emission_petrol = round(consumption_petrol * 2.32)
                yearlyemis_petrol.append(emission_petrol)
                worksheet1.write(7, month2, consumption_petrol, style4)
                worksheet1.write(7, month2 + 21, emission_petrol, style4)
            except:
                worksheet1.write(7, month2, ('-'), style4)
                worksheet1.write(7, month2 + 21, ('-'), style4)
        else:
            try:
                costpt = Cost_Petrol.objects.filter(pt_date__year = next_year, pt_date__month = month2).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                consumption_petrol = (round(costpt['pt_lit_cons__sum']))
                yearlycons_petrol.append(consumption_petrol)
                emission_petrol = round(consumption_petrol * 2.32)
                yearlyemis_petrol.append(emission_petrol)
                worksheet1.write(7, month2 + 12, consumption_petrol, style4)
                worksheet1.write(7, month2 + 33, emission_petrol, style4)
            except:
                worksheet1.write(7, month2 + 12, ('-'), style4)
                worksheet1.write(7, month2 + 33, ('-'), style4)
    worksheet1.write(7, 16, (sum(yearlycons_petrol)), style4)
    worksheet1.write(7, 37, sum(yearlyemis_petrol), style4)
    for month2 in range(1, 6):
        start_date = datetime(current_year - month2, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - month2, end_month, 31).strftime("%Y-%m-%d")
        costpt = Cost_Petrol.objects.filter(pt_date__range = (start_date, end_date)).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
        try:
            worksheet1.write(7, 16 + month2, round(costpt['pt_lit_cons__sum']), style4)
            worksheet1.write(7, 37 + month2, round(round(costpt['pt_lit_cons__sum']) * 2.32), style4)
        except:
            worksheet1.write(7, 16 + month2, 0, style4)
            worksheet1.write(7, 37 + month2, 0, style4)
            
        
    #LPG
    yearlycons_lpg = []
    yearlyemis_lpg = []
    for month3 in range(1, 13):
        if month3 > 3:
            try:
                costlpg = Cost_LPG.objects.filter(LPG_date__year = current_year, LPG_date__month = month3).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                consumption_lpg = (round(costlpg['LPG_kg_cons__sum']))
                yearlycons_lpg.append(consumption_lpg)
                emission_lpg = round(consumption_lpg * 2.19)
                yearlyemis_lpg.append(emission_lpg)
                worksheet1.write(8, month3, consumption_lpg, style4)
                worksheet1.write(8, month3 + 21, emission_lpg, style4)
            except:
                worksheet1.write(8, month3, ('-'), style4)
                worksheet1.write(8, month3 + 21, ('-'), style4)
        else:
            try:
                costlpg = Cost_LPG.objects.filter(LPG_date__year = next_year, LPG_date__month = month3).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                consumption_lpg = (round(costlpg['LPG_kg_cons__sum']))
                yearlycons_lpg.append(consumption_lpg)
                emission_lpg = round(consumption_lpg * 2.19)
                yearlyemis_lpg.append(emission_lpg)
                worksheet1.write(8, month3 + 12, consumption_lpg, style4)
                worksheet1.write(8, month3 + 33, emission_lpg, style4)
            except:
                worksheet1.write(8, month3 + 12, ('-'), style4)
                worksheet1.write(8, month3 + 33, ('-'), style4)
    worksheet1.write(8, 16, (sum(yearlycons_lpg)), style4)
    worksheet1.write(8, 37, sum(yearlyemis_lpg), style4)
    for month3 in range(1, 6):
        start_date = datetime(current_year - month3, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - month3, end_month, 31).strftime("%Y-%m-%d")
        costlpg = Cost_LPG.objects.filter(LPG_date__range = (start_date, end_date)).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
        try:
            worksheet1.write(8, 16 + month3, round(costlpg['LPG_kg_cons__sum']), style4)
            worksheet1.write(8, 37 + month3, round(round(costlpg['LPG_kg_cons__sum']) * 2.19), style4)
        except:
            worksheet1.write(8, 16 + month3, 0, style4)
            worksheet1.write(8, 37 + month3, 0, style4)
            
    #CNG    
    yearlycons_cng = []
    yearlyemis_cng = []
    for month4 in range(1, 13):
        if month4 > 3:
            try:
                costcng = Cost_CNG.objects.filter(CNG_date__year = current_year, CNG_date__month = month4).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                consumption_cng = (round(costcng['CNG_kg_cons__sum']))
                yearlycons_cng.append(consumption_cng)
                emission_cng = round(consumption_cng * 0.614)
                yearlyemis_cng.append(emission_cng)
                worksheet1.write(9, month4, consumption_cng, style4)
                worksheet1.write(9, month4 + 21, emission_cng, style4)
            except:
                worksheet1.write(9, month4, ('-'), style4)
                worksheet1.write(9, month4 + 21, ('-'), style4)
        else:
            try:
                costcng = Cost_CNG.objects.filter(CNG_date__year = next_year, CNG_date__month = month4).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                consumption_cng = (round(costcng['CNG_kg_cons__sum']))
                yearlycons_cng.append(consumption_cng)
                emission_cng = round(consumption_cng * 0.614)
                yearlyemis_cng.append(emission_cng)
                worksheet1.write(9, month4 + 12, consumption_cng, style4)
                worksheet1.write(9, month4 + 33, emission_cng, style4)
            except:
                worksheet1.write(9, month4 + 12, ('-'), style4)
                worksheet1.write(9, month4 + 33, ('-'), style4)
    worksheet1.write(9, 16, (sum(yearlycons_cng)), style4)
    worksheet1.write(9, 37, sum(yearlyemis_cng), style4)
    for month4 in range(1, 6):
        start_date = datetime(current_year - month4, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - month4, end_month, 31).strftime("%Y-%m-%d")
        costcng = Cost_CNG.objects.filter(CNG_date__range = (start_date, end_date)).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
        try:
            worksheet1.write(9, 16 + month4, round(costcng['CNG_kg_cons__sum']), style4)
            worksheet1.write(9, 37 + month4, round(round(costcng['CNG_kg_cons__sum']) * 0.614), style4)
        except:
            worksheet1.write(9, 16 + month4, 0, style4)
            worksheet1.write(9, 37 + month4, 0, style4)
        
    #PNG
    yearlycons_png = []
    yearlyemis_png = []
    for month5 in range(1, 13):
        if month5 > 3:
            try:
                costpng = Cost_PNG.objects.filter(PNG_date__year = current_year, PNG_date__month = month5).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
                consumption_png = (round(costpng['PNG_kg_cons__sum']))
                yearlycons_png.append(consumption_png)
                emission_png = round(consumption_png * 0.056)
                yearlyemis_png.append(emission_png)
                worksheet1.write(10, month5, consumption_png, style4)
                worksheet1.write(10, month5 + 21, emission_png, style4)
            except:
                worksheet1.write(10, month5, ('-'), style4)
                worksheet1.write(10, month5 + 21, ('-'), style4)
        else:
            try:
                costpng = Cost_PNG.objects.filter(PNG_date__year = next_year, PNG_date__month = month5).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
                consumption_png = (round(costpng['PNG_kg_cons__sum']))
                yearlycons_png.append(consumption_png)
                emission_png = round(consumption_png * 0.056)
                yearlyemis_png.append(emission_png)
                worksheet1.write(10, month5 + 12, consumption_png, style4)
                worksheet1.write(10, month5 + 33, emission_png, style4)
            except:
                worksheet1.write(10, month5 + 12, ('-'), style4)
                worksheet1.write(10, month5 + 33, ('-'), style4)
    worksheet1.write(10, 16, (sum(yearlycons_png)), style4)
    worksheet1.write(10, 37, sum(yearlyemis_png), style4)
    for month5 in range(1, 6):
        start_date = datetime(current_year - month5, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - month5, end_month, 31).strftime("%Y-%m-%d")
        costpng = Cost_PNG.objects.filter(PNG_date__range = (start_date, end_date)).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
        try:
            worksheet1.write(10, 16 + month5, round(costpng['PNG_kg_cons__sum']), style4)
            worksheet1.write(10, 37 + month5, round(round(costpng['PNG_kg_cons__sum']) * 0.056), style4)
        except:
            worksheet1.write(10, 16 + month5, 0, style4)
            worksheet1.write(10, 37 + month5, 0, style4) 
        
    for num1 in range(11, 14):
        for num2 in range(4, 22):
            worksheet1.write(num1, num2, '-', style4)
            
    for num1 in range(11, 14):
        for num2 in range(25, 43):
            worksheet1.write(num1, num2, '-', style4)
    for num in range(4, 22):
        worksheet1.write(15, num, '-', style4)
    for num in range(25, 43):
        worksheet1.write(15, num, '-', style4)
    
    ##################################################################  SHEET 2 ##############################################################################
    
    worksheet2.write_merge(0, 0, 0, 5, 'Environment Sustainability Data Responsibility - Scope 2', style1)
    worksheet2.row(0).height_mismatch = True
    worksheet2.row(0).height = 500
    worksheet2.write(1, 0, 'Name of Champion', style5)
    worksheet2.row(1).height_mismatch = True
    worksheet2.row(1).height = 500
    worksheet2.col(0).width = 6000
    worksheet2.write(2, 0, 'Department & Position', style5)
    worksheet2.row(2).height_mismatch = True
    worksheet2.row(2).height = 500
    worksheet2.write_merge(1, 1, 1, 5, '', style6)
    worksheet2.write_merge(2, 2, 1, 5, '', style6)
    worksheet2.write_merge(3, 3, 0, 43, 'Scope 2 Emissions : Purchased electricity, stream, heat & cooling', style2)
    worksheet2.row(3).height_mismatch = True
    worksheet2.row(3).height = 530
    worksheet2.write_merge(4, 4, 0, 4, 'SCOPE 2 Emission', style3)
    worksheet2.row(4).height_mismatch = True
    worksheet2.row(4).height = 600
    worksheet2.row(5).height_mismatch = True
    worksheet2.row(5).height = 650
    worksheet2.row(13).height_mismatch = True
    worksheet2.row(13).height = 500
    worksheet2.write_merge(4, 4, 5, 17, 'Consumption, Used, Disposed, etc', style3)
    worksheet2.write_merge(4, 4, 18, 22, 'Consumption Past Years', style3)
    worksheet2.write_merge(4, 4, 26, 38, 'Co2 eq calculation', style3)
    worksheet2.write_merge(4, 4, 39, 43, 'Co2 equ calculation Past Years', style3)
    worksheet2.write_merge(6, 11, 0, 0, 'I', style4)
    worksheet2.write(12, 0,  'II', style4)
    worksheet2.write_merge(13, 13, 0, 4, 'Total Co2 equ - Scope 2', style3)
    
    col4 = 0
    array8 = ['Chapter', 'Source', 'Type', 'Purpose', 'Units']
    for list12 in array8:
        worksheet2.write(5, col4, list12, style3)
        col4 += 1
        
    row7 = 6
    array9 = ['Purchased electricity from Electricity Authorities (non renewable)', 'Purchased electricity from Third Party (Nuclear - Non-Renewable)', 'Purchased electricity from Third Party (CNG - Non-Renewable)', 'Purchased electricity from Third Party (Biogas - Renewable)', 'Purchased electricity from Second Party (Solar - Renewable)', 'Purchased electricity from Third Party (Wind - Renewable)', 'Water Consumption from Out-source']
    for list13 in array9:
        worksheet2.write(row7, 1, list13, style10)
        worksheet2.row(row7).height_mismatch = True
        worksheet2.row(row7).height = 900
        row7 += 1
    worksheet2.col(1).width = 8500
    
    row8 = 6
    array10 = ['Electricity', 'Electricity', 'Electricity', 'Electricity', 'Electricity', 'Electricity', 'Water']
    for list13 in array10:
        worksheet2.write(row8, 2, list13, style4)
        row8 += 1
    worksheet2.col(2).width = 4000
        
    row9 = 6
    array11 = ['Production', 'Production', 'Production', 'Production', 'Production', 'Production', 'Process / Domestic']
    for list14 in array11:
        worksheet2.write(row9, 3, list14, style4)
        row9 += 1
    worksheet2.col(3).width = 4000
        
    row10 = 6
    array12 = ['kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kL']
    for list15 in array12:
        worksheet2.write(row10, 4, list15, style4)
        row10 += 1
    worksheet2.col(4).width = 2500
        
    row11 = 6
    array13 = ['CO2', 'CO2', 'CO2', 'Methane', 'CO2', 'CO2', 'CO2 equ']
    for list16 in array13:
        worksheet2.write(row11, 23, list16, style4)
        row11 += 1
    worksheet2.col(23).width = 4000
        
    row12 = 6
    array14 = [0.7132, 0.7132, 0.214, 1.13, 0.041, 0.018, 0.59]
    for list17 in array14:
        worksheet2.write(row12, 24, list17, style4)
        row12 += 1
    worksheet2.col(24).width = 4000
        
    row13 = 6
    array15 = ['Kg CO2 / kWh', 'Kg CO2 / kWh', 'Kg CO2 / kWh', 'Kg CO2 / kWh', 'Kg CO2 / kWh', 'Kg CO2 / kWh', 'Kg CO2 equ / kL']
    for list18 in array15:
        worksheet2.write(row13, 25, list18, style4)
        row13 += 1
    worksheet2.col(25).width = 4000
    
    sourcename = AddSource.objects.values('assourcename')
    for source in sourcename:
        if source['assourcename'] == 'Transformer1':
            transenergy_thisyear = []
            windenergy_thisyear = []
            for month in range(1, 13):
                if month > 3:
                    transformer = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        trans_energy = round(transformer['mtenergycons__sum'])
                    except:
                        trans_energy = 0
                    wind = Cost_Wind.objects.filter(Wind_month = calendar.month_name[month]).values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                    try:
                        wind_energy = wind['Wind_percentage__sum']
                    except:
                        wind_energy = 0
                    try:
                        total_energy = round(trans_energy * wind_energy / 100)
                    except:
                        total_energy = 0
                    worksheet2.write(11, month + 1, total_energy, style4)
                    worksheet2.write(11, month + 22, round(total_energy * 0.018), style4)
                    actual_trans = trans_energy - total_energy
                    windenergy_thisyear.append(total_energy)
                    transenergy_thisyear.append(actual_trans)
                    worksheet2.write(6, month + 1, actual_trans, style4)
                    worksheet2.write(6, month + 22, round(actual_trans * 0.7132), style4)
                else:
                    transformer = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        trans_energy = round(transformer['mtenergycons__sum'])
                    except:
                        trans_energy = 0
                    wind = Cost_Wind.objects.filter(Wind_month = calendar.month_name[month]).values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                    try:
                        wind_energy = wind['Wind_percentage__sum']
                    except:
                        wind_energy = 0
                    try:
                        total_energy = round(trans_energy * wind_energy / 100)
                    except:
                        total_energy = 0
                    worksheet2.write(11, month + 13, total_energy, style4)
                    worksheet2.write(11, month + 34, round(total_energy * 0.018), style4)
                    windenergy_thisyear.append(total_energy)
                    actual_trans = trans_energy - total_energy
                    transenergy_thisyear.append(actual_trans)
                    worksheet2.write(6, month + 13, actual_trans, style4)
                    worksheet2.write(6, month + 34, round(actual_trans * 0.7132), style4)
            worksheet2.write(6, 17, sum(windenergy_thisyear), style4)
            worksheet2.write(6, 38, round(sum(windenergy_thisyear) * 0.7132), style4)
            worksheet2.write(11, 17, sum(transenergy_thisyear), style4)
            worksheet2.write(11, 38, round(sum(transenergy_thisyear) * 0.018), style4)
                    
            for year in range(1,6):
                total_energy_array = []
                actual_trans_array = []
                for month in range(1, 13):
                    if month > 3:
                        transformer_energy = Masterdatatable.objects.filter(mtdate__year = current_year - year, mtdate__month = month, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            trans_energy = round(transformer_energy['mtenergycons__sum'])
                        except:
                            trans_energy = 0
                        wind_energy = Cost_Wind.objects.filter(Wind_month = calendar.month_name[month]).values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                        try:
                            wind_energy = wind_energy['Wind_percentage__sum']
                        except:
                            wind_energy = 0
                        try:
                            total_energy = round(trans_energy * wind_energy / 100)
                        except:
                            total_energy = 0
                        total_energy_array.append(total_energy)
                        actual_trans = trans_energy - total_energy
                        actual_trans_array.append(actual_trans)
                    else:
                        transformer_energy = Masterdatatable.objects.filter(mtdate__year = next_year - year, mtdate__month = month, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                        try:
                            trans_energy = round(transformer_energy['mtenergycons__sum'])
                        except:
                            trans_energy = 0
                        wind_energy = Cost_Wind.objects.filter(Wind_month = calendar.month_name[month]).values('Wind_percentage').aggregate(Sum('Wind_percentage'))
                        try:
                            wind_energy = wind_energy['Wind_percentage__sum']
                        except:
                            wind_energy = 0
                        try:
                            total_energy = round(trans_energy * wind_energy / 100)
                        except:
                            total_energy = 0
                        total_energy_array.append(total_energy)
                        actual_trans = trans_energy - total_energy
                        actual_trans_array.append(actual_trans)
                worksheet2.write(6, year + 17, sum(actual_trans_array), style4)
                worksheet2.write(6, year + 38, round(sum(actual_trans_array) * 0.7132), style4)
                worksheet2.write(11, year + 17, sum(total_energy_array), style4)
                worksheet2.write(11, year + 38, round(sum(total_energy_array) * 0.018), style4)
                    
        solar_yearly_cons = []
        solar_yearly_emis = []
        if source['assourcename'] == 'Solar Energy':
            for month1 in range(1, 13):
                if month1 > 3:
                    try:
                        solar = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month1, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                        worksheet2.write(10, 1 + month1, round(solar['mtenergycons__sum']), style4)
                        solar_yearly_cons.append(round(solar['mtenergycons__sum']))
                        solar_emission = round(solar['mtenergycons__sum']) * 0.041
                        worksheet2.write(10, 22 + month1, round(solar_emission), style4)
                        solar_yearly_emis.append(round(solar_emission))
                    except:
                        worksheet2.write(10, 1 + month1, '-', style4)
                        worksheet2.write(10, 22 + month1, '-', style4)
                else:
                    try:
                        solar = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month1, mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                        worksheet2.write(10, 13 + month1, round(solar['mtenergycons__sum']), style4)
                        solar_yearly_cons.append(round(solar['mtenergycons__sum']))
                        solar_emission = round(solar['mtenergycons__sum']) * 0.041
                        worksheet2.write(10, 34 + month1, round(solar_emission), style4)
                        solar_yearly_emis.append(round(solar_emission))
                    except:
                        worksheet2.write(10, 13 + month1, '-', style4)
                        worksheet2.write(10, 34 + month1, '-', style4)
            worksheet2.write(10, 17, sum(solar_yearly_cons), style4)
            worksheet2.write(10, 38, sum(solar_yearly_emis), style4)
            for year in range(1, 6):
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                solar_source = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = source['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    worksheet2.write(10, 17 + year, round(solar_source['mtenergycons__sum']), style4)
                    worksheet2.write(10, 38 + year, round(round(solar_source['mtenergycons__sum']) * 0.041), style4)
                except:
                    worksheet2.write(10, 17 + year, '-', style4)
                    worksheet2.write(10, 38 + year, '-', style4)
                    
    for num51 in range(7, 10):
        for num52 in range(5, 23):
            worksheet2.write(num51, num52, '-', style4)
            
    for num53 in range(7, 10):
        for num54 in range(26, 44):
            worksheet2.write(num53, num54, '-', style4)
            
    ######################################################################## SHEET3 ######################################################################################################
    
    worksheet3.write_merge(0, 0, 0, 5, 'Environment Sustainability Data Responsibility - Scope 3', style1)
    worksheet3.row(0).height_mismatch = True
    worksheet3.row(0).height = 500
    worksheet3.write(1, 0, 'Name of Champion', style5)
    worksheet3.row(1).height_mismatch = True
    worksheet3.row(1).height = 500
    worksheet3.col(0).width = 6000
    worksheet3.write(2, 0, 'Department & Position', style5)
    worksheet3.row(2).height_mismatch = True
    worksheet3.row(2).height = 500
    worksheet3.write_merge(1, 1, 1, 5, '', style6)
    worksheet3.write_merge(2, 2, 1, 5, '', style6)
    worksheet3.write_merge(3, 3, 0, 43, 'Scope 3 Emissions : Transportation and distribution (up and downstream), Purchased goods and services, business travel, employee commuting, investments, leased assets and Vendors', style2)
    worksheet3.row(3).height_mismatch = True
    worksheet3.row(3).height = 530
    worksheet3.write_merge(4, 4, 0, 4, 'SCOPE 3 Emission', style3)
    worksheet3.row(4).height_mismatch = True
    worksheet3.row(4).height = 600
    worksheet3.row(5).height_mismatch = True
    worksheet3.row(5).height = 600
    worksheet3.write_merge(4, 4, 5, 17, 'Consumption, Used, Disposed, etc', style3)
    worksheet3.write_merge(4, 4, 18, 22, 'Consumption Past Years', style3)
    worksheet3.write_merge(4, 4, 26, 38, 'Co2 eq calculation', style3)
    worksheet3.write_merge(4, 4, 39, 43, 'Co2 equ calculation Past Years', style3)
    worksheet3.write_merge(6, 9, 0, 0, 'I', style4)
    worksheet3.write_merge(6, 9, 1, 1, 'Raw material Consumption', style4)
    worksheet3.write_merge(10, 17, 0, 0, 'II', style4)
    worksheet3.write_merge(10, 17, 1, 1, 'Consumables', style4)
    worksheet3.write_merge(18, 26, 0, 0, 'III', style4)
    worksheet3.write_merge(18, 26, 1, 1, 'Non-Hazardous waste disposal', style4)
    worksheet3.write_merge(27, 34, 0, 0, 'IV', style4)
    worksheet3.write_merge(27, 34, 1, 1, 'Hazardous waste disposal', style4)
    worksheet3.write_merge(35, 37, 0, 0, 'V', style4)
    worksheet3.write_merge(35, 37, 1, 1, 'Employee Commuting (Common Transport)', style4)
    worksheet3.write_merge(38, 40, 0, 0, 'VI', style4)
    worksheet3.write_merge(38, 40, 1, 1, 'Employee Commuting (Company provided Vehicles for employees)', style4)
    worksheet3.write_merge(41, 44, 0, 0, 'VII', style4)
    worksheet3.write_merge(41, 44, 1, 1, 'Employee Commuting (Business Travel)', style4)
    worksheet3.write_merge(45, 47, 0, 0, 'VIII', style4)
    worksheet3.write_merge(45, 47, 1, 1, 'Finished goods (despatch to customer end)', style4)
    
    worksheet3.col(1).width = 7000
    worksheet3.col(2).width = 7500
    worksheet3.col(3).width = 6000
    worksheet3.col(25).width = 4000
    
    col5 = 0
    array16 = ['Chapter', 'Source', 'Fuel Type', 'Description', 'Units']
    for list19 in array16:
        worksheet3.write(5, col5, list19, style3)
        col5 += 1
        
    row14 = 6
    array17 = ['Total Plastic polymer resin (IIM)', 'Ink & Paint, etc. (Paint shop)', 'Thinner & Other solvents (Paint shop)', 'Hydraulic Oil Cons', 'Plastic & Poly covers', 'Metals', 'Metals', 'Metals', 'Paper', 'wood', 'Carton', 'Cloth', 'Rejected Poly Covers & Plastic Packaging', 'Aluminium waste', 'Copper waste', 'Iron & Steel waste', 'Wood', 'Carton', 'Cloth', 'Rejected Plastic / Lumps to scrap vendor', 'Food Waste', 'Paint Sludge', 'Used Hydraulic oil', 'Waste Thinner', 'Waste Paint', 'Oil Soaked Cotton', 'Empty Oil / Paint Containers', 'ETP Sludge', 'Electronic Waste (E -Waste)', 'Employee Transport Vehicles Diesel consumption', 'Employee Transport Vehicles Petrol consumption', 'Employee Transport Vehicles CNG consumption', 'Employee Vehicles Diesel consumption', 'Employee Vehicles Petrol consumption', 'Employee Vehicles CNG consumption', 'Business travel by train ', 'Business travel by Air', 'Travel by Road - Diesel', 'Travel by Road - Petrol', 'Goods Transport Vehicles Diesel consumption (MATE to customer)', 'Goods Vehicles Petrol consumption (MATE to customer)', 'Goods Vehicles CNG consumption (MATE to customer)',]
    for list20 in array17:
        worksheet3.write(row14, 2, list20, style4)
        row14 += 1
        
    row15 = 6
    array18 = ['Injection moulding', 'painting', 'painting', 'Hydraulic Oil', 'Raw material & Product packing', 'Aluminium', 'Copper', 'Iron & Steels', 'Raw material & Product packing', 'Raw material & Product packing', 'Raw material & Product packing', 'Raw material & Product packing', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Waste for disposal', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Total Distance', 'Total Air Miles', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport', 'Fuel used for transport']
    for list21 in array18:
        worksheet3.write(row15, 3, list21, style4)
        row15 += 1
        
    row16 = 6
    array19 = ['Kg', 'Litre', 'Litre', 'Litre', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Kg', 'Litre', 'Litre', 'Litre', 'Kg', 'Kg', 'Kg', 'Kg', 'Litre', 'Litre', 'Kg', 'Litre', 'Litre', 'Kg', 'KM', 'Air Mile', 'Litre', 'Litre', 'Litre', 'Litre', 'Kg']
    for list22 in array19:
        worksheet3.write(row16, 4, list22, style4)
        row16 += 1
        
    row17 = 6
    for i in range(1, 43):
        if i == 21:
            worksheet3.write(26, 23, 'COH4', style4)
        else:
            worksheet3.write(row17, 23, 'CO2', style4)
        row17 += 1
    
    row18 = 6
    array20 = [2.2, 3, 3, 3, 2.7, 0.42, 0.181, 1.4, 2.42, 2.61, 2.42, 3.07, 1.91, 0.42, 0.181, 1.41, 2.61, 2.42, 3.07, '', 9.2, 3, 1.07, 3, '', 1.07, 1.77, 3, 1.44025, 2.6, 2.32, 1.51, 2.6, 2.32, 1.51, 0.027, 0.289, 2.6, 2.32, 2.6, 2.32, 1.51]
    for list23 in array20:
        worksheet3.write(row18, 24, list23, style4)
        row18 += 1
        
    row19 = 6
    array21 = ['Kg CO2/kG', 'Kg CO2/L', 'Kg CO2/L', 'Kg CO2/L', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2 equ/kG', 'Kg CO2/kG', 'Kg CO2/L', 'Kg CO2/L', '', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', 'Kg CO2/kG', ' Kg CO2/KMs', ' Kg CO2/Air Mi', ' Kg CO2/lit', ' Kg CO2/lit', ' Kg CO2/kG', ' Kg CO2/kG', ' Kg CO2/kG']
    for list24 in array21:
        worksheet3.write(row19, 25, list24, style4)
        row19 += 1
        
    for num9 in range(6, 48):
        for num10 in range(5, 23):
            worksheet3.write(num9, num10, '-', style4)
            worksheet3.col(num10).width = 4000
            
    for num11 in range(6, 48):
        for num12 in range(26, 44):
            worksheet3.write(num11, num12, '-', style4)
            worksheet3.col(num12).width = 4000
            
    for num in range(6, 48):
        worksheet3.row(num).height_mismatch = True
        worksheet3.row(num).height = 1000
        
    ################################################################################## sheet 4 ##################################################################################
    
    worksheet4.write_merge(0, 1, 0, 0, 'Water Data', style7)
    worksheet4.col(0).width = 8700
    worksheet4.row(0).height_mismatch = True
    worksheet4.row(0).height = 500
    worksheet4.write_merge(3, 3, 0, 19, 'Total Water Consumption', style2)
    worksheet4.write_merge(9, 9, 0, 19, 'Total Treated Water', style2)
    worksheet4.write_merge(16, 16, 0, 19, 'Rain Water Harvesting', style2)
    worksheet4.write(7, 0, 'Total Fresh Water Consumption (A)', style9)
    worksheet4.write(7, 1, 'KL', style5)
    worksheet4.write(14, 0, 'Total Water Reused (B)', style9)
    worksheet4.write(14, 1, 'KL', style5)
    worksheet4.write(24, 0, 'Total Rain Water Harvesting Done (C)', style9)
    worksheet4.write(24, 1, 'KL', style5)
    worksheet4.write(2, 0, '', style3)
    worksheet4.write(2, 1, 'Unit', style3)
    worksheet4.row(2).height_mismatch = True
    worksheet4.row(2).height = 550
    worksheet4.set_panes_frozen(True)
    worksheet4.set_vert_split_pos(2)
    worksheet4.set_horz_split_pos(3)
    
    month_average = cost_water.objects.values('wt_date').distinct().count()
    
    freshwater_array = ['Fresh Water - Drinking', 'Fresh Water - Outsource', 'Fresh Water - Borewell']
    row = 4
    for data in freshwater_array:
        worksheet4.write(row, 0, data, style8)
        worksheet4.write(row, 1, 'KL', style4)
        row += 1
        
    treatedwater_array = ['Treated Water - Disposed', 'Treated Water - ETP', 'Treated Water - STP', 'Total Treated Water']
    row = 10
    for data in treatedwater_array:
        worksheet4.write(row, 0, data, style8)
        worksheet4.write(row, 1, 'KL', style4)
        row += 1
        
    rwh_array = ['Rain Water - Harvesting Pits', 'Rain Water - Pit Capacity', 'Installed Rain Water Harvesting Capacity', 'Rain Water - Average Rainfall', 'Rain Water - Roof Area', 'Rain Water - Non-Roof Area', 'Total Rain Water Harvesting Potential']
    rwh_unit = ['Nos', 'KL', 'KL', 'in mm', 'Sq. mtr.', 'Sq. mtr', 'KL']
    row = 17
    for data in rwh_array:
        worksheet4.write(row, 0, data, style8)
        row += 1
    row = 17
    for data in rwh_unit:
        worksheet4.write(row, 1, data, style4)
        row += 1

    freshwater = cost_water.objects.values('wt_source').distinct().order_by('wt_source')
    for data in freshwater:
        if data['wt_source'] == 'Fresh Water':
            for month in range(1, 13):
                if month > 3:
                    drinking = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Drinking').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        drinking_water = round(drinking['wt_consume__sum'])
                    except:
                        drinking_water = 0
                    worksheet4.write(4, month - 2, drinking_water, style4)
                    
                    outsource = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Outsource').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        outsource_water = round(outsource['wt_consume__sum'])
                    except:
                        outsource_water = 0
                    worksheet4.write(5, month - 2, outsource_water, style4)
                    worksheet2.write(12, month + 1, outsource_water, style4)
                    worksheet2.write(12, month + 22, round((outsource_water) * 0.59), style4)
                    
                    borewell = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Borewell').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        borewell_water = round(borewell['wt_consume__sum'])
                    except:
                        borewell_water = 0
                    worksheet4.write(6, month - 2, borewell_water, style4)
                    worksheet4.write(7, month - 2, outsource_water + borewell_water, style4)
                    worksheet1.write(14, month, outsource_water + borewell_water, style4)
                    worksheet1.write(14, month + 21, round((outsource_water + borewell_water) * 0.59), style4)
                else:
                    drinking = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Drinking').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        drinking_water = round(drinking['wt_consume__sum'])
                    except:
                        drinking_water = 0
                        worksheet4.write(4, month + 10, drinking_water, style4)
                    
                    outsource = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Outsource').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        outsource_water = round(outsource['wt_consume__sum'])
                    except:
                        outsource_water = 0
                        worksheet4.write(5, month + 10, outsource_water, style4)
                    worksheet2.write(12, month + 13, outsource_water, style4)
                    worksheet2.write(12, month + 34, round((outsource_water) * 0.59), style4)
                    
                    borewell = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Borewell').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        borewell_water = round(borewell['wt_consume__sum'])
                    except:
                        borewell_water = 0
                    worksheet4.write(6, month + 10, borewell_water, style4)
                    worksheet4.write(7, month + 10, outsource_water + borewell_water, style4)
                    worksheet1.write(14, month + 12, outsource_water + borewell_water, style4)
                    worksheet1.write(14, month + 33, round((outsource_water + borewell_water) * 0.59), style4)
                    
            for year in range(0, 6):
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                drinking = cost_water.objects.filter(wt_date__range = (start_date, end_date), wt_source = data['wt_source'], wt_type = 'Drinking').values('wt_consume').aggregate(Sum('wt_consume'))
                try:
                    drinking_water = round(drinking['wt_consume__sum'])
                except:
                    drinking_water = 0
                worksheet4.write(4, year + 14, drinking_water, style4)
                outsource = cost_water.objects.filter(wt_date__range = (start_date, end_date), wt_source = data['wt_source'], wt_type = 'Outsource').values('wt_consume').aggregate(Sum('wt_consume'))
                try:
                    outsource_water = round(outsource['wt_consume__sum'])
                except:
                    outsource_water = 0
                worksheet4.write(5, year + 14, outsource_water, style4)
                worksheet2.write(12, year + 17, outsource_water, style4)
                worksheet2.write(12, year + 38, round(outsource_water * 0.59), style4)
                borewell = cost_water.objects.filter(wt_date__range = (start_date, end_date), wt_source = data['wt_source'], wt_type = 'Borewell').values('wt_consume').aggregate(Sum('wt_consume'))
                try:
                    borewell_water = round(borewell['wt_consume__sum'])
                except:
                    borewell_water = 0
                worksheet4.write(6, year + 14, borewell_water, style4)
                worksheet4.write(7, year + 14, borewell_water + outsource_water, style4)
                worksheet1.write(14, year + 16, borewell_water + outsource_water, style4)
                worksheet1.write(14, year + 37, round((borewell_water + outsource_water) * 0.59), style4)
                
        if data['wt_source'] == 'Treated Water':
            for month in range(1, 13):
                if month > 3:
                    disposed = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Disposed').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        disposed_water = round(disposed['wt_consume__sum'])
                    except:
                        disposed_water = 0
                    worksheet4.write(10, month - 2, disposed_water, style4)
                    etp = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'ETP').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        etp_water = round(etp['wt_consume__sum'])
                    except:
                        etp_water = 0
                    worksheet4.write(11, month - 2, etp_water, style4)
                    stp = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'STP').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        stp_water = round(stp['wt_consume__sum'])
                    except:
                        stp_water = 0
                    worksheet4.write(12, month - 2, stp_water, style4)
                    worksheet4.write(13, month - 2, stp_water + etp_water, style4)
                    worksheet4.write(14, month - 2, (stp_water + etp_water) - disposed_water, style4)
                else:
                    disposed = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Disposed').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        disposed_water = round(disposed['wt_consume__sum'])
                    except:
                        disposed_water = 0
                    worksheet4.write(10, month + 10, disposed_water, style4)
                    etp = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'ETP').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        etp_water = round(etp['wt_consume__sum'])
                    except:
                        etp_water = 0
                    worksheet4.write(11, month + 10, etp_water, style4)
                    stp = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'STP').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        stp_water = round(stp['wt_consume__sum'])
                    except:
                        stp_water = 0
                    worksheet4.write(12, month + 10, stp_water, style4)
                    worksheet4.write(13, month + 10, stp_water + etp_water, style4)
                    worksheet4.write(14, month + 10, (stp_water + etp_water) - disposed_water, style4)
                    
            for year in range(0, 6):
                disposed_array = []
                etp_array = []
                stp_array = []
                ttwater_array = []
                twreused_array = []
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                for month in range(1, 13):
                    if month > 3:
                        disposed = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Disposed').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            disposed_water = round(disposed['wt_consume__sum'])
                            disposed_array.append(round(disposed['wt_consume__sum']))
                        except:
                            disposed_water = 0
                            disposed_array.append(0)
                        etp = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'ETP').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            etp_water = round(etp['wt_consume__sum'])
                        except:
                            etp_water = 0
                        etp_array.append(etp_water)
                        stp = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'STP').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            stp_water = round(stp['wt_consume__sum'])
                        except:
                            stp_water = 0
                        stp_array.append(stp_water)
                        ttwater_array.append(etp_water + stp_water)
                        twreused_array.append((etp_water + stp_water) - disposed_water)
                    else:
                        disposed = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Disposed').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            disposed_water = round(disposed['wt_consume__sum'])
                            disposed_array.append(round(disposed['wt_consume__sum']))
                        except:
                            disposed_water = 0
                            disposed_array.append(0)
                        etp = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'ETP').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            etp_water = round(etp['wt_consume__sum'])
                        except:
                            etp_water = 0
                        etp_array.append(etp_water)
                        stp = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'STP').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            stp_water = round(stp['wt_consume__sum'])
                        except:
                            stp_water = 0
                        stp_array.append(stp_water)
                        ttwater_array.append(etp_water + stp_water)
                        twreused_array.append((etp_water + stp_water) - disposed_water)
                worksheet4.write(10, year + 14, sum(disposed_array), style4)
                worksheet4.write(11, year + 14, sum(etp_array), style4)
                worksheet4.write(12, year + 14, sum(stp_array), style4)
                worksheet4.write(13, year + 14, sum(ttwater_array), style4)
                worksheet4.write(14, year + 14, sum(twreused_array), style4)
                
        if data['wt_source'] == 'Rain Water':
            for month in range(1, 13):
                if month > 3:
                    harvestingpits = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Harvesting Pits').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_harvesting = round(harvestingpits['wt_consume__sum'])
                    except:
                        rwh_harvesting = 0
                    worksheet4.write(17, month - 2, rwh_harvesting, style4)
                    
                    pitcapacity = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Pit Capacity').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_pits = round(pitcapacity['wt_consume__sum'])
                    except:
                        rwh_pits = 0
                    worksheet4.write(18, month - 2, rwh_pits, style4)
                    
                    installed_capacity = rwh_harvesting * rwh_pits
                    worksheet4.write(19, month - 2, installed_capacity, style4)
                    
                    rainfall = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Average Rainfall').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        average_rainfall = round(rainfall['wt_consume__sum'])
                    except:
                        average_rainfall = 0
                    worksheet4.write(20, month - 2, average_rainfall, style4)
                    
                    roofarea = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_roof = round(roofarea['wt_consume__sum'])
                    except:
                        rwh_roof = 0
                    worksheet4.write(21, month - 2, rwh_roof, style4)
                    
                    nonroofarea = cost_water.objects.filter(wt_date__year = current_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Non-Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_nonroof = round(nonroofarea['wt_consume__sum'])
                    except:
                        rwh_nonroof = 0
                    worksheet4.write(22, month - 2, rwh_nonroof, style4)
                    
                    try:
                        total_rwh_potential = round(((rwh_roof + rwh_nonroof) * average_rainfall * 0.6) / 1000)
                    except:
                        total_rwh_potential = 0
                    worksheet4.write(23, month - 2, total_rwh_potential, style4)
                    
                    if total_rwh_potential > installed_capacity:
                        total_rwh = installed_capacity
                        worksheet4.write(24, month - 2, total_rwh, style4)
                        worksheet1.write(16, month, total_rwh, style4)
                        worksheet1.write(16, month + 21, round(total_rwh * -0.59), style4)
                    elif installed_capacity > total_rwh_potential:
                        total_rwh = total_rwh_potential
                        worksheet4.write(24, month - 2, total_rwh, style4)
                        worksheet1.write(16, month, total_rwh, style4)
                        worksheet1.write(16, month + 21, round(total_rwh * -0.59), style4)
                    else:
                        total_rwh = installed_capacity
                        worksheet4.write(24, month - 2, total_rwh, style4)
                        worksheet1.write(16, month, total_rwh, style4)
                        worksheet1.write(16, month + 21, round(total_rwh * -0.59), style4)
                    
                else:
                    harvestingpits = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Harvesting Pits').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_harvesting = round(harvestingpits['wt_consume__sum'])
                    except:
                        rwh_harvesting = 0
                    worksheet4.write(17, month + 10, rwh_harvesting, style4)
                    
                    pitcapacity = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Pit Capacity').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_pits = round(pitcapacity['wt_consume__sum'])
                    except:
                        rwh_pits = 0
                    worksheet4.write(18, month + 10, rwh_pits, style4)
                    
                    installed_capacity = rwh_harvesting * rwh_pits
                    worksheet4.write(19, month + 10, installed_capacity, style4)
                    
                    rainfall = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Average Rainfall').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        average_rainfall = round(rainfall['wt_consume__sum'])
                    except:
                        average_rainfall = 0
                    worksheet4.write(20, month + 10, average_rainfall, style4)
                    
                    roofarea = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_roof = round(roofarea['wt_consume__sum'])
                    except:
                        rwh_roof = 0
                    worksheet4.write(21, month + 10, rwh_roof, style4)
                    
                    nonroofarea = cost_water.objects.filter(wt_date__year = next_year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Non-Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                    try:
                        rwh_nonroof = round(nonroofarea['wt_consume__sum'])
                    except:
                        rwh_nonroof = 0
                    worksheet4.write(22, month + 10, rwh_nonroof, style4)
                    
                    try:
                        total_rwh_potential = round(((rwh_roof + rwh_nonroof) * average_rainfall * 0.6) / 1000)
                    except:
                        total_rwh_potential = 0
                    worksheet4.write(23, month + 10, total_rwh_potential, style4)
                    
                    if total_rwh_potential > installed_capacity:
                        total_rwh = installed_capacity
                        worksheet4.write(24, month + 10, total_rwh, style4)
                        worksheet1.write(16, month + 12, total_rwh, style4)
                        worksheet1.write(16, month + 33, round(total_rwh * 0.59), style4)
                    elif installed_capacity > total_rwh_potential:
                        total_rwh = total_rwh_potential
                        worksheet4.write(24, month + 10, total_rwh, style4)
                        worksheet1.write(16, month + 12, total_rwh, style4)
                        worksheet1.write(16, month + 33, round(total_rwh * 0.59), style4)
                    else:
                        total_rwh = installed_capacity
                        worksheet4.write(24, month + 10, total_rwh, style4)
                        worksheet1.write(16, month + 12, total_rwh, style4)
                        worksheet1.write(16, month + 33, round(total_rwh * 0.59), style4)
                        
            for year in range(0, 6):
                total_rwh_potential_array = []
                rwh_pits_array = []
                pit_capacity_array = []
                average_rainfall_array = []
                roof_area_array = []
                nonroof_area_array = []
                installed_rwh_capacity_array = []
                total_rwh_done_array = []
                for month in range(1, 13):
                    if month > 3:
                        harvesting_pits = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Harvesting Pits').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            harvestingpits = round(harvesting_pits['wt_consume__sum'])
                        except:
                            harvestingpits = 0
                        rwh_pits_array.append(harvestingpits)

                        pit_capacity = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Pit Capacity').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            pitcapacity = round(pit_capacity['wt_consume__sum'])
                        except:
                            pitcapacity = 0
                        pit_capacity_array.append(pitcapacity)
                        
                        installed_rwh_capacity = harvestingpits * pitcapacity
                        installed_rwh_capacity_array.append(installed_rwh_capacity)
         
                        average_rainfall = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Average Rainfall').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            averagerainfall = round(average_rainfall['wt_consume__sum'])
                        except:
                            averagerainfall = 0
                        average_rainfall_array.append(averagerainfall)
        
                        roof_area = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            roofarea = round(roof_area['wt_consume__sum'])
                        except:
                            roofarea = 0
                        roof_area_array.append(roofarea)
        
                        non_roofarea = cost_water.objects.filter(wt_date__year = current_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Non-Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            nonroofarea = round(non_roofarea['wt_consume__sum'])
                        except:
                            nonroofarea = 0
                        nonroof_area_array.append(nonroofarea)
                            
                        total_rwh_potential = round(((roofarea + nonroofarea) * averagerainfall * 0.6) / 1000)
                        total_rwh_potential_array.append(total_rwh_potential)
                        
                        if total_rwh_potential > installed_rwh_capacity:
                            total_rwh = installed_rwh_capacity
                        elif installed_rwh_capacity > total_rwh_potential:
                            total_rwh = total_rwh_potential
                        else:
                            total_rwh = installed_rwh_capacity
                        total_rwh_done_array.append(total_rwh)
                            
                    else:
                        harvesting_pits = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Harvesting Pits').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            harvestingpits = round(harvesting_pits['wt_consume__sum'])
                        except:
                            harvestingpits = 0
                        rwh_pits_array.append(harvestingpits)

                        pit_capacity = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Pit Capacity').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            pitcapacity = round(pit_capacity['wt_consume__sum'])
                        except:
                            pitcapacity = 0
                        pit_capacity_array.append(pitcapacity)
                            
                        installed_rwh_capacity = harvestingpits * pitcapacity
                        installed_rwh_capacity_array.append(installed_rwh_capacity)
         
                        average_rainfall = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Average Rainfall').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            averagerainfall = round(average_rainfall['wt_consume__sum'])
                        except:
                            averagerainfall = 0
                        average_rainfall_array.append(averagerainfall)
        
                        roof_area = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            roofarea = round(roof_area['wt_consume__sum'])
                        except:
                            roofarea = 0
                        roof_area_array.append(roofarea)
        
                        non_roofarea = cost_water.objects.filter(wt_date__year = next_year - year, wt_date__month = month, wt_source = data['wt_source'], wt_type = 'Non-Roof Area').values('wt_consume').aggregate(Sum('wt_consume'))
                        try:
                            nonroofarea = round(non_roofarea['wt_consume__sum'])
                        except:
                            nonroofarea = 0
                        nonroof_area_array.append(nonroofarea)
                            
                        total_rwh_potential = round(((roofarea + nonroofarea) * averagerainfall * 0.6) / 1000)
                        total_rwh_potential_array.append(total_rwh_potential)
                        
                        if total_rwh_potential > installed_rwh_capacity:
                            total_rwh = installed_rwh_capacity
                        elif installed_rwh_capacity > total_rwh_potential:
                            total_rwh = total_rwh_potential
                        else:
                            total_rwh = installed_rwh_capacity
                        total_rwh_done_array.append(total_rwh)
                
                worksheet4.write(23, year + 14, sum(total_rwh_potential_array), style4)
                worksheet4.write(24, year + 14, (sum(total_rwh_done_array)), style4)
                worksheet1.write(16, year + 16, (sum(total_rwh_done_array)), style4)
                worksheet1.write(16, year + 37, round(sum(total_rwh_done_array) * -0.59), style4)
                
                harvestingpits_num = 0
                for number in rwh_pits_array:
                    if number > harvestingpits_num:
                        harvestingpits_num = number
                worksheet4.write(17, year + 14, harvestingpits_num, style4)
                pitcapacity_num = 0
                for number in pit_capacity_array:
                    if number > pitcapacity_num:
                        pitcapacity_num = number
                worksheet4.write(18, year + 14, pitcapacity_num, style4)
                
                installed_rwh_capacity_num = 0
                for number in installed_rwh_capacity_array:
                    if number > installed_rwh_capacity_num:
                        installed_rwh_capacity_num = number
                worksheet4.write(19, year + 14, installed_rwh_capacity_num, style4)
            
                worksheet4.write(20, year + 14, round(sum(average_rainfall_array) / month_average), style4)
                
                roof_area_num = 0
                for number in roof_area_array:
                    if number > roof_area_num:
                        roof_area_num = number
                worksheet4.write(21, year + 14, roof_area_num, style4)
                
                nonroof_area_num = 0
                for number in nonroof_area_array:
                    if number > nonroof_area_num:
                        nonroof_area_num = number
                worksheet4.write(22, year + 14, nonroof_area_num, style4)
                
    for row27 in range(3, 26):
        worksheet4.row(row27).height_mismatch = True
        worksheet4.row(row27).height = 550
            
#     ############################################################################## SHEET 5 #######################################################################################
    
    worksheet5.write_merge(0, 1, 0, 0, 'Energy Data', style7)
    worksheet5.row(0).height_mismatch = True
    worksheet5.row(0).height = 500
    worksheet5.col(0).width = 12000
    worksheet5.write(2, 0, '',style3)
    worksheet5.write(2, 1, 'Unit', style3)
    worksheet5.write(10, 0, 'Total Power units used', style11)
    worksheet5.write(11, 0, 'Green power to total Power consumed', style11)
    worksheet5.write(12, 0, '% of Green power to total Power consumed', style11)
    worksheet5.write(15, 0, 'Power cost to sales', style11)
    worksheet5.write(13, 0, 'Manufacturing sale', style10)
    worksheet5.write(14, 0, 'Total power cost', style10)
    worksheet5.set_panes_frozen(True)
    worksheet5.set_vert_split_pos(2)
    worksheet5.set_horz_split_pos(3)
    
    row24 = 3
    array26 = ['Purchased electricity from Electricity  Authorities (non renewable)', 'Purchased electricity from Third Party (Nuclear - Non-Renewable)', 'Purchased electricity from Third Party (CNG - Non-Renewable)', 'Purchased electricity from Third Party  (Biogas-Renewable)', 'Units  generated in-house by burning fuel (Diesel Generator - Non-Renewable)', 'Purchased electricity from  Second Party (solar - Renewable)', 'Purchased electricity from  Third Party (wind-Renewable)']
    for list29 in array26:
        worksheet5.write(row24, 0, list29, style10)
        row24 += 1
        
    row25 = 16
    array27 = ['Cost Spend for Diesel', 'Cost Spend for Petrol', 'Cost Spend for CNG', 'Cost Spend for LPG', 'Cost Spend for PNG', 'Cost Spend for Water from Out Souced']
    for list30 in array27:
        worksheet5.write(row25, 0, list30, style10)
        row25 += 1
        
    row26 = 3
    array28 = ['kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kWh', 'kWh', '%','EUR', 'EUR', '%','EUR', 'EUR', 'EUR', 'EUR', 'EUR', 'EUR',]
    for list31 in array28:
        worksheet5.write(row26, 1, list31, style4)
        row26 += 1
        
    # Energy data
    srcname = AddSource.objects.values('assourcename')
    for data in srcname:
        if data['assourcename'] == 'Transformer1':
            yearly_cons = []
            for month in range(1, 13):
                if month > 3:
                    transdata = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(3, month - 2, round(transdata['mtenergycons__sum']), style4)
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(3, month - 2, ('-'), style4)
                else:
                    transdata = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(3, month + 10, round(transdata['mtenergycons__sum']), style4)
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(3, month + 10, ('-'), style4)
            for year in range(0, 6):
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                masterdata = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    worksheet5.write(3, 14 + year, round(masterdata['mtenergycons__sum']), style4)
                except:
                    worksheet5.write(3, 14 + year, '-', style4)
                    
        if data['assourcename'] == 'Solar Energy':
            yearly_cons = []
            for month in range(1, 13):
                if month > 3:
                    transdata = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(8, month - 2, round(transdata['mtenergycons__sum']), style4)
                        worksheet5.write(11, month - 2, round(transdata['mtenergycons__sum']), style12) #Green power static value
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(8, month - 2, ('-'), style4)
                        worksheet5.write(11, month - 2, ('-'), style12) #Green power static value
                else:
                    transdata = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(8, month + 10, round(transdata['mtenergycons__sum']), style4)
                        worksheet5.write(11, month - 2, round(transdata['mtenergycons__sum']), style12) #Green power static value
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(8, month + 10, ('-'), style4)
                        worksheet5.write(11, month + 10, ('-'), style12) #Green power static value
            for year in range(0, 6):
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                masterdata = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    worksheet5.write(8, 14 + year, round(masterdata['mtenergycons__sum']), style4)
                    worksheet5.write(11, 14 + year, round(masterdata['mtenergycons__sum']), style12) #Green power static value
                except:
                    worksheet5.write(8, 14 + year, '-', style4)
                    worksheet5.write(11, 14 + year, '-', style12) #Green power static value

        if data['assourcename'] == 'DG':
            yearly_cons = []
            for month in range(1, 13):
                if month > 3:
                    transdata = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(7, month - 2, round(transdata['mtenergycons__sum']), style4)
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(7, month - 2, ('-'), style4)
                else:
                    transdata = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                    try:
                        worksheet5.write(7, month + 10, round(transdata['mtenergycons__sum']), style4)
                        yearly_cons.append(round(transdata['mtenergycons__sum']))
                    except:
                        worksheet5.write(7, month + 10, ('-'), style4)
            for year in range(0, 6):
                start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
                end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
                masterdata = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    worksheet5.write(7, 14 + year, round(masterdata['mtenergycons__sum']), style4)
                except:
                    worksheet5.write(7, 14 + year, '-', style4)
                    
    # Total power units used
    for month in range(1, 13):
        monthly_cons = []
        if month > 3:
            transformer = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(transformer['mtenergycons__sum']))
            except:
                pass
            solar = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(solar['mtenergycons__sum']))
            except:
                pass
            dg = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = 'DG', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(dg['mtenergycons__sum']))
            except:
                pass
            worksheet5.write(10, month - 2, sum(monthly_cons), style12)
        else:
            transformer = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(transformer['mtenergycons__sum']))
            except:
                pass
            solar = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(solar['mtenergycons__sum']))
            except:
                pass
            dg = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = 'DG', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
            try:
                monthly_cons.append(round(dg['mtenergycons__sum']))
            except:
                pass
            worksheet5.write(10, month + 10, sum(monthly_cons), style12)
            
    for year in range(0, 6):
        source_yearly_cons = []
        start_date = datetime(current_year - year, start_month, 1).strftime("%Y-%m-%d")
        end_date = datetime(next_year - year, end_month, 31).strftime("%Y-%m-%d")
        transformer = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            source_yearly_cons.append(round(transformer['mtenergycons__sum']))
        except:
            pass
        solar = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            source_yearly_cons.append(round(solar['mtenergycons__sum']))
        except:
            pass
        dg = Masterdatatable.objects.filter(mtdate__range = (start_date, end_date), mtsrcname = 'DG', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
        try:
            source_yearly_cons.append(round(dg['mtenergycons__sum']))
        except:
            pass
        worksheet5.write(10, 14 + year, sum(source_yearly_cons), style12)
        
    for num19 in range(4, 7):
        for num20 in range(2, 20):
            worksheet5.write(num19, num20, '-', style4)
            
    for num in range(2, 20):
        worksheet5.write(9, num, '-', style4)
            
    for num21 in range(12, 22):
        for num22 in range(2, 20):
            worksheet5.write(num21, num22, '-', style4)
    
    for row27 in range(2, 22):
        worksheet5.row(row27).height_mismatch = True
        worksheet5.row(row27).height = 550
        
    ############################################################################### SHEET 6 #######################################################################################
    
    worksheet6.write_merge(0, 1, 0, 0, 'Name of the material', style3)
    worksheet6.col(0).width = 9000
    worksheet6.write_merge(0, 1, 1, 1, 'Details', style3)
    worksheet6.col(1).width = 6000
    worksheet6.write_merge(0, 1, 2, 2, 'Unit', style3)
    worksheet6.write(8, 0, 'Name of the material', style3)
    worksheet6.write(8, 1, 'Details', style3)
    worksheet6.write(8, 2, 'Unit', style3)
    worksheet6.write_merge(6, 6, 0, 2, 'Total', style5)
    worksheet6.row(6).height_mismatch = True
    worksheet6.row(6).height = 600
    worksheet6.write_merge(17, 17, 0, 2, 'Total', style5)
    worksheet6.row(17).height_mismatch = True
    worksheet6.row(17).height = 600
    worksheet6.write_merge(28, 28, 0, 2, 'Total', style5)
    worksheet6.row(28).height_mismatch = True
    worksheet6.row(28).height = 600
    worksheet6.write_merge(38, 38, 0, 2, 'Total', style5)
    worksheet6.row(38).height_mismatch = True
    worksheet6.row(38).height = 600
    worksheet6.set_panes_frozen(True)
    worksheet6.set_vert_split_pos(3)
    
    col6 = 3
    for list32 in month_cons:
        worksheet6.write_merge(0, 0, col6, col6 + 2, list32, style3)
        col6 += 3
    
    col7 = 39
    for list33 in range(0, 6):
        worksheet6.write_merge(0, 0, col7, col7 + 2, str(current_year - list33) + ' - ' + str(next_year - list33)[-2:], style3)
        col7 += 3
        
    col8 = 3
    for list34 in range(1, 19):
        worksheet6.write(1, col8, 'Total Cons', style3)
        worksheet6.col(col8).width = 3000
        worksheet6.write(1, col8 + 1, 'Reused Material Cons', style3)
        worksheet6.col(col8 + 1).width = 3000
        worksheet6.write(1, col8 + 2, 'Virgin Material Cons', style3)
        worksheet6.col(col8 + 2).width = 3000
        worksheet6.write(8, col8, 'Initial Waste Generated', style3)
        worksheet6.write(8, col8 + 1, 'Waste Reuse-Recycled', style3)
        worksheet6.write(8, col8 + 2, 'Waste Disposed', style3)
        col8 += 3
        
    row28 = 2
    array29 = ['Consumption of Raw material', 'Consumption of Paint & Ink', 'Consumption of Thinner and other solvents', 'Consumption of Hydraulic Oil']
    for list35 in array29:
        worksheet6.write(row28, 0, list35, style11)
        worksheet6.row(row28).height_mismatch = True
        worksheet6.row(row28).height = 600
        row28 += 1
        
    row29 = 2
    array30 = ['Engg. Plastic/metal etc.', 'paint', 'Thinner', 'Hyd Oil (Top Up)']
    for list36 in array30:
        worksheet6.write(row29, 1, list36, style4)
        row29 += 1
        
    row30 = 2
    array31 = ['kG', 'Litre', 'Litre', 'Litre']
    for list37 in array31:
        worksheet6.write(row30, 2, list37, style4)
        row30 += 1
        
    worksheet6.write_merge(9, 16, 0, 0, 'Consumption of Packaging and other consumables', style11)
    row31 = 9
    array32 = ['Plastic & Poly covers', 'Aluminium', 'Copper', 'Iron & Steel', 'Paper', 'Wood', 'Carton', 'Cloth']
    for list38 in array32:
        worksheet6.write(row31, 1, list38, style4)
        worksheet6.row(row31).height_mismatch = True
        worksheet6.row(row31).height = 600
        row31 += 1
        
    for list39 in range(0, 8):
        worksheet6.write(9 + list39, 2, 'kG', style4)
        
    worksheet6.write_merge(19, 27, 0, 0, 'Non Hazardous Waste Generation', style11)
    row32 = 19
    array33 = ['Rejected Poly Covers & Plastic Packaging', 'Aluminium waste', 'Copper waste', 'Iron & Steel waste', 'Wood waste', 'Carton waste', 'Cloth waste', 'Rejected Plastic / Lumps to scrap vendor', 'Food waste']
    for list40 in array33:
        worksheet6.write(row32, 1, list40, style4)
        worksheet6.row(row32).height_mismatch = True
        worksheet6.row(row32).height = 600
        row32 += 1
    for list41 in range(0, 9):
        worksheet6.write(19 + list41, 2, 'kG', style4)
        
    worksheet6.write_merge(30, 37, 0, 0, 'Hazardous waste Generation', style11)
    row33 = 30
    array34 = ['Paint Sludge', 'Used Hydraulic oil', 'Waste Thinner', 'Waste Paint', 'Oil Soaked Cotton', 'Empty Oil / Paint Containers', 'ETP Sludge', 'Electronic Waste (E -Waste)']
    for list42 in array34:
        worksheet6.write(row33, 1, list42, style4)
        worksheet6.row(row33).height_mismatch = True
        worksheet6.row(row33).height = 600
        row33 += 1
        
    row34 = 30
    array35 = ['Kg', 'Litre', 'Litre', 'Litre', 'Kg', 'Kg', 'Kg', 'Kg']
    for list43 in array35:
        worksheet6.write(row34, 2, list43, style4)
        row34 += 1
        
    for num23 in range(2, 7):
        for num24 in range(3, 57):
            worksheet6.write(num23, num24, '-', style4)
            
    for num25 in range(9, 18):
        for num26 in range(3, 57):
            worksheet6.write(num25, num26, '-', style4)
            
    for num27 in range(19, 29):
        for num28 in range(3, 57):
            worksheet6.write(num27, num28, '-', style4)
    
    for num29 in range(30, 39):
        for num30 in range(3, 57):
            worksheet6.write(num29, num30, '-', style4)

    ############################################################################### SHEET 7 #######################################################################################

    worksheet7.write_merge(0, 0, 0, 3, 'Finished Goods Transport', style7)
    worksheet7.row(0).height_mismatch = True
    worksheet7.row(0).height = 600
    worksheet7.write_merge(2, 3, 0, 0, 'Chapter', style3)
    worksheet7.write_merge(2, 3, 1, 1, 'Details', style3)
    worksheet7.col(1).width = 5500
    worksheet7.write_merge(2, 3, 2, 2, 'Fuel Type', style3)
    worksheet7.col(2).width = 6000
    worksheet7.write_merge(2, 3, 3, 3, 'Details', style3)
    worksheet7.col(3).width = 5000
    worksheet7.write_merge(4, 10, 0, 0, 'VIII', style4)
    worksheet7.write_merge(4, 10, 1, 1, 'Finished Goods Transport', style4)
    worksheet7.write_merge(2, 3, 64, 64, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet7.write_merge(2, 3, 65, 65, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet7.set_panes_frozen(True)
    worksheet7.set_vert_split_pos(4)
    
    col9 = 4
    for list44 in month_cons:
        worksheet7.write_merge(2, 2, col9, col9 + 4, list44, style3)
        col9 += 5
        
    col10 = 0
    for list45 in range(0, 12):
        worksheet7.write(3, col10 + 4, 'No.of trips', style3)
        worksheet7.write(3, col10 + 5, 'KM per trip', style3)
        worksheet7.write(3, col10 + 6, 'Total KM', style3)
        worksheet7.write(3, col10 + 7, 'Mileage of the Vehicle (Kms / Lit)', style3)
        worksheet7.write(3, col10 + 8, 'Total Fuel consumption', style3)
        col10 += 5
    worksheet7.row(3).height_mismatch = True
    worksheet7.row(3).height = 700

    for list46 in range(4, 9):
        worksheet7.write(list46, 2, 'Finished Goods Transport Vehicles Diesel consumption', style4)
        worksheet7.row(list46).height_mismatch = True
        worksheet7.row(list46).height = 1100
        
    row36 = 4
    array36 = ['MATE 1 to MOBIS', 'MATE 1 to Ashok leyland', 'MATE 1 to Bangalore', 'MATE 1 to Unit 3', 'MATE 1 to Ford PDC']
    for list47 in array36:
        worksheet7.write(row36, 3, list47, style4)
        row36 += 1
        
    for list48 in range(4, 66):
        worksheet7.col(list48).width = 3000
        
    for num31 in range(4, 11):
        for num32 in range(4, 66):
            worksheet7.write(num31, num32, '-', style4)
            
    for num33 in range(9, 11):
        for num34 in range(2, 4):
            worksheet7.write(num33, num34, '-', style4)
            
#     ############################################################################### SHEET 8 #######################################################################################
    
    worksheet8.write_merge(0, 0, 0, 3, 'Employee commuting', style7)
    worksheet8.row(0).height_mismatch = True
    worksheet8.row(0).height = 600
    worksheet8.write_merge(2, 2, 0, 3, 'V Employee Travels', style3)
    worksheet8.write_merge(4, 8, 0, 0, 'V', style4)
    worksheet8.write_merge(4, 8, 1, 1, 'Employee Comuting (Common Transport)', style4)
    worksheet8.write_merge(2, 3, 76, 76, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(2, 3, 77, 77, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    
    worksheet8.write_merge(11, 11, 0, 1, 'VI Employee', style3)
    worksheet8.write(12, 0, 'Chapter', style3)
    worksheet8.write(12, 1, 'Details', style3)
    worksheet8.write(13, 0, 'VI(a)', style4)
    worksheet8.write(13, 1, 'Employee Commuting (Company provided Vehicles for employees)(Two Wheeler)', style4)
    worksheet8.write_merge(11, 12, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(11, 12, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    
    worksheet8.write_merge(14, 14, 0, 1, 'VI Employee', style3)
    worksheet8.write_merge(15, 22, 0, 0, 'VI(b)', style4)
    worksheet8.write_merge(15, 22, 1, 1, 'Employee Commuting (Company provided Vehicles for employees)(Petrol)', style4)
    worksheet8.write_merge(14, 15, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(14, 15, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(17, 18, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(17, 18, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(20, 21, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(20, 21, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    
    worksheet8.write_merge(23, 23, 0, 1, 'VI Employee', style3)
    worksheet8.write_merge(24, 31, 0, 0, 'VI(c)', style4)
    worksheet8.write_merge(24, 31, 1, 1, 'Employee Commuting (Company provided Vehicles for employees)(Diesel)', style4)
    worksheet8.write_merge(23, 24, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(23, 24, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(26, 27, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(26, 27, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(29, 30, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(29, 30, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    
    worksheet8.write_merge(32, 32, 0, 1, 'VI Employee', style3)
    worksheet8.write_merge(33, 40, 0, 0, 'VI(d)', style4)
    worksheet8.write_merge(33, 40, 1, 1, 'Employee Commuting (Company provided Vehicles for employees)(CNG)', style4)
    worksheet8.write_merge(32, 33, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(32, 33, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(35, 36, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(35, 36, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(38, 39, 62, 62, 'Total Fuel consumption ' + str(current_year) + ' - ' +  str(next_year), style3)
    worksheet8.write_merge(38, 39, 63, 63, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    
    worksheet8.write_merge(42, 42, 0, 1, 'VII Employee Business Travels', style3)
    worksheet8.write_merge(43, 54, 0, 0, 'VII(a)', style4)
    worksheet8.write_merge(42, 43, 74, 74, 'Total Emission ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(43, 54, 1, 1, 'Business Travels-Train', style4)
    worksheet8.write_merge(55, 62, 0, 0, 'VII(b)', style4)
    worksheet8.write_merge(55, 56, 74, 74, 'Total Emission ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(55, 62, 1, 1, 'Business Travels-Air', style4)
    worksheet8.write_merge(63, 75, 0, 0, 'VII(c)', style4)
    worksheet8.write_merge(63, 64, 62, 62, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(63, 75, 1, 1, 'Business Travels-Road(Petrol)', style4)
    worksheet8.write_merge(76, 88, 0, 0, 'VII(d)', style4)
    worksheet8.write_merge(76, 77, 62, 62, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(76, 88, 1, 1, 'Business Travels-Road(Diesel)', style4)
    worksheet8.write_merge(89, 102, 0, 0, 'VII(e)', style4)
    worksheet8.write_merge(89, 90, 62, 62, 'Total Fuel consumption ' + str(previous_year) + ' - ' + str(current_year), style3)
    worksheet8.write_merge(89, 102, 1, 1, 'Business Travels-Road-Two wheeler(Petrol)', style4)
    
    for list45 in range(1, 6):
        worksheet8.write(3 + list45, 2, 'Employee Transport Vehicles Diesel consumption', style4)
    
    col11 = 0
    array37 = ['Chapter', 'Details', 'Fuel Type', 'Details']
    for list49 in array37:
        worksheet8.write(3, col11, list49, style3)
        col11 += 1
        
    row37 = 4
    array38 = ['MATE 1 to Tambaram', 'MATE 1 to Maduranthagam 1', 'MATE 1 to Maduranthagam 2', 'Fuel used for transport', 'Fuel used for transport']
    for list50 in array38:
        worksheet8.write(row37, 3, list50, style4)
        row37 += 1
    
    col13 = 4
    for list44 in month_cons:
        worksheet8.write_merge(2, 2, col13, col13 + 5, list44, style3)
        col13 += 6
            
    col12 = 0
    for list51 in range(1, 13):
        worksheet8.write(3, col12 + 4, 'No.of trips', style3)
        worksheet8.write(3, col12 + 5, 'No.of working days', style3)
        worksheet8.write(3, col12 + 6, 'KM per trip', style3)
        worksheet8.write(3, col12 + 7, 'Total KM', style3)
        worksheet8.write(3, col12 + 8, 'Mileage of the vehicle (Kms / Lit)', style3)
        worksheet8.write(3, col12 + 9, 'Total Fuel consumption', style3)
        col12 += 6
        
    for num35 in range(4, 9):
        for num36 in range(4, 78):
            worksheet8.write(num35, num36, '-', style4)
            
    col14 = 2
    for list52 in month_cons:
        worksheet8.write_merge(11, 11, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(14, 14, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(17, 17, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(20, 20, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(23, 23, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(26, 26, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(29, 29, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(32, 32, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(35, 35, col14, col14 + 4, list52, style3)
        worksheet8.write_merge(38, 38, col14, col14 + 4, list52, style3)
        col14 += 5
        
    col15 = 2
    for list53 in range(1, 13):
        worksheet8.write(12, col15, 'No. of employees having company provided two wheeler', style3)
        worksheet8.write(12, col15 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(12, col15 + 2, 'Total allowance for the month', style3)
        worksheet8.write(12, col15 + 3, 'Fuel price per Lit', style3)
        worksheet8.write(12, col15 + 4, 'Total fuel consumed', style3)
        col15 += 5
        
    for num37 in range(1, 63):
        worksheet8.write(13, num37 + 1, '-', style4)
        
    col16 = 2
    for list54 in range(1, 13):
        worksheet8.write(15, col16, 'No. of employees having company provided  Car ( CC under 999)', style3)
        worksheet8.write(15, col16 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(15, col16 + 2, 'Total allowance for the month', style3)
        worksheet8.write(15, col16 + 3, 'Fuel price per lit', style3)
        worksheet8.write(15, col16 + 4, 'Total fuel consumed', style3)
        worksheet8.write(18, col16, 'No. of employees having company provided car ( CC With in 1000 to 1999)', style3)
        worksheet8.write(18, col16 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(18, col16 + 2, 'Total allowance for the month', style3)
        worksheet8.write(18, col16 + 3, 'Fuel price per lit', style3)
        worksheet8.write(18, col16 + 4, 'Total fuel consumed', style3)
        worksheet8.write(21, col16, 'No. of employees having company provided car ( CC 1200 and above)', style3)
        worksheet8.write(21, col16 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(21, col16 + 2, 'Total allowance for the month', style3)
        worksheet8.write(21, col16 + 3, 'Fuel price per lit', style3)
        worksheet8.write(21, col16 + 4, 'Total fuel consumed', style3)
        col16 += 5
        
    col17 = 2
    for list55 in range(1, 13):
        worksheet8.write(24, col17, 'No. of employees having company provided  Car ( CC under 999)', style3)
        worksheet8.write(24, col17 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(24, col17 + 2, 'Total allowance for the month', style3)
        worksheet8.write(24, col17 + 3, 'Fuel price per lit', style3)
        worksheet8.write(24, col17 + 4, 'Total fuel consumed', style3)
        worksheet8.write(27, col17, 'No. of employees having company provided car ( CC With in 1000 to 1999)', style3)
        worksheet8.write(27, col17 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(27, col17 + 2, 'Total allowance for the month', style3)
        worksheet8.write(27, col17 + 3, 'Fuel price per lit', style3)
        worksheet8.write(27, col17 + 4, 'Total fuel consumed', style3)
        worksheet8.write(30, col17, 'No. of employees having company provided car ( CC 1200 and above)', style3)
        worksheet8.write(30, col17 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(30, col17 + 2, 'Total allowance for the month', style3)
        worksheet8.write(30, col17 + 3, 'Fuel price per lit', style3)
        worksheet8.write(30, col17 + 4, 'Total fuel consumed', style3)
        col17 += 5
        
    col18 = 2
    for list56 in range(1, 13):
        worksheet8.write(33, col18, 'No. of employees having company provided  Car ( CC under 999)', style3)
        worksheet8.write(33, col18 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(33, col18 + 2, 'Total allowance for the month', style3)
        worksheet8.write(33, col18 + 3, 'Fuel price per lit', style3)
        worksheet8.write(33, col18 + 4, 'Total fuel consumed', style3)
        worksheet8.write(36, col18, 'No. of employees having company provided car ( CC With in 1000 to 1999)', style3)
        worksheet8.write(36, col18 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(36, col18 + 2, 'Total allowance for the month', style3)
        worksheet8.write(36, col18 + 3, 'Fuel price per lit', style3)
        worksheet8.write(36, col18 + 4, 'Total fuel consumed', style3)
        worksheet8.write(39, col18, 'No. of employees having company provided car ( CC 1200 and above)', style3)
        worksheet8.write(39, col18 + 1, 'Fuel allowance provided to  per employee', style3)
        worksheet8.write(39, col18 + 2, 'Total allowance for the month', style3)
        worksheet8.write(39, col18 + 3, 'Fuel price per lit', style3)
        worksheet8.write(39, col18 + 4, 'Total fuel consumed', style3)
        col18 += 5
        
    col19 = 2
    for list53 in month_cons:
        worksheet8.write_merge(42, 42, col19, col19 + 5, list53, style3)
        worksheet8.write_merge(55, 55, col19, col19 + 5, list53, style3)
        col19 += 6
        
    col20 = 2
    for list54 in range(1, 13):
        worksheet8.write(43, col20, 'Business travel by train', style3)
        worksheet8.write(43, col20 + 1, 'Name of employees', style3)
        worksheet8.write(43, col20 + 2, 'Traveling destination', style3)
        worksheet8.write(43, col20 + 3, 'Total Kms', style3)
        worksheet8.write(43, col20 + 4, 'Emission per Kms', style3)
        worksheet8.write(43, col20 + 5, 'Total Emission', style3)
        worksheet8.write(56, col20, 'Business travel by train', style3)
        worksheet8.write(56, col20 + 1, 'Name of employees', style3)
        worksheet8.write(56, col20 + 2, 'Traveling destination', style3)
        worksheet8.write(56, col20 + 3, 'Total Kms', style3)
        worksheet8.write(56, col20 + 4, 'Emission per Kms', style3)
        worksheet8.write(56, col20 + 5, 'Total Emission', style3)
        col20 += 6
        
    col21 = 2
    for list55 in month_cons:
        worksheet8.write_merge(63, 63, col21, col21 + 4, list55, style3)
        worksheet8.write_merge(76, 76, col21, col21 + 4, list55, style3)
        worksheet8.write_merge(89, 89, col21, col21 + 4, list55, style3)
        col21 += 5
        
    col22 = 2
    for list56 in range(1, 13):
        worksheet8.write(64, col22, 'Business travel by Road', style3)
        worksheet8.write(64, col22 + 1, 'Name of employees', style3)
        worksheet8.write(64, col22 + 2, 'Traveling destination', style3)
        worksheet8.write(64, col22 + 3, 'Total Kms', style3)
        worksheet8.write(64, col22 + 4, 'Fuel consumed', style3)
        worksheet8.write(77, col22, 'Business travel by Road', style3)
        worksheet8.write(77, col22 + 1, 'Name of employees', style3)
        worksheet8.write(77, col22 + 2, 'Traveling destination', style3)
        worksheet8.write(77, col22 + 3, 'Total Kms', style3)
        worksheet8.write(77, col22 + 4, 'Fuel consumed', style3)
        worksheet8.write(90, col22, 'Business travel by Road', style3)
        worksheet8.write(90, col22 + 1, 'Name of employees', style3)
        worksheet8.write(90, col22 + 2, 'Traveling destination', style3)
        worksheet8.write(90, col22 + 3, 'Total Kms', style3)
        worksheet8.write(90, col22 + 4, 'Fuel consumed', style3)
        col22 += 5
        
    for num38 in range(16, 41, 3):
        for num39 in range(2, 64):
            worksheet8.write(num38, num39, '-', style4)
            
    for num40 in range(44, 55):
        for num41 in range(2, 75):
            worksheet8.write(num40, num41, '-', style4)
            
    for num42 in range(57, 63):
        for num43 in range(2, 75):
            worksheet8.write(num42, num43, '-', style4)
            
    for num44 in range(65, 76):
        for num45 in range(2, 63):
            worksheet8.write(num44, num45, '-', style4)
            
    for num46 in range(78, 89):
        for num47 in range(2, 63):
            worksheet8.write(num46, num47, '-', style4)
            
    for num48 in range(91, 103):
        for num49 in range(2, 63):
            worksheet8.write(num48, num49, '-', style4)
            
    for num50 in range(1, 80):
        worksheet8.col(num50).width = 3000
    
    savepath = os.path.join(BASE_DIR, 'Report', 'CarbonReport.xls')
    workbook.save(savepath)
    
    return savepath

@csrf_exempt
def sendmail(request):
    if request.method == 'POST':
        reportpath = CarbonReport()
        request_data = json.loads(request.body)
        tomail = request_data['email']
        sub = 'Carbon Emission Report'
        messg = '''
        Dear Team, 
            Please find the attached Emission report.
        Regards, 
        EMs Team - ROBIS
        '''
        #Adding the email details to the message header of the MIMEMultipart
        msg = MIMEMultipart('alternative')
        msg['Subject']=sub
        msg['From']="R-Energy <no-reply@renergy.com>"
        msg['To']=tomail
        text = str(messg)
        part1=MIMEText(text,'plain')
        msg.attach(part1)

        #Reading the file and encoding it back to the xls format
        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(reportpath, "rb").read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="R-CarbonReport.xls"')
        msg.attach(part)
        
        #Establishing connection with the smtp server
        smtpObj=smtplib.SMTP('smtp.int.motherson.com',25)

        #Sending mail to the recipients
        smtpObj.sendmail('ntpdpmt1@int.motherson.com',tomail.split(';'),msg.as_string())
        smtpObj.quit()
        # print("Mail Sent to ",tomail )
    return JsonResponse("Mail Sent", safe=False)