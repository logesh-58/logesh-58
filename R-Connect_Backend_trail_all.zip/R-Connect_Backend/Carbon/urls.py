from django.urls import path
from Carbon import reportfile, views, excel, dashboard, analytics, yearlyemission, viewscopy, sankeycarbon

urlpatterns = [
    # path('carbonreport/',excel.CarbonReport),
    path('carbonreport/',excel.sendmail),
    path('rcarbonsummary/',views.CarbonSummary),
    path('energyconsumption/',viewscopy.EnergyConsumption),
    path('rcarbon/',dashboard.Dashboard),
    path('analyticsrcarbon/',analytics.Analytics),
    path('yearlyemission/', yearlyemission.YearlyEmission),
    path('sankeycarbon/', sankeycarbon.SankeyCarbon)
]