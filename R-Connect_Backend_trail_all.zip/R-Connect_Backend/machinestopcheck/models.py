from django.db import models
from mouldmanagement.models import Mouldmodel

# Create your models here.
class MachinestopCheck(models.Model):
    id              = models.AutoField(primary_key=True)
    date            = models.CharField(max_length=255,default=False,null=True)
    time            = models.CharField(max_length=255,default=False,null=True)
    Plantname       = models.CharField(max_length=255,default=False,null=True)
    Machinename     = models.CharField(max_length=255,default=False,null=True)
    Mouldname       = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    MachineState    = models.IntegerField(default = False)