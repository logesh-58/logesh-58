from machinestopcheck import views
from django.urls import path


urlpatterns=[
    path('machinestop/',views.checkstop,name="Machinestopcheck"),
]

