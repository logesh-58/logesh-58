from django.db.models.base import Model
from machinestopcheck.models import MachinestopCheck
from rest_framework import serializers

class MachinestopCheckSerializer(serializers.ModelSerializer):
    model  = MachinestopCheck
    fields = "__all__"

    