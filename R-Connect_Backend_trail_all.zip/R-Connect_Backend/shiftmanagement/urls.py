from django.urls import path
from .import views

urlpatterns = [
    path('shifttime/', views.timings,name="Shifttiming"),
    path('shiftproduction/', views.shiftproductiondata,name="Shiftproduction"),
    path('remaining', views.remainingtime,name="Shiftproduction"),
    path('calenderrem', views.calendertime,name="Shiftproduction"),
    # path('dashboardid/(?P<id>[0-9])/',   views.profile,      name="html"), # get particular event data
    path('materials', views.materials,name="Shiftproduction"),
]

