from django.db import models
from mouldmanagement.models import Mouldmodel

# Create your models here.
class ShiftTimings(models.Model):
    id                  = models.AutoField(primary_key=True)
    Plantname           = models.CharField(max_length=255, default=False, null=True)
    shift1start         = models.TimeField(default=False,null=True)
    shift1end           = models.TimeField(default=False,null=True)
    shift2start         = models.TimeField(default=False,null=True)
    shift2end           = models.TimeField(default=False,null=True)
    shift3start         = models.TimeField(default=False,null=True)
    shift3end           = models.TimeField(default=False,null=True)

# class ShiftProductiondata(models.Model):
#     id          = models.AutoField(primary_key=True)
#     Plantname   = models.CharField(max_length=255, default=False, null=True)
#     sdate       = models.CharField(max_length=255, default=False, null=True)
#     sMachinename= models.CharField(max_length=255, default=False, null=True)
#     sMouldname  = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
#     s1set       = models.IntegerField(default=False, null=True)
#     s2set       = models.IntegerField(default=False, null=True)
#     s3set       = models.IntegerField(default=False, null=True)
#     salertmail  = models.EmailField(default=False,null=True)
#     salertboolean   = models.BooleanField(default=False,null=True)
#     sproductiontime = models.TimeField(default=False,null=True)
#     stargetcount    = models.IntegerField(default=False, null=True)
#     starttime       = models.TimeField(default=False,null=True)
#     endtime         = models.TimeField(default=False,null=True)

class ShiftProductiondata(models.Model):
    sp_id          = models.AutoField(primary_key=True)
    # sp_code        = models.CharField(max_length=255, default=False, null=True)
    sp_plantname   = models.CharField(max_length=255, default=False, null=True)
    sp_date        = models.CharField(max_length=255, default=False, null=True)
    sp_machinename = models.CharField(max_length=255, default=False, null=True)
    sp_mouldname   = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    # sp_mouldname   = models.CharField(max_length=255, default=False, null=True)
    # sp_mouldname   = models.ForeignKey(Mouldmodel,on_delete=models.CASCADE,null=True,default=False)
    sp_material       = models.CharField(max_length=255, default=False, null=True)
    sp_shift       = models.CharField(max_length=255, default=False, null=True)
    sp_totalproduction = models.IntegerField(default=False, null=True)
    sp_totalproductiontime = models.FloatField(default=False, null=True)