from django.shortcuts import render
from .models import ShiftTimings, ShiftProductiondata
from .serializers import ShiftTimingSerializer, ShiftproductiondataSerializer
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from analysis.views import machineArray
from datetime import datetime, timedelta, time
from mouldmanagement.models import Mouldmodel
from machinemanagement.models import AddMachine

# Create your views here.
@csrf_exempt
def timings(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        timingdata = ShiftTimings.objects.filter(Plantname = Plantname).all()
        serialized_time = ShiftTimingSerializer(timingdata, many=True)
        return JsonResponse(serialized_time.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        httpdata = json.loads(request.body)
        s1starttime = httpdata['s1starttime']
        s1endtime   = httpdata['s1endtime']
        s2starttime = httpdata['s2starttime']
        s2endtime   = httpdata['s2endtime']
        s3starttime = httpdata['s3starttime']
        s3endtime   = httpdata['s3endtime']

        instance = ShiftTimings(Plantname = Plantname, shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
        if(ShiftTimings.objects.filter(Plantname = Plantname).exists()):
            ShiftTimings.objects.filter(Plantname = Plantname).update(shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
        else:
            instance.save()
        return JsonResponse('Data saved successfully', safe=False)

@csrf_exempt
def shiftproductiondatanew(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        productionsetdata   = ShiftProductiondata.objects.filter(sp_plantname = Plantname).all().order_by('sp_id')
        serialized_data  = ShiftproductiondataSerializer(productionsetdata, many=True)
        return JsonResponse(serialized_data.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        code = data['sp_code']
        if ShiftProductiondata.objects.filter(sp_code = code).exists():
            return JsonResponse ("Data Already Added", safe=False)
        else:
            item = ShiftProductiondata(sp_date = data['sp_date'], 
                                       sp_code = data['sp_code'],
                                       sp_plantname = Plantname,
                                       sp_machinename = data['sp_machinename'],
                                       sp_totalproduction = data['sp_totalproduction'],
                                       sp_totalproductiontime = data['sp_totalproductiontime'],
                                       sp_shift = data['sp_shift'],
                                       sp_mouldname = data['sp_mouldname'])
            item.save()
            return JsonResponse("Data Saved Successfully", safe=False)
    
    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        if ShiftProductiondata.objects.filter(sp_code = data['sp_code']).exists():
            ShiftProductiondata.objects.filter(sp_code = data['sp_code']).update(sp_date = data['sp_date'], 
                                                                                sp_plantname = Plantname,
                                                                                sp_machinename = data['sp_machinename'],
                                                                                sp_totalproduction = data['sp_totalproduction'],
                                                                                sp_totalproductiontime = data['sp_totalproductiontime'],
                                                                                sp_shift = data['sp_shift'],
                                                                                sp_mouldname = data['sp_mouldname'])
            return JsonResponse('Data updated successfully', safe=False)
        else:
            return JsonResponse('Failed to update data', safe=False)

    if request.method == 'DELETE':
        data = json.loads(request.body)
        data = data['sp_code']
        if(ShiftProductiondata.objects.filter(sp_code = data).exists()):
            ShiftProductiondata.objects.filter(sp_code = data).delete()
            return JsonResponse('Data deleted successfully', safe=False)

def profile(request, tid):
    if(ShiftProductiondata.objects.filter(id = id).exists()):
        ShiftProductiondata.objects.filter(id = id).update(s2set = '')
    return JsonResponse('Approved', safe=False)
    

# {

# "sp_code" : "spcode_6",
# "sp_plantname" : "MATE U1",
# "sp_date" : "2024-09-03",
# "sp_machinename" : "2000TA",
# "sp_mouldname" : "2FM PAD",
# "sp_shift" : "A",
# "sp_totalproduction" : 77,
# "sp_totalproductiontime" : 6

# }

# @csrf_exempt
# def shiftproductiondata(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']
#         productionsetdata   = ShiftProductiondata.objects.filter(sp_plantname = Plantname).all().order_by('sp_id')
#         serialized_data  = ShiftproductiondataSerializer(productionsetdata, many=True)
#         return JsonResponse(serialized_data.data, safe=False)

#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']
#         data = json.loads(request.body)

#         if ShiftProductiondata.objects.filter(sp_date = data['sp_date'], sp_plantname = Plantname, sp_machinename = data['sp_machinename'], sp_shift = data['sp_shift']).exists():
#             return JsonResponse ("Data Already Added", safe=False)
#         else:
#             item = ShiftProductiondata(sp_date = data['sp_date'], 
#                                        sp_plantname = Plantname,
#                                        sp_machinename = data['sp_machinename'],
#                                        sp_totalproduction = data['sp_totalproduction'],
#                                        sp_totalproductiontime = data['sp_totalproductiontime'],
#                                        sp_shift = data['sp_shift']
#                                        )
#             item.save()
#             return JsonResponse("Data Saved Successfully", safe=False)
    
#     if request.method == 'PUT':
#         Plantname = request.GET['Plantname']
#         data = json.loads(request.body)
#         if ShiftProductiondata.objects.filter(sp_date = data['sp_date'], sp_plantname = Plantname, sp_machinename = data['sp_machinename'], sp_shift = data['sp_shift']).exists():
#             ShiftProductiondata.objects.filter(sp_machinename = data['sp_machinename'], sp_plantname = Plantname, sp_shift = data['sp_shift']).update(sp_date = data['sp_date'],                                                                     
#                                                                                 sp_totalproduction = data['sp_totalproduction'],
#                                                                                 sp_totalproductiontime = data['sp_totalproductiontime']                                                                
#                                                                                 )
#             return JsonResponse('Data updated successfully', safe=False)
#         else:
#             return JsonResponse('Failed to update data', safe=False)

#     if request.method == 'DELETE':
#         Plantname = request.GET['Plantname']  # Extract Plantname here as well
#         data = json.loads(request.body)
    
#         if(ShiftProductiondata.objects.filter(sp_date = data['sp_date'], sp_plantname = Plantname, sp_machinename = data['sp_machinename'], sp_shift = data['sp_shift']).exists()):
#             ShiftProductiondata.objects.filter(sp_date = data['sp_date'], sp_plantname = Plantname, sp_machinename = data['sp_machinename'], sp_shift = data['sp_shift']).delete()
#             return JsonResponse('Data deleted successfully', safe=False)
        
#         else:
#             return JsonResponse('There is No data to delete', safe=False)

@csrf_exempt
def shiftproductiondata(request):
    if request.method == 'GET':
        Plantname = request.GET.get('Plantname')
        productionsetdata = ShiftProductiondata.objects.filter(sp_plantname=Plantname).all().order_by('sp_id')
        serialized_data = ShiftproductiondataSerializer(productionsetdata, many=True)

        # Retrieve and print sp_mouldname for each entry in serialized data
        # mould_names = []
        for item in serialized_data.data:
            mould_id = item['sp_mouldname']
            time = item['sp_totalproductiontime']
            try:
                sp_mouldname = Mouldmodel.objects.get(id=mould_id).Mouldname
                item['sp_mouldname'] = sp_mouldname  # Update with the actual mould name
                # mould_names.append(sp_mouldname)

                alt_time = str(timedelta(seconds=int(time * 3600)))
                item['sp_totalproductiontime'] = alt_time 
            except Mouldmodel.DoesNotExist:
                item['sp_mouldname'] = "Unknown Mould Name"
                # mould_names.append("Unknown Mould Name")
                item['sp_totalproductiontime'] = "Unknown Time"
        
        # print("Mould Names:", mould_names)
        return JsonResponse(serialized_data.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data_list = json.loads(request.body)  # Assuming the request body contains a list of data objects

        response_messages = []  # To collect responses for each entry

        for data in data_list:
            try:

                # Validate machine name
                if not AddMachine.objects.filter(amMachinename=data['sp_machinename']).exists():
                    response_messages.append(
                        "Machine name not found"
                    )
                    continue  # Skip processing this entry if material is invalid

                # Try to get the mould object
                mould_instance = Mouldmodel.objects.get(Mouldname=data['sp_mouldname'])

                if data['sp_material'] not in mould_instance.Material:
                    response_messages.append(
                        f"Material '{data['sp_material']}' not found for mould '{data['sp_mouldname']}' in Machine '{data['sp_machinename']}'."
                    )
                    continue  # Skip processing this entry if material is invalid

                # Check if the record already exists
                if ShiftProductiondata.objects.filter(
                    sp_date=data['sp_date'],
                    sp_plantname=Plantname,
                    sp_machinename=data['sp_machinename'],
                    sp_mouldname=mould_instance,
                    sp_shift=data['sp_shift'],
                    sp_material=data['sp_material']
                ).exists():
                    response_messages.append("Data Already Added")
                else:
                    # Create and save the new record
                    item = ShiftProductiondata(
                        sp_date=data['sp_date'],
                        sp_plantname=Plantname,
                        sp_machinename=data['sp_machinename'],
                        sp_mouldname=mould_instance,
                        sp_totalproduction=data['sp_totalproduction'],
                        sp_totalproductiontime=data['sp_totalproductiontime'],
                        sp_shift=data['sp_shift'],
                        sp_material=data['sp_material']
                    )
                    item.save()
                    response_messages.append("Data Saved Successfully")
            except Mouldmodel.DoesNotExist:
                # If the mould name is not found, add a detailed error message
                # response_messages.append({
                #     "message": "Invalid Mould Name Found",
                #     "Date": data['sp_date'],
                #     "Machine Name": data['sp_machinename'],
                #     "Shift": data['sp_shift'],
                #     "sp_totalproduction": data['sp_totalproduction'],
                #     "Invalid Mould Name": data['sp_mouldname'],
                #     "sp_totalproductiontime": data['sp_totalproductiontime']
                # })

                response_messages.append(
                        f"Mould name '{data['sp_mouldname']}' not found in Mould master."
                    )

        return JsonResponse(response_messages, safe=False)

    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        if ShiftProductiondata.objects.filter(sp_date=data['sp_date'], 
                                                sp_plantname=Plantname, 
                                                sp_machinename=data['sp_machinename'],
                                                sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']), 
                                                sp_shift=data['sp_shift']).exists():
            ShiftProductiondata.objects.filter(sp_date=data['sp_date'], sp_machinename = data['sp_machinename'], sp_plantname = Plantname, sp_shift = data['sp_shift'], sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname'])).update(                                                                     
                                                                                sp_totalproduction = data['sp_totalproduction'],
                                                                                sp_totalproductiontime = data['sp_totalproductiontime'],
                                                                                sp_material=data['sp_material']                                                            
                                                                                )
            if data['updateStatus']==True:
                ShiftProductiondata.objects.filter(sp_id = data['sp_id']).delete()
            else:
                print("No Changes Done by user")
            return JsonResponse('Data Partially updated', safe=False)
        else:
            ShiftProductiondata.objects.filter(sp_id = data['sp_id'], sp_plantname = Plantname).update(sp_date = data['sp_date'],
                                            sp_machinename = data['sp_machinename'],
                                            sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']),
                                            sp_totalproduction = data['sp_totalproduction'],
                                            sp_totalproductiontime = data['sp_totalproductiontime'],
                                            sp_shift = data['sp_shift'],
                                            sp_material = data['sp_material'])
            return JsonResponse('Data updated successfully', safe=False)
        

    if request.method == 'DELETE':
        data = json.loads(request.body)
        data = data['sp_id']
        if(ShiftProductiondata.objects.filter(sp_id = data).exists()):
            ShiftProductiondata.objects.filter(sp_id = data).delete()
            return JsonResponse('Data deleted successfully', safe=False)


@csrf_exempt
def remainingtime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        data = json.loads(request.body)

        date = data['sp_date'] 
        machinename = data['sp_machinename']
        shift = data['sp_shift']

        ##########################################################################################
        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        # Access each shift time correctly from the dictionary
        shiftone_starttime = shift_times['shift1start'].hour
        print("shift 1 start:", shiftone_starttime)
        shiftone_endtime = shift_times['shift1end'].hour
        print("shift 1 end:", shiftone_endtime)
        shifttwo_starttime = shift_times['shift2start'].hour
        print("shift 2 start:", shifttwo_starttime)
        shifttwo_endtime = shift_times['shift2end'].hour
        print("shift 2 end:", shifttwo_endtime)
        shiftthree_starttime = shift_times['shift3start'].hour
        print("shift 3 start:", shiftthree_starttime)
        shiftthree_endtime = shift_times['shift3end'].hour
        print("shift 3 end:", shiftthree_endtime)

        response_data = []

        all_aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=date,
                    sp_plantname=Plantname,
                    sp_machinename=machinename,
                    sp_shift=shift
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift').order_by('sp_id')

        if all_aggregated_data:
            
            remaining_time = [r for r in all_aggregated_data]

            mac_hours = sum(r['sp_totalproductiontime'] for r in remaining_time) if remaining_time else 0

            if shift == "A":
                shift_total_time = shiftone_endtime - shiftone_starttime
            elif shift == "B":
                shift_total_time = shifttwo_endtime - shifttwo_starttime
            elif shift == "C":
                if shiftthree_endtime < shiftthree_starttime:
                    shift_total_time = (shiftthree_endtime + 24) - shiftthree_starttime
                else:
                    shift_total_time = shiftthree_endtime - shiftthree_starttime
            else:
                shift_total_time = 0

            retime = shift_total_time - mac_hours

            ########
            if retime <= 0:
                final_hours = "Nil"
            else:
                final_hours = retime
            ########

            print("11111111111111111111")

        else:

            mac_hours = 0

            if shift == "A":
                shift_total_time = shiftone_endtime - shiftone_starttime
            elif shift == "B":
                shift_total_time = shifttwo_endtime - shifttwo_starttime
            elif shift == "C":
                if shiftthree_endtime < shiftthree_starttime:
                    shift_total_time = (shiftthree_endtime + 24) - shiftthree_starttime
                else:
                    shift_total_time = shiftthree_endtime - shiftthree_starttime
            else:
                shift_total_time = 0

            retime = shift_total_time - mac_hours

            ########
            if retime <= 0:
                final_hours = "Nil"
            else:
                final_hours = retime
            ########

            print("22222222222222222222")

        # print("shift_total_time:", shift_total_time, "mac_hours:", mac_hours)

        # Construct the response for the current date
        response_data.append({
            "date": date,
            "Machine": machinename,
            "Remaining_hours": final_hours
        })

        return JsonResponse(response_data, safe=False)

    return JsonResponse({"status": "failed"}, status=400)
#ji


# @csrf_exempt
# def calendertime(request):
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']

#         data = json.loads(request.body)

#         date = data['sp_date']

#         # Cache machine names and shift timings
#         MachinenamesArray = machineArray(Plantname)

#         ##########################################################################################
#         shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
#             'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
#         ).last()

#         # Access each shift time correctly from the dictionary
#         shiftone_starttime = shift_times['shift1start'].hour
#         print("shift 1 start:", shiftone_starttime)
#         shiftone_endtime = shift_times['shift1end'].hour
#         print("shift 1 end:", shiftone_endtime)
#         shifttwo_starttime = shift_times['shift2start'].hour
#         print("shift 2 start:", shifttwo_starttime)
#         shifttwo_endtime = shift_times['shift2end'].hour
#         print("shift 2 end:", shifttwo_endtime)
#         shiftthree_starttime = shift_times['shift3start'].hour
#         print("shift 3 start:", shiftthree_starttime)
#         shiftthree_endtime = shift_times['shift3end'].hour
#         print("shift 3 end:", shiftthree_endtime)

#         response_data = []

#         today_date = datetime.strptime(date, "%Y-%m-%d")  # Replace with dynamic date
#         startdate = today_date.replace(day=1)
#         enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
#         total_days = (enddate - startdate).days + 1

#         startdate_str = startdate.strftime('%Y-%m-%d')
#         enddate_str = enddate.strftime('%Y-%m-%d')
#         ################################################################
#         all_aggregated_data = ShiftProductiondata.objects.filter(
#                     sp_date__range=[startdate_str, enddate_str],
#                     sp_plantname=Plantname,
#                     sp_machinename__in=MachinenamesArray
#                 ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift').order_by('sp_id')


#         for day_offset in range(total_days):
#             current_date = startdate + timedelta(days=day_offset)
#             current_date_str = current_date.strftime('%Y-%m-%d')

#             current_day = current_date.strftime('%A')

#             for select_machine in MachinenamesArray:
                
#                 remaining_time = [r for r in all_aggregated_data if
#                                   r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str]

#                 shift_list = ["A", "B", "C"]
#                 remaining_hours_list = []

#                 bool_list = []


#                 for shift in shift_list:

#                     if not remaining_time:
#                         mac_hours = 0
#                     else:
#                         mac_hours = sum(r['sp_totalproductiontime'] for r in remaining_time if r['sp_shift'] == shift)

#                     if shift == "A":
#                         shift_total_time = shiftone_endtime - shiftone_starttime
#                     elif shift == "B":
#                         shift_total_time = shifttwo_endtime - shifttwo_starttime
#                     elif shift == "C":
#                         if shiftthree_endtime < shiftthree_starttime:
#                             shift_total_time = (shiftthree_endtime + 24) - shiftthree_starttime
#                         else:
#                             shift_total_time = shiftthree_endtime - shiftthree_starttime
#                     else:
#                         shift_total_time = 0  

#                     retime = shift_total_time - mac_hours
                    
#                     ########
#                     if retime < 0:
#                         final_hours = 0
#                     else:
#                         final_hours = retime
#                     ########
#                     if final_hours > 0:
#                         insert = 1
#                     else:
#                         insert = 0

#                     # print("######################################################################")
#                     remaining_hours_list.append(final_hours)
#                     bool_list.append(insert)

#                 # Add the result for the current machine
#                 response_data.append({
#                     "date": current_date_str,
#                     "day": current_day,
#                     "Machine": select_machine,
#                     "Shift": shift_list,
#                     "Remaining_hours": remaining_hours_list,
#                     "Count": bool_list
#                 })

#         return JsonResponse(response_data, safe=False)

#     return JsonResponse({"status": "failed"}, status=400)
@csrf_exempt
def calendertime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        date = data['sp_date']

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        shiftone_starttime = shift_times['shift1start'].hour
        shiftone_endtime = shift_times['shift1end'].hour
        shifttwo_starttime = shift_times['shift2start'].hour
        shifttwo_endtime = shift_times['shift2end'].hour
        shiftthree_starttime = shift_times['shift3start'].hour
        shiftthree_endtime = shift_times['shift3end'].hour

        response_data = []

        today_date = datetime.strptime(date, "%Y-%m-%d")
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        total_days = (enddate - startdate).days + 1

        startdate_str = startdate.strftime('%Y-%m-%d')
        enddate_str = enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
            sp_date__range=[startdate_str, enddate_str],
            sp_plantname=Plantname,
            sp_machinename__in=MachinenamesArray
        ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift').order_by('sp_id')

        for day_offset in range(total_days):
            current_date = startdate + timedelta(days=day_offset)
            current_date_str = current_date.strftime('%Y-%m-%d')
            current_day = current_date.strftime('%A')

            # Initialize shift counters for free machines
            shift_free_machines = {"Shift_A": 0, "Shift_B": 0, "Shift_C": 0}

            day_data = []

            for select_machine in MachinenamesArray:
                remaining_time = [r for r in all_aggregated_data if
                                  r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str]

                shift_list = ["A", "B", "C"]
                remaining_hours_list = []
                shift_count = {}

                for shift in shift_list:
                    if not remaining_time:
                        mac_hours = 0
                    else:
                        mac_hours = sum(r['sp_totalproductiontime'] for r in remaining_time if r['sp_shift'] == shift)

                    if shift == "A":
                        shift_total_time = shiftone_endtime - shiftone_starttime
                    elif shift == "B":
                        shift_total_time = shifttwo_endtime - shifttwo_starttime
                    elif shift == "C":
                        if shiftthree_endtime < shiftthree_starttime:
                            shift_total_time = (shiftthree_endtime + 24) - shiftthree_starttime
                        else:
                            shift_total_time = shiftthree_endtime - shiftthree_starttime
                    else:
                        shift_total_time = 0  

                    retime = shift_total_time - mac_hours
                    final_hours = max(retime, 0)

                    remaining_hours_list.append(final_hours)

                    # Count free machines per shift
                    if final_hours > 0:
                        shift_free_machines[f"Shift_{shift}"] += 1

                day_data.append({
                    "date": current_date_str,
                    "day": current_day,
                    "Machine": select_machine,
                    "Shift": shift_list,
                    "Remaining_hours": remaining_hours_list
                })

            # Append shift counts to each machine entry for the day
            for machine_entry in day_data:
                machine_entry.update(shift_free_machines)
                response_data.append(machine_entry)

        return JsonResponse(response_data, safe=False)

    return JsonResponse({"status": "failed"}, status=400)



@csrf_exempt
def materials(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        data = json.loads(request.body)

        mould = data['sp_mouldname']

        response_data = []
        ##########################################################################################

        all_mould_data = Mouldmodel.objects.filter(
                Plantname=Plantname,
                Mouldname=mould
            ).values_list('Material', flat=True).order_by('id')

        # Prepare the response data
        response_data = list(all_mould_data)

        return JsonResponse(response_data, safe=False)
    
    return JsonResponse({"status": "failed"}, status=400)