from django.db.models import fields
from rest_framework import serializers
from .models import ShiftTimings, ShiftProductiondata

class ShiftTimingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftTimings
        fields = ('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end')

class ShiftproductiondataSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftProductiondata
        fields = '__all__'