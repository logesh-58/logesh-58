from pymodbus.client import ModbusTcpClient
from datetime import datetime
import psycopg2
import time
from pgconfig import config
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
import requests
import json

####################################################### PROCESS DATA #######################################################

def process_read_plc_values(client, ambarelzonecount, amhrtczonecount, ip):
    """
    Function to read PLC values from specified register addresses.
    """
    registerAddressList_ambarelzonecount = [404, 406, 408, 410, 412, 414, 416, 418, 420, 422, 424, 426]
    registerAddressList = [500, 7, 458, 450, 451, 461, 462, 464] #458 - 3
    hrtc_registers = [701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 
                      721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 
                      741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 
                      761, 762, 763, 764]
    
    # Initialize the list to hold all PLC values
    plc_values = [None] * (len(registerAddressList_ambarelzonecount) + len(registerAddressList) + len(hrtc_registers))

    # Read values from registerAddressList_ambarelzonecount
    for i in range(min(ambarelzonecount, len(registerAddressList_ambarelzonecount))):
        address = registerAddressList_ambarelzonecount[i]
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from registerAddressList
    for i, address in enumerate(registerAddressList):
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from hrtc_registers
    for i in range(min(amhrtczonecount, len(hrtc_registers))):
        address = hrtc_registers[i]
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + len(registerAddressList) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    return plc_values

#################################################### PRODUCTION DATA ####################################################

def read_plc_values(client, plc_address):

    registerAddressList = [650,222,201,700,262,702,263,2008,265,230,264]
    arr1 = []; arr2 = []
    for address in registerAddressList:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr1.append(response.registers[0])
        except:
            continue
    
    registerAddress_breakdown = [222, 7992, 650]
    for address in registerAddress_breakdown:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr2.append(response.registers[0])
        except:
            continue
    
    arr3 = []
    registerAddress_oilfilterclog = [6000, 6001, 6008, 6006, 6004]
    for address in registerAddress_oilfilterclog:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr3.append(response.registers[0])
        except:
            continue

    arr4 = []
    registerAddress_badparts = [230,7992,650,264]
    for address in registerAddress_badparts:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr4.append(response.registers[0])
        except:
            continue

    return arr1, arr2, arr3, arr4

#################################################### REST  CODE #####################################################

def write_plc_values(client, plc_address):
    registerAddressList = [700, 262, 702, 263, 2008, 265, 230]  # List of register addresses
    write_data = 0  # Value to write

    try:
        for register in registerAddressList:
            response = client.write_register(register, write_data)  # Writing 0 to each register separately
            if response.isError():
                print(f"Error writing to PLC at {ip}, address {register}: {response}")
            else:
                print(f"Written successfully to PLC at {ip}, address {register}: {response}")
    except Exception as e:
        print(f"Exception during write to PLC at {ip}: {e}")

# Initialize a flag to track execution
execution_done = False


while True:

    # url = "http://65.2.44.34:8000/machinemanagement/"
    url = "http://127.0.0.1:8000/machinemanagement/"
    headers = {
        "Content-Type": "application/json",
        "XRequest": "test"
    }
    params = {
        "Plantname": "MATE U1"
    }
    try:
        response = requests.get(url, headers=headers, params=params)  # Send Plantname as a parameter
        if response.status_code == 200:
            data = response.json()  # Assuming the response is in JSON format

            # Convert JSON data to a list of tuples
            getIPaddress = [tuple(item.values()) for item in data]

            # print(getIPaddress)  # Print to verify the output
        else:
            print(f"Error: {response.status_code}, {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")



    url = "http://127.0.0.1:8000/shifttime/"
    # url = "http://65.2.44.34:8000/shifttime/"
    headers = {
        "Content-Type": "application/json",
        "XRequest": "test"
    }
    params = {
        "Plantname": "MATE U1"
    }

    try:
        # Send request to get shift times
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            shift_times_data = response.json()  # Convert response to JSON
            
            if isinstance(shift_times_data, list) and shift_times_data:  # Ensure it's a non-empty list
                shift_times_dict = shift_times_data[0]  # Extract first dictionary

                # Extract shift end times
                shift_times = [
                    shift_times_dict.get("shift1end"),
                    shift_times_dict.get("shift2end"),
                    shift_times_dict.get("shift3end")
                ]

                shift_times = [t for t in shift_times if t]

                # Convert shift times to string format
                shift_times = [datetime.strptime(t, '%H:%M:%S').strftime('%H:%M:%S') for t in shift_times]

                current_time = datetime.now().strftime('%H:%M:%S')  # Corrected time format

                if not execution_done and current_time in shift_times:
                    for ip in getIPaddress:
                        client = ModbusTcpClient(ip[7], port=502)
                        if client.connect():
                            write_plc_values(client, ip[7])
                            print('Data Resetted For:', ip[2])
                            client.close()
                        else:
                            print('Error: Client is not connected to', ip[7])

                    # Mark the execution as done
                    execution_done = True

                elif execution_done and current_time not in shift_times:
                    # Reset flag when the time no longer matches any shift time
                    execution_done = False
            else:
                print("Error: No shift timings found in the response")

        else:
            print(f"Error: {response.status_code} - {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")

    except Exception as e:
        print(f"Unexpected error: {e}")

    
    for ip in getIPaddress:
            
        ambarelzonecount = int(ip[8])  # Convert ambarelzonecount to integer
        amhrtczonecount = int(ip[9])

        client = ModbusTcpClient(ip[7], port = 502)

        plant_name = ip[1]

        machine_name = ip[2]

        if client.connect():
            StringArr = []; Break_Down = []; curr_date = datetime.strftime(datetime.now(), '%Y-%m-%d'); curr_time = datetime.strftime(datetime.now(), '%H:%M:%S') 
            Break_Down.append(str(curr_date)); Break_Down.append(str(curr_time))
            StringArr = []
            plcResponsne, plcresponse_breakdown, plcresponse_maintenance, plcresponse_badpart = read_plc_values(client, ip[7])


            process_plc_response = process_read_plc_values(client, ambarelzonecount, amhrtczonecount, ip[7])
            java = len(process_plc_response)
            if len(process_plc_response) < 84:
                process_plc_response += [None] * (84 - len(process_plc_response))
            data_to_insert = [plant_name, machine_name] + process_plc_response + [curr_date, curr_time]
            print('Modbus Process Data: ', data_to_insert)


            len_list1 = plcResponsne; len_list2 = plcresponse_breakdown; len_list3 = plcresponse_maintenance; len_list4 = plcresponse_badpart
            StringArr.append(ip[1])
            StringArr.append(ip[2])
            Break_Down.append(ip[1])
            Break_Down.append(ip[2])
            StringArr += plcResponsne
            dashboardArr = StringArr + [str(datetime.now().time())]
            StringArr += [str(curr_date), str(curr_time)]
            print('Modbus Production Data: ', StringArr)

            print('__________________________________________________________________________________________________________')

            url = "http://127.0.0.1:8000/datamaster/"
            # url = "http://65.2.44.34:8000/datamaster/"
            headers = {
                "Content-Type": "application/json",
                "XRequest": "test"
            }

            try:
                process_data = {
                            "Name": "Process Module data",
                            "Plantname": data_to_insert[0],
                            "Machinename": data_to_insert[1],
                            "BarelTempZ1": data_to_insert[2],
                            "BarelTempZ2": data_to_insert[3],
                            "BarelTempZ3": data_to_insert[4],
                            "BarelTempZ4": data_to_insert[5],
                            "BarelTempZ5": data_to_insert[6],
                            "BarelTempZ6": data_to_insert[7],
                            "BarelTempZ7": data_to_insert[8],
                            "BarelTempZ8": data_to_insert[9],
                            "BarelTempZ9": data_to_insert[10],
                            "BarelTempZ10": data_to_insert[11],
                            "BarelTempZ11": data_to_insert[12],
                            "BarelTempZ12": data_to_insert[13],
                            "airInletPressureGuage": data_to_insert[14],
                            "hopperMaterialLevel": data_to_insert[15],
                            "hopperTemperature": data_to_insert[16],
                            "MTC": data_to_insert[17],
                            "CWIP": data_to_insert[18],
                            "CWOP": data_to_insert[19],
                            "CWIT": data_to_insert[20],
                            "CWOT": data_to_insert[21],
                            "HRTC1": data_to_insert[22],
                            "HRTC2": data_to_insert[23],
                            "HRTC3": data_to_insert[24],
                            "HRTC4": data_to_insert[25],
                            "HRTC5": data_to_insert[26],
                            "HRTC6": data_to_insert[27],
                            "HRTC7": data_to_insert[28],
                            "HRTC8": data_to_insert[29],
                            "HRTC9": data_to_insert[30],
                            "HRTC10": data_to_insert[31],
                            "HRTC11": data_to_insert[32],
                            "HRTC12": data_to_insert[33],
                            "HRTC13": data_to_insert[34],
                            "HRTC14": data_to_insert[35],
                            "HRTC15": data_to_insert[36],
                            "HRTC16": data_to_insert[37],
                            "HRTC17": data_to_insert[38],
                            "HRTC18": data_to_insert[39],
                            "HRTC19": data_to_insert[40],
                            "HRTC20": data_to_insert[41],
                            "HRTC21": data_to_insert[42],
                            "HRTC22": data_to_insert[43],
                            "HRTC23": data_to_insert[44],
                            "HRTC24": data_to_insert[45],
                            "HRTC25": data_to_insert[46],
                            "HRTC26": data_to_insert[47],
                            "HRTC27": data_to_insert[48],
                            "HRTC28": data_to_insert[49],
                            "HRTC29": data_to_insert[50],
                            "HRTC30": data_to_insert[51],
                            "HRTC31": data_to_insert[52],
                            "HRTC32": data_to_insert[53],
                            "HRTC33": data_to_insert[54],
                            "HRTC34": data_to_insert[55],
                            "HRTC35": data_to_insert[56],
                            "HRTC36": data_to_insert[57],
                            "HRTC37": data_to_insert[58],
                            "HRTC38": data_to_insert[59],
                            "HRTC39": data_to_insert[60],
                            "HRTC40": data_to_insert[61],
                            "HRTC41": data_to_insert[62],
                            "HRTC42": data_to_insert[63],
                            "HRTC43": data_to_insert[64],
                            "HRTC44": data_to_insert[65],
                            "HRTC45": data_to_insert[66],
                            "HRTC46": data_to_insert[67],
                            "HRTC47": data_to_insert[68],
                            "HRTC48": data_to_insert[69],
                            "HRTC49": data_to_insert[70],
                            "HRTC50": data_to_insert[71],
                            "HRTC51": data_to_insert[72],
                            "HRTC52": data_to_insert[73],
                            "HRTC53": data_to_insert[74],
                            "HRTC54": data_to_insert[75],
                            "HRTC55": data_to_insert[76],
                            "HRTC56": data_to_insert[77],
                            "HRTC57": data_to_insert[78],
                            "HRTC58": data_to_insert[79],
                            "HRTC59": data_to_insert[80],
                            "HRTC60": data_to_insert[81],
                            "HRTC61": data_to_insert[82],
                            "HRTC62": data_to_insert[83],
                            "HRTC63": data_to_insert[84],
                            "HRTC64": data_to_insert[85],
                            "date": data_to_insert[86],
                            "time": data_to_insert[87]
                            }

                try:
                    response = requests.post(url, headers=headers, json=process_data, timeout=10)  # Timeout in seconds
                    response.raise_for_status()  # Raises an error for non-2xx responses
                except requests.exceptions.Timeout:
                    print("Request timed out. Retrying...")
                except requests.exceptions.RequestException as e:
                    print(f"Request failed: {e}")

            except Exception as e:
                print(f"Error inserting or updating data in database: {e}")


            if len(len_list1) >= 11 :

                ########################################   Dashboard & Production Table ##############################################

                dashboard_array = dashboardArr + [True]
                
                # dashboard_data = {
                #                 "Name": "Production data",
                #                 "Plantname": dashboard_array[0],
                #                 "Machinename": dashboard_array[1],
                #                 "Mouldname_id": dashboard_array[2],
                #                 "MachineState": dashboard_array[3],
                #                 "Alarm": dashboard_array[4],
                #                 "ProductionCountActual": dashboard_array[5],
                #                 "ProductionCountSet": dashboard_array[6],
                #                 "CycletimeActual": dashboard_array[7],
                #                 "CycletimeSet": dashboard_array[8],
                #                 "ProductionTimeActual": dashboard_array[9],
                #                 "ProductionTimeTotal": dashboard_array[10],
                #                 "RejectionParts": dashboard_array[11],
                #                 "Cavity": dashboard_array[12],
                #                 "datetime": dashboard_array[13],
                #                 "machinestatus": dashboard_array[14]
                #                 }
                # response = requests.post(url, headers=headers, json=dashboard_data)

                production_data = {
                                "Name": "Production data",
                                "Plantname": StringArr[0],
                                "Machinename": StringArr[1],
                                "Mouldname_id": StringArr[2],
                                "MachineState": StringArr[3],
                                "Alarm": StringArr[4],
                                "ProductionCountActual": StringArr[5],
                                "ProductionCountSet": StringArr[6],
                                "CycletimeActual": StringArr[7],
                                "CycletimeSet": StringArr[8],
                                "ProductionTimeActual": StringArr[9],
                                "ProductionTimeTotal": StringArr[10],
                                "RejectionParts": StringArr[11],
                                "Cavity": StringArr[12],
                                "date": StringArr[13],
                                "time": StringArr[14],
                                "datetime": dashboard_array[13],
                                "machinestatus": dashboard_array[14]
                                }

                try:
                    response = requests.post(url, headers=headers, json=production_data, timeout=10)  # Timeout in seconds
                    response.raise_for_status()  # Raises an error for non-2xx responses
                except requests.exceptions.Timeout:
                    print("Request timed out. Retrying...")
                except requests.exceptions.RequestException as e:
                    print(f"Request failed: {e}")

            if len(len_list2) >= 3 :
                ########################################   Break Down Table ##############################################
                Master_Break = Break_Down+plcresponse_breakdown
                breakdown_data = {
                                "Name": "Breakdown data",
                                "date": Master_Break[0],
                                "time": Master_Break[1],
                                "Plantname": Master_Break[2],
                                "Machinename": Master_Break[3],
                                "MachineState": Master_Break[4],
                                "primaryreason": Master_Break[5],
                                "Mouldname_id": Master_Break[6]
                                }

                try:
                    response = requests.post(url, headers=headers, json=breakdown_data, timeout=10)  # Timeout in seconds
                    response.raise_for_status()  # Raises an error for non-2xx responses
                except requests.exceptions.Timeout:
                    print("Request timed out. Retrying...")
                except requests.exceptions.RequestException as e:
                    print(f"Request failed: {e}")

            if len(len_list3) >= 5:
                ######################################## Maintenance Table ##############################################
                maintenance_data = {
                                    "Name": "Maintenance data",
                                    "mnt_date": curr_date,
                                    "mnt_time": curr_time,
                                    "mnt_machinename": machine_name,
                                    "mnt_oilfilter_clogge": plcresponse_maintenance[0],
                                    "mnt_lubrication": plcresponse_maintenance[1],
                                    "mnt_hydraulic": plcresponse_maintenance[2],
                                    "mnt_pumpstatus": plcresponse_maintenance[3],
                                    "mnt_oilfilter_motor": plcresponse_maintenance[4]
                                    }

                try:
                    response = requests.post(url, headers=headers, json=maintenance_data, timeout=10)  # Timeout in seconds
                    response.raise_for_status()  # Raises an error for non-2xx responses
                except requests.exceptions.Timeout:
                    print("Request timed out. Retrying...")
                except requests.exceptions.RequestException as e:
                    print(f"Request failed: {e}")

            if len(len_list4) >= 4:
                ########################################   Badpart Table ##############################################
                data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                badpart_data = {
                                "Name": "Badpart data",
                                "date": data_to_insert[0],
                                "time": data_to_insert[1],
                                "Plantname": data_to_insert[2],
                                "Machinename": data_to_insert[3],
                                "partcount": data_to_insert[4],
                                "reason": data_to_insert[5],
                                "Mouldname_id": data_to_insert[6],
                                "Cavity": data_to_insert[7]
                                }

                try:
                    response = requests.post(url, headers=headers, json=badpart_data, timeout=10)  # Timeout in seconds
                    response.raise_for_status()  # Raises an error for non-2xx responses
                except requests.exceptions.Timeout:
                    print("Request timed out. Retrying...")
                except requests.exceptions.RequestException as e:
                    print(f"Request failed: {e}")
            
            client.close()    
        else:

            dashboard_array = [plant_name, machine_name, False]
                            
            dashboard_data = {
                            "Name": "Update Dashboard data",
                            "Plantname": dashboard_array[0],
                            "Machinename": dashboard_array[1],
                            "machinestatus": dashboard_array[2]
                            }
            
            try:
                response = requests.post(url, headers=headers, json=dashboard_data, timeout=10)  # Timeout in seconds
                response.raise_for_status()  # Raises an error for non-2xx responses
            except requests.exceptions.Timeout:
                print("Request timed out. Retrying...")
            except requests.exceptions.RequestException as e:
                print(f"Request failed: {e}")

            print(f'Error : {ip[7]} : {ip[2]} - Client is not connected')

            print('__________________________________________________________________________________________________________')

    # time.sleep(5)
