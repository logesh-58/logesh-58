from pymodbus.client import ModbusTcpClient
from datetime import datetime
import psycopg2
import time
from pgconfig import config
from pymodbus.exceptions import ModbusException
from psycopg2.extras import execute_values


# Database connection setup
params = config()
conn = psycopg2.connect(**params)
cur = conn.cursor()


def write_plc_values(client, plc_address):
    registerAddressList = [700, 230, 226]  # List of register addresses
    write_data = 0  # Value to write

    try:
        for register in registerAddressList:
            response = client.write_register(register, write_data)  # Writing 0 to each register separately
            if response.isError():
                print(f"Error writing to PLC at {ip}, address {register}: {response}")
            else:
                print(f"Written successfully to PLC at {ip}, address {register}: {response}")
    except Exception as e:
        print(f"Exception during write to PLC at {ip}: {e}")

# Initialize a flag to track execution
execution_done = False

while True:
    cur.execute("SELECT shift1end, shift2end, shift3end FROM public.shiftmanagement_shifttimings")
    shift_times = cur.fetchone()  # Fetch only one row

    if shift_times:
        # Convert shift times to string format
        shift_times = [t.strftime('%H:%M:%S') for t in shift_times if t]

        current_time = datetime.now().strftime('%H:%M:%S')  # Corrected time format

        if not execution_done and current_time in shift_times:
            ip = "192.168.3.51"
            client = ModbusTcpClient(ip, port=502)
            if client.connect():
                write_plc_values(client, ip)
                client.close()
            else:
                print('Error: Client is not connected to', ip)

        # Mark the execution as done
            execution_done = True

        elif execution_done and current_time not in shift_times:
            # Reset flag when the time no longer matches any shift time
            execution_done = False

    else:
        print("Error: No shift timings found in the database")