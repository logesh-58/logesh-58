from pymodbus.client import ModbusTcpClient
from datetime import datetime
import psycopg2
import time
from pgconfig import config
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders

params = config()
conn = psycopg2.connect(**params)
cur = conn.cursor()

# machineQuery = ('SELECT "amPlantname", "amMachinename", ammachineip FROM public.machinemanagement_addmachine' )
# cur.execute(machineQuery)
# getIPaddress = cur.fetchall()

def sendmail(machinename, parameters):
    param = None
    if parameters == 'mnt_oilfilter_clogge':
        param = ' Oil Filter is Clogged '
    elif parameters == 'mnt_lubrication':
        param = ' Lubrication Oil Level is Dropped '
    elif parameters == 'mnt_hydraulic':
        param = ' Hydraulic Oil Level is Dropped '
    # elif parameters == 'mnt_pumpstatus':
        # param = ' Main Motor is Powered OFF '
    print("Report generating")
    tomail='Gokul.Annadurai@motherson.com'
    sub='RConnect Alarm : ' + param 
    message = '''Dear Team, <br> 
                    <br> 
                     The '''+ param + ''' in the ''' + machinename + ''' machine. 
                      Please check it.  
                    <br>
                    <br>
                Regards, <br>
                R-Connect Team. 
                <br>
                <br> 
                Note: This is an system generated mail.'''
    msg = MIMEMultipart('alternative')
    msg['Subject'] = sub
    msg['From'] = "R-Connect <no-reply@rconnect.com>"
    msg['To'] = tomail
    part2 = MIMEText(message, 'html')
    msg.attach(part2)
    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
    smtpObj.sendmail('R-Connect <no-reply@rconnect.com>',tomail.split(';'),msg.as_string())
    smtpObj.quit()
    print('Mail send successfully')
    print("Mail Sent to ",tomail)
    return 'Mail Sent'

def read_plc_values(client, plc_address):

    registerAddressList = [650,222,201,700,262,702,263,2008,265,230,264]
    arr1 = []; arr2 = []
    for address in registerAddressList:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr1.append(response.registers[0])
        except:
            continue
    
    registerAddress_breakdown = [222, 7992, 650]
    for address in registerAddress_breakdown:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr2.append(response.registers[0])
        except:
            continue
    
    arr3 = []
    registerAddress_oilfilterclog = [{"mnt_oilfilter_clogge":6000}, {"mnt_lubrication":6001}, {"mnt_hydraulic":6008}, {"mnt_pumpstatus":6006}, {"mnt_oilfilter_motor":6004}]
    for address in registerAddress_oilfilterclog:
        try:
            response = client.read_holding_registers(list(address.values())[0])
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr3.append({str(list(address.keys())[0]):response.registers[0]})
        except:
            continue

    arr4 = []
    registerAddress_badparts = [230,7992,650]
    for address in registerAddress_badparts:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr4.append(response.registers[0])
        except:
            continue

    return arr1, arr2, arr3, arr4


while True:
    insertQuery = ('INSERT INTO productiontable_productiontable("Plantname","Machinename","Mouldname_id","MachineState","Alarm","ProductionCountActual","ProductionCountSet","CycletimeActual","CycletimeSet","ProductionTimeActual","ProductionTimeTotal","RejectionParts","Cavity","date","time") VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)')
    dashboard_Query = 'INSERT INTO dashboard_dashboard("Plantname","Machinename","Mouldname_id","MachineState","Alarm","ProductionCountActual","ProductionCountSet","CycletimeActual","CycletimeSet","ProductionTimeActual","ProductionTimeTotal","RejectionParts","Cavity","datetime", "machinestatus") VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
    breakdown_Query = 'INSERT INTO timeline_breakdown(date, "time", "Plantname", "Machinename", "MachineState", primaryreason, "Mouldname_id") VALUES(%s,%s,%s,%s,%s,%s,%s)'
    
    badpart_Query = ('INSERT INTO timeline_badpart(date,"time", "Plantname","Machinename",partcount,reason,"Mouldname_id") VALUES(%s,%s,%s,%s,%s,%s,%s)')
    
    machineQuery = ('SELECT "amPlantname", "amMachinename", ammachineip FROM public.machinemanagement_addmachine' )
    cur.execute(machineQuery)
    getIPaddress = cur.fetchall()
    
    for ip in getIPaddress:
            print(ip)
            client = ModbusTcpClient(ip[2], port = 502)

            plant_name = ip[0]
            # print(plant_name)
            machine_name = ip[1]
            # print(machine_name)

            if client.connect():
                StringArr = []; Break_Down = []; curr_date = datetime.strftime(datetime.now(), '%Y-%m-%d'); curr_time = datetime.strftime(datetime.now(), '%H:%M:%S') 
                Break_Down.append(str(curr_date)); Break_Down.append(str(curr_time))
                StringArr = []
                plcResponsne, plcresponse_breakdown, plcresponse_maintenance, plcresponse_badpart = read_plc_values(client, ip[2])
                len_list1 = plcResponsne; len_list2 = plcresponse_breakdown; len_list3 = plcresponse_maintenance; len_list4 = plcresponse_badpart
                StringArr.append(ip[0])
                StringArr.append(ip[1])
                Break_Down.append(ip[0])
                Break_Down.append(ip[1])
                StringArr += plcResponsne
                dashboardArr = StringArr + [str(datetime.now().time())]
                StringArr += [str(curr_date), str(curr_time)]
                # print('Modbus Data: ', StringArr)
                # Get MachineLastData
                # print('len_list2:', len_list2)
                if len(len_list1) >= 11 :
                    try:
                    #############################################################################################################################################################
                        getQuery = ('SELECT "ProductionCountActual", "Mouldname_id" FROM public.productiontable_productiontable where "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                        getLastData = cur.execute(getQuery)
                        getLastData = cur.fetchone()
                        if((plcResponsne[3] != getLastData[0]) or (plcResponsne[0] != getLastData[1])):
                            maxs = plcResponsne[6] * 2
                            print("plcResponsne:", plcResponsne[6], "maxs:", maxs)
                            if plcResponsne[5] <= maxs:
                                dashboard_array = dashboardArr + [True]
                                cur.execute(insertQuery,StringArr)
                                cur.execute(dashboard_Query, dashboard_array)
                                conn.commit()
                                print('Data Inserted for machine ',ip[1])
                    except:
                        if StringArr[2] != 0:
                            cur.execute(insertQuery,StringArr)
                            cur.execute(dashboard_Query, dashboard_array)  ####### needed
                            conn.commit()
                        else:
                            pass
                if len(len_list2) >= 3 :
                    ########################################   Break Down Table ##############################################
                    try:
                        getbreakdown_Query =  ('SELECT "MachineState", primaryreason, date FROM public.timeline_breakdown where "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                        getLastData_breakdown = cur.execute(getbreakdown_Query)
                        getLastData_breakdown = cur.fetchone()
                        if getLastData_breakdown[2] == curr_date:
                            if (plcresponse_breakdown[0] == getLastData_breakdown[0] and plcresponse_breakdown[1] == getLastData_breakdown[1]):
                                # print('moulding1111')
                                pass
                                
                            else:
                                cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                                conn.commit()
                                # print('moulding2222')
                        else:
                            cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                            conn.commit()
                            # print('moulding3333')
                    except:
                        if plcresponse_breakdown[2] != 0:
                            cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                            conn.commit()
                            # print('moulding4444')
                        else:
                            # print('moulding5555')
                            pass
                if len(len_list3) >= 5:
                    for dict_ in plcresponse_maintenance:
                        print(dict_)
                        if list(dict_.values())[0] == 0:
                            getmaintenance = 'select ' + str(list(dict_.keys())[0])+' from public.maintenance_maintenance_module where mnt_date = %s and mnt_machinename = %s'
                            try:
                                cur.execute(getmaintenance, (curr_date, ip[1]))
                                maintenance_data = cur.fetchone()
                                if maintenance_data[0] == 1:
                                    updateQuery = 'update public.maintenance_maintenance_module set '+ str(list(dict_.keys())[0]) +' = %s where mnt_date = %s and mnt_machinename = %s'
                                    cur.execute(updateQuery, (maintenance_data[0],curr_date, ip[1]))
                                    conn.commit()
                            except:
                                if str(list(dict_.keys())[0]) not in ['mnt_pumpstatus', 'mnt_oilfilter_motor']:
                                    maintenance_insertQuery = 'insert into public.maintenance_maintenance_module (mnt_date, mnt_machinename, mnt_time, ' + str(list(dict_.keys())[0]) +') values(%s, %s, %s, %s)'
                                    cur.execute(maintenance_insertQuery, (curr_date, ip[1], str(curr_time), list(dict_.values())[0]))
                                    conn.commit()
                if len(len_list4) >= 3:
                    ########################################   Break Down Table ##############################################
                    try:
                        getQuery = ('SELECT partcount, "Mouldname_id", date FROM public.timeline_badpart '
                                    'WHERE "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                        cur.execute(getQuery) 
                        getLastData = cur.fetchone()
                        # if getLastData[2] == curr_date:
                        if (plcresponse_badpart[0] != getLastData[0] or plcresponse_badpart[2] != getLastData[1]):
                            data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                            cur.execute(badpart_Query, data_to_insert)
                            conn.commit()
                                # print('Data successfully inserted for bad parts')
                            # else:
                            #     print('Data not inserted for bad parts')
                        # else:
                        #     # print('Date not matched')
                        #     data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                        #     cur.execute(badpart_Query, data_to_insert)
                        #     conn.commit()

                    except Exception as e:
                        # print(f"Error inserting or updating data in database: {e}")
                        # conn.rollback()  # Rollback to reset the transaction state
                        data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                        cur.execute(badpart_Query, data_to_insert)
                        conn.commit()
                
                client.close()    
            else:
                getQuery = 'SELECT ID FROM dashboard_dashboard WHERE "Machinename" = ' + "'"+ip[1]+"'"+' LIMIT 1'
                getLastData = cur.execute(getQuery)
                getLastData = cur.fetchone()
                dashboard_Q = "UPDATE dashboard_dashboard SET machinestatus = %s where id = %s "
                data = cur.execute(dashboard_Q, ('false', str(getLastData[0])))
                conn.commit()
                print('Error :', 'Client is not connected')
    time.sleep(5)