from pymodbus.client import ModbusTcpClient
from datetime import datetime
import psycopg2
import time
from pgconfig import config
#time
from pymodbus.exceptions import ModbusException
from psycopg2.extras import execute_values
# mail packages
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders

#--------------------------

params = config()
conn = psycopg2.connect(**params)
cur = conn.cursor()

# print("Machine names and IP addresses fetched from the database.")
# print("*********************************************")

def read_plc_values(client, ambarelzonecount, amhrtczonecount, ip):
    """
    Function to read PLC values from specified register addresses.
    """
    registerAddressList_ambarelzonecount = [404, 406, 408, 410, 412, 414, 416, 418, 420, 422, 424, 426]
    registerAddressList = [500, 7, 458, 450, 451, 461, 462, 464] #458 - 3
    hrtc_registers = [701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 
                      721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 
                      741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 
                      761, 762, 763, 764]
    
    # Initialize the list to hold all PLC values
    plc_values = [None] * (len(registerAddressList_ambarelzonecount) + len(registerAddressList) + len(hrtc_registers))

    # Read values from registerAddressList_ambarelzonecount
    for i in range(min(ambarelzonecount, len(registerAddressList_ambarelzonecount))):
        address = registerAddressList_ambarelzonecount[i]
        try:
            response = client.read_holding_registers(address, 1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from registerAddressList
    for i, address in enumerate(registerAddressList):
        try:
            response = client.read_holding_registers(address, 1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from hrtc_registers
    for i in range(min(amhrtczonecount, len(hrtc_registers))):
        address = hrtc_registers[i]
        try:
            response = client.read_holding_registers(address, 1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + len(registerAddressList) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    return plc_values

def record_exists(plant_name, machine_name):
    cur.execute('SELECT 1 FROM process_module_process_modulelive WHERE "Plantname"=%s AND "Machinename"=%s', (plant_name, machine_name))
    return cur.fetchone() is not None

while True:
    process_module_insert_query = '''
        INSERT INTO process_module_process_module(
            "Plantname", "Machinename", "BarelTempZ1", "BarelTempZ2", "BarelTempZ3", "BarelTempZ4", "BarelTempZ5", "BarelTempZ6", "BarelTempZ7", "BarelTempZ8", "BarelTempZ9", "BarelTempZ10", "BarelTempZ11", "BarelTempZ12", "airInletPressureGuage", "hopperMaterialLevel", "hopperTemperature", "MTC", "CWIP", "CWOP", "CWIT", "CWOT", "HRTC1", "HRTC2", "HRTC3", "HRTC4", "HRTC5", "HRTC6", "HRTC7", "HRTC8", "HRTC9", "HRTC10", "HRTC11", "HRTC12", "HRTC13", "HRTC14", "HRTC15", "HRTC16", "HRTC17", "HRTC18", "HRTC19", "HRTC20", "HRTC21", "HRTC22", "HRTC23", "HRTC24", "HRTC25", "HRTC26", "HRTC27", "HRTC28", "HRTC29", "HRTC30", "HRTC31", "HRTC32", "HRTC33", "HRTC34", "HRTC35", "HRTC36", "HRTC37", "HRTC38", "HRTC39", "HRTC40", "HRTC41", "HRTC42", "HRTC43", "HRTC44", "HRTC45", "HRTC46", "HRTC47", "HRTC48", "HRTC49", "HRTC50", "HRTC51", "HRTC52", "HRTC53", "HRTC54", "HRTC55", "HRTC56", "HRTC57", "HRTC58", "HRTC59", "HRTC60", "HRTC61", "HRTC62", "HRTC63", "HRTC64", "date", "time"
        ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''
    
    process_module_update_query = '''
        UPDATE process_module_process_modulelive
        SET "BarelTempZ1"=%s, "BarelTempZ2"=%s, "BarelTempZ3"=%s, "BarelTempZ4"=%s, "BarelTempZ5"=%s, "BarelTempZ6"=%s, "BarelTempZ7"=%s, "BarelTempZ8"=%s, "BarelTempZ9"=%s, "BarelTempZ10"=%s, "BarelTempZ11"=%s, "BarelTempZ12"=%s, "airInletPressureGuage"=%s, "hopperMaterialLevel"=%s, "hopperTemperature"=%s, "MTC"=%s, "CWIP"=%s, "CWOP"=%s, "CWIT"=%s, "CWOT"=%s, "HRTC1"=%s, "HRTC2"=%s, "HRTC3"=%s, "HRTC4"=%s, "HRTC5"=%s, "HRTC6"=%s, "HRTC7"=%s, "HRTC8"=%s, "HRTC9"=%s, "HRTC10"=%s, "HRTC11"=%s, "HRTC12"=%s, "HRTC13"=%s, "HRTC14"=%s, "HRTC15"=%s, "HRTC16"=%s, "HRTC17"=%s, "HRTC18"=%s, "HRTC19"=%s, "HRTC20"=%s, "HRTC21"=%s, "HRTC22"=%s, "HRTC23"=%s, "HRTC24"=%s, "HRTC25"=%s, "HRTC26"=%s, "HRTC27"=%s, "HRTC28"=%s, "HRTC29"=%s, "HRTC30"=%s, "HRTC31"=%s, "HRTC32"=%s, "HRTC33"=%s, "HRTC34"=%s, "HRTC35"=%s, "HRTC36"=%s, "HRTC37"=%s, "HRTC38"=%s, "HRTC39"=%s, "HRTC40"=%s, "HRTC41"=%s, "HRTC42"=%s, "HRTC43"=%s, "HRTC44"=%s, "HRTC45"=%s, "HRTC46"=%s, "HRTC47"=%s, "HRTC48"=%s, "HRTC49"=%s, "HRTC50"=%s, "HRTC51"=%s, "HRTC52"=%s, "HRTC53"=%s, "HRTC54"=%s, "HRTC55"=%s, "HRTC56"=%s, "HRTC57"=%s, "HRTC58"=%s, "HRTC59"=%s, "HRTC60"=%s, "HRTC61"=%s, "HRTC62"=%s, "HRTC63"=%s, "HRTC64"=%s, "date"=%s, "time"=%s
        WHERE "Plantname"=%s AND "Machinename"=%s
    '''
    
    process_module_live_insert_query = '''
        INSERT INTO process_module_process_modulelive(
            "Plantname", "Machinename", "BarelTempZ1", "BarelTempZ2", "BarelTempZ3", "BarelTempZ4", "BarelTempZ5", "BarelTempZ6", "BarelTempZ7", "BarelTempZ8", "BarelTempZ9", "BarelTempZ10", "BarelTempZ11", "BarelTempZ12", "airInletPressureGuage", "hopperMaterialLevel", "hopperTemperature", "MTC", "CWIP", "CWOP", "CWIT", "CWOT", "HRTC1", "HRTC2", "HRTC3", "HRTC4", "HRTC5", "HRTC6", "HRTC7", "HRTC8", "HRTC9", "HRTC10", "HRTC11", "HRTC12", "HRTC13", "HRTC14", "HRTC15", "HRTC16", "HRTC17", "HRTC18", "HRTC19", "HRTC20", "HRTC21", "HRTC22", "HRTC23", "HRTC24", "HRTC25", "HRTC26", "HRTC27", "HRTC28", "HRTC29", "HRTC30", "HRTC31", "HRTC32", "HRTC33", "HRTC34", "HRTC35", "HRTC36", "HRTC37", "HRTC38", "HRTC39", "HRTC40", "HRTC41", "HRTC42", "HRTC43", "HRTC44", "HRTC45", "HRTC46", "HRTC47", "HRTC48", "HRTC49", "HRTC50", "HRTC51", "HRTC52", "HRTC53", "HRTC54", "HRTC55", "HRTC56", "HRTC57", "HRTC58", "HRTC59", "HRTC60", "HRTC61", "HRTC62", "HRTC63", "HRTC64", "date", "time"
        ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''

    machineQuery = 'SELECT "amPlantname", "ambarelzonecount", "amhrtczonecount", "amMachinename", "ammachineip" FROM public.machinemanagement_addmachine'
    cur.execute(machineQuery)
    getIPaddress = cur.fetchall()         ########## changed

    for ip_info in getIPaddress:
        plant_name, ambarelzonecount, amhrtczonecount, machine_name, ip = ip_info
        ambarelzonecount = int(ambarelzonecount)  # Convert ambarelzonecount to integer
        amhrtczonecount = int(amhrtczonecount)
        client = ModbusTcpClient(ip, port=502)
        if client.connect():
            curr_datetime = datetime.now()
            curr_date = curr_datetime.strftime('%Y-%m-%d')
            curr_time = curr_datetime.strftime('%H:%M:%S')
            
            plc_response = read_plc_values(client, ambarelzonecount, amhrtczonecount, ip)

            java = len(plc_response)
            print(java)
            
            # Ensure plc_response has exactly 21 elements
            if len(plc_response) < 84:
                # print("less")
                plc_response += [None] * (84 - len(plc_response))
                # print("less")
            
            # print("machine_name:", machine_name, "plc_response:", plc_response)
            data_to_insert = [plant_name, machine_name] + plc_response + [curr_date, curr_time]
            print('Modbus Data: ', data_to_insert)
            
            try:
                # Insert into process_module_process_module
                cur.execute(process_module_insert_query, data_to_insert)
                
                # Check if record exists in process_module_process_modulelive
                if record_exists(plant_name, machine_name):
                    # Update the existing record
                    cur.execute(process_module_update_query, plc_response + [curr_date, curr_time, plant_name, machine_name])
                else:
                    # Insert a new record
                    cur.execute(process_module_live_insert_query, data_to_insert)
                    
                conn.commit()
            except Exception as e:
                print(f"Error inserting or updating data in database: {e}")
            finally:
                client.close()
        else:
            print('Error: Client is not connected to', ip)
    # print("---------------------------------------------------")
    time.sleep(15)                                                       # 13.08.2024
