from pymodbus.client import ModbusTcpClient
from datetime import datetime
import psycopg2
import time
from pgconfig import config
from email.mime.base import MIMEBase
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders

params = config()
conn = psycopg2.connect(**params)
cur = conn.cursor()

####################################################### PROCESS DATA #######################################################

def process_read_plc_values(client, ambarelzonecount, amhrtczonecount, ip):
    """
    Function to read PLC values from specified register addresses.
    """
    registerAddressList_ambarelzonecount = [404, 406, 408, 410, 412, 414, 416, 418, 420, 422, 424, 426]
    registerAddressList = [500, 7, 458, 450, 451, 461, 462, 464] #458 - 3
    hrtc_registers = [701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 
                      721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 
                      741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 
                      761, 762, 763, 764]
    
    # Initialize the list to hold all PLC values
    plc_values = [None] * (len(registerAddressList_ambarelzonecount) + len(registerAddressList) + len(hrtc_registers))

    # Read values from registerAddressList_ambarelzonecount
    for i in range(min(ambarelzonecount, len(registerAddressList_ambarelzonecount))):
        address = registerAddressList_ambarelzonecount[i]
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from registerAddressList
    for i, address in enumerate(registerAddressList):
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    # Read values from hrtc_registers
    for i in range(min(amhrtczonecount, len(hrtc_registers))):
        address = hrtc_registers[i]
        try:
            response = client.read_holding_registers(address, count=1)
            if response.isError():
                print(f"Error reading from PLC at {ip}, address {address}: {response}")
            else:
                plc_values[len(registerAddressList_ambarelzonecount) + len(registerAddressList) + i] = response.registers[0]
        except Exception as e:
            print(f"Exception reading from PLC at {ip}, address {address}: {e}")

    return plc_values

def record_exists(plant_name, machine_name):
    cur.execute('SELECT 1 FROM process_module_process_modulelive WHERE "Plantname"=%s AND "Machinename"=%s', (plant_name, machine_name))
    return cur.fetchone() is not None

#################################################### PRODUCTION DATA ####################################################

def read_plc_values(client, plc_address):

    registerAddressList = [650,222,201,700,262,702,263,2008,265,230,264]
    arr1 = []; arr2 = []
    for address in registerAddressList:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr1.append(response.registers[0])
        except:
            continue
    
    registerAddress_breakdown = [222, 7992, 650]
    for address in registerAddress_breakdown:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr2.append(response.registers[0])
        except:
            continue
    
    arr3 = []
    registerAddress_oilfilterclog = [{"mnt_oilfilter_clogge":6000}, {"mnt_lubrication":6001}, {"mnt_hydraulic":6008}, {"mnt_pumpstatus":6006}, {"mnt_oilfilter_motor":6004}]
    for address in registerAddress_oilfilterclog:
        try:
            response = client.read_holding_registers(list(address.values())[0])
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr3.append({str(list(address.keys())[0]):response.registers[0]})
        except:
            continue

    arr4 = []
    registerAddress_badparts = [230,7992,650]
    for address in registerAddress_badparts:
        try:
            response = client.read_holding_registers(address)
            if response.isError():
                print(f"Error reading from PLC at {plc_address}: {response}")
            else:
                arr4.append(response.registers[0])
        except:
            continue

    return arr1, arr2, arr3, arr4

#################################################### REST  CODE #####################################################

def write_plc_values(client, plc_address):
    registerAddressList = [700, 262, 702, 263, 2008, 265, 230]  # List of register addresses
    write_data = 0  # Value to write

    try:
        for register in registerAddressList:
            response = client.write_register(register, write_data)  # Writing 0 to each register separately
            if response.isError():
                print(f"Error writing to PLC at {ip}, address {register}: {response}")
            else:
                print(f"Written successfully to PLC at {ip}, address {register}: {response}")
    except Exception as e:
        print(f"Exception during write to PLC at {ip}: {e}")

# Initialize a flag to track execution
execution_done = False


while True:
    insertQuery = ('INSERT INTO productiontable_productiontable("Plantname","Machinename","Mouldname_id","MachineState","Alarm","ProductionCountActual","ProductionCountSet","CycletimeActual","CycletimeSet","ProductionTimeActual","ProductionTimeTotal","RejectionParts","Cavity","date","time") VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)')
    dashboard_Query = 'INSERT INTO dashboard_dashboard("Plantname","Machinename","Mouldname_id","MachineState","Alarm","ProductionCountActual","ProductionCountSet","CycletimeActual","CycletimeSet","ProductionTimeActual","ProductionTimeTotal","RejectionParts","Cavity","datetime", "machinestatus") VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
    breakdown_Query = 'INSERT INTO timeline_breakdown(date, "time", "Plantname", "Machinename", "MachineState", primaryreason, "Mouldname_id") VALUES(%s,%s,%s,%s,%s,%s,%s)'
    
    badpart_Query = ('INSERT INTO timeline_badpart(date,"time", "Plantname","Machinename",partcount,reason,"Mouldname_id") VALUES(%s,%s,%s,%s,%s,%s,%s)')
    
    process_module_insert_query = '''
        INSERT INTO process_module_process_module(
            "Plantname", "Machinename", "BarelTempZ1", "BarelTempZ2", "BarelTempZ3", "BarelTempZ4", "BarelTempZ5", "BarelTempZ6", "BarelTempZ7", "BarelTempZ8", "BarelTempZ9", "BarelTempZ10", "BarelTempZ11", "BarelTempZ12", "airInletPressureGuage", "hopperMaterialLevel", "hopperTemperature", "MTC", "CWIP", "CWOP", "CWIT", "CWOT", "HRTC1", "HRTC2", "HRTC3", "HRTC4", "HRTC5", "HRTC6", "HRTC7", "HRTC8", "HRTC9", "HRTC10", "HRTC11", "HRTC12", "HRTC13", "HRTC14", "HRTC15", "HRTC16", "HRTC17", "HRTC18", "HRTC19", "HRTC20", "HRTC21", "HRTC22", "HRTC23", "HRTC24", "HRTC25", "HRTC26", "HRTC27", "HRTC28", "HRTC29", "HRTC30", "HRTC31", "HRTC32", "HRTC33", "HRTC34", "HRTC35", "HRTC36", "HRTC37", "HRTC38", "HRTC39", "HRTC40", "HRTC41", "HRTC42", "HRTC43", "HRTC44", "HRTC45", "HRTC46", "HRTC47", "HRTC48", "HRTC49", "HRTC50", "HRTC51", "HRTC52", "HRTC53", "HRTC54", "HRTC55", "HRTC56", "HRTC57", "HRTC58", "HRTC59", "HRTC60", "HRTC61", "HRTC62", "HRTC63", "HRTC64", "date", "time"
        ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''
    
    process_module_update_query = '''
        UPDATE process_module_process_modulelive
        SET "BarelTempZ1"=%s, "BarelTempZ2"=%s, "BarelTempZ3"=%s, "BarelTempZ4"=%s, "BarelTempZ5"=%s, "BarelTempZ6"=%s, "BarelTempZ7"=%s, "BarelTempZ8"=%s, "BarelTempZ9"=%s, "BarelTempZ10"=%s, "BarelTempZ11"=%s, "BarelTempZ12"=%s, "airInletPressureGuage"=%s, "hopperMaterialLevel"=%s, "hopperTemperature"=%s, "MTC"=%s, "CWIP"=%s, "CWOP"=%s, "CWIT"=%s, "CWOT"=%s, "HRTC1"=%s, "HRTC2"=%s, "HRTC3"=%s, "HRTC4"=%s, "HRTC5"=%s, "HRTC6"=%s, "HRTC7"=%s, "HRTC8"=%s, "HRTC9"=%s, "HRTC10"=%s, "HRTC11"=%s, "HRTC12"=%s, "HRTC13"=%s, "HRTC14"=%s, "HRTC15"=%s, "HRTC16"=%s, "HRTC17"=%s, "HRTC18"=%s, "HRTC19"=%s, "HRTC20"=%s, "HRTC21"=%s, "HRTC22"=%s, "HRTC23"=%s, "HRTC24"=%s, "HRTC25"=%s, "HRTC26"=%s, "HRTC27"=%s, "HRTC28"=%s, "HRTC29"=%s, "HRTC30"=%s, "HRTC31"=%s, "HRTC32"=%s, "HRTC33"=%s, "HRTC34"=%s, "HRTC35"=%s, "HRTC36"=%s, "HRTC37"=%s, "HRTC38"=%s, "HRTC39"=%s, "HRTC40"=%s, "HRTC41"=%s, "HRTC42"=%s, "HRTC43"=%s, "HRTC44"=%s, "HRTC45"=%s, "HRTC46"=%s, "HRTC47"=%s, "HRTC48"=%s, "HRTC49"=%s, "HRTC50"=%s, "HRTC51"=%s, "HRTC52"=%s, "HRTC53"=%s, "HRTC54"=%s, "HRTC55"=%s, "HRTC56"=%s, "HRTC57"=%s, "HRTC58"=%s, "HRTC59"=%s, "HRTC60"=%s, "HRTC61"=%s, "HRTC62"=%s, "HRTC63"=%s, "HRTC64"=%s, "date"=%s, "time"=%s
        WHERE "Plantname"=%s AND "Machinename"=%s
    '''
    
    process_module_live_insert_query = '''
        INSERT INTO process_module_process_modulelive(
            "Plantname", "Machinename", "BarelTempZ1", "BarelTempZ2", "BarelTempZ3", "BarelTempZ4", "BarelTempZ5", "BarelTempZ6", "BarelTempZ7", "BarelTempZ8", "BarelTempZ9", "BarelTempZ10", "BarelTempZ11", "BarelTempZ12", "airInletPressureGuage", "hopperMaterialLevel", "hopperTemperature", "MTC", "CWIP", "CWOP", "CWIT", "CWOT", "HRTC1", "HRTC2", "HRTC3", "HRTC4", "HRTC5", "HRTC6", "HRTC7", "HRTC8", "HRTC9", "HRTC10", "HRTC11", "HRTC12", "HRTC13", "HRTC14", "HRTC15", "HRTC16", "HRTC17", "HRTC18", "HRTC19", "HRTC20", "HRTC21", "HRTC22", "HRTC23", "HRTC24", "HRTC25", "HRTC26", "HRTC27", "HRTC28", "HRTC29", "HRTC30", "HRTC31", "HRTC32", "HRTC33", "HRTC34", "HRTC35", "HRTC36", "HRTC37", "HRTC38", "HRTC39", "HRTC40", "HRTC41", "HRTC42", "HRTC43", "HRTC44", "HRTC45", "HRTC46", "HRTC47", "HRTC48", "HRTC49", "HRTC50", "HRTC51", "HRTC52", "HRTC53", "HRTC54", "HRTC55", "HRTC56", "HRTC57", "HRTC58", "HRTC59", "HRTC60", "HRTC61", "HRTC62", "HRTC63", "HRTC64", "date", "time"
        ) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''

    machineQuery = ('SELECT "amPlantname", "amMachinename", ammachineip, "ambarelzonecount", "amhrtczonecount" FROM public.machinemanagement_addmachine' )
    cur.execute(machineQuery)
    getIPaddress = cur.fetchall()

    cur.execute("SELECT shift1end, shift2end, shift3end FROM public.shiftmanagement_shifttimings")
    shift_times = cur.fetchone()  # Fetch only one row

    if shift_times:
        # Convert shift times to string format
        shift_times = [t.strftime('%H:%M:%S') for t in shift_times if t]

        current_time = datetime.now().strftime('%H:%M:%S')  # Corrected time format

        if not execution_done and current_time in shift_times:
            for ip in getIPaddress:
                client = ModbusTcpClient(ip[2], port=502)
                if client.connect():
                    write_plc_values(client, ip[2])
                    print('Data Resetted For:', ip[1])
                    client.close()
                else:
                    print('Error: Client is not connected to', ip[2])

            # Mark the execution as done
            execution_done = True

        elif execution_done and current_time not in shift_times:
            # Reset flag when the time no longer matches any shift time
            execution_done = False

    else:
        print("Error: No shift timings found in the database")
    
    for ip in getIPaddress:
            
        ambarelzonecount = int(ip[3])  # Convert ambarelzonecount to integer
        amhrtczonecount = int(ip[4])

        client = ModbusTcpClient(ip[2], port = 502)

        plant_name = ip[0]

        machine_name = ip[1]

        if client.connect():
            StringArr = []; Break_Down = []; curr_date = datetime.strftime(datetime.now(), '%Y-%m-%d'); curr_time = datetime.strftime(datetime.now(), '%H:%M:%S') 
            Break_Down.append(str(curr_date)); Break_Down.append(str(curr_time))
            StringArr = []
            plcResponsne, plcresponse_breakdown, plcresponse_maintenance, plcresponse_badpart = read_plc_values(client, ip[2])


            process_plc_response = process_read_plc_values(client, ambarelzonecount, amhrtczonecount, ip[2])
            java = len(process_plc_response)
            if len(process_plc_response) < 84:
                process_plc_response += [None] * (84 - len(process_plc_response))
            data_to_insert = [plant_name, machine_name] + process_plc_response + [curr_date, curr_time]
            print('Modbus Process Data: ', data_to_insert)


            len_list1 = plcResponsne; len_list2 = plcresponse_breakdown; len_list3 = plcresponse_maintenance; len_list4 = plcresponse_badpart
            StringArr.append(ip[0])
            StringArr.append(ip[1])
            Break_Down.append(ip[0])
            Break_Down.append(ip[1])
            StringArr += plcResponsne
            dashboardArr = StringArr + [str(datetime.now().time())]
            StringArr += [str(curr_date), str(curr_time)]
            print('Modbus Production Data: ', StringArr)

            print('__________________________________________________________________________________________________________')


            try:
                # Insert into process_module_process_module
                cur.execute(process_module_insert_query, data_to_insert)
                
                # Check if record exists in process_module_process_modulelive
                if record_exists(plant_name, machine_name):
                    # Update the existing record
                    cur.execute(process_module_update_query, process_plc_response + [curr_date, curr_time, plant_name, machine_name])
                else:
                    # Insert a new record
                    cur.execute(process_module_live_insert_query, data_to_insert)
                    
                conn.commit()
            except Exception as e:
                print(f"Error inserting or updating data in database: {e}")


            if len(len_list1) >= 11 :
                try:
                #############################################################################################################################################################
                    getQuery = ('SELECT "ProductionCountActual", "Mouldname_id" FROM public.productiontable_productiontable where "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                    getLastData = cur.execute(getQuery)
                    getLastData = cur.fetchone()
                    if((plcResponsne[3] != getLastData[0]) or (plcResponsne[0] != getLastData[1])):
                        maxs = plcResponsne[6] * 2 ####### new
                        if plcResponsne[5] <= maxs:  ####### new
                            dashboard_array = dashboardArr + [True]
                            cur.execute(insertQuery,StringArr)
                            cur.execute(dashboard_Query, dashboard_array)
                            conn.commit()
                        
                except:
                    if StringArr[2] != 0:
                        maxs = plcResponsne[6] * 2 ####### new
                        if plcResponsne[5] <= maxs:  ####### new
                            cur.execute(insertQuery,StringArr)
                            cur.execute(dashboard_Query, dashboard_array)  ####### new
                            conn.commit()
                    else:
                        pass

            if len(len_list2) >= 3 :
                ########################################   Break Down Table ##############################################
                try:
                    getbreakdown_Query =  ('SELECT "MachineState", primaryreason, date FROM public.timeline_breakdown where "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                    getLastData_breakdown = cur.execute(getbreakdown_Query)
                    getLastData_breakdown = cur.fetchone()
                    if getLastData_breakdown[2] == curr_date:
                        if (plcresponse_breakdown[0] == getLastData_breakdown[0] and plcresponse_breakdown[1] == getLastData_breakdown[1]):
                            pass

                        else:
                            cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                            conn.commit()
                    else:
                        cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                        conn.commit()

                except:
                    if plcresponse_breakdown[2] != 0:
                        cur.execute(breakdown_Query,(Break_Down+plcresponse_breakdown))
                        conn.commit()
                    else:
                        pass

            if len(len_list3) >= 5:
                for dict_ in plcresponse_maintenance:
                    if list(dict_.values())[0] == 0:
                        getmaintenance = 'select ' + str(list(dict_.keys())[0])+' from public.maintenance_maintenance_module where mnt_date = %s and mnt_machinename = %s'
                        try:
                            cur.execute(getmaintenance, (curr_date, ip[1]))
                            maintenance_data = cur.fetchone()
                            if maintenance_data[0] == 1:
                                updateQuery = 'update public.maintenance_maintenance_module set '+ str(list(dict_.keys())[0]) +' = %s where mnt_date = %s and mnt_machinename = %s'
                                cur.execute(updateQuery, (maintenance_data[0],curr_date, ip[1]))
                                conn.commit()
                        except:
                            if str(list(dict_.keys())[0]) not in ['mnt_pumpstatus', 'mnt_oilfilter_motor']:
                                maintenance_insertQuery = 'insert into public.maintenance_maintenance_module (mnt_date, mnt_machinename, mnt_time, ' + str(list(dict_.keys())[0]) +') values(%s, %s, %s, %s)'
                                cur.execute(maintenance_insertQuery, (curr_date, ip[1], str(curr_time), list(dict_.values())[0]))
                                conn.commit()

            if len(len_list4) >= 3:
                ########################################   Break Down Table ##############################################
                try:
                    getQuery = ('SELECT partcount, "Mouldname_id", date FROM public.timeline_badpart '
                                'WHERE "Machinename"= ' + "'" + str(ip[1]) + "'" +' order by id desc limit 1;')
                    cur.execute(getQuery) 
                    getLastData = cur.fetchone()
                    # if getLastData[2] == curr_date:
                    if (plcresponse_badpart[0] != getLastData[0] or plcresponse_badpart[2] != getLastData[1]):
                        data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                        cur.execute(badpart_Query, data_to_insert)
                        conn.commit()
                            
                    # else:
                    #     data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                    #     cur.execute(badpart_Query, data_to_insert)
                    #     conn.commit()

                except Exception as e:
                    data_to_insert = [curr_date, curr_time, plant_name, machine_name] + plcresponse_badpart
                    cur.execute(badpart_Query, data_to_insert)
                    conn.commit()
            
            client.close()    
        else:
            getQuery = 'SELECT ID FROM dashboard_dashboard WHERE "Machinename" = ' + "'"+ip[1]+"'"+' LIMIT 1'
            getLastData = cur.execute(getQuery)
            getLastData = cur.fetchone()
            dashboard_Q = "UPDATE dashboard_dashboard SET machinestatus = %s where id = %s "
            data = cur.execute(dashboard_Q, ('false', str(getLastData[0])))
            conn.commit()
            print(f'Error : {ip[2]} - Client is not connected')

    # time.sleep(5)