from django.db import models

# Create your models here.
class AddMasterAdministrator(models.Model):
    amaid = models.AutoField(primary_key=True)
    amamaxmachines = models.IntegerField(default=False,null=True)
    amamaxusers = models.IntegerField(default=False,null=True)
    amaPlantname = models.CharField(max_length=255,default=False,null=True)
    