from django.urls import path
from .import views

urlpatterns = [
    path('ucode/', views.ucode,name="user code"),
    path('mcode/', views.mcode,name="machine code"),
    path('eventcode/', views.eventcode,name="device code"),
    path('mouldcode/', views.moldcode,name="device code"),
    path('sp_code/', views.shiftproductioncode)
]
