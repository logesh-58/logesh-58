from django.db.models import fields
from rest_framework import serializers
from .models import maintenance_module

class maintenance_moduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = maintenance_module
        fields = '__all__'