from django.urls import path 
from maintenance import main_optimize

urlpatterns=[
    path('oilfilter/', main_optimize.maintenance_func),
    path('analytics/', main_optimize.Analytics),
    path('historical/', main_optimize.Historical)
]
