from django.conf.urls import url
from django.urls.resolvers import URLPattern
from source_management import views

urlpatterns=[
    url('sourcemanagement/',views.addsource,name='source_management')
    # url('delete/<str:id>',views.delete,name='source_delete')
]
