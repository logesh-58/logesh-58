from django.apps import AppConfig


class SourceManagementConfig(AppConfig):
    name = 'source_management'
