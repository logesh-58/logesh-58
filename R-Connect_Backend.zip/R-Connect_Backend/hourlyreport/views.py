from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import json
from datetime import datetime
from datetime import timedelta
from productiontable.serializers import ProductionTableSerializers
from shiftmanagement.models import ShiftTimings
from shiftmanagement.serializers import ShiftTimingSerializer
from timeline.models import badpart, breakdown
from productiontable.models import ProductionTable
from mouldmanagement.models import Mouldmodel
from timeline.serializers import breakdownSerializers
from timeline.views import breakdownReason, fetchDowntimeData
# Create your views here.
def getID(date, Plantname):
    Shifttime = ShiftTimings.objects.values('shift1start', 'shift3end')
    shiftstarttime = '';    shiftendtime   = ''
    for i in Shifttime:
        shiftstarttime = str(i['shift1start'])
        shiftendtime   = str(i['shift3end'])
    fid = 0; lid = 0
    if(ProductionTable.objects.filter(date = date).exists()):
        nextdate = str((datetime.strptime(date, '%Y-%m-%d')).date() + (timedelta(days=1)))
        # print(nextdate)     
        fid = ProductionTable.objects.filter(date = date, time__gte = shiftstarttime, Plantname = Plantname).values('id').first()
        if(ProductionTable.objects.filter(date = nextdate).exists()):
            lid = ProductionTable.objects.filter(date = date, time__lte = shiftendtime, Plantname = Plantname).values('id').last()
        else:
            lid = ProductionTable.objects.filter(date = date, Plantname = Plantname).values('id').last()
        fid = fid['id']
        lid = lid['id']
    idArray = [fid, lid]
    return idArray

def getdistinctMachines(date, Plantname):
    idarray = getID(date, Plantname)
    # print(idarray[0], idarray[1])
    getmachines = ProductionTable.objects.filter(id__range = (idarray[0], idarray[1]), Plantname = Plantname).values('Machinename').distinct()
    machineArray = []
    for i in getmachines:
        if(i['Machinename'] not in machineArray):
            machineArray.append({'Machinename': i['Machinename']})   
    return machineArray

def getShiftMoldID(date, Machinename, shift, Plantname):
    Shifttime = ShiftTimings.objects.all()
    Shifttime = (ShiftTimingSerializer(Shifttime, many=True)).data
    shift1starttime=''; shift1endtime=''; shift2starttime=''; shift2endtime=''; shift3starttime=''; shift3endtime=''
    for i in Shifttime:
        shift1starttime = str(i['shift1start'])
        shift2starttime = str(i['shift2start'])
        shift3starttime = str(i['shift3start'])
        shift1endtime   = str(i['shift1end'])
        shift2endtime   = str(i['shift2end'])
        shift3endtime   = str(i['shift3end'])

    fid = 0; lid = 0
    if(shift == 'Shift-I'):
        if(ProductionTable.objects.filter(date = date).exists()):
            nextdate = str((datetime.strptime(date, '%Y-%m-%d')).date() + (timedelta(days=1)))
            fid = ProductionTable.objects.filter(date = date, time__gte = shift1starttime, Plantname = Plantname, Machinename = Machinename).values('id').first()
            lid = ProductionTable.objects.filter(date = date, time__lte = shift1endtime, Plantname = Plantname, Machinename = Machinename).values('id').last()
    if(shift == 'Shift-II'):
        if(ProductionTable.objects.filter(date = date).exists()):
            nextdate = str((datetime.strptime(date, '%Y-%m-%d')).date() + (timedelta(days=1)))
            fid = ProductionTable.objects.filter(date = date, time__gte = shift2starttime, Plantname = Plantname, Machinename = Machinename).values('id').first()
            lid = ProductionTable.objects.filter(date = date, time__lte = shift2endtime, Plantname = Plantname, Machinename = Machinename).values('id').last()
    if(shift == 'Shift-III'):
        if(ProductionTable.objects.filter(date = date).exists()):
            nextdate = str((datetime.strptime(date, '%Y-%m-%d')).date() + (timedelta(days=1)))
            fid = ProductionTable.objects.filter(date = date, time__gte = shift3starttime, Plantname = Plantname, Machinename = Machinename).values('id').first()
            if(ProductionTable.objects.filter(date = nextdate).exists()):
                lid = ProductionTable.objects.filter(date = nextdate, time__lte = shift3endtime, Plantname = Plantname, Machinename = Machinename).values('id').last()
            else:
                lid = ProductionTable.objects.filter(date = date, Plantname = Plantname).values('id').last()
    try:
        fid = fid['id']
        lid = lid['id']
    except:
        fid = 0
        lid = 0
    idArray = [fid, lid]
    # print(idArray)
    return idArray

def getMouldnames(date, Machinename, shift, Plantname):
    idarray = []
    if(shift == "Shift-I"):
        idarray = getShiftMoldID(date, Machinename, shift, Plantname)
    if(shift == "Shift-II"):
        idarray = getShiftMoldID(date, Machinename, shift, Plantname)
    if(shift == "Shift-III"):
        idarray = getShiftMoldID(date, Machinename, shift, Plantname)
    
    # print(idarray)
    getmolds = ProductionTable.objects.filter(id__range = (idarray[0], idarray[1]), Plantname = Plantname, Machinename = Machinename).values('Mouldname_id').distinct()
    moldArray = []
    for i in getmolds:
        Mouldname_id = i['Mouldname_id']
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
        Mouldname = ''
        for i in Mouldname_data:
            Mouldname = i['Mouldname']       
            if(Mouldname not in moldArray):
                moldArray.append({'Mouldname': Mouldname, 'Mould_id':Mouldname_id}) 
        print(moldArray)
    return moldArray

def diffTime(previoustime, currenttime):
    difftime = ((datetime.strptime(currenttime, '%H:%M:%S')) - (datetime.strptime(previoustime, '%H:%M:%S')))
    return difftime.total_seconds()

def matchReason(DowntimeArrayAll, ListArray):
    # print(ListArray)
    actualtime = (ListArray[len(ListArray)-2])['time']
    for i in DowntimeArrayAll:
        if(i['starttime'] == actualtime):
            (ListArray[len(ListArray) - 1])['primaryreason'] = i['primaryreason']

def breakdownReason(reasonnumber):
    reason = ''
    try:
        reasonarray = ['Mold Change', 'Tool Change', 'Material Change', 'Maintenance', 'Production', 'Operator']
        reason = reasonarray[reasonnumber - 1]
    except:
        reason='Not selected'
    return reason

def getMolddatas(Plantname, date, Machinename, Mouldname, shift):
    backupdate = date
    nextdate = ((datetime.strptime(date, '%Y-%m-%d')).date() + (timedelta(days=1))).strftime('%Y-%m-%d')
    shiftstarttime = datetime.now() ; shift3endtime = datetime.now()
    if(shift == 'Shift-I'):
        Shifttime = ShiftTimings.objects.values('shift1start', 'shift1end')
        for i in Shifttime:
            shiftstarttime = i['shift1start']
            shiftendtime = i['shift1end']
    if(shift == 'Shift-II'):
        Shifttime = ShiftTimings.objects.values('shift2start', 'shift2end')
        for i in Shifttime:
            shiftstarttime = i['shift2start']
            shiftendtime = i['shift2end']
    if(shift == 'Shift-III'):
        Shifttime = ShiftTimings.objects.values('shift3start', 'shift3end')
        for i in Shifttime:
            shiftstarttime = i['shift3start']
            shiftendtime = i['shift3end']

    targethour = ProductionTable.objects.filter(date = date, time__gte = (str(shiftstarttime)), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('ProductionTimeTotal').first()
    CycletimeSet = ProductionTable.objects.filter(date = date, time__gte = (str(shiftstarttime)), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('CycletimeSet').first()
    
    try: targethour = round(targethour['ProductionTimeTotal'], 1) 
    except: targethour = 0
    try: CycletimeSet = int(CycletimeSet['CycletimeSet']/1000000)
    except: CycletimeSet = 0

    hourArray = [];  previouspartcount = 0;  badpartcount = 0;  runtime = ''; hourlyreportArray = []; rejCountArray = []; totalRejCount = []; rejTotalCountArray = []
    for i in range(0, 17):
        totalRejCount.append(0)

    if(shift == 'Shift-III'):
        endtime = '23:59:59'
        smpfirstdata = ProductionTable.objects.filter(date = date, time__range = (shiftstarttime, endtime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('CycletimeSet', 'actualinjtime', 'actualcoolingtime', 'injectionvelocity1', 'actualinjectionpressure', 'hotrunnerused', 'zone1temp', 'zone2temp', 'zone3temp', 'zone4temp', 'zone5temp', 'zone6temp', 'zone7temp', 'zone8temp', 'zone9temp', 'zone10temp', 'zone11temp', 'zone12temp').first()
        if(smpfirstdata != None): 
            for i in smpfirstdata:
                i['CycletimeSet'] = int(i['CycletimeSet']/1000000)
        if(smpfirstdata == None):
            smpfirstdata = ProductionTable.objects.filter(date = date, time__range = ('00:00:01', shiftendtime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('CycletimeSet', 'actualinjtime', 'actualcoolingtime', 'injectionvelocity1', 'actualinjectionpressure', 'hotrunnerused', 'zone1temp', 'zone2temp', 'zone3temp', 'zone4temp', 'zone5temp', 'zone6temp', 'zone7temp', 'zone8temp', 'zone9temp', 'zone10temp', 'zone11temp', 'zone12temp').first()
            if(smpfirstdata != None): 
                for i in smpfirstdata:
                    i['CycletimeSet'] = int(i['CycletimeSet']/1000000)
            if(smpfirstdata == None):
                smpfirstdata = {
                    'CycletimeSet':0, 'actualinjtime':0, 'actualcoolingtime':0, 'injectionvelocity1':0, 'actualinjectionpressure':0, 'hotrunnerused':0, 'zone1temp':0, 'zone2temp':0, 'zone3temp':0, 'zone4temp':0, 'zone5temp':0, 'zone6temp':0, 'zone7temp':0, 'zone8temp':0, 'zone9temp':0, 'zone10temp':0, 'zone11temp':0, 'zone12temp':0
                    }
    else:
        endtime = shiftendtime
        print(date, shiftstarttime, endtime)
        smpfirstdata = ProductionTable.objects.filter(date = date, time__range = (shiftstarttime, endtime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('CycletimeSet'
        # , 'actualinjtime', 'actualcoolingtime', 'injectionvelocity1', 'actualinjectionpressure', 'hotrunnerused', 'zone1temp', 'zone2temp', 'zone3temp', 'zone4temp', 'zone5temp', 'zone6temp', 'zone7temp', 'zone8temp', 'zone9temp', 'zone10temp', 'zone11temp', 'zone12temp'
        ).first()
        if(smpfirstdata != None):
            print(smpfirstdata) 
            smpfirstdata['CycletimeSet'] = int(smpfirstdata['CycletimeSet'])
    
    # smpfirstdata['holdpress'] = 0
    # smpfirstdata['shortsize'] = 0
    # smpfirstdata['nozzletemp'] = 0
    # smpfirstdata['mtcorchiller1'] = 0
    # smpfirstdata['mtcprchiller2'] = 0

    DowntimeArrayAll = fetchDowntimeData(date, Plantname)

    hrcount = 0
    checkvalues=[]
    for i in range(shiftstarttime.hour, (shiftstarttime.hour+8) ):
        hr = i 
        if(hr >= 24):
            hr = hr - 24
            date = nextdate
        else:
            date = date
        hr1 = hr + 1
        if((hr+1) == 24):
            (hr1) = 0

        if((len(str(hr))) <= 1):
            hr = '0'+str(hr)
        if((len(str(hr1))) <= 1):
            hr1 = '0'+str(hr1)
        
        fmt = str(hr) +':00:00 - '+ str(hr) + ':59:59'
        reporttime = str(hr) +':00 - '+ str(hr1) + ':00'
        hourArray.append(fmt)
        
        #//Get Four hours once report
        hrcount = hrcount + 1
        # print('Count = ', hrcount, type(hrcount))
        
        print(date)
        if(hrcount %4 == 0):
            Ftime = str(hr) + ':59:00'
            Ltime = str(hr1) + ':01:00'
            print(Ftime, Ltime)
            Fdata = ProductionTable.objects.filter(date = date, time__range = (Ftime, Ltime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('CycletimeSet'
            # , 'actualinjtime', 'actualcoolingtime', 'injectionvelocity1', 'actualinjectionpressure', 'hotrunnerused', 'zone1temp', 'zone2temp', 'zone3temp', 'zone4temp', 'zone5temp', 'zone6temp', 'zone7temp', 'zone8temp', 'zone9temp', 'zone10temp', 'zone11temp', 'zone12temp'
            ).last()
            if(Fdata != None):
                    Fdata['CycletimeSet'] = int(Fdata['CycletimeSet'])
            if(Fdata == None):
                Fdata = {       
                    'CycletimeSet':0, 'actualinjtime':0, 'actualcoolingtime':0, 'injectionvelocity1':0, 'actualinjectionpressure':0, 'hotrunnerused':0, 'zone1temp':0, 'zone2temp':0, 'zone3temp':0, 'zone4temp':0, 'zone5temp':0, 'zone6temp':0, 'zone7temp':0, 'zone8temp':0, 'zone9temp':0, 'zone10temp':0, 'zone11temp':0, 'zone12temp':0
                }
            # print('4hrs data = ', Fdata)
            Fdata['time'] = str(hr1)+':00:00'
            Fdata['holdpress'] = 0
            Fdata['shortsize'] = 0
            Fdata['nozzletemp'] = 0
            Fdata['mtcorchiller1'] = 0
            Fdata['mtcprchiller2'] = 0
            checkvalues.append(Fdata)
            print(Fdata)
        #// Get Counter value and count value
        fid = ProductionTable.objects.filter(date = date, time__range = ((str(hr) +':00:00'), (str(hr) + ':59:59')), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, MachineState__gt = 1, ProductionCountActual__gt = 0).values('id').first()
        lid = ProductionTable.objects.filter(date = date, time__range = ((str(hr) +':00:00'), (str(hr) + ':59:59')), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname, MachineState__gt = 1, ProductionCountActual__gt = 0).values('id').last()
        try:
            fid = fid['id'];  lid = lid['id']
        except:
            fid = 0; lid = 0

        if(fid and lid):
            getcount = ProductionTable.objects.filter(id__range = (fid, lid), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).count()
            getfirst = ProductionTable.objects.filter(id = fid , Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('ProductionCountActual')
            getlast = ProductionTable.objects.filter(id = lid , Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('ProductionCountActual')
            for i in getfirst:
                getfirst =int(i['ProductionCountActual'])
            if(getfirst == None): getfirst = 0
            for i in getlast:
                getlast = int(i['ProductionCountActual'])
            if(getlast == None): getlast = 0
        else:
            getcount = 0
            getfirst = 0
            getlast = 0
        
        #// Get downtime value
        ListArray = list(breakdown.objects.filter(date = date, time__range = ((str(hr) +':00:00'), (str(hr) + ':59:59')), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('time', 'MachineState', 'primaryreason').order_by('id'))

        dict0 = {'time': str(hr)+':00:00', 'MachineState' : 0, "primaryreason": ''}
        dict1 = {'time': str(hr)+':59:59', 'MachineState' : 1, "primaryreason": ''}

        if(ListArray != []):
            ms0 = (ListArray[0])['MachineState']
            ms1 = (ListArray[len(ListArray) - 1])['MachineState']
            if(len(ListArray) > 1):
                if((ms0) == 1): 
                    ListArray.insert(0, dict0)
                if((ms1) == 0): 
                    ListArray.insert(len(ListArray), dict1)
                    LA = matchReason(DowntimeArrayAll, ListArray)
            if(len(ListArray) == 1):
                if((ms0) == 1): ListArray.insert(0, dict0)
                else: ListArray.insert(1, dict1); LA = matchReason(DowntimeArrayAll, ListArray)
        
        # print(ListArray)
        prevstate = -1
        for i in ListArray:
            if(i['MachineState'] == prevstate): ListArray.remove(i)
            prevstate = i['MachineState']
        downtimeArray = []; j = 0
        for i in range(0, (len(ListArray)//2)):
            if(ListArray != []):
                reason = (ListArray[j+1])['primaryreason']
                if(type(reason) == int):
                    primaryreason = breakdownReason(reason)
                else:
                    primaryreason = reason   

                print(primaryreason, type(primaryreason))
                dict = {'Starttime': (ListArray[j])['time'], 'Endtime': (ListArray[j+1])['time'], 'reason': primaryreason}
                downtimeArray.append(dict)
                j += 2

        #//Get RejectionParts hourly count
        RejectionParts = badpart.objects.filter(date = date, time__range = ((str(hr) +':00:00'), (str(hr) + ':59:59')), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('partcount', 'reason').last()      
        try:
            currentpartcount = RejectionParts['partcount']
            badpartcount = currentpartcount - previouspartcount
        except:
            badpartcount = 0;   currentpartcount = 0
        previouspartcount = currentpartcount
        
        #//Badpart rejection details
        count = list(badpart.objects.filter(date = date, time__range = ((str(hr) +':00:00'), (str(hr) + ':59:59')), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('reason'))
        ca = []
        for i in range(0,17):
            ca.append(0)
        for i in count:
            index = i['reason']
            ca[index -1] += 1
            totalRejCount[index -1] += 1
        
        #Goodparts
        try:
            Goodparts = int(getcount - badpartcount)
            if(Goodparts < 0):
                Goodparts = 0
        except:
            Goodparts = 0

        hourlyreportdict = {
                            'time'          :reporttime,
                            'counterstart'  :getfirst,
                            'counterend'    :getlast,
                            'totalshots'    :getcount,
                            'goodparts'     :Goodparts,
                            'setuprej'      :0,
                            'inprocessrej'  :badpartcount,
                            'downtime'      :downtimeArray
                            }
        hourlyreportArray.append(hourlyreportdict)
        rejectioncountdict = {
                                'time'      : reporttime,
                                'setup'     : ca[0],
                                'flash'     : ca[1],
                                'sinkmark'  : ca[2],
                                'silverstreaks': ca[3],
                                'pinmark': ca[4],
                                'shortfill': ca[5],
                                'burnmark': ca[6],
                                'scoring': ca[7],
                                'blackmark': ca[8],
                                'whitemark': ca[9],
                                'jettingorflowmark': ca[10],
                                'weldline': ca[11],
                                'scratches': ca[12],
                                'shining': ca[13],
                                'colormismatch': ca[14],
                                'oilmark': ca[15],
                                'others': ca[16],
                            }
            
        rejCountArray.append(rejectioncountdict)

    rejectionTotalcountdict = {
                            'setup'             : totalRejCount[0],
                            'flash'             : totalRejCount[1],
                            'sinkmark'          : totalRejCount[2],
                            'silverstreaks'     : totalRejCount[3],
                            'pinmark'           : totalRejCount[4],
                            'shortfill'         : totalRejCount[5],
                            'burnmark'          : totalRejCount[6],
                            'scoring'           : totalRejCount[7],
                            'blackmark'         : totalRejCount[8],
                            'whitemark'         : totalRejCount[9],
                            'jettingorflowmark' : totalRejCount[10],
                            'weldline'          : totalRejCount[11],
                            'scratches'         : totalRejCount[12],
                            'shining'           : totalRejCount[13],
                            'colormismatch'     : totalRejCount[14],
                            'oilmark'           : totalRejCount[15],
                            'others'            : totalRejCount[16],
                        }
        
    rejTotalCountArray.append(rejectionTotalcountdict)

    date = backupdate
    if(shiftendtime.hour < shiftstarttime.hour):
        nextdate = nextdate
    else:
        nextdate = date
    # print(date, nextdate)

    dfid = breakdown.objects.filter(Plantname = Plantname, date = date, time__gte = (str(shiftstarttime))).values('id').first()
    dlid = breakdown.objects.filter(Plantname = Plantname, date = nextdate, time__lte = (str(shift3endtime))).values('id').last()
    try:
        dfid = dfid['id'];  dlid = dlid['id']
    except:
        dfid = 0; dlid = 0

    breakdowndata = breakdown.objects.filter(id__range = (dfid, dlid), Machinename = Machinename, Plantname = Plantname, Mouldname = Mouldname).all().order_by('id')
    breakdown_serialdata = breakdownSerializers(breakdowndata, many=True)
    previousstate = -1; previoustime = ''
    currentstate = -1; currenttime = ''
    flag = 0; downtimeseconds = 0

    for i in (breakdown_serialdata.data):
        currentstate = i['MachineState']
        currenttime  = i['time']
        if(flag == 0):
            previousstate = currentstate
            previoustime  = currenttime
            flag = 1
        if(previousstate == 0 and currentstate == 1):
            downtimeseconds = downtimeseconds + diffTime(previoustime, currenttime)
        previousstate = currentstate
        previoustime  = currenttime

    totaldowntime = timedelta(seconds = downtimeseconds)
    
    # runtime
    timeArray = []
    if(shiftendtime.hour > shiftstarttime.hour):
        dateArray = [date]
        timeArray = [shiftstarttime, shiftendtime]
    else:
        dateArray = [date, nextdate]
        timeArray = [str(shiftstarttime), '23:59:59', '00:00:01', str(shiftendtime)]
    tf = 0
    Firsttime = ''
    for i in range(0, len(dateArray)):
        ind = (i*i)+ i
        date_ = dateArray[i]
        fromtime = timeArray[ind]
        totime   = timeArray[ind + 1]
        Ftime = ProductionTable.objects.filter(date = date_, time__range = (fromtime, totime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('time').first()
        Ltime = ProductionTable.objects.filter(date = date_, time__range = (fromtime, totime), Plantname = Plantname, Machinename = Machinename, Mouldname = Mouldname).values('time').last()
        try:
            if(tf == 0):
                Firsttime = date_ + ' ' +  Ftime['time']
                tf = 1
            lasttime =  date_ + ' ' + Ltime['time']
        except:
            Firsttime = date_ + ' 00:00:00'
            lasttime = date_ + ' 00:00:00'

    Runtimeseconds = ((datetime.strptime(lasttime, '%d-%m-%Y %H:%M:%S') - datetime.strptime(Firsttime, '%d-%m-%Y %H:%M:%S'))).total_seconds()
    ActualRuntime = timedelta(seconds = abs(Runtimeseconds - downtimeseconds))

    #-----------Total Good parts & shots ---------
    totalgoodparts = 0
    totalRejectionParts = 0
    totalshots = 0
    for data in hourlyreportArray:
        totalgoodparts = totalgoodparts + data['goodparts']
        totalshots = totalshots + data['totalshots']
        totalRejectionParts = totalRejectionParts + data['inprocessrej']
    
    #-------- API Formation ------------------
    commonreportArray = []
    commonreportdict = {
                            'date':backupdate,
                            'shift':shift,
                            'partname':Mouldname,
                            'cycletime':CycletimeSet,
                            'targerhour':targethour,
                            'totalshots':totalshots,
                            'totalgoodparts':totalgoodparts,
                            'partweight':0,
                            'runnerweight':0,
                            'shotweight':0,
                            'lumpsweight':0,
                            'toolnumber':0,
                            'totalrunnerweight':0,
                            'totalrunhours': str(ActualRuntime),
                            'totalsetuprej':0,
                            'totalinprocessrej': totalRejectionParts,
                            'totaldowntime':str(totaldowntime)
                        } 
    commonreportArray.append(commonreportdict)
    dataArray = []; rejbreakdowns = []; smpvalue = [smpfirstdata]
    mydict1 = {"cummulative": rejTotalCountArray, 'breakdowns': rejCountArray}
    rejbreakdowns.append(mydict1)
    checkerdict = {
                    "preheatingtemp":0,
                    "dehumidifier":0,
                    "binno":0
                    }
    checkerArray = [checkerdict]
    mydict3 = {"checker":checkerArray , "smpvalue": smpvalue, "checkvalues": checkvalues}
    smparray = [mydict3]
    mydict3 = {"rejbreakdowns": rejbreakdowns, "smp": smparray,  "commonreport": commonreportArray, "hourlyreport": hourlyreportArray}
    dataArray.append(mydict3)
    return dataArray

@csrf_exempt
def report(request):
    if(request.method == 'POST'):
        # Plantname = 'MATE WALAJABAD'
        Plantname = request.GET['Plantname']
        hd = json.loads(request.body)
        if(hd['Machinename'] == '' and hd['Mouldname'] == ''):
            return JsonResponse(getdistinctMachines(hd['date'], Plantname), safe=False)
        if(hd['Machinename'] and hd['Mouldname'] == ''):
            return JsonResponse(getMouldnames(hd['date'], hd['Machinename'], hd['shift'],Plantname), safe=False)
        if(hd['Machinename'] and hd['Mouldname']):
            return JsonResponse(getMolddatas(Plantname, hd['date'], hd['Machinename'], hd['Mouldname'], hd['shift']), safe=False)

