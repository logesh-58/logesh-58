from email.mime.multipart import MIMEMultipart
from django.http.response import JsonResponse, HttpResponse
from django.shortcuts import render
from datetime import datetime
from machinestopcheck.models import MachinestopCheck
from machinestopcheck.serializers import MachinestopCheckSerializer
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from mouldmanagement.models import Mouldmodel

from workflow.models import WorkflowData

# from celery.schedules import crontab
# from celery.task import periodic_task


# Create your views here.
# @periodic_task(run_every=(crontab(minute='*/1')))

def checkstop(wfeventcode):
    Plantname = 'ROBIS'
    # wfeventcode=request.get('wfeventcode') 
    workflowtab = WorkflowData.objects.get(wfeventcode=wfeventcode)
    print(workflowtab)
    tomail=workflowtab.atoemail
    sub=workflowtab.asubject
    wftime = str(workflowtab.stime)
    # print(wftime, type(wftime))
    tolerancetime = (wftime.split(":"))[0] 
        

    now  = datetime.now()
    date = now.strftime('%Y-%m-%d')
    distinctmachines = MachinestopCheck.objects.filter(date = date, Plantname = Plantname).values('Machinename').distinct().order_by('id')
    for machine in distinctmachines:
        # print(machine)
        Machinename = machine['Machinename']
        stopdatas = MachinestopCheck.objects.filter(date = date, Plantname = Plantname, Machinename = Machinename).values('id', 'date', 'time', 'Mouldname_id', 'MachineState').last()
        Mouldname_id= machine['Mouldname_id']
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
        # print('Mouldname')
        mouldname = ''
        for i in Mouldname_data:
            Mouldname = i['Mouldname']
            print(Mouldname)
        
        # try:
        #     workflowtab = WorkflowData.objects.get(wfeventcode=wfeventcode)
        # except:
        #     workflowtab = None
                
        
        try:
            datecmb = datetime.strptime(stopdatas['date'], '%Y-%m-%d')            
            if(stopdatas['MachineState'] <= 1):
                manualmoderisetime = now - (datetime.combine(datecmb , datetime.strptime(stopdatas['time'], '%H:%M:%S').time()))
                idleminutes = int((manualmoderisetime.seconds)/60)
                if(idleminutes >= int(tolerancetime)):
                    message = '''Dear team, <br> 
                                    Machine (''' + Machinename + ''') has stopped from ''' + stopdatas['time'] + '''.
                                    <br><br>
                                    <b><U>Machine Details:</b></U> <br>
                                    Date : ''' + stopdatas['date'] +'''.<br>
                                    Time : ''' + stopdatas['time'] +'''.<br>
                                    Machinename : ''' + Machinename +'''.<br>
                                    Mouldname    : ''' + stopdatas['Mouldname'] +'''.
                                    <br>
                                    <br>
                                Regards, <br>
                                R-Connect Team. 
                                <br>
                                <br> 
                                Note: This is an system generated mail. Don't reply for this.'''
                    msg = MIMEMultipart('alternative')
                    msg['Subject'] = sub
                    msg['From'] = "R-Connect<no-reply@rconnect.com>"
                    msg['To'] = tomail
                    part2 = MIMEText(message, 'html')
                    msg.attach(part2)
                    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
                    smtpObj.sendmail('ntpdpmt1@int.motherson.com',tomail.split(';'),msg.as_string())
                    smtpObj.quit()
                    print('Mail send successfully')
            MachinestopCheck.objects.filter(id__lte = stopdatas['id'], Plantname= Plantname, Machinename = Machinename).delete()                
            print('Deleted ', Machinename)
        except: 
            continue
    return HttpResponse('1')
