from mouldmanagement.models import Mouldmodel
# from productiontable.views import name
from django.shortcuts import render
from workflow.models import Tickets
from machinemanagement.models import AddMachine
import datetime
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import badpart, breakdown, timeline
from .serializers import RejectionPartsSerializers, breakdownSerializers, timelineSerializers
import json
from productiontable.models import ProductionTable
from shiftmanagement.models import ShiftTimings
from celery.schedules import crontab
# from celery.task import periodic_task
from analysis.views import machineArray
from usermanagement.models import AddUser
from django.db.models import Q


def shiftStarttime(Plantname):
    shiftstarttime = datetime.datetime.now().time()
    for i in (ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')):    shiftstarttime = i['shift1start']
    return shiftstarttime
#--------------------- Breakdown --------------------------------

def breakdownReason(reasonnumber):
    reasonarray = ['None' ,'Maintenance', 'Robot Problem', 'Power Issue', 'Mould Change', 'Material Change', 'Tool Problem', 'Machine Breakdown', 'Operator Absence']
    return reasonarray[reasonnumber - 1]

def diffTime(i, previoustime, currenttime, difftime):
    dict = {
        'id'            : i['id'], 
        'date'          : i['date'], 
        'difftime'      : str(difftime), 
        'Machinename'   : i['Machinename'], 
        'Mouldname'      : i['Mouldname'],  
        'MachineState'  : i['MachineState'], 
        'primaryreason' : breakdownReason(i['primaryreason']), 
        'rootcause'     : i['rootcause'],
        'starttime'     : (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')).time(),
        'endtime'       : (datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')).time()
    }
    return dict
 
def fetchDowntimeData(today, Plantname):
    tomorrow = str((datetime.datetime.strptime(today, '%Y-%m-%d') - datetime.timedelta(days = 1)).date())

    shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()

    # Extracting shift timings as strings (converted from time objects)
    shift_starttime_str = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
    shift_endtime_str = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

    breakdowndata = breakdown.objects.filter(Q(date = today, time__gte = shift_starttime_str,  Plantname = Plantname) | Q (date = tomorrow, time__lte = shift_endtime_str, Plantname = Plantname)).all().order_by('id')
    breakdown_serialdata    = breakdownSerializers(breakdowndata, many=True)
    previousstate = -1; previoustime = ''
    currentstate = -1; currenttime = ''
    flag = 0
    DataArray = []; dict = None
    for i in (breakdown_serialdata.data):
        currentstate = i['MachineState']
        currenttime  = i['date'] + " " + i['time'] 
        Mouldname_data = Mouldmodel.objects.filter(id = i['Mouldname']).values('Mouldname')
        for molddata in Mouldname_data:
            i['Mouldname'] = molddata['Mouldname']
        if(flag == 0):
            previousstate = currentstate
            previoustime  = currenttime
            flag = 1
        if(previousstate == 0 and currentstate == 1):
            difftime = ((datetime.datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')) - (datetime.datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')))
            # if int(difftime.total_seconds()) >= 300: 
            dict = diffTime(i, previoustime, currenttime, difftime)
            DataArray.append(dict)
        previousstate = currentstate
        previoustime  = currenttime
    return DataArray

@csrf_exempt
def breakdowndata(request):
    if(request.method == 'POST'):
        Plantname = request.GET['Plantname']
        httpdata  = json.loads(request.body)
        if(httpdata['update'] == 0):
            return JsonResponse((fetchDowntimeData(httpdata['date'], Plantname)), safe=False)   
        elif(httpdata['update'] == 1):
            if(breakdown.objects.filter(id = httpdata['id']).exists()):
                breakdown.objects.filter(id = httpdata['id']).update(rootcause = httpdata['rootcause'])
                return JsonResponse((fetchDowntimeData(httpdata['date'], Plantname)), safe=False)

#--------------------- Bad Parts --------------------------------
def RejectionPartsreason(reasonnumber):
	reasonarray = ['Setup', 'Flash', 'Sink Mark', 'Silver Streaks', 'Pin Mark', 'Short Fill', 'Burn Mark', 'Scoring', 'Black Mark', 'White Mark', 'Flow Mark', 'Weld Lines', 'Scratches', 'Shining', 'Colour Mis Match', 'Oil Mark', 'Others']
	return reasonarray[reasonnumber - 1]

@csrf_exempt
def RejectionPartsdata(request):
    if(request.method == 'POST'):
        Plantname = request.GET['Plantname']

        today = (json.loads(request.body))['date']
        tomorrow = str((datetime.datetime.strptime(today, '%Y-%m-%d') + datetime.timedelta(days = 1)).date())

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()

        # Extracting shift timings as strings (converted from time objects)
        shift_starttime_str = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        shift_endtime_str = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None
        
        badpartdata = badpart.objects.filter((Q(date = today, time__gte = shift_starttime_str)|Q(date = tomorrow, time__lte = shift_endtime_str)), partcount__gt = 0, Plantname=Plantname).order_by('id')

        RejectionParts = RejectionPartsSerializers(badpartdata, many=True)
        for i in (RejectionParts.data):
            reason_str = RejectionPartsreason(i['reason'])
            i['reason'] = reason_str

            Mouldname_data = Mouldmodel.objects.get(id=i['Mouldname']).Mouldname

            i['Mouldname_id'] = Mouldname_data

        return JsonResponse(RejectionParts.data, safe=False)

@csrf_exempt
def data(request):
    if(request.method == 'POST'):
        inputDate = (json.loads(request.body))['date']
        Plantname = AddUser.objects.values('udPlantname').last()['udPlantname']
        MasterMachineArray = machineArray(Plantname)
        # MasterMachineArray = ['2000TA']
        downtime = fetchDowntimeData(inputDate, Plantname)
        for Machine in MasterMachineArray:
            try:
                TimeArray   = []; StatusArray = []; ReasonArray = []; CauseArray = []
                # getMould = list(ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine).values('Mouldname_id').distinct())
                mouldfla = 0; mouldflagid = 0; 
                nonproductionseconds = 0; productionseconds = 0
                
                #-------------------------
                #Get Machine Start and end time for calc production and non production time            
                MStartTime   = (ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine).values('time').first())['time']
                MEndTime     = (ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine).values('time').last())['time']
                TotalRunSeconds = (datetime.datetime.strptime(MEndTime, '%H:%M:%S') - datetime.datetime.strptime(MStartTime, '%H:%M:%S')).total_seconds()
                TotalProdCount = ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine).count()
                # print(MStartTime, MEndTime, TotalRunSeconds, TotalProdCount)
                # print(TotalProdCount)
                #-------------------------
                #Get machines produced mold names and sort it using lamda function

                try: 
                    sorted_getmold = (list(ProductionTable.objects.filter(date = inputDate, Machinename = Machine, Plantname = Plantname).values('id', 'Mouldname_id').order_by('id')))
                    # print(sorted_getmold)
                except:
                    sorted_getmold = []
                    # print(sorted_getmold)
                    #Get distinct mold from sorted mold
                timeflag = 0; moldflag = 0
                # print(sorted_getmold)
                uniquesortedmold = []; tempcount = 0; currmoldid = 0; idarray = []
                for mold in sorted_getmold:
                    currmold = mold['Mouldname_id']
                    currmoldid = mold['id']
                    if(tempcount == 0):
                        prevmold = mold['Mouldname_id']
                        prevmoldid = mold['id']
                        uniquesortedmold.append(mold['Mouldname_id'])
                        idarray.append(prevmoldid)
                        tempcount = 1
                    if(tempcount ==1):
                        if(currmold != prevmold):
                            uniquesortedmold.append(mold['Mouldname_id'])
                            idarray.append(prevmoldid)
                            idarray.append(currmoldid)
                    prevmold = currmold
                    prevmoldid = currmoldid
                idarray.append(currmoldid)
                # print(idarray)
                # print(uniquesortedmold)                             
                index = 0
                for Mouldname_id in uniquesortedmold:
                    # print(Mouldname_id)
                    Mouldname   = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')[0]['Mouldname']
                    StartTime   = (ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine, Mouldname_id = Mouldname_id, MachineState__gte = 0).values('time').first())['time']
                    EndTime     = (ProductionTable.objects.filter(date = inputDate, Plantname = Plantname, Machinename = Machine, Mouldname_id = Mouldname_id, MachineState__gte = 0).values('time').last())['time']
                    TimeArray.append(StartTime)
                    StatusArray.append(Mouldname)
                    ReasonArray.append('Production Started')
                    CauseArray.append(0)
                    
                    if(mouldflagid == 0):
                        mouldflagid = Mouldname_id
                    elif (mouldflagid != Mouldname_id):
                        StartTime   = ((list(ProductionTable.objects.filter(id = idarray[2*index -1]).values('time')))[0])['time']
                        EndTime     = ((list(ProductionTable.objects.filter(id = idarray[2*index]).values('time')))[0])['time']
                        TimeArray.append(str(StartTime + ' - ' + EndTime))
                        StatusArray.append('Machine Idle')
                        ReasonArray.append('Mould Change')
                        CauseArray.append(1)
                        mouldflagid = Mouldname_id

                    for data in downtime:
                        if(data['Machinename'] == Machine and data['Mouldname'] == Mouldname and data['difftime'] > '0:03:00'):
                            TimeArray.append(str(data['starttime'] + ' - ' + data['endtime']))
                            StatusArray.append('Machine Idle')
                            ReasonArray.append(data['primaryreason'])
                            CauseArray.append(2)
                            nonproductionseconds += (datetime.datetime.strptime(data['difftime'], "%H:%M:%S") - datetime.datetime(1900, 1, 1)).total_seconds()
                    index += 1
                nonproductionhour = datetime.timedelta(seconds=nonproductionseconds)
                productionhour = datetime.timedelta(seconds=TotalRunSeconds - nonproductionseconds)
                # print(TimeArray, StatusArray, ReasonArray, CauseArray)
                if(timeline.objects.filter(date = inputDate, Machinename = Machine).exists()):
                    # print(Machine)
                    timeline.objects.filter(date = inputDate, Machinename = Machine).update(Mouldname_id = Mouldname_id, time = TimeArray, lasttime= MEndTime, status = StatusArray, reason = ReasonArray, cause = CauseArray, productionhour=str(productionhour),
                                                                                            nonproductionhour=str(nonproductionhour), moldchangenumber=len(uniquesortedmold), totalparts= TotalProdCount)
                else:
                    # print(Machine)
                    inst = timeline(date = inputDate, Plantname = Plantname, Machinename = Machine, Mouldname_id = Mouldname_id, time = TimeArray, status = StatusArray, reason = ReasonArray,
                                    value = [], cause = CauseArray, name = [], lasttime= MEndTime, machinetype='assets/LK.png', operation=1, totalparts=1500, moldchangenumber=len(uniquesortedmold),  moldchangetime='01:00:00', 
                                    productionhour=str(productionhour), nonproductionhour=str(nonproductionhour))
                    inst.save()
            except:

                pass
        tdata = timeline.objects.filter(date = inputDate, Plantname = Plantname).values('id', 'Machinename').order_by('id')
        machine= []
        for i in tdata:
            machine.append(i['Machinename'])
        machinevalue = []
        machines = []
        reason=[]
        dict = {}
        reasonsArray = []
        for i in machine:
            # print(i)
            mdata = timeline.objects.filter(date = inputDate, Machinename = i).values('Machinename','productionhour', 'nonproductionhour', 'time', 'status', 'reason', 'name', 'value', 'cause', 'machinetype', 'operation')
            # print(mdata)
            for j in mdata:
                # print(j)
                mname = j['Machinename']; time = j['time']; status = j['status']; reason = j['reason']; prdhr = j['productionhour'];  nprdhr = j['nonproductionhour']; name = j['name']; 
                value = j['value']; cause = j['cause']; sel_machine = j['machinetype']; operation = j['operation']; 
                name_cause = []; time_line = []
                for i in range(0, len(name)): name_cause.append({"name":name[i],"value":value[i]})
                for x in range(0, len(time)): time_line.append({"time":time[x],"status":status[x],"reason":reason[x],"cause":cause[x]})

            machinevalue.append( {"Machinename": mname, "productionhrs":prdhr, "nonproductionhrs":nprdhr, "selectedmachine":sel_machine, "operation":operation, "log":time_line})
            for i in name_cause:
                if(i in reasonsArray): print('Dataname exist')
                else: reasonsArray.append(i)

            machines.append({'reasons': reasonsArray, "machines": machinevalue})
            # print(machines)
            data = json.dumps(machines)
            print(data)
            data_ = json.loads(data)
            print(data_)
            dict = {'mcstatusdashboard':data_[-1]}
        return JsonResponse(dict, safe=False)


# @periodic_task(run_every=crontab(hour=6, minute=5))
def machineAlert():
    getMachines = machineArray('MATE U1')
    for machine in getMachines:
        getDatas = breakdown.objects.filter(Plantname ='MATE U1', Machinename = machine).values('date', 'time', 'MachineState').order_by('id').last()
        print(getDatas['date'], getDatas['time'], getDatas['MachineState'])

def alertMail():
    tomail='Gokulraj.Rajasekaran@motherson.com;'
    sub='Houlry Wise and Rejection report for R-Connect'
    message = '''Dear Team, <br> 
                    Machine stop alert !!!
                    <br>
                    <br>
                Regards, <br>
                R-Connect Team. 
                <br>
                <br> 
                Note: This is an system generated mail.'''
    msg = MIMEMultipart('alternative')
    msg['Subject'] = sub
    msg['From'] = "R-Connect <no-reply@rconnect.com>"
    msg['To'] = tomail
    part2 = MIMEText(message, 'html')
    msg.attach(part2)
    smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
    smtpObj.sendmail('R-Connect <no-reply@rconnect.com>',tomail.split(';'),msg.as_string())
    smtpObj.quit()
    print("Mail Sent to ",tomail)
    return 1