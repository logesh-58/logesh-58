from mouldmanagement.models import Mouldmodel
# from productiontable.views import name
from django.shortcuts import render
from workflow.models import Tickets
from machinemanagement.models import AddMachine
from datetime import datetime, timedelta, time
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import badpart, breakdown, timeline
from .serializers import RejectionPartsSerializers, breakdownSerializers, timelineSerializers
import json
from productiontable.models import ProductionTable
from shiftmanagement.models import ShiftTimings
from celery.schedules import crontab
from dashboard.models import Dashboard
from analysis.views import machineArray
from usermanagement.models import AddUser
from django.db.models import Q

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

@csrf_exempt
def data(request):
    if(request.method == 'POST'):
        
        Plantname = request.GET['Plantname']

        DateReq = json.loads(request.body)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        Prd_strtime = shift_starttime['shift3end']

        # Extracting shift timings as strings (converted from time objects)
        shift_starttime_str = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        shift_endtime_str = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        inputDate = DateReq.get('date')

        startdate_dt = datetime.strptime(inputDate, "%Y-%m-%d")
        nex_enddate_dt = startdate_dt + timedelta(days=1)

        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')

        machinelist = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename', 'ammachineimage', 'amconsiderbool').order_by('amid')
        machine_names = [machine['amMachinename'] for machine in machinelist]

        all_breakdown_data = breakdown.objects.filter(Q(date = startdate_str, time__gte = shift_starttime_str) | 
                                                 Q (date = nex_enddate_str, time__lte = shift_endtime_str), 
                                                 Machinename__in=machine_names, 
                                                 Plantname=Plantname
                                                 ).values().order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                            Q(date=startdate_str, time__gte=shift_starttime_str) |
                            Q(date=nex_enddate_str, time__lte=shift_endtime_str),
                            Plantname=Plantname,
                            Machinename__in=machine_names,
                            ProductionCountActual__gt=0,
                            MachineState=1
                        ).values().order_by('id')
        
        response_data = []

        for machine in machinelist:

            select_machine = machine['amMachinename']

            if len([v for v in all_dashboard_value if v['date'] == startdate_str and v['Machinename'] == select_machine and v['time'] >= shift_starttime_str]) != 0:
            
                dashboard_value = [p for p in all_dashboard_value if
                                    p['Machinename'] == select_machine]
        
                # Function to group contiguous time ranges
                def group_time_ranges(mould_details, time_gap_minutes=90): #60 or #30
                    
                    time_gap = timedelta(minutes=time_gap_minutes)
                    grouped_ranges = []
                    current_group = [mould_details[0]]

                    for i in range(1, len(mould_details)):
                        current_time = datetime.strptime(mould_details[i]['time'], '%H:%M:%S')
                        previous_time = datetime.strptime(mould_details[i - 1]['time'], '%H:%M:%S')
                        
                        if current_time - previous_time <= time_gap:
                            current_group.append(mould_details[i])
                        else:
                            grouped_ranges.append(current_group)
                            current_group = [mould_details[i]]

                    if current_group:
                        grouped_ranges.append(current_group)

                    return grouped_ranges

                seen = set()
                distinctMould = [p['Mouldname_id'] for p in dashboard_value if not (p['Mouldname_id'] in seen or seen.add(p['Mouldname_id']))]
                # print("distinctMould:", distinctMould)

                machine_data = {"Machinename": select_machine, "Image": machine['ammachineimage'], "Data": []}
                
                saw = [k for k in all_breakdown_data if
                                        k['Machinename'] == select_machine
                                        ]

                breakdown_serialdata = breakdownSerializers(saw, many=True)

                previousstate = -1; previoustime = ''
                currentstate = -1; currenttime = ''
                flag = 0
                total_breakdown_seconds = 0
                for i in (breakdown_serialdata.data):

                    currentstate = i['MachineState']
                    currenttime  = i['date'] + " " + i['time'] 

                    if(flag == 0):
                        previousstate = currentstate
                        previoustime  = currenttime
                        flag = 1

                    if(previousstate == 0 and currentstate == 1):
                        difftime = ((datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')) - (datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')))
                        total_breakdown_seconds += difftime.total_seconds()
                        reasonarray = [None ,'Maintenance', 'Robot Problem', 'Power Issue', 'Machine Failure', 'Mould Change', 'Material Change', 'Operator Absence', 'Tool Problem']
                        machine_data["Data"].append({
                            "date": i['date'], 
                            'Breakdown_time': str(difftime),   
                            'Status': "Machine Idle",
                            'primaryreason': reasonarray[i['primaryreason']],
                            "Time": f"{(datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')).time()} to {(datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')).time()}",
                            "Current Mould Start Time"     : (datetime.strptime(previoustime, '%Y-%m-%d %H:%M:%S')).time(),
                            "Current Mould end time"       : (datetime.strptime(currenttime, '%Y-%m-%d %H:%M:%S')).time()
                        })
                    previousstate = currentstate
                    previoustime  = currenttime

                machine_data["Data"].sort(
                    key=lambda x: (
                        str(x.get("date", "9999-99-99")).split(" to ")[-1],  # Extracts the last part of the date string
                        str(x.get("Current Mould end time", "99:99:99"))  # Default high value for sorting time
                    )
                )

                total_breakdown_time = str(timedelta(seconds=int(total_breakdown_seconds)))
                machine_data["Total_Breakdown"] = total_breakdown_time

                total_production_seconds = 0
        
                production_data = []
                for mould_id in distinctMould:
                    mouldname = Mouldmodel.objects.get(id=mould_id).Mouldname
                    mould_detail = [p for p in dashboard_value if p['Mouldname_id'] == mould_id]
                    grouped_ranges = group_time_ranges(mould_detail)

                    for group in grouped_ranges:
                        production_entry ={
                            "Mouldname": mouldname,
                            "Mould Start Time": group[0]['time'],
                            "Mould end time": group[-1]['time'],
                            # "date":f"{group[0]['date']} -> {group[-1]['date']}",
                            "Total Production of mould": len(group)
                        }

                        # Handle the date formatting conditionally
                        if group[0]['date'] != group[-1]['date']:
                            production_entry["date"] = f"{group[0]['date']} to {group[-1]['date']}"
                        else:
                            production_entry["date"] = group[0]['date']

                        lasttime = group[-1]['date'] + " " + group[-1]['time']
                        firsttime = group[0]['date'] + " " + group[0]['time']

                        # Corrected line to calculate the difference in time
                        difftime = ((datetime.strptime(lasttime, '%Y-%m-%d %H:%M:%S')) - 
                                    (datetime.strptime(firsttime, '%Y-%m-%d %H:%M:%S')))
                        total_production_seconds += difftime.total_seconds()
                        
                        production_data.append(production_entry)

                Total_production = str(timedelta(seconds=int(total_production_seconds)))
                machine_data["Total_production"] = Total_production

                production_data = sorted(
                    production_data,
                    key=lambda x: (
                        x['date'].split(" to ")[-1],  # Extract the last date from the range
                        x.get('Mould end time', '99:99:99')
                    )
                )

                # Process production data with mould changes
                previous_mould = None
                previous_end_time = None
                for idx, prod in enumerate(production_data):
                    if "Mouldname" in prod:
                        date = prod["date"]
                        mouldname = prod["Mouldname"]
                        current_start_time = prod["Mould Start Time"]
                        current_end_time = prod["Mould end time"]

                        if previous_mould is None:
                            machine_data["Data"].append({
                                
                                    "date": date,
                                    "Mould": mouldname,
                                    "Time": current_start_time,
                                    "Current Mould Start Time": current_start_time,
                                    "Current Mould end time": current_end_time,
                                    "Status": "Production Commenced"
                                
                            })
                        else:
                            machine_data["Data"].append({
                                
                                    "date": date,
                                    "Mould": f"{previous_mould} to {mouldname}",
                                    "Time": f"{previous_end_time} to {current_start_time}",
                                    "Current Mould start time": current_start_time,
                                    "Current Mould end time": current_end_time,
                                    "Status": "Mould Change"
                                
                            })

                        previous_mould = mouldname
                        previous_end_time = current_end_time

                        if idx == len(production_data) - 1:
                            prd_datetime = Prd_strtime  # Assuming Prd_strtime is already a datetime.time object

                            # Check the format of current_end_time and parse accordingly
                            if isinstance(current_end_time, str):
                                if ":" in current_end_time and len(current_end_time) == 8:  # Likely "%H:%M:%S" format
                                    current_end_time = datetime.strptime(current_end_time, "%H:%M:%S").time()
                                else:
                                    raise ValueError(f"Unexpected format for current_end_time: {current_end_time}")

                            current_end_datetime = current_end_time

                            # if (datetime.combine(datetime.today(), prd_datetime) - datetime.combine(datetime.today(), current_end_datetime)).total_seconds() <= 3600 or current_end_datetime == Prd_strtime:
                                
                            if (datetime.combine(datetime.today(), current_end_datetime) - datetime.combine(datetime.today(), prd_datetime)).total_seconds() <= 3600 or current_end_datetime == Prd_strtime:

                                machine_data["Data"].append({
                                    
                                        "date": date,
                                        "Mould": mouldname,
                                        "Time": current_end_time,
                                        "Current Mould end time": current_end_time,
                                        "Status": "Production Concluded"
                                    
                                })
                            else:
                                machine_data["Data"].append({
                                    
                                        "date": date,
                                        "Mould": mouldname,
                                        "Time": current_end_time,
                                        "Current Mould end time": current_end_time,
                                        "Status": "Production Underway"
                                    
                                })

                # machine_data["Data"].sort(
                #     key=lambda x: (
                #         str(x.get("Production", {}).get("date", "9999-99-99")).split(" -> ")[-1],  # Extracts the last part of the date string
                #         str(x.get("Production", {}).get("Current Mould end time", "99:99:99"))  # Default high value for sorting time
                #     )
                # )
                machine_data["Data"].sort(
                    key=lambda x: (
                        str(x.get("date", "9999-99-99")).split(" to ")[-1],  # Extracts the last part of the date string
                        str(x.get("Current Mould end time", "99:99:99"))  # Default high value for sorting time
                    )
                )

                response_data.append(machine_data)

        return JsonResponse(response_data, safe=False)