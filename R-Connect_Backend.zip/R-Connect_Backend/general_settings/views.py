from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http.response import HttpResponse
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from general_settings.models import Timingtable
from general_settings.serializers import TimingTableDbSerializer
import datetime
# Create your views here.

@csrf_exempt
def generalset(request):
    plntname=request.GET['plantname']
    # print("Plantname:",a)
    if request.method == "GET":
        # print("data")
        timngtbl = Timingtable.objects.filter(ttplntname=plntname).values()
        gensetserailizer = TimingTableDbSerializer(timngtbl,many=True)
        return JsonResponse(gensetserailizer.data,safe=False)
    elif request.method == "POST":
        genconfig_DbData = JSONParser().parse(request)
        # print("peakhour config")
        gsdatacode = genconfig_DbData["ttcode"]
        gsconfigdata = Timingtable.objects.all()
        count=0
        for s in gsconfigdata:
            if s.ttcode == gsdatacode:
                count+=1
        if count==0:
            gensetSerializerData = TimingTableDbSerializer(data=genconfig_DbData,partial=True)
            if gensetSerializerData.is_valid():
                gensetSerializerData.save()
                return JsonResponse("General Settings saved to DB",safe=False)
            else:
                return JsonResponse("General Settings data already exist to the DB",safe=False)
    elif request.method == "PUT":          
        gsconfigdata = JSONParser().parse(request)
        Timingtable.objects.filter(ttcode=gsconfigdata["ttcode"]).update(ttplntname = gsconfigdata["ttplntname"],
                                                                         ttdaystarttime = gsconfigdata["ttdaystarttime"],
                                                                         tts1time = gsconfigdata["tts1time"],
                                                                         tts2time = gsconfigdata["tts2time"],
                                                                         tts3time = gsconfigdata["tts3time"],
                                                                         ttlastupdate = datetime.datetime.now(),
                                                                         ttcreatedby=gsconfigdata["ttcreatedby"],
                                                                         ttmodifiedby=gsconfigdata["ttmodifiedby"],
                                                                         ttcode=gsconfigdata["ttcode"])
        return JsonResponse("Data updated successfully",safe=False)
    elif request.method == "DELETE":
        Dbdata= JSONParser().parse(request)
            # print(Dbdata["code"])
        Timingtable.objects.filter(ttcode=Dbdata["code"]).delete()

        return JsonResponse("General Settings Record Deleted Successfully",safe=False)