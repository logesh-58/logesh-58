# from django import forms

# class AddMeter(forms.Form):
#     metername = forms.CharField(max_length=255,default=False,null=True)
#     metercode = forms.CharField(max_length=255,default=False,null=True)
#     metergroup = forms.ChoiceField(choices[('IMG','IMG'),('Non-Production','Non-Production'),('Paintshop','Paintshop')])
#     metercategory = forms.ChoiceField(choices[('Primary','Primary'),('Secondary','Secondary')])
#     meterlocation = forms.CharField(max_length=255,default=False,null=True)
#     plantname = forms.CharField(max_length=255,default=False,null=True)