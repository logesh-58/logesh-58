from django.db.models.base import Model
from rest_framework import serializers
from meter_management.models import AddMeter

class MeterManagementdbSerializer(serializers.ModelSerializer):
    class Meta:
        model = AddMeter
        fields = ['amid',
                  'ammetername',
                  'ammetersource',
                  'ammetercode',
                  'ammetergroup',
                  'ammetercategory',
                  'ammeterlocation',
                  'amplantname',
                  'amconsiderbool'
                  ]