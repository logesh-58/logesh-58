from django.http.response import HttpResponse
from meter_data.models import Demand
from django.views.decorators.csrf import csrf_exempt
from meter_management.models import AddMeter
from datetime import datetime, timedelta
from decimal import Decimal

# Create Your Code HERE...!
def main_fun(Ewondata, hours):
    # print(Ewondata)
    for i in Ewondata:
        # print(i)
        current_date = datetime.strptime(i['crntdate'], "%Y-%m-%d")
        # Chech the hour
        if hours in [0, 1, 2, 3, 4, 5]:
            current_date = datetime.strptime(i['crntdate'], "%Y-%m-%d") - timedelta(days = 1)
            # decalre the hours to the demand fields.
        field_name = [{"dm_h1":6}, {"dm_h2":7}, {"dm_h3":8},{"dm_h4":9},{"dm_h5":10},{"dm_h6":11},{"dm_h7":12},{"dm_h8":13},{"dm_h9":14},{"dm_h10":15},{"dm_h11":16},{"dm_h12":17},
                {"dm_h13":18}, {"dm_h14":19}, {"dm_h15":20}, {"dm_h16":21}, {"dm_h17":22}, {"dm_h18":23}, {"dm_h19":0}, {"dm_h20":1}, {"dm_h21":2}, {"dm_h22":3},{"dm_h23":4}, {"dm_h24":5}]
            # only Elite500 metername take it........!
        if i['metername'] == 'Elite500':
            for dict1 in field_name:
                for keys1 in dict1:
                    column_name = keys1
                    if hours == dict1[column_name]:
                        try:
                            # Check the Given data are already there in DB or Not
                            check_data  = Demand.objects.get(dm_date = current_date, dm_metername = i['metername'])
                            # if it is already there and we can only updated the given data in DB
                            for dict2 in Demand.objects.filter(dm_date = current_date, dm_metername = i['metername']).values():
                                for keys2 in dict2:
                                    # Check the given ewon KVA data is greater than the exixting data or not in DB
                                    if column_name == keys2 and Decimal(i['kva']) > (dict2[keys2]):
                                        #the Given data is greater than the exisiting data and then it should be updated into the DB
                                        update_data = Demand.objects.filter(dm_date = current_date, dm_metername = i['metername']).update(dm_date     = current_date, 
                                                                                                                                                dm_metername = i['metername'], 
                                                                                                                                                **{column_name : i['kva']})
                        except Demand.DoesNotExist:
                            # Creating the New object for the Given data in DB
                            create_data = Demand.objects.create(dm_date      = current_date, 
                                                                dm_metername = i['metername'], 
                                                                **{column_name : i['kva']})
def max_demand(meterDatabase_data):
    # Get the Hour data in that particualr date
    Hour = ((datetime.now().hour))
    main_fun(meterDatabase_data, Hour)