from meter_data.models import MeterStatus
from datetime import datetime, timedelta, date
from general_settings.models import Timingtable
from meter_management.models import AddMeter

#Create your code here..!
def insertmeterhealth(meterDatabase_data):
    meternames = AddMeter.objects.values('ammetername')
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    start_time = None
    timeing_query = Timingtable.objects.values('ttdaystarttime')
    date = datetime.now().date()
    previous_date    = date - timedelta(days=1)
    for data in timeing_query:
        start_time = data['ttdaystarttime']
    if current_time <= str(start_time):
        date =  str(previous_date)
    for mtr_nme in meternames:
        try:
            meter_create = MeterStatus.objects.get(ms_date = date, ms_metername = mtr_nme['ammetername'])
            if meter_create:
                meter_onlineoroffline = 1
                for meterhealth_data in meterDatabase_data:
                    # print(meterhealth_data['crntdate'], str(date))
                    if current_time >= '06:00:00' and current_time <= '07:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h1 = meter_onlineoroffline)
                    if current_time >= '07:00:00' and current_time <= '08:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h2 = meter_onlineoroffline)
                    if current_time >= '08:00:00' and current_time <= '09:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h3 = meter_onlineoroffline)
                    if current_time >= '09:00:00' and current_time <= '10:00:00' and meterhealth_data['crntdate'] == str(date):
                       update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h4 = meter_onlineoroffline) 
                    if current_time >= '10:00:00' and current_time <= '11:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h5 = meter_onlineoroffline)
                    if current_time >= '11:00:00' and current_time <= '12:00:00' and meterhealth_data['crntdate'] == str(date):
                       update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h6 = meter_onlineoroffline)
                    if current_time >= '12:00:00' and current_time <= '13:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h7 = meter_onlineoroffline) 
                    if current_time >= '13:00:00' and current_time <= '14:00:00' and meterhealth_data['crntdate'] == str(date):
                      update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h8 = meter_onlineoroffline) 
                    if current_time >= '14:00:00' and current_time <= '15:00:00' and meterhealth_data['crntdate'] == str(date):
                       update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h9 = meter_onlineoroffline)
                    if current_time >= '15:00:00' and current_time <= '16:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h10 = meter_onlineoroffline)
                    if current_time >= '16:00:00' and current_time <= '17:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h11 = meter_onlineoroffline)
                    if current_time >= '17:00:00' and current_time <= '18:00:00' and meterhealth_data['crntdate'] == str(date):
                       update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h12 = meter_onlineoroffline) 
                    if current_time >= '18:00:00' and current_time <= '19:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h13 = meter_onlineoroffline)
                    if current_time >= '19:00:00' and current_time <= '20:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h14 = meter_onlineoroffline)
                    if current_time >= '20:00:00' and current_time <= '21:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h15 = meter_onlineoroffline)
                    if current_time >= '21:00:00' and current_time <= '22:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h16 = meter_onlineoroffline)
                    if current_time >= '22:00:00' and current_time <= '23:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h17 = meter_onlineoroffline) 
                    if current_time >= '23:00:00' and current_time <= '23:59:59' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h18 = meter_onlineoroffline)
                    if current_time >= '00:00:00' and current_time <= '01:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h19 = meter_onlineoroffline)
                    if current_time >= '01:00:00' and current_time <= '02:00:00' and meterhealth_data['crntdate'] == str(date):
                       update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h20 = meter_onlineoroffline) 
                    if current_time >= '02:00:00' and current_time <= '03:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h21 = meter_onlineoroffline) 
                    if current_time >= '03:00:00' and current_time <= '04:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h22 = meter_onlineoroffline)
                    if current_time >= '04:00:00' and current_time <= '05:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h23 = meter_onlineoroffline) 
                    if current_time >= '05:00:00' and current_time <= '06:00:00' and meterhealth_data['crntdate'] == str(date):
                        update = MeterStatus.objects.filter(ms_date = meterhealth_data['crntdate'], ms_metername = meterhealth_data['metername']).update(ms_date = meterhealth_data['crntdate'], 
                                            ms_metername = meterhealth_data['metername'], ms_lastupdate = current_time, ms_h24 = meter_onlineoroffline)
                    # post data to db
        except MeterStatus.DoesNotExist:
            meter_create = MeterStatus.objects.create(ms_date  = date, ms_metername = mtr_nme['ammetername'], ms_lastupdate = current_time)
    # print("data_successfully created in DB")
  
