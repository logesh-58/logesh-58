from django.db.models.aggregates import Sum
from general_settings.models import Timingtable
from meter_data.models import Masterdatatable,Meterdata,Dailydatacache
from meter_data.serializers import DailydatacacheDbSerializer,MeterDatabaseSerializer
import datetime
from datetime import timedelta
from django.db.models import F
from django.db.models import FloatField

def insertcachedata(meterDatabase_data):
    timingtblrow = Timingtable.objects.get(ttid=1)
    dailyreporttime = timingtblrow.ttdaystarttime
    s1time = timingtblrow.tts1time
    s2time = timingtblrow.tts2time
    s3time = timingtblrow.tts3time
    for meterDatabase_data_dict in meterDatabase_data:
        s1string = s1time.strftime('%H')
        s1hrint = int(s1string)
        current_time = datetime.datetime.now()
        # Subtract 2 hours from datetime object containing current time
        past_time = current_time - timedelta(hours=s1hrint)
        # Convert datetime object to string in specific format 
        past_time_str = past_time.strftime('%Y-%m-%d')
        try:
            checkrow = Dailydatacache.objects.get(dcdate=past_time_str, dcmtrname=meterDatabase_data_dict["metername"])
            # try:
            #     checkdaterow = Dailydatacache.objects.get(dcmtrname=meterDatabase_data_dict["metername"],dcdate=past_time_str)
            # except:
            #     Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcdate=past_time_str,    dcevdaystart=meterDatabase_data_dict["actualenergy"])
        except Dailydatacache.DoesNotExist:
            #print("Exception Occured")
            deldata = Dailydatacache.objects.filter(dcdate__lt=past_time_str, dcmtrname=meterDatabase_data_dict["metername"]).all().delete()
            dailydatacahedbserializer = DailydatacacheDbSerializer(data={'dcmtrname':meterDatabase_data_dict["metername"],
                                                                        'dcevdaystart':meterDatabase_data_dict["actualenergy"],
                                                                        # 'dcmaxdemands' : meterDatabase_data_dict["kva"],
                                                                        'dcdate':past_time_str},
                                                                        partial=True)
            dailydatacahedbserializer.is_valid()
            dailydatacahedbserializer.save()
        # #print(s1time,s2time,s3time)
        matchrow = Dailydatacache.objects.get(dcdate=past_time_str, dcmtrname=meterDatabase_data_dict["metername"])
        #print("Dailycache matchrow executed")
        ##print(matchrow)
        curntshift = matchrow.dccrntshift
        curnthour = matchrow.dccrnthour
        curnttime = datetime.datetime.now().time()
        ##print(curntshift,curnthour,curnttime)
        #Assigning the Meter Status
        mtrstatus=meterDatabase_data_dict["meterstatus"]
        s1string = s1time.strftime('%H')
        h1time = int(s1string)
        h2time = ((h1time-24) + 1) if h1time>=23 else (h1time + 1)
        h3time = ((h2time-24) + 1) if h2time>=23 else (h2time + 1)
        h4time = ((h3time-24) + 1) if h3time>=23 else (h3time + 1)
        h5time = ((h4time-24) + 1) if h4time>=23 else (h4time + 1)
        h6time = ((h5time-24) + 1) if h5time>=23 else (h5time + 1)
        h7time = ((h6time-24) + 1) if h6time>=23 else (h6time + 1)
        h8time = ((h7time-24) + 1) if h7time>=23 else (h7time + 1)
        h9time = ((h8time-24) + 1) if h8time>=23 else (h8time + 1)
        h10time = ((h9time-24) + 1) if h9time>=23 else (h9time + 1)
        h11time = ((h10time-24) + 1) if h10time>=23 else (h10time + 1)
        h12time = ((h11time-24) + 1) if h11time>=23 else (h11time + 1)
        h13time = ((h12time-24) + 1) if h12time>=23 else (h12time + 1)
        h14time = ((h13time-24) + 1) if h13time>=23 else (h13time + 1)
        h15time = ((h14time-24) + 1) if h14time>=23 else (h14time + 1)
        h16time = ((h15time-24) + 1) if h15time>=23 else (h15time + 1)
        h17time = ((h16time-24) + 1) if h16time>=23 else (h16time + 1)
        h18time = ((h17time-24) + 1) if h17time>=23 else (h17time + 1)
        h19time = ((h18time-24) + 1) if h18time>=23 else (h18time + 1)
        h20time = ((h19time-24) + 1) if h19time>=23 else (h19time + 1)
        h21time = ((h20time-24) + 1) if h20time>=23 else (h20time + 1)
        h22time = ((h21time-24) + 1) if h21time>=23 else (h21time + 1)
        h23time = ((h22time-24) + 1) if h22time>=23 else (h22time + 1)
        h24time = ((h23time-24) + 1) if h23time>=23 else (h23time + 1)
        curnttimestring = curnttime.strftime('%H')
        #LOGIC TO GET CURRENT HOUR INT
        curnttimeint = int(curnttimestring)
        #LOGIC TO WRITE SHIFT START ENERGY
        #Everyday start energy consumption
        daystrt_ec = Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).values('dcevdaystart')
        daystrt_eng = daystrt_ec[0]['dcevdaystart']
        
        if (((h1time==curnttimeint) or (h2time==curnttimeint) or (h3time==curnttimeint) or (h4time==curnttimeint) or
           (h5time==curnttimeint) or (h6time==curnttimeint) or (h7time==curnttimeint) or (h8time==curnttimeint)) and (curntshift!=1)):
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcs1start=meterDatabase_data_dict["actualenergy"], dccrntshift=1)

        elif (((h9time==curnttimeint) or (h10time==curnttimeint) or (h11time==curnttimeint) or (h12time==curnttimeint) or
             (h13time==curnttimeint) or (h14time==curnttimeint) or (h15time==curnttimeint) or (h16time==curnttimeint)) and (curntshift!=2)):
            s1ec = Masterdatatable.objects.filter(mtdate=past_time_str,mtmtrname=meterDatabase_data_dict["metername"]).values('mts1ec')
            if len(s1ec)!=0:
                s2strt=float(daystrt_eng)+float(s1ec[0]['mts1ec'])
                Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcs2start=s2strt,dccrntshift=2)
            else:
                s2strt=float(daystrt_eng)+float(0.00)
                Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcs2start=s2strt,dccrntshift=2)
                                                                        
        elif (((h17time==curnttimeint) or (h18time==curnttimeint) or (h19time==curnttimeint) or (h20time==curnttimeint) or
             (h21time==curnttimeint) or (h22time==curnttimeint) or (h23time==curnttimeint) or (h24time==curnttimeint)) and (curntshift!=3)):
            ups2ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(shft_sum=F('mts1ec')+F('mts2ec'))
            if len(ups2ec)!=0:
                tot_shft_ec = ups2ec[0].shft_sum
                s3strt = float(daystrt_eng) + float(tot_shft_ec)
                Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcs3start=s3strt, dccrntshift=3)
            else:
                tot_shft_ec = 0.00
                s3strt = float(daystrt_eng) + float(tot_shft_ec)
                Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dcs3start=s3strt, dccrntshift=3)

        #LOGIC TO WRITE HOUR START ENERGY
        if ((h1time == curnttimeint) and (curnthour!= h1time)):
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch1start=daystrt_eng, dccrnthour=h1time)
        elif ((h2time == curnttimeint) and (curnthour!= h2time)):
            h1_ec = Masterdatatable.objects.filter(mtdate=past_time_str,mtmtrname=meterDatabase_data_dict["metername"]).values('mth1ec')
            if len(h1_ec)==0:
                h1_eng=0.00
            else:
                h1_eng=h1_ec[0]['mth1ec']
            h2strt = float(daystrt_eng) + float(h1_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch2start=h2strt,dccrnthour=h2time)  

        elif ((h3time == curnttimeint) and (curnthour!= h3time)):
            uh2_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh2_sum=F('mth1ec')+F('mth2ec'))
            if len(uh2_ec)==0:
                uh2_eng=0.00
            else:
                uh2_eng=uh2_ec[0].uh2_sum
            h3strt = float(daystrt_eng) + float(uh2_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch3start=h3strt,dccrnthour=h3time)

        elif ((h4time == curnttimeint) and (curnthour!= h4time)):
            uh3_ec = Masterdatatable.objects.filter(mtdate=past_time_str,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh3_sum=F('mth1ec')+F('mth2ec')+F('mth3ec'))
            if len(uh3_ec)==0:
                uh3_eng=0.00
            else:
                uh3_eng=uh3_ec[0].uh3_sum
            h4strt = float(daystrt_eng) + float(uh3_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch4start=h4strt,dccrnthour=h4time)

        elif ((h5time == curnttimeint) and (curnthour!= h5time)):
            uh4_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh4_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec'))
            if len(uh4_ec)==0:
                uh4_eng=0.00
            else:
                uh4_eng=uh4_ec[0].uh4_sum
            h5strt = float(daystrt_eng) + float(uh4_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch5start=h5strt,dccrnthour=h5time)

        elif ((h6time == curnttimeint) and (curnthour!= h6time)):
            uh5_ec = Masterdatatable.objects.filter(mtdate=past_time_str,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh5_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec'))
            if len(uh5_ec)==0:
                uh5_eng=0.00
            else:
                uh5_eng=uh5_ec[0].uh5_sum
            h6strt = float(daystrt_eng) + float(uh5_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch6start=h6strt,dccrnthour=h6time)    

        elif ((h7time == curnttimeint) and (curnthour!= h7time)):
            uh6_ec = Masterdatatable.objects.filter(mtdate=past_time_str,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh6_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')+F('mth6ec'))
            if len(uh6_ec)==0:
                uh6_eng=0.00
            else:
                uh6_eng=uh6_ec[0].uh6_sum
            h7strt = float(daystrt_eng) + float(uh6_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch7start=h7strt,dccrnthour=h7time)  

        elif ((h8time == curnttimeint) and (curnthour!= h8time)):
            uh7_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh7_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec'))
            if len(uh7_ec)==0:
                uh7_eng=0.00
            else:
                uh7_eng=uh7_ec[0].uh7_sum
            h8strt = float(daystrt_eng) + float(uh7_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch8start=h8strt,dccrnthour=h8time) 

        elif ((h9time == curnttimeint) and (curnthour!= h9time)):
            uh8_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh8_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec'))
            if len(uh8_ec)==0:
                uh8_eng=0.00
            else:
                uh8_eng=uh8_ec[0].uh8_sum
            h9strt = float(daystrt_eng) + float(uh8_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch9start=h9strt,dccrnthour=h9time) 

        elif ((h10time == curnttimeint) and (curnthour!= h10time)):
            uh9_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh9_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec'))
            if len(uh9_ec)==0:
                uh9_eng=0.00
            else:
                uh9_eng=uh9_ec[0].uh9_sum
            h10strt = float(daystrt_eng) + float(uh9_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch10start=h10strt,dccrnthour=h10time)  

        elif ((h11time == curnttimeint) and (curnthour!= h11time)):
            uh10_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh10_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec'))
            if len(uh10_ec)==0:
                uh10_eng=0.00
            else:
                uh10_eng=uh10_ec[0].uh10_sum
            h11strt = float(daystrt_eng) + float(uh10_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch11start=h11strt,dccrnthour=h11time)       

        elif ((h12time == curnttimeint) and (curnthour!= h12time)):
            uh11_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh11_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec'))
            if len(uh11_ec)==0:
                uh11_eng=0.00
            else:
                uh11_eng=uh11_ec[0].uh11_sum
            h12strt = float(daystrt_eng) + float(uh11_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch12start=h12strt,dccrnthour=h12time) 

        elif ((h13time == curnttimeint) and (curnthour!= h13time)):
            uh12_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh12_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec'))
            if len(uh12_ec)==0:
                uh12_eng=0.00
            else:
                uh12_eng=uh12_ec[0].uh12_sum
            h13strt = float(daystrt_eng) + float(uh12_eng)
            # #print("This is h13:",h13strt)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch13start=h13strt,dccrnthour=h13time)   

        elif ((h14time == curnttimeint) and (curnthour!= h14time)):
            uh13_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh13_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec'))
            if len(uh13_ec)==0:
                uh13_eng=0.00
            else:
                uh13_eng=uh13_ec[0].uh13_sum
            h14strt = float(daystrt_eng) + float(uh13_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch14start=h14strt,dccrnthour=h14time)  

        elif ((h15time == curnttimeint) and (curnthour!= h15time)):
            uh14_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh14_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec'))
            if len(uh14_ec)==0:
                uh14_eng=0.00
            else:
                uh14_eng=uh14_ec[0].uh14_sum
            h15strt = float(daystrt_eng) + float(uh14_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch15start=h15strt,dccrnthour=h15time)   

        elif ((h16time == curnttimeint) and (curnthour!= h16time)):
            uh15_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh15_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec'))
            if len(uh15_ec)==0:
                uh15_eng=0.00
            else:
                uh15_eng=uh15_ec[0].uh15_sum
            h16strt = float(daystrt_eng) + float(uh15_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch16start=h16strt,dccrnthour=h16time)  

        elif ((h17time == curnttimeint) and (curnthour!= h17time)):
            uh16_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh16_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec'))
            if len(uh16_ec)==0:
                uh16_eng=0.00
            else:
                uh16_eng=uh16_ec[0].uh16_sum
            h17strt = float(daystrt_eng) + float(uh16_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch17start=h17strt,dccrnthour=h17time)  

        elif ((h18time == curnttimeint) and (curnthour!= h18time)):
            uh17_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh17_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec'))
            if len(uh17_ec)==0:
                uh17_eng=0.00
            else:
                uh17_eng=uh17_ec[0].uh17_sum
            h18strt = float(daystrt_eng) + float(uh17_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch18start=h18strt,dccrnthour=h18time) 

        elif ((h19time == curnttimeint) and (curnthour!= h19time)):
            uh18_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh18_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec'))
            if len(uh18_ec)==0:
                uh18_eng=0.00
            else:
                uh18_eng=uh18_ec[0].uh18_sum
            h19strt = float(daystrt_eng) + float(uh18_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch19start=h19strt,dccrnthour=h19time)    

        elif ((h20time == curnttimeint) and (curnthour!= h20time)):
            uh19_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh19_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec')
                                                                                              +F('mth19ec'))
            if len(uh19_ec)==0:
                uh19_eng=0.00
            else:
                uh19_eng=uh19_ec[0].uh19_sum
            h20strt = float(daystrt_eng) + float(uh19_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch20start=h20strt,dccrnthour=h20time) 

        elif ((h21time == curnttimeint) and (curnthour!= h21time)):
            uh20_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh20_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec')
                                                                                              +F('mth19ec')+F('mth20ec'))
            if len(uh20_ec)==0:
                uh20_eng=0.00
            else:
                uh20_eng=uh20_ec[0].uh20_sum
            h21strt = float(daystrt_eng) + float(uh20_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch21start=h21strt,dccrnthour=h21time)   

        elif ((h22time == curnttimeint) and (curnthour!= h22time)):
            uh21_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh21_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec')
                                                                                              +F('mth19ec')+F('mth20ec')+F('mth21ec'))
            if len(uh21_ec)==0:
                uh21_eng=0.00
            else:
                uh21_eng=uh21_ec[0].uh21_sum
            h22strt = float(daystrt_eng) + float(uh21_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch22start=h22strt,dccrnthour=h22time) 

        elif ((h23time == curnttimeint) and (curnthour!= h23time)):
            uh22_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh22_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec')
                                                                                              +F('mth19ec')+F('mth20ec')+F('mth21ec')+F('mth22ec'))
            if len(uh22_ec)==0:
                uh22_eng=0.00
            else:
                uh22_eng=uh22_ec[0].uh22_sum
            h23strt = float(daystrt_eng) + float(uh22_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch23start=h23strt,dccrnthour=h23time) 

        elif ((h24time == curnttimeint) and (curnthour!= h24time)):
            uh23_ec = Masterdatatable.objects.filter(mtdate=past_time_str
                            ,mtmtrname=meterDatabase_data_dict["metername"]).annotate(uh23_sum=F('mth1ec')+F('mth2ec')+F('mth3ec')+F('mth4ec')+F('mth5ec')
                                                                                              +F('mth6ec')+F('mth7ec')+F('mth8ec')+F('mth9ec')+F('mth10ec')
                                                                                              +F('mth11ec')+F('mth12ec')+F('mth13ec')+F('mth14ec')
                                                                                              +F('mth15ec')+F('mth16ec')+F('mth17ec')+F('mth18ec')
                                                                                              +F('mth19ec')+F('mth20ec')+F('mth21ec')+F('mth22ec')
                                                                                              +F('mth23ec'))
            if len(uh23_ec)==0:
                uh23_eng=0.00
            else:
                uh23_eng=uh23_ec[0].uh23_sum
            h24strt = float(daystrt_eng) + float(uh23_eng)
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dch24start=h24strt,dccrnthour=h24time)   
        try:
            Dailydatacache.objects.filter(dcmtrname=meterDatabase_data_dict["metername"]).update(dclastupd=datetime.datetime.now())                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
        except Exception as error:
            print('Insert daily data catche Error: ', error)
              
    print('Insert daily data catche Completed @', datetime.datetime.now())
    print('----------------------------------------------------------------')


