from django.shortcuts import render
from celery.task import periodic_task
from celery.schedules import crontab
# from celery.utils.log import get_task_logger
from django.http.response import JsonResponse
from django.http import HttpResponse
from workflow_dashboard.models import WorkflowData
from datetime import timedelta
import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from meter_data.models import Masterdatatable
from django.db.models import Q
from datetime import date
# from django_celery_beat.models import PeriodicTask, IntervalSchedule

# Create your views here.
# schedule = IntervalSchedule.objects.create(every=10, period=IntervalSchedule.SECONDS)
# task = PeriodicTask.objects.create(interval=schedule, name=guid1, task='mtrstatus_mail.views.meterstatusmail', args=json.dumps([guid1]))
@periodic_task(run_every=timedelta(seconds=1800))
# @periodic_task(run_every=crontab(minute=30,hour='0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23'))
def MeterStatusMail():
        # if request.method == 'GET':
        Workflowdata = WorkflowData.objects.all().order_by('wfid').values('wfplantname')
        plntname=Workflowdata[0]["wfplantname"]
        crntdate=date.today()
        # print(crntdate)
        offlinemtrdata = Masterdatatable.objects.filter((Q(mtmtrstatus=0) | Q(mtmtrstatus=2)) & Q(mtdate=crntdate) & Q(mtplntlctn=plntname)).values('mtmtrname')
        offlinecount=offlinemtrdata.count()
        # print(offlinecount)
        if offlinecount!=0:
            Workflowdata = WorkflowData.objects.all().order_by('wfid')
            tomail=Workflowdata[0].atoemail
            ccmail=Workflowdata[0].accmail

            mailto = str(tomail)+";"+str(ccmail)
            sub = "Meter Offline - Notification"
            body = "Dear Team,<br> The meters listed below are in Offline. Kindly check in real-time and update <br>"
            i=1
            for data in offlinemtrdata:
                body=body+str(i)+". "+str(data["mtmtrname"])+"<br>"
                i+=1
            body=body+"<br> <b>Note: This is an auto-generated mail </b><br><br>"
            body=body+"Regards,<br>"
            body=body+"R-Energy Team.<br>"
            msg = MIMEMultipart('alternative')
            msg['Subject'] = sub
            msg['From'] = "R-Energy <no-reply@r-energy.com>"
            msg['To'] = mailto
            part2 = MIMEText(body, 'html')
            msg.attach(part2)
            message = """From: R-Energy Team
                        To: """+ mailto +""";
                        Subject: """+ sub +"""
                        """+ body +""".
                        """
            smtpObj = smtplib.SMTP('smtp.int.motherson.com',25)
            smtpObj.sendmail('ntpdpmt1@int.motherson.com',mailto.split(';'),msg.as_string())    
            smtpObj.quit() 
        # return HttpResponse("Hi",status=200)