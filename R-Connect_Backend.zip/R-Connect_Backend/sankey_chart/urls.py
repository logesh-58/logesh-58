from django.urls import path
from sankey_chart import views, tests, sankeychart

urlpatterns = [
    # path('sankeychart/', views.sankey_fun, name= "SANKEY CHART"),
    # path('sankeycharttest/', tests.sankey_fun, name= "SANKEY CHART")
    path('sankeychart/', sankeychart.Sankey, name= "sankeychart")
]
