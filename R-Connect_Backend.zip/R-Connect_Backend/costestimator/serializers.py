from django.db.models import fields
from costestimator.models import  Cost_DG, Cost_EB, Cost_Solar, Cost_Wind, Cost_Petrol, Cost_LPG, Cost_CNG, Cost_PNG, cost_water
from rest_framework import serializers

# class CostSettingsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CostEstimationModel
#         fields =[
#                 'ce_id',
#                 'ce_srcname',
#                 'ce_unitcost', 
#                 'ce_plantname'
#         ]

class DGSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_DG
        fields ="__all__"

class SolarSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_Solar
        fields ="__all__"

class EBSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_EB
        fields ="__all__"

class WindSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_Wind
        fields ="__all__"

class PetrolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_Petrol
        fields = "__all__"

class LPGSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_LPG
        fields = "__all__"

class CNGSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_CNG
        fields = "__all__"

class PNGSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cost_PNG
        fields = "__all__"
        
class WaterSerializer(serializers.ModelSerializer):
    class Meta:
        model = cost_water
        fields = "__all__"