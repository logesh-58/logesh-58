from django.urls import path
from costestimator import views , reportfile, costviews

urlpatterns =[
    # path('costconfig/',views.CostSettings,name="cost estimator"),
    # path('costcalc/',views.CostCalculator,name="cost calculator")
    
    path('costdata/',views.Costing,name="cost data"),
    path('costreport/',views.costreport,name="cost data"),
    path('reportfile/',reportfile.costreport,name="cost data"),
    path('energycost/',views.energycost,name="cost data"),
    path('plantcost/',costviews.PlantCost,name="plantcost")
]
