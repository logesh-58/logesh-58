from django.apps import AppConfig


class ExcessPowerConfig(AppConfig):
    name = 'excess_power'
