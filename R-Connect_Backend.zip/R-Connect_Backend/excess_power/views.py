from django.shortcuts import render
from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from meter_data.models import Masterdatatable
from source_management.models import AddSource
import json

# Create your views here.
@csrf_exempt
def excessdemand(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        # print(data)
        from_date = data['fromdate']; to_date = data['todate']; srcname = data['srcname']
        Totalcapacity = AddSource.objects.get(assourcename = srcname).assourcecapacity
        if srcname == 'Transformer1':
            consumedcapacity = Masterdatatable.objects.filter(mtdate__range = [from_date, to_date], mtsrcname = srcname, mtcategory = 'Secondary', mtmtrname = 'Elite500', mtgrpname = 'Incomer').values('mtdate' ,'mtmaxdemands').order_by('id')
            request_list = []
            for dct in consumedcapacity:
                excess_power = Totalcapacity -  round(dct['mtmaxdemands'])
                request_list.append({"date":dct['mtdate'], "totalcapacity":int(Totalcapacity), "consumedcapacity":int(round(dct['mtmaxdemands'])), "excess_power":int(excess_power)})
            return JsonResponse(request_list, safe = False)
        elif srcname == 'DG':
            request_list = []
            return JsonResponse(request_list, safe = False)
        elif srcname == 'Solar Energy':
            request_list = []
            return JsonResponse(request_list, safe = False)