from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
from costestimator.models import Cost_CNG, Cost_LPG, Cost_DG, Cost_PNG, Cost_Petrol
from django.db.models.aggregates import Sum
from meter_data.models import Masterdatatable
from source_management.models import AddSource

@csrf_exempt
def Dashboard(request):
    if request.method == 'GET':
        
        current_date = datetime.now()
        current_month = current_date.month
        current_year = current_date.year
        next_year = current_year + 1
        
        # FUEL
        fuel_array = []
        try:
            dg_data = Cost_DG.objects.filter(dg_date__year = current_year, dg_date__month = current_month).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
            fuel_array.append(float(dg_data['dg_lit_cons__sum']) * 2.6)
        except:
            fuel_array.append(0)
        try:
            pt_data = Cost_Petrol.objects.filter(pt_date__year = current_year, pt_date__month = current_month).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
            fuel_array.append(float(pt_data['pt_lit_cons__sum']) * 2.32)
        except:
            fuel_array.append(0)
        try: 
            lpg_data = Cost_LPG.objects.filter(LPG_date__year = current_year, LPG_date__month = current_month).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
            fuel_array.append(float(lpg_data['LPG_kg_cons__sum']) * 2.19)
        except:
            fuel_array.append(0)
        try:
            cng_data = Cost_CNG.objects.filter(CNG_date__year = current_year, CNG_date__month = current_month).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
            fuel_array.append(float(cng_data['CNG_kg_cons__sum']) * 0.614)
        except:
            fuel_array.append(0)
        try:
            png_data = Cost_PNG.objects.filter(PNG_date__year = current_year, PNG_date__month = current_month).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
            fuel_array.append(float(png_data['PNG_kg_cons__sum']) * 0.056)
        except:
            fuel_array.append(0)
       
        # print(round(sum(fuel_array)))
        
        # ELECTRICITY
        electricity_array = []
        sourcename = AddSource.objects.values('assourcename')
        for data in sourcename:
            # print(data['assourcename'])
            if data['assourcename'] == 'Transformer1':
                transformer = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = current_month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    electricity_array.append(float(transformer['mtenergycons__sum']) * 0.7132)
                except:
                    electricity_array.append(0)
            if data['assourcename'] == 'Solar Energy':
                solar = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = current_month, mtsrcname = data['assourcename'], mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    electricity_array.append(float(solar['mtenergycons__sum']) * 0.041)
                except:
                    electricity_array.append(0)
        # print(round(sum(electricity_array)))
        
        # Line graph
        # Scope1
        emission1_array = []
        for month in range(4, 13):
            monthwise_emission = []
            # print(current_year, month)
            try:
                dg_data = Cost_DG.objects.filter(dg_date__year = current_year, dg_date__month = month).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                monthwise_emission.append(float(dg_data['dg_lit_cons__sum']) * 2.6)
            except:
                monthwise_emission.append(0)
            try:
                pt_data = Cost_Petrol.objects.filter(pt_date__year = current_year, pt_date__month = month).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                monthwise_emission.append(float(pt_data['pt_lit_cons__sum']) * 2.32)
            except:
                monthwise_emission.append(0)
            try:
                lpg_data = Cost_LPG.objects.filter(LPG_date__year = current_year, LPG_date__month = month).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                monthwise_emission.append(float(lpg_data['LPG_kg_cons__sum']) * 2.19)
            except:
                monthwise_emission.append(0)
            try:
                cng_data = Cost_CNG.objects.filter(CNG_date__year = current_year, CNG_date__month = month).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                monthwise_emission.append(float(cng_data['CNG_kg_cons__sum']) * 0.614)
            except:
                monthwise_emission.append(0)
            try:
                png_data = Cost_PNG.objects.filter(PNG_date__year = current_year, PNG_date__month = month).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
                monthwise_emission.append(float(png_data['PNG_kg_cons__sum']) * 0.056)
            except:
                monthwise_emission.append(0)
            emission1_array.append(round(sum(monthwise_emission)))
            emission2_array = []
        for month in range(1, 4):
            monthwise_emission = []
            # print(next_year, month)
            try:
                dg_data = Cost_DG.objects.filter(dg_date__year = next_year, dg_date__month = month).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                monthwise_emission.append(float(dg_data['dg_lit_cons__sum']) * 2.6)
            except:
                monthwise_emission.append(0)
            try:
                pt_data = Cost_Petrol.objects.filter(pt_date__year = next_year, pt_date__month = month).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                monthwise_emission.append(float(pt_data['pt_lit_cons__sum']) * 2.32)
            except:
                monthwise_emission.append(0)
            try:
                lpg_data = Cost_LPG.objects.filter(LPG_date__year = next_year, LPG_date__month = month).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                monthwise_emission.append(float(lpg_data['LPG_kg_cons__sum']) * 2.19)
            except:
                monthwise_emission.append(0)
            try:
                cng_data = Cost_CNG.objects.filter(CNG_date__year = next_year, CNG_date__month = month).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                monthwise_emission.append(float(cng_data['CNG_kg_cons__sum']) * 0.614)
            except:
                monthwise_emission.append(0)
            try:
                png_data = Cost_PNG.objects.filter(PNG_date__year = next_year, PNG_date__month = month).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons'))
                monthwise_emission.append(float(png_data['PNG_kg_cons__sum']) * 0.056)
            except:
                monthwise_emission.append(0)
            emission2_array.append(round(sum(monthwise_emission)))   
        # print(emission1_array + emission2_array)
        
        # Scope2
        scope2_monthly_emission = []
        for month in range(4, 13):
            array1 = []
            try:
                trans_emission = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                array1.append(float(trans_emission['mtenergycons__sum']) * 0.7132)
            except:
                array1.append(0)
            try:
                solar_emission = Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = month, mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                array1.append(float(solar_emission['mtenergycons__sum']) * 0.041)
            except:
                array1.append(0)
            scope2_monthly_emission.append(round(sum(array1)))
        for month in range(1, 4):
            array2 = []
            try:
                trans_emission = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                array2.append(float(trans_emission['mtenergycons__sum']) * 0.7132)
            except:
                array2.append(0)
            try:
                solar_emission = Masterdatatable.objects.filter(mtdate__year = next_year, mtdate__month = month, mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons'))
                array2.append(float(solar_emission['mtenergycons__sum']) * 0.041)
            except:
                array2.append(0)
            scope2_monthly_emission.append(round(sum(array2)))
        # print(scope2_monthly_emission)
        
        # Scope3
        
        scope3_monthly_emission = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        
        # Donut yearly chart
        scope1 = sum(emission1_array + emission2_array)
        scope2 = sum(scope2_monthly_emission)
        scope3 = 0
        
        # PieChart current month based
        # Diesel
        diesel = ( Cost_DG.objects.filter(dg_date__year = current_year, dg_date__month = current_month).values('dg_lit_cons').aggregate(Sum('dg_lit_cons')))['dg_lit_cons__sum']
        if diesel is None:
            diesel = 0
        # print(round(diesel['dg_lit_cons__sum']))
        
        # Petrol
        petrol = (Cost_Petrol.objects.filter(pt_date__year = current_year, pt_date__month = current_month).values('pt_lit_cons').aggregate(Sum('pt_lit_cons')))['pt_lit_cons__sum']
        if petrol is None:
            petrol = 0
        # print(round(petrol['pt_lit_cons__sum']))
        
        # LPG
        lpg =( Cost_LPG.objects.filter(LPG_date__year = current_year, LPG_date__month = current_month).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons')))['LPG_kg_cons__sum']
        if lpg is None:
            lpg = 0
        # print(round(lpg['LPG_kg_cons__sum']))
        
        # CNG 
        cng = ( Cost_CNG.objects.filter(CNG_date__year = current_year, CNG_date__month = current_month).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons')))['CNG_kg_cons__sum']
        if cng is None:
            cng = 0
        # print(round(cng['CNG_kg_cons__sum']))
        
        # PNG 
        png =( Cost_PNG.objects.filter(PNG_date__year = current_year, PNG_date__month = current_month).values('PNG_kg_cons').aggregate(Sum('PNG_kg_cons')))['PNG_kg_cons__sum']
        if png is None:
            png =0
        # print(round(png['PNG_kg_cons__sum']))
        
        # Transformer1
        
        transformer1 =float(( Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = current_month, mtsrcname = 'Transformer1', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons')))['mtenergycons__sum']) * 0.7132
        if transformer1 is None:
            transformer1 = 0
        # print(round(transformer1['mtenergycons__sum']))
        
        # Solar Energy
        solarenergy =float(( Masterdatatable.objects.filter(mtdate__year = current_year, mtdate__month = current_month, mtsrcname = 'Solar Energy', mtcategory = 'Secondary', mtgrpname = 'Incomer').values('mtenergycons').aggregate(Sum('mtenergycons')))['mtenergycons__sum']) * 0.041
        if solarenergy is None:
            solarenergy = 0
        # print(round(solarenergy['mtenergycons__sum']))
        
        # Final
        
        total_energy_emission = round(sum(electricity_array))
        total_fuel_emission = round(sum(fuel_array))
        waste = 0
        scope_data = [scope1, scope2, scope3]
        scope_name = ['S1', 'S2', 'S3']
        emission_data = [round(transformer1), round(solarenergy), round(diesel), round(petrol), round(lpg), round(cng), round(png)]
        emission_name = ['Transformer', 'Solar Energy', 'Diesel', 'Petrol', 'LPG', 'CNG', 'PNG']
        monthly_emission_name = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar']
        # print(monthly_emission_name)
        monthly_emission_s1 = emission1_array + emission2_array
        # print(monthly_emission_s1)
        monthly_emission_s2 = scope2_monthly_emission
        # print(monthly_emission_s2)
        monthly_emission_s3 = scope3_monthly_emission
        
        mydict = {
            'Energy_Emission' : total_energy_emission,
            'Fuel_Emission' : total_fuel_emission,
            'Waste': waste,
            'Scope_data': scope_data,
            'Scope_name' : scope_name,
            'Emission_name' : emission_name,
            'Emission_data' : emission_data,
            'Monthly_emission_name' : monthly_emission_name,
            'Monthly_emission_S1' : monthly_emission_s1,
            'Monthly_emission_S2' : monthly_emission_s2,
            'Monthly_emission_S3' : monthly_emission_s3
        }
        return JsonResponse(mydict, safe=False)