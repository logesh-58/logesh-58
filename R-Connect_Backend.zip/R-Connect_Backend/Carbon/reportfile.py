from time import strftime
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import xlwt
import os
from django.db.models.aggregates import Sum
from REnergy.settings import BASE_DIR
from costestimator.models import Cost_DG, Cost_LPG, Cost_Petrol, Cost_Wind, Cost_CNG
from meter_data.models import Masterdatatable
from source_management.models import AddSource
from datetime import datetime, timedelta
import calendar

@csrf_exempt
def CarbonExcel(request):

    current_date = datetime.now()
    current_month = current_date.month
    current_year = current_date.year

    start_month = 4
    while start_month <= current_month:
        start_date = datetime(current_year, start_month, 1).strftime("%Y-%m-%d")
        # print(start_date)
        if start_month == 12:
            end_date = datetime(current_year, start_month, 31).strftime("%Y-%m-%d")
            # print(end_date)
        else:
            end_date = (datetime(current_year, start_month + 1, 1) + timedelta(days = -1)).strftime("%Y-%m-%d")
            # print(end_date)
        start_month += 1

    start_month = 4
    if start_month > current_month:
        last_year = current_year - 1
        
        for temp_month in range(4, 13):
            start_date = datetime(last_year, temp_month, 1).strftime("%Y-%m-%d")
            # print(start_date)
            if temp_month == 12:
                end_date = datetime(last_year, temp_month, 31).strftime("%Y-%m-%d")
                # print(end_date)
            else:
                end_date = (datetime(last_year, temp_month + 1, 1) + timedelta(days = -1)).strftime("%Y-%m-%d")
                # print(end_date)
        
        start_month = 1
        while start_month <= current_month:
            start_date = datetime(current_year, start_month, 1).strftime("%Y-%m-%d")
            # print(start_date)
            end_date = (datetime(current_year, start_month + 1, 1) + timedelta(days = -1)).strftime("%Y-%m-%d")
            # print(end_date)
            start_month += 1

        addsource = AddSource.objects.values('assourcename')

        Consumption_list = []
        Emission_list = []
        
        for j in addsource:
            if j['assourcename'] == 'Transformer1':
                ebdata = Masterdatatable.objects.filter(mtgrpname = 'Incomer', mtcategory = 'Secondary', mtsrcname = 'Transformer1', mtdate__range =(start_date, end_date)).values('mtenergycons').aggregate(Sum('mtenergycons'))
                try:
                    Consumption = round(ebdata['mtenergycons__sum'])
                    # print("Transformer1 consumption :",Consumption)
                    list1 = Consumption
                    Consumption_list.append(list1)
                    Emission = Consumption * 0.7132
                    # print("Transformer1 Emission :",Emission)
                    list2 = Emission
                    Emission_list.append(list2)
                except:
                    Consumption = 0
                Emission_value = Consumption * 0.041
                Emission = round(Emission_value)

            if j['assourcename'] == 'DG':
                ebdata = Cost_DG.objects.filter(dg_date__range =(start_date, end_date)).values('dg_lit_cons').aggregate(Sum('dg_lit_cons'))
                try:
                    Consumption = round(ebdata['dg_lit_cons__sum'])
                    # print("DG consumption :",Consumption)
                    conlist1 = Consumption
                    Consumption_list.append(conlist1)
                    Emission = Consumption * 0.7132
                    # print("DG emission :",Emission)
                    emilist1 = Emission
                    Emission_list.append(emilist1)
                except:
                    Consumption = 0
                Emission_value = Consumption * 0.041
                Emission = round(Emission_value)

            if j['assourcename'] == 'Petrol':
                ebdata = Cost_Petrol.objects.filter(pt_date__range =(start_date, end_date)).values('pt_lit_cons').aggregate(Sum('pt_lit_cons'))
                try:
                    Consumption = round(ebdata['pt_lit_cons__sum'])
                    # print("Petrol consumption :",Consumption)
                    conlist2 = Consumption
                    Consumption_list.append(conlist2)
                    Emission = Consumption * 0.7132
                    # print("Petrol emission",Emission)
                    emilist2 = Emission
                    Emission_list.append(emilist2)
                except:
                    Consumption = 0
                Emission_value = Consumption * 2.32
                Emission = round(Emission_value)

            if j['assourcename'] == 'CNG':
                ebdata = Cost_CNG.objects.filter(CNG_date__range =(start_date, end_date)).values('CNG_kg_cons').aggregate(Sum('CNG_kg_cons'))
                try:
                    Consumption = round(ebdata['CNG_kg_cons__sum'])
                    # print("CNG consumption :",Consumption)
                    conlist3 = Consumption
                    Consumption_list.append(conlist3)
                    Emission = Consumption * 0.7132
                    # print("cng emission :",Emission)
                    emilist3 = Emission
                    Emission_list.append(emilist3)
                except:
                    Consumption = 0
                Emission_value = Consumption * 0.614
                Emission = round(Emission_value)

            if j['assourcename'] == 'LPG':
                ebdata = Cost_LPG.objects.filter(LPG_date__range =(start_date, end_date)).values('LPG_kg_cons').aggregate(Sum('LPG_kg_cons'))
                try:
                    Consumption = round(ebdata['LPG_kg_cons__sum'])
                    # print("lpg consumption :",Consumption)
                    conlist4 = Consumption
                    Consumption_list.append(conlist4)
                    Emission = Consumption * 2.19
                    # print("lpg emission :",Emission)
                    emilist4 = Emission
                    Emission_list.append(emilist4)
                except:
                    Consumption = 0
                Emission_value = Consumption * 2.19
                Emission = round(Emission_value)

        # print("Consumption_list :",Consumption_list)
        # print("Emission_list :",Emission_list)
        
    return HttpResponse('Data')

