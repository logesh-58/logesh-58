from django.db import models

# Create your models here.
class secmodel(models.Model):
    sec_id        = models.AutoField(primary_key=True)
    sec_date      = models.DateField()
    sec_energy    = models.DecimalField(max_digits=20, decimal_places=2, blank=True, null=True)
    sec_material  = models.DecimalField(max_digits=20, decimal_places=2, blank=True, null=True,default=0) 
    sec_value     = models.DecimalField(max_digits=20, decimal_places=2, blank=True, null=True,default=0) 
    sec_conform   = models.IntegerField(null=True, default=0)