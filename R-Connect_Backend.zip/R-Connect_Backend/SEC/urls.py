from django.urls import path
from SEC import views, secchart

urlpatterns = [
    path("sec/", views.secreport, name = "sec_report"),
    path("secchart/", secchart.SECchart, name = "secchart")
    # path('secenergy/',views.sec_energy,name='sec_energy')
]
