from django.shortcuts import render
from .models import Mouldmodel
from .serializers import MouldSerializers
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.db.models import Max
# Create your views here.

# @csrf_exempt               #31.08.2024
# def add(request):
#     if request.method == 'GET':
#         Plantname = request.GET['Plantname']
#         molddata = Mouldmodel.objects.filter(Plantname=Plantname).all().order_by('id')
#         molddataserializer = MouldSerializers(molddata, many=True)
#         return JsonResponse(molddataserializer.data, safe=False)
#     if request.method == 'POST':
#         Plantname = request.GET['Plantname']
#         data = request.body
#         httpdata = json.loads(data)
#         moldcode = httpdata['moldcode']
#         Mouldname = httpdata['Mouldname']
#         moldchangetime = httpdata['moldchangetime']
#         maintenanceinterval = httpdata['maintenanceinterval']
#         lastmaintenance = httpdata['lastmaintenance']
#         nextmaintenance = httpdata['nextmaintenance']
#         thresholdtime = httpdata['thresholdtime']
        
#         #new update
#         barelsetvalue1 = httpdata['barelsetvalue1']
#         barelsetvalue2 = httpdata['barelsetvalue2']
#         barelsetvalue3 = httpdata['barelsetvalue3']
#         barelsetvalue4 = httpdata['barelsetvalue4']
#         barelsetvalue5 = httpdata['barelsetvalue5']
#         barelsetvalue6 = httpdata['barelsetvalue6']
#         barelsetvalue7 = httpdata['barelsetvalue7']
#         barelsetvalue8 = httpdata['barelsetvalue8']
#         barelsetvalue9 = httpdata['barelsetvalue9']
#         barelsetvalue10 = httpdata['barelsetvalue10']
#         barelsetvalue11 = httpdata['barelsetvalue11']
#         barelsetvalue12 = httpdata['barelsetvalue12']

#         moldcodeall = Mouldmodel.objects.values('moldcode')
#         available_count = 0
#         for i in moldcodeall:
#             if(moldcode == i['moldcode']):
#                 available_count = 1
#                 return JsonResponse('Data already exist..', safe=False)
#         if (available_count == 0):
#             instance = Mouldmodel(moldcode= moldcode, Mouldname = Mouldname, moldchangetime= moldchangetime, Plantname=Plantname,
#                                     maintenanceinterval = maintenanceinterval, lastmaintenance = lastmaintenance,
#                                      nextmaintenance = nextmaintenance, thresholdtime = thresholdtime, barelsetvalue1 = barelsetvalue1, barelsetvalue2 = barelsetvalue2, barelsetvalue3 = barelsetvalue3, barelsetvalue4 = barelsetvalue4, barelsetvalue5 = barelsetvalue5, barelsetvalue6 = barelsetvalue6, barelsetvalue7 = barelsetvalue7, barelsetvalue8 = barelsetvalue8, barelsetvalue9 = barelsetvalue9, barelsetvalue10 = barelsetvalue10, barelsetvalue11 = barelsetvalue11, barelsetvalue12 = barelsetvalue12)
#             instance.save()
#             return JsonResponse('Data added successfully', safe=False)

#     if request.method == 'PUT':
#         Plantname = request.GET['Plantname']
#         data = request.body
#         httpdata = json.loads(data)
#         moldcode = httpdata['moldcode']
#         Mouldname = httpdata['Mouldname']
#         moldchangetime = httpdata['moldchangetime']
#         maintenanceinterval = httpdata['maintenanceinterval']
#         lastmaintenance = httpdata['lastmaintenance']
#         nextmaintenance = httpdata['nextmaintenance']
#         thresholdtime = httpdata['thresholdtime']
#         #new update
#         barelsetvalue1 = httpdata['barelsetvalue1']
#         barelsetvalue2 = httpdata['barelsetvalue2']
#         barelsetvalue3 = httpdata['barelsetvalue3']
#         barelsetvalue4 = httpdata['barelsetvalue4']
#         barelsetvalue5 = httpdata['barelsetvalue5']
#         barelsetvalue6 = httpdata['barelsetvalue6']
#         barelsetvalue7 = httpdata['barelsetvalue7']
#         barelsetvalue8 = httpdata['barelsetvalue8']
#         barelsetvalue9 = httpdata['barelsetvalue9']
#         barelsetvalue10 = httpdata['barelsetvalue10']
#         barelsetvalue11 = httpdata['barelsetvalue11']
#         barelsetvalue12 = httpdata['barelsetvalue12']

#         Mouldmodel.objects.filter(moldcode = moldcode ).update(Mouldname = Mouldname, moldchangetime= moldchangetime, Plantname=Plantname,
#                                     maintenanceinterval = maintenanceinterval, lastmaintenance = lastmaintenance,
#                                      nextmaintenance = nextmaintenance, thresholdtime = thresholdtime, barelsetvalue1 = barelsetvalue1, barelsetvalue2 = barelsetvalue2, barelsetvalue3 = barelsetvalue3, barelsetvalue4 = barelsetvalue4, barelsetvalue5 = barelsetvalue5, barelsetvalue6 = barelsetvalue6, barelsetvalue7 = barelsetvalue7, barelsetvalue8 = barelsetvalue8, barelsetvalue9 = barelsetvalue9, barelsetvalue10 = barelsetvalue10, barelsetvalue11 = barelsetvalue11, barelsetvalue12 = barelsetvalue12)
#         return JsonResponse('Date updated successfully', safe=False)
    
#     if request.method == 'DELETE':
#         data = request.body
#         httpdata = json.loads(data)
#         print(httpdata)
#         deldata = httpdata['code']
#         if(Mouldmodel.objects.filter(moldcode = deldata).exists()):
#             Mouldmodel.objects.filter(moldcode = deldata).delete()
#             return JsonResponse('Data deleted successfully', safe=False)
#         else:
#             return JsonResponse('Failed to delete data', safe=False)
        
#         #jishaab

################################################################################################

@csrf_exempt
def add(request):                       #31.08.2024 new update
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        molddata = Mouldmodel.objects.filter(Plantname=Plantname).all().order_by('id')
        molddataserializer = MouldSerializers(molddata, many=True)
        return JsonResponse(molddataserializer.data, safe=False)
    
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        moldcode = httpdata['moldcode']
        Mouldname = httpdata['Mouldname']
        changeovertime = httpdata['changeovertime']
        cycletimeset = httpdata['cycletimeset']
        cavity = httpdata['cavity']
        Customername = httpdata['Customername']
        weight = httpdata['weight']
        Material = httpdata['Material']
        Model = httpdata['Model']
        # New update
        barelsetvalue1 = httpdata['barelsetvalue1']
        barelsetvalue2 = httpdata['barelsetvalue2']
        barelsetvalue3 = httpdata['barelsetvalue3']
        barelsetvalue4 = httpdata['barelsetvalue4']
        barelsetvalue5 = httpdata['barelsetvalue5']
        barelsetvalue6 = httpdata['barelsetvalue6']
        barelsetvalue7 = httpdata['barelsetvalue7']
        barelsetvalue8 = httpdata['barelsetvalue8']
        barelsetvalue9 = httpdata['barelsetvalue9']
        barelsetvalue10 = httpdata['barelsetvalue10']
        barelsetvalue11 = httpdata['barelsetvalue11']
        barelsetvalue12 = httpdata['barelsetvalue12']

        # Check if the moldcode already exists
        # moldcodeall = Mouldmodel.objects.values('moldcode')
        # if any(moldcode == i['moldcode'] for i in moldcodeall):
        #     return JsonResponse('Data already exists..', safe=False)

        if Mouldmodel.objects.filter(moldcode=moldcode).exists() or Mouldmodel.objects.filter(Mouldname=Mouldname).exists():
            # print("HI111111111111")
            return JsonResponse('Data already exists..', safe=False)
        
        else:
            # print("HI22222222")
            # Find the maximum existing ID and increment it
            max_id = Mouldmodel.objects.aggregate(Max('id'))['id__max']
            new_id = max_id + 1 if max_id else 1

            # Save with the new ID
            instance = Mouldmodel(
                id=new_id,  # Manually set the new ID
                moldcode=moldcode, 
                Mouldname=Mouldname, 
                changeovertime=changeovertime, 
                Plantname=Plantname,
                cycletimeset=cycletimeset, 
                cavity=cavity,
                Customername=Customername, 
                weight=weight,
                Model=Model,
                barelsetvalue1=barelsetvalue1, 
                barelsetvalue2=barelsetvalue2, 
                barelsetvalue3=barelsetvalue3, 
                barelsetvalue4=barelsetvalue4, 
                barelsetvalue5=barelsetvalue5, 
                barelsetvalue6=barelsetvalue6, 
                barelsetvalue7=barelsetvalue7, 
                barelsetvalue8=barelsetvalue8, 
                barelsetvalue9=barelsetvalue9, 
                barelsetvalue10=barelsetvalue10, 
                barelsetvalue11=barelsetvalue11, 
                barelsetvalue12=barelsetvalue12,
                Material=Material
            )
            instance.save()
            return JsonResponse('Data added successfully', safe=False)
    
    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        moldcode = httpdata['moldcode']
        Mouldname = httpdata['Mouldname']
        changeovertime = httpdata['changeovertime']
        cycletimeset = httpdata['cycletimeset']
        cavity = httpdata['cavity']
        Customername = httpdata['Customername']
        weight = httpdata['weight']
        Material = httpdata['Material']
        Model = httpdata['Model']
        
        # New update
        barelsetvalue1 = httpdata['barelsetvalue1']
        barelsetvalue2 = httpdata['barelsetvalue2']
        barelsetvalue3 = httpdata['barelsetvalue3']
        barelsetvalue4 = httpdata['barelsetvalue4']
        barelsetvalue5 = httpdata['barelsetvalue5']
        barelsetvalue6 = httpdata['barelsetvalue6']
        barelsetvalue7 = httpdata['barelsetvalue7']
        barelsetvalue8 = httpdata['barelsetvalue8']
        barelsetvalue9 = httpdata['barelsetvalue9']
        barelsetvalue10 = httpdata['barelsetvalue10']
        barelsetvalue11 = httpdata['barelsetvalue11']
        barelsetvalue12 = httpdata['barelsetvalue12']

        Mouldmodel.objects.filter(moldcode=moldcode).update(
            Mouldname=Mouldname, changeovertime=changeovertime, Plantname=Plantname,
            Model=Model,
            cycletimeset=cycletimeset, cavity=cavity,
            Customername=Customername, weight=weight,
            barelsetvalue1=barelsetvalue1, barelsetvalue2=barelsetvalue2, barelsetvalue3=barelsetvalue3,
            barelsetvalue4=barelsetvalue4, barelsetvalue5=barelsetvalue5, barelsetvalue6=barelsetvalue6,
            barelsetvalue7=barelsetvalue7, barelsetvalue8=barelsetvalue8, barelsetvalue9=barelsetvalue9,
            barelsetvalue10=barelsetvalue10, barelsetvalue11=barelsetvalue11, barelsetvalue12=barelsetvalue12, Material=Material
        )
        return JsonResponse('Data updated successfully', safe=False)
    
    if request.method == 'DELETE':
        data = request.body
        httpdata = json.loads(data)
        deldata = httpdata['code']
        if Mouldmodel.objects.filter(moldcode=deldata).exists():
            Mouldmodel.objects.filter(moldcode=deldata).delete()
            return JsonResponse('Data deleted successfully', safe=False)
        else:
            return JsonResponse('Failed to delete data', safe=False)