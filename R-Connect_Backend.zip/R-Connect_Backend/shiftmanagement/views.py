from django.shortcuts import render
from .models import ShiftTimings, ShiftProductiondata
from .serializers import ShiftTimingSerializer, ShiftproductiondataSerializer
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from analysis.views import machineArray
from datetime import datetime, timedelta, time
from mouldmanagement.models import Mouldmodel
from machinemanagement.models import AddMachine
from hourly_production.dailyenrgyhrs_report import schedule_sendmail
from hourly_production.tasks import shift_schedule_sendmail

# Create your views here.
@csrf_exempt
def timings(request):
    if request.method == 'GET':
        Plantname = request.GET['Plantname']
        timingdata = ShiftTimings.objects.filter(Plantname = Plantname).all()
        serialized_time = ShiftTimingSerializer(timingdata, many=True)
        return JsonResponse(serialized_time.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        httpdata = json.loads(request.body)
        s1starttime = httpdata['s1starttime']
        s1endtime   = httpdata['s1endtime']
        s2starttime = httpdata['s2starttime']
        s2endtime   = httpdata['s2endtime']
        s3starttime = httpdata['s3starttime']
        s3endtime   = httpdata['s3endtime']

        instance = ShiftTimings(Plantname = Plantname, shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
        if(ShiftTimings.objects.filter(Plantname = Plantname).exists()):
            ShiftTimings.objects.filter(Plantname = Plantname).update(shift1start = s1starttime, shift1end = s1endtime, shift2start = s2starttime, shift2end = s2endtime, shift3start = s3starttime, shift3end = s3endtime)
            shift_schedule_sendmail()
            schedule_sendmail()
        else:
            instance.save()
            shift_schedule_sendmail()
            schedule_sendmail()
        return JsonResponse('Data saved successfully', safe=False)

@csrf_exempt
def shiftproductiondatanew(request):
    if request.method == 'GET':
        Plantname = request.GET.get('Plantname')
        productionsetdata = ShiftProductiondata.objects.filter(sp_plantname=Plantname).all().order_by('sp_id')
        serialized_data = ShiftproductiondataSerializer(productionsetdata, many=True)

        for item in serialized_data.data:
            mould_id = item['sp_mouldname']
            time = item['sp_totalproductiontime']
            try:
                sp_mouldname = Mouldmodel.objects.get(id=mould_id).Mouldname
                item['sp_mouldname'] = sp_mouldname  

                alt_time = str(timedelta(seconds=int(time * 3600)))
                formatted_time = datetime.strptime(alt_time, "%H:%M:%S").strftime("%H:%M:%S")
                item['sp_totalproductiontime'] = formatted_time 
            except Mouldmodel.DoesNotExist:
                item['sp_mouldname'] = "Unknown Mould Name"
                item['sp_totalproductiontime'] = "Unknown Time"
        
        return JsonResponse(serialized_data.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data_list = json.loads(request.body)  # Assuming the request body contains a list of data objects

        response_messages = []  # To collect responses for each entry

        for data in data_list:
            try:

                # Validate machine name
                if not AddMachine.objects.filter(amMachinename=data['sp_machinename']).exists():
                    response_messages.append(
                        "Machine name not found"
                    )
                    continue  # Skip processing this entry if material is invalid

                # Try to get the mould object
                mould_instance = Mouldmodel.objects.get(Mouldname=data['sp_mouldname'])

                if data['sp_material'] not in mould_instance.Material:
                    response_messages.append(
                        f"Material '{data['sp_material']}' not found for mould '{data['sp_mouldname']}' in Machine '{data['sp_machinename']}'."
                    )
                    continue  # Skip processing this entry if material is invalid

                # Check if the record already exists
                if ShiftProductiondata.objects.filter(
                    sp_date=data['sp_date'],
                    sp_plantname=Plantname,
                    sp_machinename=data['sp_machinename'],
                    sp_mouldname=mould_instance,
                    sp_shift=data['sp_shift'],
                    sp_material=data['sp_material']
                ).exists():
                    response_messages.append("Data Already Added")
                else:
                    # Create and save the new record
                    item = ShiftProductiondata(
                        sp_date=data['sp_date'],
                        sp_plantname=Plantname,
                        sp_machinename=data['sp_machinename'],
                        sp_mouldname=mould_instance,
                        sp_totalproduction=data['sp_totalproduction'],
                        sp_totalproductiontime=data['sp_totalproductiontime'],
                        sp_shift=data['sp_shift'],
                        sp_material=data['sp_material']
                    )
                    item.save()
                    response_messages.append("Data Saved Successfully")
            except Mouldmodel.DoesNotExist:
                response_messages.append(
                        f"Mould name '{data['sp_mouldname']}' not found in Mould master."
                    )

        return JsonResponse(response_messages, safe=False)

    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        if ShiftProductiondata.objects.filter(sp_date=data['sp_date'], 
                                                sp_plantname=Plantname, 
                                                sp_machinename=data['sp_machinename'],
                                                sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']), 
                                                sp_shift=data['sp_shift']).exists():
            ShiftProductiondata.objects.filter(sp_date=data['sp_date'], sp_machinename = data['sp_machinename'], sp_plantname = Plantname, sp_shift = data['sp_shift'], sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname'])).update(                                                                     
                                                                                sp_totalproduction = data['sp_totalproduction'],
                                                                                sp_totalproductiontime = data['sp_totalproductiontime'],
                                                                                sp_material=data['sp_material']                                                            
                                                                                )
            if data['updateStatus']==True:
                ShiftProductiondata.objects.filter(sp_id = data['sp_id']).delete()
            else:
                print("No Changes Done by user")
            return JsonResponse('Data Partially updated', safe=False)
        else:
            ShiftProductiondata.objects.filter(sp_id = data['sp_id'], sp_plantname = Plantname).update(sp_date = data['sp_date'],
                                            sp_machinename = data['sp_machinename'],
                                            sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']),
                                            sp_totalproduction = data['sp_totalproduction'],
                                            sp_totalproductiontime = data['sp_totalproductiontime'],
                                            sp_shift = data['sp_shift'],
                                            sp_material = data['sp_material'])
            return JsonResponse('Data updated successfully', safe=False)
        

    if request.method == 'DELETE':
        data = json.loads(request.body)
        data = data['sp_id']
        if(ShiftProductiondata.objects.filter(sp_id = data).exists()):
            ShiftProductiondata.objects.filter(sp_id = data).delete()
            return JsonResponse('Data deleted successfully', safe=False)
    

@csrf_exempt
def shiftproductiondata(request):
    if request.method == 'GET':
        Plantname = request.GET.get('Plantname')
        productionsetdata = ShiftProductiondata.objects.filter(sp_plantname=Plantname).all().order_by('sp_id')
        serialized_data = ShiftproductiondataSerializer(productionsetdata, many=True)

        # Retrieve and print sp_mouldname for each entry in serialized data
        # mould_names = []
        for item in serialized_data.data:
            mould_id = item['sp_mouldname']
            time = item['sp_totalproductiontime']
            try:
                sp_mouldname = Mouldmodel.objects.get(id=mould_id).Mouldname
                item['sp_mouldname'] = sp_mouldname  # Update with the actual mould name
                # mould_names.append(sp_mouldname)

                alt_time = str(timedelta(seconds=int(time * 3600)))
                formatted_time = datetime.strptime(alt_time, "%H:%M:%S").strftime("%H:%M:%S")
                item['sp_totalproductiontime'] = formatted_time 
            except Mouldmodel.DoesNotExist:
                item['sp_mouldname'] = "Unknown Mould Name"
                # mould_names.append("Unknown Mould Name")
                item['sp_totalproductiontime'] = "Unknown Time"
        
        # print("Mould Names:", mould_names)
        return JsonResponse(serialized_data.data, safe=False)

    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data_list = json.loads(request.body)  # Assuming the request body contains a list of data objects

        response_messages = []  # To collect responses for each entry

        for data in data_list:
            try:

                # Validate machine name
                if not AddMachine.objects.filter(amMachinename=data['sp_machinename']).exists():
                    response_messages.append(
                        "Machine name not found"
                    )
                    continue  # Skip processing this entry if material is invalid

                # Try to get the mould object
                mould_instance = Mouldmodel.objects.get(Mouldname=data['sp_mouldname'])

                if data['sp_material'] not in mould_instance.Material:
                    response_messages.append(
                        f"Material '{data['sp_material']}' not found for mould '{data['sp_mouldname']}' in Machine '{data['sp_machinename']}'."
                    )
                    continue  # Skip processing this entry if material is invalid

                # Check if the record already exists
                if ShiftProductiondata.objects.filter(
                    sp_date=data['sp_date'],
                    sp_plantname=Plantname,
                    sp_machinename=data['sp_machinename'],
                    sp_mouldname=mould_instance,
                    sp_shift=data['sp_shift'],
                    sp_material=data['sp_material']
                ).exists():
                    response_messages.append("Data Already Added")
                else:
                    # Create and save the new record
                    item = ShiftProductiondata(
                        sp_date=data['sp_date'],
                        sp_plantname=Plantname,
                        sp_machinename=data['sp_machinename'],
                        sp_mouldname=mould_instance,
                        sp_totalproduction=data['sp_totalproduction'],
                        sp_totalproductiontime=data['sp_totalproductiontime'],
                        sp_shift=data['sp_shift'],
                        sp_material=data['sp_material']
                    )
                    item.save()
                    response_messages.append("Data Saved Successfully")
            except Mouldmodel.DoesNotExist:
                response_messages.append(
                        f"Mould name '{data['sp_mouldname']}' not found in Mould master."
                    )

        return JsonResponse(response_messages, safe=False)

    if request.method == 'PUT':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        if ShiftProductiondata.objects.filter(sp_date=data['sp_date'], 
                                                sp_plantname=Plantname, 
                                                sp_machinename=data['sp_machinename'],
                                                sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']), 
                                                sp_shift=data['sp_shift']).exists():
            ShiftProductiondata.objects.filter(sp_date=data['sp_date'], sp_machinename = data['sp_machinename'], sp_plantname = Plantname, sp_shift = data['sp_shift'], sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname'])).update(                                                                     
                                                                                sp_totalproduction = data['sp_totalproduction'],
                                                                                sp_totalproductiontime = data['sp_totalproductiontime'],
                                                                                sp_material=data['sp_material']                                                            
                                                                                )
            if data['updateStatus']==True:
                ShiftProductiondata.objects.filter(sp_id = data['sp_id']).delete()
            else:
                print("No Changes Done by user")
            return JsonResponse('Data Partially updated', safe=False)
        else:
            ShiftProductiondata.objects.filter(sp_id = data['sp_id'], sp_plantname = Plantname).update(sp_date = data['sp_date'],
                                            sp_machinename = data['sp_machinename'],
                                            sp_mouldname = Mouldmodel.objects.get(Mouldname = data['sp_mouldname']),
                                            sp_totalproduction = data['sp_totalproduction'],
                                            sp_totalproductiontime = data['sp_totalproductiontime'],
                                            sp_shift = data['sp_shift'],
                                            sp_material = data['sp_material'])
            return JsonResponse('Data updated successfully', safe=False)
        

    if request.method == 'DELETE':
        data = json.loads(request.body)
        data = data['sp_id']
        if(ShiftProductiondata.objects.filter(sp_id = data).exists()):
            ShiftProductiondata.objects.filter(sp_id = data).delete()
            return JsonResponse('Data deleted successfully', safe=False)


@csrf_exempt
def remainingtime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        data = json.loads(request.body)

        date = data['sp_date'] 
        machinename = data['sp_machinename']
        shift = data['sp_shift']

        ##########################################################################################
        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        # Convert time fields to datetime objects
        reference_date = datetime.strptime(date, "%Y-%m-%d")  # Convert date string to datetime

        def convert_to_datetime(time_value):
            """Convert a time object to a datetime object based on the reference date."""
            return datetime.combine(reference_date, time_value)

        shiftone_starttime = convert_to_datetime(shift_times['shift1start'])
        shiftone_endtime = convert_to_datetime(shift_times['shift1end'])
        shifttwo_starttime = convert_to_datetime(shift_times['shift2start'])
        shifttwo_endtime = convert_to_datetime(shift_times['shift2end'])
        shiftthree_starttime = convert_to_datetime(shift_times['shift3start'])
        shiftthree_endtime = convert_to_datetime(shift_times['shift3end'])

        response_data = []

        all_aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=date,
                    sp_plantname=Plantname,
                    sp_machinename=machinename,
                    sp_shift=shift
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift').order_by('sp_id')

        if all_aggregated_data:

            mac_hours = sum(r['sp_totalproductiontime'] for r in all_aggregated_data) if all_aggregated_data else 0

            # Compute shift total time
            if shift == "A":
                shift_total_time = (shiftone_endtime - shiftone_starttime).total_seconds() / 3600
            elif shift == "B":
                shift_total_time = (shifttwo_endtime - shifttwo_starttime).total_seconds() / 3600
            elif shift == "C":
                if shiftthree_endtime < shiftthree_starttime:
                    shiftthree_endtime += timedelta(days=1)
                shift_total_time = (shiftthree_endtime - shiftthree_starttime).total_seconds() / 3600
            else:
                shift_total_time = 0

            retime = shift_total_time - mac_hours

            ########
            if retime <= 0:
                final_hours = "Nil"
                formatted_time = "00:00:00"
            else:
                final_hours = round(retime, 2)
                alt_time = str(timedelta(seconds=int(final_hours * 3600)))
                formatted_time = datetime.strptime(alt_time, "%H:%M:%S").strftime("%H:%M:%S")
            ########

        else:

            mac_hours = 0

            # Compute shift total time
            if shift == "A":
                shift_total_time = (shiftone_endtime - shiftone_starttime).total_seconds() / 3600
            elif shift == "B":
                shift_total_time = (shifttwo_endtime - shifttwo_starttime).total_seconds() / 3600
            elif shift == "C":
                if shiftthree_endtime < shiftthree_starttime:
                    shiftthree_endtime += timedelta(days=1)
                shift_total_time = (shiftthree_endtime - shiftthree_starttime).total_seconds() / 3600
            else:
                shift_total_time = 0

            retime = shift_total_time - mac_hours

            ########
            if retime <= 0:
                final_hours = "Nil"
                formatted_time = "00:00:00"
            else:
                final_hours = round(retime, 2)
                alt_time = str(timedelta(seconds=int(final_hours * 3600)))
                formatted_time = datetime.strptime(alt_time, "%H:%M:%S").strftime("%H:%M:%S")
            ########

        # Construct the response for the current date
        response_data.append({
            "date": date,
            "Machine": machinename,
            "Remaining_hours": final_hours,
            "formatted_time": formatted_time
        })

        return JsonResponse(response_data, safe=False)

    return JsonResponse({"status": "failed"}, status=400)
#ji

@csrf_exempt
def calendertime(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = json.loads(request.body)
        date = data['sp_date']

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        shift_times = ShiftTimings.objects.filter(Plantname=Plantname).values(
            'shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end'
        ).last()

        # Convert time fields to datetime objects
        reference_date = datetime.strptime(date, "%Y-%m-%d")  # Convert date string to datetime

        def convert_to_datetime(time_value):
            """Convert a time object to a datetime object based on the reference date."""
            return datetime.combine(reference_date, time_value)

        shiftone_starttime = convert_to_datetime(shift_times['shift1start'])
        shiftone_endtime = convert_to_datetime(shift_times['shift1end'])
        shifttwo_starttime = convert_to_datetime(shift_times['shift2start'])
        shifttwo_endtime = convert_to_datetime(shift_times['shift2end'])
        shiftthree_starttime = convert_to_datetime(shift_times['shift3start'])
        shiftthree_endtime = convert_to_datetime(shift_times['shift3end'])

        response_data = []

        today_date = datetime.strptime(date, "%Y-%m-%d")
        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        total_days = (enddate - startdate).days + 1

        startdate_str = startdate.strftime('%Y-%m-%d')
        enddate_str = enddate.strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
            sp_date__range=[startdate_str, enddate_str],
            sp_plantname=Plantname,
            sp_machinename__in=MachinenamesArray
        ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift').order_by('sp_id')

        for day_offset in range(total_days):
            current_date = startdate + timedelta(days=day_offset)
            current_date_str = current_date.strftime('%Y-%m-%d')
            current_day = current_date.strftime('%A')

            # Initialize shift counters for free machines
            shift_free_machines = {"Shift_A": 0, "Shift_B": 0, "Shift_C": 0}

            day_data = []

            for select_machine in MachinenamesArray:
                remaining_time = [r for r in all_aggregated_data if
                                  r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str]

                shift_list = ["A", "B", "C"]
                remaining_hours_list = []
                formatted_hours_list = []
                shift_count = {}

                for shift in shift_list:
                    if not remaining_time:
                        mac_hours = 0
                    else:
                        mac_hours = sum(r['sp_totalproductiontime'] for r in remaining_time if r['sp_shift'] == shift)

                    # Compute shift total time
                    if shift == "A":
                        shift_total_time = (shiftone_endtime - shiftone_starttime).total_seconds() / 3600
                    elif shift == "B":
                        shift_total_time = (shifttwo_endtime - shifttwo_starttime).total_seconds() / 3600
                    elif shift == "C":
                        if shiftthree_endtime < shiftthree_starttime:
                            shiftthree_endtime += timedelta(days=1)
                        shift_total_time = (shiftthree_endtime - shiftthree_starttime).total_seconds() / 3600
                    else:
                        shift_total_time = 0  

                    retime = shift_total_time - mac_hours
                    final_hours = max(retime, 0)

                    alt_time = str(timedelta(seconds=int(final_hours * 3600)))
                    formatted_time = datetime.strptime(alt_time, "%H:%M:%S").strftime("%H:%M:%S")

                    remaining_hours_list.append(final_hours)
                    formatted_hours_list.append(formatted_time)

                    # Count free machines per shift
                    if final_hours > 0:
                        shift_free_machines[f"Shift_{shift}"] += 1

                day_data.append({
                    "date": current_date_str,
                    "day": current_day,
                    "Machine": select_machine,
                    "Shift": shift_list,
                    "Remaining_hours": remaining_hours_list,
                    "Formatted_hours": formatted_hours_list
                })

            # Append shift counts to each machine entry for the day
            for machine_entry in day_data:
                machine_entry.update(shift_free_machines)
                response_data.append(machine_entry)

        return JsonResponse(response_data, safe=False)

    return JsonResponse({"status": "failed"}, status=400)



@csrf_exempt
def materials(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']

        data = json.loads(request.body)

        mould = data['sp_mouldname']

        response_data = []
        ##########################################################################################

        all_mould_data = Mouldmodel.objects.filter(
                Plantname=Plantname,
                Mouldname=mould
            ).values_list('Material', flat=True).order_by('id')

        # Prepare the response data
        response_data = list(all_mould_data)

        return JsonResponse(response_data, safe=False)
    
    return JsonResponse({"status": "failed"}, status=400)