from django.http.response import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from edgedevicemanagement.models import AddEdgeDevice
from edgedevicemanagement.serializers import EdgedeviceManagementSerializer
import json

@csrf_exempt
def edgedevice(request):
    if request.method == "GET":
        plantname = request.GET['plantname']
        edgedevicedata = AddEdgeDevice.objects.filter(aeplantname=plantname).all().order_by('aeid')
        edgedeviceserializer = EdgedeviceManagementSerializer(edgedevicedata,many=True)
        return JsonResponse(edgedeviceserializer.data,safe=False)
    
    if request.method == "POST":
        plantname = request.GET['plantname']
        data = request.body
        httpdata  = json.loads(data)
        devicecode  = httpdata['aedevicecode']
        devicename  = httpdata['aeedgedevicename']
        devicelocation  = httpdata['aelocation']
        devicekey = httpdata['aeapikey']
        devicestatus = httpdata['aestatus']

        devicecodeall = AddEdgeDevice.objects.values('aedevicecode')

        available_count = 0
        for i in devicecodeall:
            if(devicecode == i['aedevicecode']):
                available_count = 1
                return JsonResponse('Data already exist..', safe=False)
        if(available_count == 0):
            ins = AddEdgeDevice(
                aedevicecode       = devicecode,
                aeedgedevicename   = devicename,
                aelocation         = devicelocation,
                aeapikey           = devicekey,
                aestatus           = devicestatus,
                aeplantname        = plantname
            )
            ins.save()
            return JsonResponse('Data saved successfully', safe=False)

    if request.method == 'PUT':
        plantname = request.GET['plantname']
        data = request.body
        httpdata  = json.loads(data)
        devicecode  = httpdata['aedevicecode']
        devicename  = httpdata['aeedgedevicename']
        devicelocation  = httpdata['aelocation']
        devicekey = httpdata['aeapikey']
        devicestatus = httpdata['aestatus']

        if(AddEdgeDevice.objects.filter(aedevicecode = devicecode).exists()):
            AddEdgeDevice.objects.filter(aedevicecode = devicecode).update(
                aedevicecode       = devicecode,
                aeedgedevicename   = devicename,
                aelocation         = devicelocation,
                aeapikey           = devicekey,
                aestatus           = devicestatus,
                aeplantname        = plantname
            )
            return JsonResponse('Data updated successfully', safe=False)
        else:
            return JsonResponse('Failed to update data', safe=False)

    if request.method == 'DELETE':
        data = request.body
        httpdata  = json.loads(data)
        devicecode  = httpdata['code']
        if(AddEdgeDevice.objects.filter(aedevicecode = devicecode).exists()):
            AddEdgeDevice.objects.filter(aedevicecode = devicecode).delete()
            return JsonResponse('Data deleted successfully', safe=False)
        else:
            return JsonResponse('Failed to delete data', safe=False)