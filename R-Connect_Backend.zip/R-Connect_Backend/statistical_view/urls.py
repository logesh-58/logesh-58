from django.urls import path, include
from . import optimize_code

urlpatterns = [

   path('statistical/', optimize_code.statistical_fun, name = 'Statistical_View'),
   path('productivity/', optimize_code.historical_fun, name = 'Statistical_View'),

] 