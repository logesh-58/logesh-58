from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dashboard
from productiontable.models import ProductionTable
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from datetime import datetime, time, timedelta
import pytz
from django.db.models import Q, Min, Max, Count, F, Sum
from analysis.views import machineArray
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from timeline.models import breakdown, badpart

def delete_dashboarddata(Plantname):
    getMachines = machineArray(Plantname)
    for machine in getMachines:
        getis = Dashboard.objects.filter(Plantname = Plantname, Machinename = machine).values('id').order_by('id').last()
        try: Dashboard.objects.filter(Machinename = machine, id__lt = getis['id']).delete()
        except: continue
    return None


@csrf_exempt
def production_dashboards(request):
    if request.method=="GET":
        Plantname = request.GET['Plantname']
        API_list = []; dict = {}
        machinelist = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename', 'ammachineimage', 'amconsiderbool').order_by('amid')
        machine_names = [machine['amMachinename'] for machine in machinelist]
        
        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        shift_1endtime_str = shift_starttime['shift1end'].strftime('%H:%M:%S') if shift_starttime['shift1end'] else None
        shift_2starttime_str = shift_starttime['shift2start'].strftime('%H:%M:%S') if shift_starttime['shift2start'] else None
        shift_2endtime_str = shift_starttime['shift2end'].strftime('%H:%M:%S') if shift_starttime['shift2end'] else None
        shift_3starttime_str = shift_starttime['shift3start'].strftime('%H:%M:%S') if shift_starttime['shift3start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        # Get the current time in IST
        timenow_ist = datetime.now().time()

        time_start_A = time(0, 0, 0)
        time_end_A = shift_starttime['shift3end']

        if time_start_A <= timenow_ist <= time_end_A:
            current_date = (datetime.today()).date() - timedelta(days=1)
        else:
            current_date = (datetime.today()).date()
        ###############################################################################

        next_date = current_date + timedelta(days=1)

        # Use strftime to convert the datetime object to a string if needed
        current_date_str = current_date.strftime("%Y-%m-%d")
        next_day_str = next_date.strftime("%Y-%m-%d")

        all_dashboard_value = ProductionTable.objects.filter(
                    Q(date=current_date_str, time__gte=firstday_start) |
                    Q(date=next_day_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=machine_names,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename', 'time', 'date', 'CycletimeActual', 'Cavity').order_by('id')
        
        all_breakdown_data = breakdown.objects.filter(
                    Q(date=current_date_str, time__gte=firstday_start) |
                    Q(date=next_day_str, time__lte=secondday_end),
                    Machinename__in=machine_names,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_live = Dashboard.objects.filter(
            Plantname=Plantname, Machinename__in=machine_names
        ).values('Machinename', 'Mouldname_id', 'MachineState', 'Alarm', 'CycletimeActual', 'CycletimeSet', 'machinestatus').order_by('id')

        all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=current_date_str, time__gte=firstday_start) |
                    Q(date=next_day_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=machine_names
                ).values('Machinename', 'date', 'time', 'Cavity').order_by('id')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date=current_date_str,
                    sp_plantname=Plantname,
                    sp_machinename__in=machine_names
                ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        ################

        # Define the shift time ranges
        shift_A_start = shift_starttime['shift1start']
        shift_A_end = shift_starttime['shift1end']

        shift_B_start = shift_starttime['shift2start']
        shift_B_end = shift_starttime['shift2end']

        shift_C_start = shift_starttime['shift3start']
        shift_C_end = shift_starttime['shift3end']

        # Determine the company shift
        if shift_A_start <= timenow_ist <= shift_A_end:
            company_shift = 'A'
            time_shift = [firstday_start, shift_1endtime_str]
        elif shift_B_start <= timenow_ist <= shift_B_end:
            company_shift = 'B'
            time_shift = [shift_2starttime_str, shift_2endtime_str]
        # Special case for shift C, which spans over midnight
        elif timenow_ist >= shift_C_start or timenow_ist <= shift_C_end:
            company_shift = 'C'
            time_shift = [shift_3starttime_str, secondday_end]
        else:
            company_shift = 0
            time_shift = 0


        for machine_value in machinelist:

            Mac_Log = machine_value['amconsiderbool']

            if Mac_Log == True:

                machine_name  = machine_value['amMachinename']
                
                machine_image = machine_value['ammachineimage']

                dashboard_value  = [r for r in all_dashboard_live if r['Machinename'] == machine_name]

                if dashboard_value:
                    
                    dashboard_value = dashboard_value[-1]     # 0   # -1
                
                    machine_status  = dashboard_value['machinestatus']

                    ########################### Getting the Shift Start and End time #####################################
            
                    if len([v for v in all_dashboard_value if v['date'] == current_date_str and v['Machinename'] == machine_name and v['time'] >= firstday_start]) != 0:

                        Mouldname_id  = dashboard_value['Mouldname_id']
                        Mouldname     = Mouldmodel.objects.get(id = Mouldname_id).Mouldname
                        MachineState  = dashboard_value['MachineState']
                        Alarm = int(dashboard_value['Alarm'])
                        
                        CycletimeActual         = float(dashboard_value['CycletimeActual'])
                        CycletimeSet            = float(dashboard_value['CycletimeSet'])

                        ################
                        if company_shift == 'C':
                                
                            saw = [k for k in all_breakdown_data if
                            k['Machinename'] == machine_name and
                            ((k['date'] == current_date_str and shift_3starttime_str <= k['time']) or
                            (k['date'] == next_day_str and k['time'] <= secondday_end))
                                ]
                            

                            RejectionParts_calculate = [
                                e for e in all_RejectionParts_cal if
                                e['Machinename'] == machine_name and (
                                    (e['date'] == current_date_str and shift_3starttime_str <= e['time']) or
                                    (e['date'] == next_day_str and e['time'] <= secondday_end)
                                )
                            ]

                            alter_value = [p for p in all_dashboard_value if
                                p['Machinename'] == machine_name and
                                ((p['date'] == current_date_str and shift_3starttime_str <= p['time']) or
                                    (p['date'] == next_day_str and p['time'] <= secondday_end))
                            ]

                        else:
                            
                            saw = [k for k in all_breakdown_data if
                                k['Machinename'] == machine_name and
                                (k['date'] == current_date_str and time_shift[0] <= k['time'] <= time_shift[1])
                                    ]
                            
                            RejectionParts_calculate = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == machine_name and
                                (e['date'] == current_date_str and time_shift[0] <= e['time'] <= time_shift[1]) 
                                ]
                            
                            alter_value = [p for p in all_dashboard_value if
                                p['Machinename'] == machine_name and
                                (p['date'] == current_date_str and time_shift[0] <= p['time'] <= time_shift[1])
                            ]

                        if alter_value:
                            ProductionCountActual   = sum(p['Cavity'] for p in alter_value) if alter_value else 0

                            ProductionTimeActual_minute = sum(p['CycletimeActual'] for p in alter_value) / 60  # Convert to minutes
                            ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in alter_value) / 3600  # Convert to hours

                        else:
                            ProductionCountActual = 0
                            ProductionTimeActual_minute = 0
                            ProductionTimeActual_hour = 0
                        
                        if RejectionParts_calculate:
                            RejectionParts = sum(p['Cavity'] for p in RejectionParts_calculate) if RejectionParts_calculate else 0
                            
                        else:
                            RejectionParts = 0  
                        
                            
                        # Calculate total idle time
                        #  .total_seconds()     # .seconds
                        total_idle_time = 0  # Initialize the sum

                        last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                        # Iterate through the breakdown data and calculate time differences
                        for last, bd in zip(saw, saw[1:]):
                            # If `MachineState = 0` for last, store its time but don't calculate yet
                            if last['MachineState'] == 0:
                                # Capture the first occurrence of MachineState = 0
                                if last_time_str is None:
                                    last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
                            # Only calculate the time difference when transitioning from 0 to 1
                            if last_time_str and bd['MachineState'] == 1:
                                # Combine date and time for `bd`
                                bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                                # Parse the combined date and time
                                last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                                bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                                # Calculate the time difference in seconds
                                time_difference = (bd_time - last_time).total_seconds()

                                # Accumulate the total time in seconds
                                total_idle_time += time_difference

                                # Reset last_time_str to None after calculating for this transition
                                last_time_str = None
                  
                        total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                        ################

                        aggregated_data = [b for b in all_aggregated_data if
                                    b['sp_machinename'] == machine_name and b['sp_date'] == current_date_str
                                ]

                        shift = max(b['sp_shift'] for b in aggregated_data) if aggregated_data else 0

                        aggregated_data2 = [r for r in all_aggregated_data if
                                    r['sp_machinename'] == machine_name and r['sp_date'] == current_date_str and r['sp_shift'] == company_shift
                                ]
                        mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data2) if aggregated_data2 else 0

                        mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data2) if aggregated_data2 else 0

                        if shift == 'A':
                            mac_hoursss = 8
                        elif shift == 'B':
                            mac_hoursss = 16
                        elif shift == 'C':
                            mac_hoursss = 24
                        else:
                            mac_hoursss = 0

                        uptime_cal = mac_hoursss - total_idle_time_hours

                        try:
                            ProductionTimeTotal     = round(float(mac_hours), 2)
                        except:
                            ProductionTimeTotal  = 0
                        ################
                        try:
                            efficiency = ((ProductionCountActual/mac_counts)*(abs(ProductionCountActual-RejectionParts)/ProductionCountActual))*100
                            #---------------------
                            oee_availability = (float(ProductionTimeActual_hour)/mac_hours)*100
                            oee_performance = (ProductionCountActual/mac_counts)*100
                            oee_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                            oee = ((oee_availability / 100) * (oee_performance / 100) * (oee_quality / 100)) * 100
                            #---------------------
                            teep_availability = (float(ProductionTimeActual_hour)/24)*100
                            teep_performance = (ProductionCountActual/mac_counts)*100
                            teep_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                            teep = ((teep_availability / 100) * (teep_performance / 100) * (teep_quality / 100)) * 100
                            #---------------------
                            ooe_availability = (float(ProductionTimeActual_hour)/mac_hoursss)*100
                            ooe_performance = (ProductionCountActual/mac_counts)*100
                            ooe_quality = (abs(ProductionCountActual-RejectionParts)/ProductionCountActual)*100
                            ooe = ((ooe_availability / 100) * (ooe_performance / 100) * (ooe_quality / 100)) * 100
                            #---------------------
                            Availability = (float(ProductionTimeActual_hour) / (mac_hours)) * 100
                            #---------------------
                            Uptime = (uptime_cal / 24) * 100
                            #---------------------
                            Utilization_Rate = (mac_hours / 24) * 100
                        except:
                            efficiency = 0
                            ooe = 0
                            teep = 0
                            oee  = 0
                            Availability = 0
                            Uptime = 0
                            oee_availability = 0
                            oee_performance = 0
                            oee_quality = 0
                            teep_availability = 0
                            teep_performance = 0
                            teep_quality = 0
                            ooe_availability = 0
                            ooe_performance = 0
                            ooe_quality = 0
                            Utilization_Rate = 0

                        try:
                            # Convert ProductionTimeTotal from hours to minutes
                            ProductionTimeTotal_minutes = ProductionTimeTotal * 60
                        except:
                            ProductionTimeTotal_minutes = 0

                        try:
                            mprogress = (float(ProductionCountActual) / mac_counts) *100
                            RemainingProdTime = float(int(ProductionTimeTotal_minutes)) - float(ProductionTimeActual_minute)
                        except:
                            mprogress = 0
                            RemainingProdTime = 0
                        dict = {'Alarm'             : Alarm,
                                'machineimage'      : machine_image,
                                'RejectionParts'    : RejectionParts,
                                'Machinename'       : machine_name,
                                'MachineState'      : MachineState,
                                'Mouldname'         : Mouldname,
                                'CycletimeSet'      : CycletimeSet,
                                'CycletimeActual'   : CycletimeActual,
                                'ProductionCountActual' : ProductionCountActual,
                                'ProductionCountSet'    :mac_counts,
                                'ProductionTimeActual'  : round(float(ProductionTimeActual_minute)),
                                'ProductionTimeTotal'   : round(ProductionTimeTotal_minutes),
                                'efficiency'            : round(efficiency, 2),
                                "oee"               : round(oee, 2),
                                "teep"              :round(teep, 2),
                                "ooe"               :round(ooe, 2),
                                "Availability"      :round(Availability, 2),
                                "Uptime"            :round(Uptime, 2),
                                "oee_availability" : round(oee_availability, 2),
                                "oee_performance" : round(oee_performance, 2),
                                "oee_quality" : round(oee_quality, 2),
                                "teep_availability" : round(teep_availability, 2),
                                "teep_performance" : round(teep_performance, 2),
                                "teep_quality" : round(teep_quality, 2),
                                "ooe_availability" : round(ooe_availability, 2),
                                "ooe_performance" : round(ooe_performance, 2),
                                "ooe_quality" : round(ooe_quality, 2),
                                "Utilization_Rate" : round(Utilization_Rate, 2),
                                "machinestatus"     :machine_status,
                                "mprogress"         : round(mprogress, 2),
                                "RemainingProdTime" : round(RemainingProdTime, 2)
                                }
                        API_list.append(dict)
                        delete_dashboarddata(Plantname)

                    else:
                        dict = {'Alarm'             :0,
                                'machineimage'      :machine_image,
                                'RejectionParts'    :0,
                                'Machinename'       :machine_name,
                                'MachineState'      :0,
                                'Mouldname'         :None,
                                'CycletimeSet'      :0,
                                'CycletimeActual'   :0,
                                'ProductionCountActual' :0,
                                'ProductionCountSet'    :0,
                                'ProductionTimeActual'  :0,
                                'ProductionTimeTotal'   :0,
                                'efficiency'            :0,
                                "oee"               :0,
                                "teep"              :0,
                                "ooe"               :0,
                                "Availability"      :0,
                                "Uptime"            :0,
                                "oee_availability" : 0,
                                "oee_performance" : 0,
                                "oee_quality" : 0,
                                "teep_availability" : 0,
                                "teep_performance" : 0,
                                "teep_quality" : 0,
                                "ooe_availability" : 0,
                                "ooe_performance" : 0,
                                "ooe_quality" : 0,
                                "Utilization_Rate" : 0,
                                "machinestatus"     :machine_status,
                                "mprogress"         :0,
                                "RemainingProdTime" :0
                                }
                        API_list.append(dict)

        return JsonResponse(API_list, safe=False)


