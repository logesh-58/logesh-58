from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dashboard
from productiontable.models import ProductionTable
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from datetime import datetime, time, timedelta
import pytz
from django.db.models import Q, Min, Max, Count, F, Sum
from analysis.views import machineArray
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from timeline.models import breakdown, badpart
import json
from process_module.models import process_module, process_modulelive
from maintenance.models import maintenance_module


@csrf_exempt
def datar_w(request):
    if request.method=="POST":
        DateReq = json.loads(request.body)
        
        Name = DateReq.get("Name")

        if Name == "Process Module data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            BarelTempZ1 = DateReq.get("BarelTempZ1")
            BarelTempZ2 = DateReq.get("BarelTempZ2")
            BarelTempZ3 = DateReq.get("BarelTempZ3")
            BarelTempZ4 = DateReq.get("BarelTempZ4")
            BarelTempZ5 = DateReq.get("BarelTempZ5")
            BarelTempZ6 = DateReq.get("BarelTempZ6")
            BarelTempZ7 = DateReq.get("BarelTempZ7")
            BarelTempZ8 = DateReq.get("BarelTempZ8")
            BarelTempZ9 = DateReq.get("BarelTempZ9")
            BarelTempZ10 = DateReq.get("BarelTempZ10")
            BarelTempZ11 = DateReq.get("BarelTempZ11")
            BarelTempZ12 = DateReq.get("BarelTempZ12")
            airInletPressureGuage = DateReq.get("airInletPressureGuage")
            hopperMaterialLevel = DateReq.get("hopperMaterialLevel")
            hopperTemperature = DateReq.get("hopperTemperature")
            MTC = DateReq.get("MTC")
            CWIP = DateReq.get("CWIP")
            CWOP = DateReq.get("CWOP")
            CWIT = DateReq.get("CWIT")
            CWOT = DateReq.get("CWOT")
            HRTC1 = DateReq.get("HRTC1")
            HRTC2 = DateReq.get("HRTC2")
            HRTC3 = DateReq.get("HRTC3")
            HRTC4 = DateReq.get("HRTC4")
            HRTC5 = DateReq.get("HRTC5")
            HRTC6 = DateReq.get("HRTC6")
            HRTC7 = DateReq.get("HRTC7")
            HRTC8 = DateReq.get("HRTC8")
            HRTC9 = DateReq.get("HRTC9")
            HRTC10 = DateReq.get("HRTC10")
            HRTC11 = DateReq.get("HRTC11")
            HRTC12 = DateReq.get("HRTC12")
            HRTC13 = DateReq.get("HRTC13")
            HRTC14 = DateReq.get("HRTC14")
            HRTC15 = DateReq.get("HRTC15")
            HRTC16 = DateReq.get("HRTC16")
            HRTC17 = DateReq.get("HRTC17")
            HRTC18 = DateReq.get("HRTC18")
            HRTC19 = DateReq.get("HRTC19")
            HRTC20 = DateReq.get("HRTC20")
            HRTC21 = DateReq.get("HRTC21")
            HRTC22 = DateReq.get("HRTC22")
            HRTC23 = DateReq.get("HRTC23")
            HRTC24 = DateReq.get("HRTC24")
            HRTC25 = DateReq.get("HRTC25")
            HRTC26 = DateReq.get("HRTC26")
            HRTC27 = DateReq.get("HRTC27")
            HRTC28 = DateReq.get("HRTC28")
            HRTC29 = DateReq.get("HRTC29")
            HRTC30 = DateReq.get("HRTC30")
            HRTC31 = DateReq.get("HRTC31")
            HRTC32 = DateReq.get("HRTC32")
            HRTC33 = DateReq.get("HRTC33")
            HRTC34 = DateReq.get("HRTC34")
            HRTC35 = DateReq.get("HRTC35")
            HRTC36 = DateReq.get("HRTC36")
            HRTC37 = DateReq.get("HRTC37")
            HRTC38 = DateReq.get("HRTC38")
            HRTC39 = DateReq.get("HRTC39")
            HRTC40 = DateReq.get("HRTC40")
            HRTC41 = DateReq.get("HRTC41")
            HRTC42 = DateReq.get("HRTC42")
            HRTC43 = DateReq.get("HRTC43")
            HRTC44 = DateReq.get("HRTC44")
            HRTC45 = DateReq.get("HRTC45")
            HRTC46 = DateReq.get("HRTC46")
            HRTC47 = DateReq.get("HRTC47")
            HRTC48 = DateReq.get("HRTC48")
            HRTC49 = DateReq.get("HRTC49")
            HRTC50 = DateReq.get("HRTC50")
            HRTC51 = DateReq.get("HRTC51")
            HRTC52 = DateReq.get("HRTC52")
            HRTC53 = DateReq.get("HRTC53")
            HRTC54 = DateReq.get("HRTC54")
            HRTC55 = DateReq.get("HRTC55")
            HRTC56 = DateReq.get("HRTC56")
            HRTC57 = DateReq.get("HRTC57")
            HRTC58 = DateReq.get("HRTC58")
            HRTC59 = DateReq.get("HRTC59")
            HRTC60 = DateReq.get("HRTC60")
            HRTC61 = DateReq.get("HRTC61")
            HRTC62 = DateReq.get("HRTC62")
            HRTC63 = DateReq.get("HRTC63")
            HRTC64 = DateReq.get("HRTC64")
            date = DateReq.get("date")
            time = DateReq.get("time")

            if process_modulelive.objects.filter(Plantname = Plantname, Machinename = Machinename).exists():
                process_modulelive.objects.filter(Plantname = Plantname, Machinename = Machinename).update(
                        BarelTempZ1 = BarelTempZ1,
                        BarelTempZ2 = BarelTempZ2,
                        BarelTempZ3 = BarelTempZ3,
                        BarelTempZ4 = BarelTempZ4,
                        BarelTempZ5 = BarelTempZ5,
                        BarelTempZ6 = BarelTempZ6,
                        BarelTempZ7 = BarelTempZ7,
                        BarelTempZ8 = BarelTempZ8,
                        BarelTempZ9 = BarelTempZ9,
                        BarelTempZ10 = BarelTempZ10,
                        BarelTempZ11 = BarelTempZ11,
                        BarelTempZ12 = BarelTempZ12,
                        airInletPressureGuage = airInletPressureGuage,
                        hopperMaterialLevel = hopperMaterialLevel,
                        hopperTemperature = hopperTemperature,
                        MTC = MTC,
                        CWIP = CWIP,
                        CWOP = CWOP,
                        CWIT = CWIT,
                        CWOT = CWOT,
                        HRTC1 = HRTC1,
                        HRTC2 = HRTC2,
                        HRTC3 = HRTC3,
                        HRTC4 = HRTC4,
                        HRTC5 = HRTC5,
                        HRTC6 = HRTC6,
                        HRTC7 = HRTC7,
                        HRTC8 = HRTC8,
                        HRTC9 = HRTC9,
                        HRTC10 = HRTC10,
                        HRTC11 = HRTC11,
                        HRTC12 = HRTC12,
                        HRTC13 = HRTC13,
                        HRTC14 = HRTC14,
                        HRTC15 = HRTC15,
                        HRTC16 = HRTC16,
                        HRTC17 = HRTC17,
                        HRTC18 = HRTC18,
                        HRTC19 = HRTC19,
                        HRTC20 = HRTC20,
                        HRTC21 = HRTC21,
                        HRTC22 = HRTC22,
                        HRTC23 = HRTC23,
                        HRTC24 = HRTC24,
                        HRTC25 = HRTC25,
                        HRTC26 = HRTC26,
                        HRTC27 = HRTC27,
                        HRTC28 = HRTC28,
                        HRTC29 = HRTC29,
                        HRTC30 = HRTC30,
                        HRTC31 = HRTC31,
                        HRTC32 = HRTC32,
                        HRTC33 = HRTC33,
                        HRTC34 = HRTC34,
                        HRTC35 = HRTC35,
                        HRTC36 = HRTC36,
                        HRTC37 = HRTC37,
                        HRTC38 = HRTC38,
                        HRTC39 = HRTC39,
                        HRTC40 = HRTC40,
                        HRTC41 = HRTC41,
                        HRTC42 = HRTC42,
                        HRTC43 = HRTC43,
                        HRTC44 = HRTC44,
                        HRTC45 = HRTC45,
                        HRTC46 = HRTC46,
                        HRTC47 = HRTC47,
                        HRTC48 = HRTC48,
                        HRTC49 = HRTC49,
                        HRTC50 = HRTC50,
                        HRTC51 = HRTC51,
                        HRTC52 = HRTC52,
                        HRTC53 = HRTC53,
                        HRTC54 = HRTC54,
                        HRTC55 = HRTC55,
                        HRTC56 = HRTC56,
                        HRTC57 = HRTC57,
                        HRTC58 = HRTC58,
                        HRTC59 = HRTC59,
                        HRTC60 = HRTC60,
                        HRTC61 = HRTC61,
                        HRTC62 = HRTC62,
                        HRTC63 = HRTC63,
                        HRTC64 = HRTC64,
                        date = date,
                        time = time)
            else:
                item = process_modulelive(
                        Plantname = Plantname, 
                        Machinename = Machinename,
                        BarelTempZ1 = BarelTempZ1,
                        BarelTempZ2 = BarelTempZ2,
                        BarelTempZ3 = BarelTempZ3,
                        BarelTempZ4 = BarelTempZ4,
                        BarelTempZ5 = BarelTempZ5,
                        BarelTempZ6 = BarelTempZ6,
                        BarelTempZ7 = BarelTempZ7,
                        BarelTempZ8 = BarelTempZ8,
                        BarelTempZ9 = BarelTempZ9,
                        BarelTempZ10 = BarelTempZ10,
                        BarelTempZ11 = BarelTempZ11,
                        BarelTempZ12 = BarelTempZ12,
                        airInletPressureGuage = airInletPressureGuage,
                        hopperMaterialLevel = hopperMaterialLevel,
                        hopperTemperature = hopperTemperature,
                        MTC = MTC,
                        CWIP = CWIP,
                        CWOP = CWOP,
                        CWIT = CWIT,
                        CWOT = CWOT,
                        HRTC1 = HRTC1,
                        HRTC2 = HRTC2,
                        HRTC3 = HRTC3,
                        HRTC4 = HRTC4,
                        HRTC5 = HRTC5,
                        HRTC6 = HRTC6,
                        HRTC7 = HRTC7,
                        HRTC8 = HRTC8,
                        HRTC9 = HRTC9,
                        HRTC10 = HRTC10,
                        HRTC11 = HRTC11,
                        HRTC12 = HRTC12,
                        HRTC13 = HRTC13,
                        HRTC14 = HRTC14,
                        HRTC15 = HRTC15,
                        HRTC16 = HRTC16,
                        HRTC17 = HRTC17,
                        HRTC18 = HRTC18,
                        HRTC19 = HRTC19,
                        HRTC20 = HRTC20,
                        HRTC21 = HRTC21,
                        HRTC22 = HRTC22,
                        HRTC23 = HRTC23,
                        HRTC24 = HRTC24,
                        HRTC25 = HRTC25,
                        HRTC26 = HRTC26,
                        HRTC27 = HRTC27,
                        HRTC28 = HRTC28,
                        HRTC29 = HRTC29,
                        HRTC30 = HRTC30,
                        HRTC31 = HRTC31,
                        HRTC32 = HRTC32,
                        HRTC33 = HRTC33,
                        HRTC34 = HRTC34,
                        HRTC35 = HRTC35,
                        HRTC36 = HRTC36,
                        HRTC37 = HRTC37,
                        HRTC38 = HRTC38,
                        HRTC39 = HRTC39,
                        HRTC40 = HRTC40,
                        HRTC41 = HRTC41,
                        HRTC42 = HRTC42,
                        HRTC43 = HRTC43,
                        HRTC44 = HRTC44,
                        HRTC45 = HRTC45,
                        HRTC46 = HRTC46,
                        HRTC47 = HRTC47,
                        HRTC48 = HRTC48,
                        HRTC49 = HRTC49,
                        HRTC50 = HRTC50,
                        HRTC51 = HRTC51,
                        HRTC52 = HRTC52,
                        HRTC53 = HRTC53,
                        HRTC54 = HRTC54,
                        HRTC55 = HRTC55,
                        HRTC56 = HRTC56,
                        HRTC57 = HRTC57,
                        HRTC58 = HRTC58,
                        HRTC59 = HRTC59,
                        HRTC60 = HRTC60,
                        HRTC61 = HRTC61,
                        HRTC62 = HRTC62,
                        HRTC63 = HRTC63,
                        HRTC64 = HRTC64,
                        date = date,
                        time = time)
                item.save()

        if Name == "Production data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            MachineState = DateReq.get("MachineState")
            Alarm = DateReq.get("Alarm")
            ProductionCountActual = DateReq.get("ProductionCountActual")
            ProductionCountSet = DateReq.get("ProductionCountSet")
            CycletimeActual = DateReq.get("CycletimeActual")
            CycletimeSet = DateReq.get("CycletimeSet")
            ProductionTimeActual = DateReq.get("ProductionTimeActual")
            ProductionTimeTotal = DateReq.get("ProductionTimeTotal")
            RejectionParts = DateReq.get("RejectionParts")
            Cavity = DateReq.get("Cavity")
            date =  DateReq.get("date")
            time =  DateReq.get("time")
            # datetime = DateReq.get("datetime")
            machinestatus = DateReq.get("machinestatus")


            if date and time:
                datetime_str = f"{date} {time}"
                datetime_obj = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
            else:
                return JsonResponse({"error": "Invalid date or time format"}, status=400)

            try:
                all_dashboard_value = ProductionTable.objects.filter(
                        Plantname=Plantname,
                        Machinename=Machinename
                    ).values("ProductionCountActual", "Mouldname_id").order_by('id').last()
                
                last_production_count = all_dashboard_value["ProductionCountActual"]
                last_mould_id = all_dashboard_value["Mouldname_id"]

                if last_production_count != ProductionCountActual or last_mould_id != Mouldname_id:
                    maxs = CycletimeSet * 2
                    if CycletimeActual <= maxs:
                        item = Dashboard(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            datetime=datetime_obj,
                            machinestatus=machinestatus
                        )
                        item.save()

                        item = ProductionTable(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            date =  date,
                            time =  time
                        )
                        item.save()
            except:

                if Mouldname_id != 0:
                    maxs = CycletimeSet * 2
                    if CycletimeActual <= maxs:
                        item = Dashboard(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            datetime=datetime_obj,
                            machinestatus=machinestatus
                        )
                        item.save()

                        item = ProductionTable(
                            Plantname=Plantname,
                            Machinename=Machinename,
                            Mouldname_id=Mouldname_id,
                            MachineState=MachineState,
                            Alarm=Alarm,
                            ProductionCountActual=ProductionCountActual,
                            ProductionCountSet=ProductionCountSet,
                            CycletimeActual=CycletimeActual,
                            CycletimeSet=CycletimeSet,
                            ProductionTimeActual=ProductionTimeActual,
                            ProductionTimeTotal=ProductionTimeTotal,
                            RejectionParts=RejectionParts,
                            Cavity=Cavity,
                            date =  date,
                            time =  time
                        )
                        item.save()

        if Name == "Breakdown data":
            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            MachineState = DateReq.get("MachineState")
            primaryreason = DateReq.get("primaryreason")
            date =  DateReq.get("date")
            time =  DateReq.get("time")
            try:
                all_breakdown_data = breakdown.objects.filter(
                        Machinename=Machinename,
                        Plantname=Plantname
                    ).values('primaryreason', 'MachineState').order_by('id').last()
                
                last_primaryreason = all_breakdown_data["primaryreason"]
                last_MachineState = all_breakdown_data["MachineState"]

                if last_primaryreason == primaryreason and last_MachineState == MachineState:
                    pass
                else:
            
                    item = breakdown(
                                    Plantname=Plantname,
                                    Machinename=Machinename,
                                    Mouldname_id=Mouldname_id,
                                    MachineState=MachineState,
                                    primaryreason=primaryreason,
                                    date =  date,
                                    time =  time
                                )
                    item.save()
            except:
                if Mouldname_id != 0:
                    item = breakdown(
                                        Plantname=Plantname,
                                        Machinename=Machinename,
                                        Mouldname_id=Mouldname_id,
                                        MachineState=MachineState,
                                        primaryreason=primaryreason,
                                        date =  date,
                                        time =  time
                                    )
                    item.save()

        if Name == "Maintenance data":
            mnt_oilfilter_clogge = DateReq.get("mnt_oilfilter_clogge")
            mnt_machinename = DateReq.get("mnt_machinename")
            mnt_lubrication = DateReq.get("mnt_lubrication")
            mnt_hydraulic = DateReq.get("mnt_hydraulic")
            mnt_pumpstatus = DateReq.get("mnt_pumpstatus")
            mnt_date =  DateReq.get("mnt_date")
            mnt_time =  DateReq.get("mnt_time")
            mnt_oilfilter_motor = DateReq.get("mnt_oilfilter_motor")

            if maintenance_module.objects.filter(mnt_date = mnt_date, mnt_machinename = mnt_machinename).exists():
                maintenance_module.objects.filter(mnt_date = mnt_date, mnt_machinename = mnt_machinename).update(
                    mnt_oilfilter_clogge=mnt_oilfilter_clogge,
                    mnt_lubrication=mnt_lubrication,
                    mnt_hydraulic=mnt_hydraulic,
                    mnt_pumpstatus=mnt_pumpstatus,
                    mnt_time=mnt_time,
                    mnt_oilfilter_motor=mnt_oilfilter_motor)
                
            else:
                item = maintenance_module(
                                mnt_date=mnt_date,
                                mnt_machinename=mnt_machinename,
                                mnt_oilfilter_clogge=mnt_oilfilter_clogge,
                                mnt_lubrication=mnt_lubrication,
                                mnt_hydraulic=mnt_hydraulic,
                                mnt_pumpstatus=mnt_pumpstatus,
                                mnt_time=mnt_time,
                                mnt_oilfilter_motor=mnt_oilfilter_motor
                                    )
                item.save()

        if Name == "Badpart data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            Mouldname_id = DateReq.get("Mouldname_id")
            partcount = DateReq.get("partcount")
            Cavity = DateReq.get("Cavity")
            reason = DateReq.get("reason")
            date =  DateReq.get("date")
            time =  DateReq.get("time")

            try:

                all_RejectionParts_cal = badpart.objects.filter(
                        Plantname=Plantname,
                        Machinename=Machinename
                    ).values('Mouldname_id', 'partcount').order_by('id').last()
                
                last_Mouldname_id = all_RejectionParts_cal["Mouldname_id"]
                last_partcount = all_RejectionParts_cal["partcount"]

                if last_partcount != partcount or last_Mouldname_id != Mouldname_id:
                    item = badpart(
                                Plantname=Plantname,
                                Machinename=Machinename,
                                Mouldname_id=Mouldname_id,
                                partcount=partcount,
                                Cavity=Cavity,
                                reason=reason,
                                time=time,
                                date=date
                            )
                    item.save()

            except:
                if Mouldname_id != 0:
                    item = badpart(
                                    Plantname=Plantname,
                                    Machinename=Machinename,
                                    Mouldname_id=Mouldname_id,
                                    partcount=partcount,
                                    Cavity=Cavity,
                                    reason=reason,
                                    time=time,
                                    date=date
                                )
                    item.save()

        if Name == "Update Dashboard data":

            Plantname = DateReq.get("Plantname")
            Machinename = DateReq.get("Machinename")
            machinestatus = DateReq.get("machinestatus")
            
            if Dashboard.objects.filter(Plantname = Plantname, Machinename = Machinename).exists():
                Dashboard.objects.filter(Plantname = Plantname, Machinename = Machinename).update(
                    machinestatus=machinestatus)
                
            # else:
            #     item = Dashboard(
            #                 Plantname=Plantname,
            #                 Machinename=Machinename,
            #                 machinestatus=machinestatus
            #                     )
            #     item.save()

    return JsonResponse("Data Received Successfully", safe=False)

#ji