from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
from dateutil.relativedelta import relativedelta
from django.db import connection
##########################################  16-09-2024  ##################################################

# Function to get a list of dates between startdate and enddate
def get_dates_in_range(startdate, enddate):
    date_list = []
    current_date = startdate
    while current_date <= enddate:
        date_list.append(current_date)
        current_date += timedelta(days=1)
    return date_list

@csrf_exempt
def kpi_history(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        select_metrics = DateReq.get('select_metrics')
        startdate = DateReq.get('startdate')
        enddate = DateReq.get('enddate')
        select_wise = DateReq.get('select_wise')
        select_machine = DateReq.get('select_machine')

        selected_machines = DateReq.get('selected_machines')
        
        response_data = []

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        # Convert the date strings to datetime objects
        startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
        enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

        # Calculate the total days in the range
        total_days = (enddate_dt - startdate_dt).days + 1

        nex_enddate_dt = enddate_dt + timedelta(days=1)

        seconddate_dt = startdate_dt + timedelta(days=1)

        # Convert to string only for querying
        nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
        startdate_str = startdate_dt.strftime('%Y-%m-%d')
        enddate_str = enddate_dt.strftime('%Y-%m-%d')
        seconddate_str = seconddate_dt.strftime('%Y-%m-%d')


        if select_metrics == "OEE":
            
            if select_wise == "All_Machines":
                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}
                
                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=MachinenamesArray
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename').annotate(total_set_count=Sum('sp_totalproduction'), 
                    total_set_time=Sum('sp_totalproductiontime'))

                # Convert to dictionary with float conversion
                machine_set_data = {entry['sp_machinename']: (float(entry['total_set_count']) , float(entry['total_set_time'])) 
                              for entry in aggregated_data}

                for machine in MachinenamesArray:

                    machine_values = machine_data.get(machine, (0, 0))

                    ProductionTimeActual_hour = machine_values[0]
                    total_ProductionCountActual = machine_values[1]

                    machine_datas = machine_set_data.get(machine, (0, 0))

                    total_counts = machine_datas[0]
                    total_hours = machine_datas[1]

                    total_RejectionParts = machine_bad_count.get(machine, 0)

                    availability = (float(ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    oee = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "OEE": round(oee, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=selected_machines,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}
                
                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=selected_machines
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=selected_machines
                ).values('sp_machinename').annotate(total_set_count=Sum('sp_totalproduction'), 
                    total_set_time=Sum('sp_totalproductiontime'))

                # Convert to dictionary with float conversion
                machine_set_data = {entry['sp_machinename']: (float(entry['total_set_count']) , float(entry['total_set_time'])) 
                              for entry in aggregated_data}

                for machine in selected_machines:

                    machine_values = machine_data.get(machine, (0, 0))

                    ProductionTimeActual_hour = machine_values[0]
                    total_ProductionCountActual = machine_values[1]

                    machine_datas = machine_set_data.get(machine, (0, 0))

                    total_counts = machine_datas[0]
                    total_hours = machine_datas[1]

                    total_RejectionParts = machine_bad_count.get(machine, 0)

                    availability = (float(ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    oee = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "OEE": round(oee, 2)
                    })

                return JsonResponse(response_data, safe=False)
                
                
#--------------------------------------------------- OEE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "OOE":

            # List of dates between start and end date
            date_range = get_dates_in_range(startdate_dt, enddate_dt)
            
            if select_wise == "All_Machines":

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                        sp_date__range=[startdate_str, enddate_str],
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_shift').annotate(
                        total_set_count=Sum('sp_totalproduction')
                    )

                # Convert to dictionary with float conversion
                machine_set_count = {}
                for entry in aggregated_data:
                    machine = entry['sp_machinename']
                    total_set_count = float(entry['total_set_count'])
                    if machine in machine_set_count:
                        machine_set_count[machine] += total_set_count
                    else:
                        machine_set_count[machine] = total_set_count

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=MachinenamesArray
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}

                for machine in MachinenamesArray:
                    
                    aggregated_data_filtered = [r for r in aggregated_data if r['sp_machinename'] == machine]

                    total_counts = machine_set_count.get(machine, 0)

                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data_filtered if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    machine_values = machine_data.get(machine, (0, 0))

                    ProductionTimeActual_hour = machine_values[0]
                    total_ProductionCountActual = machine_values[1]
                    
                    total_RejectionParts = machine_bad_count.get(machine, 0)

                    availability = (float(ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    ooe = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "OOE": round(ooe, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                        sp_date__range=[startdate_str, enddate_str],
                        sp_plantname=Plantname,
                        sp_machinename__in=selected_machines
                    ).values('sp_machinename', 'sp_date', 'sp_shift').annotate(
                        total_set_count=Sum('sp_totalproduction')
                    )

                # Convert to dictionary with float conversion
                machine_set_count = {}
                for entry in aggregated_data:
                    machine = entry['sp_machinename']
                    total_set_count = float(entry['total_set_count'])
                    if machine in machine_set_count:
                        machine_set_count[machine] += total_set_count
                    else:
                        machine_set_count[machine] = total_set_count

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=selected_machines
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=selected_machines,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}

                for machine in selected_machines:
                    
                    aggregated_data_filtered = [r for r in aggregated_data if r['sp_machinename'] == machine]

                    total_counts = machine_set_count.get(machine, 0)

                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data_filtered if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    machine_values = machine_data.get(machine, (0, 0))

                    ProductionTimeActual_hour = machine_values[0]
                    total_ProductionCountActual = machine_values[1]
                    
                    total_RejectionParts = machine_bad_count.get(machine, 0)

                    availability = (float(ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    ooe = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "OOE": round(ooe, 2)
                    })

                return JsonResponse(response_data, safe=False)
                
#--------------------------------------------------- OOE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "TEEP":
            
            if select_wise == "All_Machines":
                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename').annotate(total_set_count=Sum('sp_totalproduction'))

                # Convert to dictionary with float conversion
                machine_set_count = {entry['sp_machinename']: float(entry['total_set_count']) for entry in aggregated_data}

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=MachinenamesArray
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}

                # Compute availability for each machine
                response_data = [
                    {
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "TEEP": round(teep, 2)
                    }
                    for machine in MachinenamesArray
                    if (
                        total_hours := 24 * total_days,
                        machine_values := machine_data.get(machine, (0, 0)),
                        availability := (machine_values[0] / total_hours) if total_hours != 0 else 0,
                        quality := abs((machine_values[1] - machine_bad_count.get(machine, 0)) / 
                                     machine_values[1]) if machine_values[1] != 0 else 0,
                        performance := (machine_values[1] / machine_set_count.get(machine, 0)) 
                                     if machine_set_count.get(machine, 0) != 0 else 0,
                        teep := (availability * performance * quality) * 100
                    )[1]
                ]

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=selected_machines
                ).values('sp_machinename').annotate(total_set_count=Sum('sp_totalproduction'))

                # Convert to dictionary with float conversion
                machine_set_count = {entry['sp_machinename']: float(entry['total_set_count']) for entry in aggregated_data}

                all_RejectionParts_cal = badpart.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    partcount__gt=0,
                    Machinename__in=selected_machines
                ).values('Machinename').annotate(total_bad_count=Sum('Cavity'))  # Changed len to Count

                # Corrected machine_bad_count dictionary creation
                machine_bad_count = {entry['Machinename']: float(entry['total_bad_count']) for entry in all_RejectionParts_cal}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=selected_machines,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(
                    production_time=Sum('CycletimeActual'), 
                    total_count=Sum('Cavity')
                )

                # Combined dictionary with production time (converted to hours) and count
                machine_data = {entry['Machinename']: (float(entry['production_time']) / 3600, float(entry['total_count'])) 
                              for entry in production_data}

                # Compute availability for each machine
                response_data = [
                    {
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "TEEP": round(teep, 2)
                    }
                    for machine in selected_machines
                    if (
                        total_hours := 24 * total_days,
                        machine_values := machine_data.get(machine, (0, 0)),
                        availability := (machine_values[0] / total_hours) if total_hours != 0 else 0,
                        quality := abs((machine_values[1] - machine_bad_count.get(machine, 0)) / 
                                     machine_values[1]) if machine_values[1] != 0 else 0,
                        performance := (machine_values[1] / machine_set_count.get(machine, 0)) 
                                     if machine_set_count.get(machine, 0) != 0 else 0,
                        teep := (availability * performance * quality) * 100
                    )[1]
                ]

                return JsonResponse(response_data, safe=False)

                
#--------------------------------------------------- TEEP COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Uptime":

            # List of dates between start and end date
            date_range = get_dates_in_range(startdate_dt, enddate_dt)

            if select_wise == "All_Machines":

                all_aggregated_data = ShiftProductiondata.objects.filter(
                        sp_date__range=[startdate_str, enddate_str],
                        sp_plantname=Plantname,
                        sp_machinename__in=MachinenamesArray
                    ).values('sp_machinename', 'sp_date', 'sp_shift').order_by('sp_id')

                all_breakdown_data = breakdown.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Machinename__in=MachinenamesArray,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                for machine in MachinenamesArray:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    
                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    saw = [k for k in all_breakdown_data if k['Machinename'] == machine]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    key = total_hours - total_idle_time_hours

                    uptime = (key / (24 * total_days)) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "Uptime": round(uptime, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":

                all_aggregated_data = ShiftProductiondata.objects.filter(
                        sp_date__range=[startdate_str, enddate_str],
                        sp_plantname=Plantname,
                        sp_machinename__in=selected_machines
                    ).values('sp_machinename', 'sp_date', 'sp_shift').order_by('sp_id')

                all_breakdown_data = breakdown.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Machinename__in=selected_machines,
                        Plantname=Plantname
                    ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                for machine in selected_machines:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    
                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    saw = [k for k in all_breakdown_data if k['Machinename'] == machine]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    key = total_hours - total_idle_time_hours

                    uptime = (key / (24 * total_days)) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "Uptime": round(uptime, 2)
                    })

                return JsonResponse(response_data, safe=False)


#--------------------------------------------------- Uptime COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Availability":

            if select_wise == "All_Machines":
                    
                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename').annotate(total_hours=Sum('sp_totalproductiontime'))

                # Convert to dictionary with float conversion
                machine_hours = {entry['sp_machinename']: float(entry['total_hours']) for entry in aggregated_data}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=MachinenamesArray,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(production_time=Sum('CycletimeActual'))

                # Convert production data to dictionary with float conversion
                machine_production = {entry['Machinename']: float(entry['production_time']) / 3600 for entry in production_data}

                # Compute availability for each machine
                response_data = [
                            {
                                "select_metrics": select_metrics,
                                "select_wise": select_wise,
                                "Machine": machine,
                                "Availability": round(
                                    (float(machine_production.get(machine, 0)) / machine_hours.get(machine, 0)) * 100, 2
                                ) if machine_hours.get(machine, 0) > 0 else 0  # Avoid division by zero
                            }
                            for machine in MachinenamesArray
                        ]

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                    
                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=selected_machines
                ).values('sp_machinename').annotate(total_hours=Sum('sp_totalproductiontime'))

                # Convert to dictionary with float conversion
                machine_hours = {entry['sp_machinename']: float(entry['total_hours']) for entry in aggregated_data}

                # Fetch production data directly with aggregation
                production_data = ProductionTable.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Plantname=Plantname,
                    Machinename__in=selected_machines,
                    ProductionCountActual__gt=0,
                    MachineState=1
                ).values('Machinename').annotate(production_time=Sum('CycletimeActual'))

                # Convert production data to dictionary with float conversion
                machine_production = {entry['Machinename']: float(entry['production_time']) / 3600 for entry in production_data}

                # Compute availability for each machine
                response_data = [
                            {
                                "select_metrics": select_metrics,
                                "select_wise": select_wise,
                                "Machine": machine,
                                "Availability": round(
                                    (float(machine_production.get(machine, 0)) / machine_hours.get(machine, 0)) * 100, 2
                                ) if machine_hours.get(machine, 0) > 0 else 0  # Avoid division by zero
                            }
                            for machine in selected_machines
                        ]

                return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Availability COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Utilization_rate":

            if select_wise == "All_Machines":

                all_breakdown_data = breakdown.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Machinename__in=MachinenamesArray,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=MachinenamesArray
                ).values('sp_machinename').annotate(total_hours=Sum('sp_totalproductiontime'))

                machine_hours = {entry['sp_machinename']: float(entry['total_hours']) for entry in aggregated_data}

                total_days = (enddate_dt - startdate_dt).days + 1
                time = 24 * total_days

                for machine in MachinenamesArray:
                    mac_hours = machine_hours.get(machine, 0)

                    saw = [k for k in all_breakdown_data if k['Machinename'] == machine]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_hours = mac_hours - total_idle_time_hours

                    utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "Utilization_rate": round(utilization_rate, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":

                all_breakdown_data = breakdown.objects.filter(
                    Q(date=startdate_str, time__gte=firstday_start) |
                    Q(date__range=[seconddate_str, enddate_str]) |
                    Q(date=nex_enddate_str, time__lte=secondday_end),
                    Machinename__in=selected_machines,
                    Plantname=Plantname
                ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

                # Fetch production time data directly from DB using aggregation
                aggregated_data = ShiftProductiondata.objects.filter(
                    sp_date__range=[startdate_str, enddate_str],
                    sp_plantname=Plantname,
                    sp_machinename__in=selected_machines
                ).values('sp_machinename').annotate(total_hours=Sum('sp_totalproductiontime'))

                machine_hours = {entry['sp_machinename']: float(entry['total_hours']) for entry in aggregated_data}

                total_days = (enddate_dt - startdate_dt).days + 1
                time = 24 * total_days

                for machine in selected_machines:
                    mac_hours = machine_hours.get(machine, 0)

                    saw = [k for k in all_breakdown_data if k['Machinename'] == machine]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_hours = mac_hours - total_idle_time_hours

                    utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                    response_data.append({
                        "select_metrics": select_metrics,
                        "select_wise": select_wise,
                        "Machine": machine,
                        "Utilization_rate": round(utilization_rate, 2)
                    })

                return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Utilization_rate COMPLETED ---------------------------------------------------------#