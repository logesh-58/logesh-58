from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache
import pytz
from dateutil.relativedelta import relativedelta
##########################################  16-09-2024  ##################################################

# Function to get a list of dates between startdate and enddate
def get_dates_in_range(startdate, enddate):
    date_list = []
    current_date = startdate
    while current_date <= enddate:
        date_list.append(current_date)
        current_date += timedelta(days=1)
    return date_list

@csrf_exempt
def kpi_history(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        select_metrics = DateReq.get('select_metrics')
        # select_range = DateReq.get('select_range')
        startdate = DateReq.get('startdate')
        enddate = DateReq.get('enddate')
        # monthwise = DateReq.get('monthwise')
        # yearwise = DateReq.get('yearwise')
        select_wise = DateReq.get('select_wise')
        select_machine = DateReq.get('select_machine')

        selected_machines = DateReq.get('selected_machines')
        
        response_data = []

        # Cache machine names and shift timings
        MachinenamesArray = machineArray(Plantname)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift1end', 'shift2start', 'shift2end', 'shift3start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        # Other time definitions
        firstday_end = '23:59:59'
        secondday_start = '00:00:00'

        if select_metrics == "OEE":
            # if select_range == "Date_Range":
            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            # Retrieve and store all data for the date range
            all_dashboard_value = ProductionTable.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        ProductionCountActual__gt=0,
                        MachineState=1
                    ).values('Machinename', 'time', 'date', 'id', 'CycletimeActual').order_by('id')

            # Aggregate data
            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            all_RejectionParts_cal = badpart.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            # all_breakdown_data = breakdown.objects.filter(
            #     Q(date=startdate_str, time__gte=firstday_start) |
            #     Q(date__range=[seconddate_str, enddate_str]) |
            #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     Machinename__in=MachinenamesArray,
            #     Plantname=Plantname
            # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            if select_wise == "Individual":

                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] == select_machine and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                    
                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] == select_machine and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                    RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #     k['Machinename'] == select_machine and
                    #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                    #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    # ]


                    # #  .total_seconds()     # .seconds
                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None


                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                    performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                    quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                    oee = (availability * performance * quality) * 100

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "OEE": round(oee, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:
                    print('Machine: ', select_machine)

                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None

                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    oee = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "OEE": round(oee, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:
                    print('Machine: ', select_machine)

                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None

                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time_hours
                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    oee = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "OEE": round(oee, 2)
                    })

                return JsonResponse(response_data, safe=False)
                
            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            #     #######

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                 p['Machinename'] == select_machine and
            #                 ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
            #                     (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
            #             ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                 e['Machinename'] == select_machine and
            #                 ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
            #                     (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
            #             ]
            #             RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #     k['Machinename'] == select_machine and
            #             #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #             #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             # ]


            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None


            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
            #             performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
            #             quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:
            #             print('Machine: ', select_machine)

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             print('Machine: ', select_machine)

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # print('StartDate: ', startdate_str, 'EndDate: ', nex_enddate_str)

            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             current_month_name = month_startdate.strftime('%B')

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             dashboard_value = [p for p in all_dashboard_value if
            #                            p['Machinename'] == select_machine and
            #                            ((p['date'] == month_startdate_str and firstday_start <= p['time']) or
            #                             (seconddate_str <= p['date'] <= month_enddate_str) or
            #                             (p['date'] == nex_enddate_str and p['time'] <= secondday_end))]
                        
            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]
                        
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                               e['Machinename'] == select_machine and
            #                               ((e['date'] == month_startdate_str and firstday_start <= e['time']) or
            #                                (seconddate_str <= e['date'] <= month_enddate_str) or
            #                                (e['date'] == nex_enddate_str and e['time'] <= secondday_end))]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #    k['Machinename'] == select_machine and
            #             #    ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #             #     (seconddate_str <= k['date'] <= month_enddate_str) or
            #             #     (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

                
            #     elif select_wise == "All_Machines":

            #         for select_machine in MachinenamesArray:
            #             print('Machine: ', select_machine)

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             print('Machine: ', select_machine)

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             oee = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OEE": round(oee, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
#--------------------------------------------------- OEE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "OOE":
            # if select_range == "Date_Range":
            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            # Retrieve and store all data for the date range
            all_dashboard_value = ProductionTable.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        ProductionCountActual__gt=0,
                        MachineState=1
                    ).values('Machinename', 'time', 'date', 'id', 'CycletimeActual').order_by('id')

            # Aggregate data
            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            all_RejectionParts_cal = badpart.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            # all_breakdown_data = breakdown.objects.filter(
            #     Q(date=startdate_str, time__gte=firstday_start) |
            #     Q(date__range=[seconddate_str, enddate_str]) |
            #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     Machinename__in=MachinenamesArray,
            #     Plantname=Plantname
            # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            # List of dates between start and end date
            date_range = get_dates_in_range(startdate_dt, enddate_dt)

            if select_wise == "Individual":

                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] == select_machine and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                    
                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    
                    shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                    # print("mac_counts:", mac_counts)

                    # print("machine:", select_machine, "shift:", shift)

                    if shift == 'A':
                        mac_hours = 8
                    elif shift == 'B':
                        mac_hours = 16
                    elif shift == 'C':
                        mac_hours = 24
                    else:
                        mac_hours = 0

                    # print("machine:", select_machine, "mac_hours:", mac_hours)

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] == select_machine and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                    RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #     k['Machinename'] == select_machine and
                    #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                    #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    # ]

                    # #  .total_seconds()     # .seconds
                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None

                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                    performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                    quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                    ooe = (availability * performance * quality) * 100

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "OOE": round(ooe, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    # total_hours += mac_hours

                    # print("Machine:", select_machine, "total_hours:", total_hours)
                    # print("Machine:", select_machine, "total_counts:", total_counts)
                    # print("##################################################################")

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    ooe = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "OOE": round(ooe, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

                    print("aggregated_data:", aggregated_data)

                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    print("total_counts:", total_counts)

                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    print("total_hours:", total_hours)

                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0

                    print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                    print("total_ProductionCountActual:", total_ProductionCountActual)

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    print("total_RejectionParts:", total_RejectionParts)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    # total_hours += mac_hours

                    # print("Machine:", select_machine, "total_hours:", total_hours)
                    # # print("Machine:", select_machine, "total_counts:", total_counts)
                    # print("##################################################################")

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    ooe = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "OOE": round(ooe, 2)
                    })

                return JsonResponse(response_data, safe=False)

                
            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            #     #######

            #     # List of dates between start and end date
            #     date_range = get_dates_in_range(startdate, enddate)

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                 p['Machinename'] == select_machine and
            #                 ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
            #                     (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
            #             ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
                        
            #             shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

            #             mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
            #             # print("mac_counts:", mac_counts)

            #             # print("machine:", select_machine, "shift:", shift)

            #             if shift == 'A':
            #                 mac_hours = 8
            #             elif shift == 'B':
            #                 mac_hours = 16
            #             elif shift == 'C':
            #                 mac_hours = 24
            #             else:
            #                 mac_hours = 0

            #             # print("machine:", select_machine, "mac_hours:", mac_hours)

            #             ProductionTimeActual_hour = 0
            #             ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                 e['Machinename'] == select_machine and
            #                 ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
            #                     (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
            #             ]
            #             RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #     k['Machinename'] == select_machine and
            #             #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #             #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             # ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
            #             performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
            #             quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:
            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             current_month_name = month_startdate.strftime('%B')

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             # List of dates between start and end date
            #             date_range = get_dates_in_range(month_startdate, month_enddate)

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                            p['Machinename'] == select_machine and
            #                            ((p['date'] == month_startdate_str and firstday_start <= p['time']) or
            #                             (seconddate_str <= p['date'] <= month_enddate_str) or
            #                             (p['date'] == nex_enddate_str and p['time'] <= secondday_end))]
                        
            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]
                        
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0
                        
            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                               e['Machinename'] == select_machine and
            #                               ((e['date'] == month_startdate_str and firstday_start <= e['time']) or
            #                                (seconddate_str <= e['date'] <= month_enddate_str) or
            #                                (e['date'] == nex_enddate_str and e['time'] <= secondday_end))]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #    k['Machinename'] == select_machine and
            #             #    ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #             #     (seconddate_str <= k['date'] <= month_enddate_str) or
            #             #     (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             # print("Machine:", select_machine, "total_hours:", total_hours)
            #             # print("##################################################################")

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current month
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     elif select_wise == "All_Machines":

            #         # List of dates between start and end date
            #         date_range = get_dates_in_range(startdate, enddate)

            #         for select_machine in MachinenamesArray:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":

            #         # List of dates between start and end date
            #         date_range = get_dates_in_range(startdate, enddate)

            #         for select_machine in selected_machines:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None

            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             ooe = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "OOE": round(ooe, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
#--------------------------------------------------- OOE COMPLETED ---------------------------------------------------------#

        elif select_metrics == "TEEP":
            # if select_range == "Date_Range":
            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            # Retrieve and store all data for the date range
            all_dashboard_value = ProductionTable.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        ProductionCountActual__gt=0,
                        MachineState=1
                    ).values('Machinename', 'time', 'date', 'id', 'CycletimeActual').order_by('id')

            # Aggregate data
            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            all_RejectionParts_cal = badpart.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            # all_breakdown_data = breakdown.objects.filter(
            #     Q(date=startdate_str, time__gte=firstday_start) |
            #     Q(date__range=[seconddate_str, enddate_str]) |
            #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     Machinename__in=MachinenamesArray,
            #     Plantname=Plantname
            # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            if select_wise == "Individual":

                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] == select_machine and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                    
                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    mac_hours = 24
                    mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        ProductionCountActual = 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        e['Machinename'] == select_machine and
                        ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
                            (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
                    ]
                    RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #     k['Machinename'] == select_machine and
                    #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                    #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    # ]


                    # #  .total_seconds()     # .seconds
                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None

                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
                    performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
                    quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

                    teep = (availability * performance * quality) * 100

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "TEEP": round(teep, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:

                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                    
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = 24 * total_days
                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    # print("Machine:", select_machine, "total_hours:", total_hours)
                    # print("##################################################################")

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    teep = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "TEEP": round(teep, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:
            
                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                    
                    ProductionTimeActual_hour = 0
                    total_ProductionCountActual = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                        total_ProductionCountActual = len(dashboard_value)
                    else:
                        ProductionTimeActual_hour = 0
                        total_ProductionCountActual = 0
                    
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = 24 * total_days
                    total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                    RejectionParts_cal = [e for e in all_RejectionParts_cal if
                                e['Machinename'] == select_machine
                            ]
                    
                    total_RejectionParts = len(RejectionParts_cal)

                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    # print("Machine:", select_machine, "total_hours:", total_hours)
                    # print("##################################################################")

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
                    quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
                    performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
                    teep = (availability * performance * quality) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "TEEP": round(teep, 2)
                    })

                return JsonResponse(response_data, safe=False)

                
            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
            #     #######

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                 p['Machinename'] == select_machine and
            #                 ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
            #                     (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
            #             ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
            #             mac_hours = 24
            #             mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                 e['Machinename'] == select_machine and
            #                 ((e['date'] == current_date_str and firstday_start <= e['time'] <= firstday_end) or
            #                     (e['date'] == next_day_str and secondday_start <= e['time'] <= secondday_end))
            #             ]
            #             RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #     k['Machinename'] == select_machine and
            #             #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #             #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             # ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / mac_hours) if mac_hours > 0 else 0
            #             performance = (ProductionCountActual / mac_counts) if mac_counts > 0 else 0
            #             quality = (abs(ProductionCountActual - RejectionParts) / ProductionCountActual) if ProductionCountActual > 0 else 0

            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = 24 * total_days
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:
                
            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = 24 * total_days
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

                
            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_RejectionParts_cal = badpart.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Plantname=Plantname,
            #         partcount__gt=0,
            #         Machinename__in=MachinenamesArray
            #     ).values('Machinename', 'date', 'time', 'partcount', 'id').order_by('id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             current_month_name = month_startdate.strftime('%B')

            #             total_days = (month_enddate - month_startdate).days + 1

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             dashboard_value = [p for p in all_dashboard_value if
            #                            p['Machinename'] == select_machine and
            #                            ((p['date'] == month_startdate_str and firstday_start <= p['time']) or
            #                             (seconddate_str <= p['date'] <= month_enddate_str) or
            #                             (p['date'] == nex_enddate_str and p['time'] <= secondday_end))]
                            
            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]

            #             total_hours = 24 * total_days
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                               e['Machinename'] == select_machine and
            #                               ((e['date'] == month_startdate_str and firstday_start <= e['time']) or
            #                                (seconddate_str <= e['date'] <= month_enddate_str) or
            #                                (e['date'] == nex_enddate_str and e['time'] <= secondday_end))]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #    k['Machinename'] == select_machine and
            #             #    ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #             #     (seconddate_str <= k['date'] <= month_enddate_str) or
            #             #     (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current month
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     elif select_wise == "All_Machines":

            #         for select_machine in MachinenamesArray:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = 24 * total_days
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:
                
            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = 24 * total_days
            #             total_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0
            #             total_ProductionCountActual = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #                 total_ProductionCountActual = len(dashboard_value)
            #             else:
            #                 ProductionTimeActual_hour = 0
            #                 total_ProductionCountActual = 0

            #             RejectionParts_cal = [e for e in all_RejectionParts_cal if
            #                         e['Machinename'] == select_machine
            #                     ]
                        
            #             total_RejectionParts = len(RejectionParts_cal)

            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) if total_hours != 0 else 0
            #             quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) if total_ProductionCountActual != 0 else 0
            #             performance = (total_ProductionCountActual / total_counts) if total_counts != 0 else 0
            #             teep = (availability * performance * quality) * 100

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "TEEP": round(teep, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

                
#--------------------------------------------------- TEEP COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Uptime":
            # if select_range == "Date_Range":
            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
            all_breakdown_data = breakdown.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            # List of dates between start and end date
            date_range = get_dates_in_range(startdate_dt, enddate_dt)

            if select_wise == "Individual":
                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    
                    shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

                    if shift == 'A':
                        mac_hours = 8
                    elif shift == 'B':
                        mac_hours = 16
                    elif shift == 'C':
                        mac_hours = 24
                    else:
                        mac_hours = 0

                    saw = [k for k in all_breakdown_data if
                        k['Machinename'] == select_machine and
                        ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                            (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    ]

                    #  .total_seconds()     # .seconds
                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    key = mac_hours - total_idle_time_hours

                    uptime = (key / 24) * 100

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "Uptime": round(uptime, 2)
                    })

                return JsonResponse(response_data, safe=False)

            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    
                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine
                                    ]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    key = total_hours - total_idle_time_hours

                    uptime = (key / (24 * total_days)) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Uptime": round(uptime, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    
                    # Iterate over each date in the date range and find the shift
                    total_hours = 0
                    for date in date_range:
                        date_str = date.strftime('%Y-%m-%d')

                        # Filter the shift data for the specific date
                        date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

                        if date_shift_data:
                            shift = max(r['sp_shift'] for r in date_shift_data)
                        else:
                            shift = None

                        # Set total_hours based on the shift
                        if shift == 'A':
                            total_hours += 8
                        elif shift == 'B':
                            total_hours += 16
                        elif shift == 'C':
                            total_hours += 24
                        else:
                            total_hours += 0

                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine
                                    ]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    key = total_hours - total_idle_time_hours

                    uptime = (key / (24 * total_days)) * 100

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Uptime": round(uptime, 2)
                    })

                return JsonResponse(response_data, safe=False)

            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_breakdown_data = breakdown.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Machinename__in=MachinenamesArray,
            #         Plantname=Plantname
            #     ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     # List of dates between start and end date
            #     date_range = get_dates_in_range(startdate, enddate)

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
                        
            #             shift = max(r['sp_shift'] for r in aggregated_data) if aggregated_data else 0

            #             if shift == 'A':
            #                 mac_hours = 8
            #             elif shift == 'B':
            #                 mac_hours = 16
            #             elif shift == 'C':
            #                 mac_hours = 24
            #             else:
            #                 mac_hours = 0

            #             saw = [k for k in all_breakdown_data if
            #                 k['Machinename'] == select_machine and
            #                 ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #                     (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             ]

            #             #  .total_seconds()     # .seconds
            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = mac_hours - total_idle_time_hours

            #             uptime = (key / 24) * 100

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                        
            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = total_hours - total_idle_time_hours

            #             uptime = (key / (24 * total_days)) * 100
                        
            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                        
            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = total_hours - total_idle_time_hours

            #             uptime = (key / (24 * total_days)) * 100
                        
            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     total_days = (enddate - startdate).days + 1

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     all_breakdown_data = breakdown.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Machinename__in=MachinenamesArray,
            #         Plantname=Plantname
            #     ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             total_days = (month_enddate - month_startdate).days + 1

            #             current_month_name = month_startdate.strftime('%B')

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             # List of dates between start and end date
            #             date_range = get_dates_in_range(month_startdate, month_enddate)

            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]
                        
            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             saw = [k for k in all_breakdown_data if
            #                k['Machinename'] == select_machine and
            #                ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #                 (seconddate_str <= k['date'] <= month_enddate_str) or
            #                 (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = total_hours - total_idle_time_hours

            #             uptime = (key / (24 * total_days)) * 100

            #             # Construct the response for the current month
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":

            #         # List of dates between start and end date
            #         date_range = get_dates_in_range(startdate, enddate)

            #         for select_machine in MachinenamesArray:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = total_hours - total_idle_time_hours

            #             uptime = (key / (24 * total_days)) * 100
                        
            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":

            #         # List of dates between start and end date
            #         date_range = get_dates_in_range(startdate, enddate)

            #         for select_machine in selected_machines:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             # Iterate over each date in the date range and find the shift
            #             total_hours = 0
            #             for date in date_range:
            #                 date_str = date.strftime('%Y-%m-%d')

            #                 # Filter the shift data for the specific date
            #                 date_shift_data = [r for r in aggregated_data if r['sp_date'] == date_str]

            #                 if date_shift_data:
            #                     shift = max(r['sp_shift'] for r in date_shift_data)
            #                 else:
            #                     shift = None

            #                 # Set total_hours based on the shift
            #                 if shift == 'A':
            #                     total_hours += 8
            #                 elif shift == 'B':
            #                     total_hours += 16
            #                 elif shift == 'C':
            #                     total_hours += 24
            #                 else:
            #                     total_hours += 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             key = total_hours - total_idle_time_hours

            #             uptime = (key / (24 * total_days)) * 100
                        
            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Uptime": round(uptime, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Uptime COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Availability":

            # if select_range == "Date_Range":

            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            # Retrieve and store all data for the date range
            all_dashboard_value = ProductionTable.objects.filter(
                        Q(date=startdate_str, time__gte=firstday_start) |
                        Q(date__range=[seconddate_str, enddate_str]) |
                        Q(date=nex_enddate_str, time__lte=secondday_end),
                        Plantname=Plantname,
                        Machinename__in=MachinenamesArray,
                        ProductionCountActual__gt=0,
                        MachineState=1
                    ).values('Machinename', 'time', 'date', 'id', 'CycletimeActual').order_by('id')

            # Aggregate data
            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            # all_breakdown_data = breakdown.objects.filter(
            #     Q(date=startdate_str, time__gte=firstday_start) |
            #     Q(date__range=[seconddate_str, enddate_str]) |
            #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     Machinename__in=MachinenamesArray,
            #     Plantname=Plantname
            # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            if select_wise == "Individual":

                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    dashboard_value = [p for p in all_dashboard_value if
                        p['Machinename'] == select_machine and
                        ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
                            (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
                    ]
                    
                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                    else:
                        ProductionTimeActual_hour = 0
                    # print("ProductionTimeActual_hour:", ProductionTimeActual_hour)
                    # saw = [k for k in all_breakdown_data if
                    #     k['Machinename'] == select_machine and
                    #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                    #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    # ]


                    # #  .total_seconds()     # .seconds
                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / mac_hours) * 100 if mac_hours > 0 else 0

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "Availability": round(availability, 2)
                    })

                return JsonResponse(response_data, safe=False)

            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:

                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                        
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                    else:
                        ProductionTimeActual_hour = 0


                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Availability": round(availability, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:

                    dashboard_value = [p for p in all_dashboard_value if
                            p['Machinename'] == select_machine
                        ]
                        
                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
                    total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    ProductionTimeActual_hour = 0

                    if dashboard_value:
                        # first_record = dashboard_value[0]
                        # last_record = dashboard_value[-1]

                        # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
                        # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

                        # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
                        # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                        
                        # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
                        ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                    else:
                        ProductionTimeActual_hour = 0


                    # saw = [k for k in all_breakdown_data if
                    #                k['Machinename'] == select_machine
                    #                ]

                    # total_idle_time = 0  # Initialize the sum

                    # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # # Iterate through the breakdown data and calculate time differences
                    # for last, bd in zip(saw, saw[1:]):
                    #     # If `MachineState = 0` for last, store its time but don't calculate yet
                    #     if last['MachineState'] == 0:
                    #         # Capture the first occurrence of MachineState = 0
                    #         if last_time_str is None:
                    #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                    #     # Only calculate the time difference when transitioning from 0 to 1
                    #     if last_time_str and bd['MachineState'] == 1:
                    #         # Combine date and time for `bd`
                    #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                    #         # Parse the combined date and time
                    #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                    #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                    #         # Calculate the time difference in seconds
                    #         time_difference = (bd_time - last_time).total_seconds()

                    #         # Print the intermediate values
                    #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                    #         # Accumulate the total time in seconds
                    #         total_idle_time += time_difference

                    #         # Reset last_time_str to None after calculating for this transition
                    #         last_time_str = None
                    # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = ProductionTimeActual_hour

                    availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

                    # Construct the response for the current date and machine
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Availability": round(availability, 2)
                    })

                return JsonResponse(response_data, safe=False)
                

            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                 p['Machinename'] == select_machine and
            #                 ((p['date'] == current_date_str and firstday_start <= p['time'] <= firstday_end) or
            #                     (p['date'] == next_day_str and secondday_start <= p['time'] <= secondday_end))
            #             ]
                        
            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0

            #             # saw = [k for k in all_breakdown_data if
            #             #     k['Machinename'] == select_machine and
            #             #     ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #             #         (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             # ]


            #             # #  .total_seconds()     # .seconds
            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / mac_hours) * 100 if mac_hours > 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0


            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":

            #         for select_machine in selected_machines:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0


            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     all_dashboard_value = ProductionTable.objects.filter(
            #                 Q(date=startdate_str, time__gte=firstday_start) |
            #                 Q(date__range=[seconddate_str, enddate_str]) |
            #                 Q(date=nex_enddate_str, time__lte=secondday_end),
            #                 Plantname=Plantname,
            #                 Machinename__in=MachinenamesArray,
            #                 ProductionCountActual__gt=0,
            #                 MachineState=1
            #             ).values('Machinename', 'time', 'date', 'id').order_by('id')

            #     # Aggregate data
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')

            #     # all_breakdown_data = breakdown.objects.filter(
            #     #     Q(date=startdate_str, time__gte=firstday_start) |
            #     #     Q(date__range=[seconddate_str, enddate_str]) |
            #     #     Q(date=nex_enddate_str, time__lte=secondday_end),
            #     #     Machinename__in=MachinenamesArray,
            #     #     Plantname=Plantname
            #     # ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             current_month_name = month_startdate.strftime('%B')

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             dashboard_value = [p for p in all_dashboard_value if
            #                            p['Machinename'] == select_machine and
            #                            ((p['date'] == month_startdate_str and firstday_start <= p['time']) or
            #                             (seconddate_str <= p['date'] <= month_enddate_str) or
            #                             (p['date'] == nex_enddate_str and p['time'] <= secondday_end))]
                        
            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]
                        
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0

            #             # saw = [k for k in all_breakdown_data if
            #             #    k['Machinename'] == select_machine and
            #             #    ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #             #     (seconddate_str <= k['date'] <= month_enddate_str) or
            #             #     (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current month
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":

            #         for select_machine in MachinenamesArray:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0


            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             dashboard_value = [p for p in all_dashboard_value if
            #                     p['Machinename'] == select_machine
            #                 ]
                            
            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]
            #             total_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             ProductionTimeActual_hour = 0

            #             if dashboard_value:
            #                 # first_record = dashboard_value[0]
            #                 # last_record = dashboard_value[-1]

            #                 # first_time = datetime.strptime(first_record['time'], "%H:%M:%S").time()
            #                 # last_time = datetime.strptime(last_record['time'], "%H:%M:%S").time()

            #                 # first_date = datetime.strptime(first_record['date'], "%Y-%m-%d").date()
            #                 # last_date = datetime.strptime(last_record['date'], "%Y-%m-%d").date()
                            
            #                 # ProductionTimeActual_hour = ((datetime.combine(last_date, last_time) - datetime.combine(first_date, first_time)).total_seconds()) / 3600
            #                 ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
            #             else:
            #                 ProductionTimeActual_hour = 0


            #             # saw = [k for k in all_breakdown_data if
            #             #                k['Machinename'] == select_machine
            #             #                ]

            #             # total_idle_time = 0  # Initialize the sum

            #             # last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # # Iterate through the breakdown data and calculate time differences
            #             # for last, bd in zip(saw, saw[1:]):
            #             #     # If `MachineState = 0` for last, store its time but don't calculate yet
            #             #     if last['MachineState'] == 0:
            #             #         # Capture the first occurrence of MachineState = 0
            #             #         if last_time_str is None:
            #             #             last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #             #     # Only calculate the time difference when transitioning from 0 to 1
            #             #     if last_time_str and bd['MachineState'] == 1:
            #             #         # Combine date and time for `bd`
            #             #         bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #             #         # Parse the combined date and time
            #             #         last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #             #         bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #             #         # Calculate the time difference in seconds
            #             #         time_difference = (bd_time - last_time).total_seconds()

            #             #         # Print the intermediate values
            #             #         # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #             #         # Accumulate the total time in seconds
            #             #         total_idle_time += time_difference

            #             #         # Reset last_time_str to None after calculating for this transition
            #             #         last_time_str = None
            #             # # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             # total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = ProductionTimeActual_hour

            #             availability = (float(total_ProductionTimeActual_hour) / total_hours) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date and machine
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Availability": round(availability, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

#--------------------------------------------------- Availability COMPLETED ---------------------------------------------------------#

        elif select_metrics == "Utilization_rate":
            # if select_range == "Date_Range":
            # Convert the date strings to datetime objects
            startdate_dt = datetime.strptime(startdate, "%Y-%m-%d")
            enddate_dt = datetime.strptime(enddate, "%Y-%m-%d")

            # Calculate the total days in the range
            total_days = (enddate_dt - startdate_dt).days + 1

            nex_enddate_dt = enddate_dt + timedelta(days=1)

            seconddate_dt = startdate_dt + timedelta(days=1)

            # Convert to string only for querying
            nex_enddate_str = nex_enddate_dt.strftime('%Y-%m-%d')
            startdate_str = startdate_dt.strftime('%Y-%m-%d')
            enddate_str = enddate_dt.strftime('%Y-%m-%d')
            seconddate_str = seconddate_dt.strftime('%Y-%m-%d')

            # Retrieve and store all data for the date range
            all_aggregated_data = ShiftProductiondata.objects.filter(
                Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
            all_breakdown_data = breakdown.objects.filter(
                Q(date=startdate_str, time__gte=firstday_start) |
                Q(date__range=[seconddate_str, enddate_str]) |
                Q(date=nex_enddate_str, time__lte=secondday_end),
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            if select_wise == "Individual":

                # Iterate over each day in the date range
                for day_offset in range(total_days):
                    current_date = startdate_dt + timedelta(days=day_offset)
                    current_date_str = current_date.strftime('%Y-%m-%d')
                    next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                    # Filter stored data for the current day and the shift boundaries specific to the machine
                    aggregated_data = [r for r in all_aggregated_data if
                        r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
                    ]
                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    timely = 24

                    saw = [k for k in all_breakdown_data if
                        k['Machinename'] == select_machine and
                        ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
                            (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
                    ]


                    #  .total_seconds()     # .seconds
                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                            
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_ProductionTimeActual_hour = mac_hours - total_idle_time_hours


                    utilization_rate = (total_ProductionTimeActual_hour / timely) * 100 if total_ProductionTimeActual_hour != 0 else 0

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "date": current_date_str,
                        "Machine": select_machine,
                        "Utilization_rate": round(utilization_rate, 2)
                    })

                return JsonResponse(response_data, safe=False)

            elif select_wise == "All_Machines":
                for select_machine in MachinenamesArray:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

                    time = 24 * total_days

                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine
                                    ]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                    # print("total_idle_time_hours:", total_idle_time_hours)
                    total_hours = mac_hours - total_idle_time_hours
                    # print("total_hours:", total_hours)
                    utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0
                    # print("utilization_rate:", utilization_rate)
                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Utilization_rate": round(utilization_rate, 2)
                    })

                return JsonResponse(response_data, safe=False)
            
            #--------------------------------
            elif select_wise == "selected_machines":
                for select_machine in selected_machines:

                    aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

                    time = 24 * total_days

                    mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                    saw = [k for k in all_breakdown_data if
                                    k['Machinename'] == select_machine
                                    ]

                    total_idle_time = 0  # Initialize the sum

                    last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                    # Iterate through the breakdown data and calculate time differences
                    for last, bd in zip(saw, saw[1:]):
                        # If `MachineState = 0` for last, store its time but don't calculate yet
                        if last['MachineState'] == 0:
                            # Capture the first occurrence of MachineState = 0
                            if last_time_str is None:
                                last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                        
                        # Only calculate the time difference when transitioning from 0 to 1
                        if last_time_str and bd['MachineState'] == 1:
                            # Combine date and time for `bd`
                            bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                            # Parse the combined date and time
                            last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                            bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                            # Calculate the time difference in seconds
                            time_difference = (bd_time - last_time).total_seconds()

                            # Print the intermediate values
                            # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

                            # Accumulate the total time in seconds
                            total_idle_time += time_difference

                            # Reset last_time_str to None after calculating for this transition
                            last_time_str = None
                    # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
                    total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

                    total_hours = mac_hours - total_idle_time_hours

                    utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

                    # Construct the response for the current date
                    response_data.append({
                        "select_metrics": select_metrics,
                        # "select_range": select_range,
                        "select_wise": select_wise,
                        "Machine": select_machine,
                        "Utilization_rate": round(utilization_rate, 2)
                    })

                return JsonResponse(response_data, safe=False)

            # elif select_range == "Monthwise":
            #     # Convert monthwise to datetime object (start date of the month)
            #     startdate = datetime.strptime(monthwise, "%Y-%m-%d")

            #     # Calculate the end date by adding one month and subtracting one day
            #     if startdate.month == 12:
            #         enddate = startdate.replace(year=startdate.year + 1, month=1) - timedelta(days=1)
            #     else:
            #         enddate = startdate.replace(month=startdate.month + 1) - timedelta(days=1)

            #     # Convert the date strings to datetime objects
            #     startdate_str = startdate.strftime("%Y-%m-%d")
            #     enddate_str = enddate.strftime("%Y-%m-%d")

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     #####
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            #     all_breakdown_data = breakdown.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Machinename__in=MachinenamesArray,
            #         Plantname=Plantname
            #     ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
                

            #     if select_wise == "Individual":

            #         # Iterate over each day in the date range
            #         for day_offset in range(total_days):
            #             current_date = startdate + timedelta(days=day_offset)
            #             current_date_str = current_date.strftime('%Y-%m-%d')
            #             next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             aggregated_data = [r for r in all_aggregated_data if
            #                 r['sp_machinename'] == select_machine and r['sp_date'] == current_date_str
            #             ]
            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             timely = 24

            #             saw = [k for k in all_breakdown_data if
            #                 k['Machinename'] == select_machine and
            #                 ((k['date'] == current_date_str and firstday_start <= k['time'] <= firstday_end) or
            #                     (k['date'] == next_day_str and secondday_start <= k['time'] <= secondday_end))
            #             ]


            #             #  .total_seconds()     # .seconds
            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
                                
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_ProductionTimeActual_hour = mac_hours - total_idle_time_hours


            #             utilization_rate = (total_ProductionTimeActual_hour / timely) * 100 if total_ProductionTimeActual_hour != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "date": current_date_str,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":
            #         for select_machine in MachinenamesArray:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             time = 24 * total_days

            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_hours = mac_hours - total_idle_time_hours

            #             utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             time = 24 * total_days

            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_hours = mac_hours - total_idle_time_hours

            #             utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            # elif select_range == "Yearwise":

            #     # Convert yearwise to datetime object (start date of the year)
            #     startdate = datetime.strptime(yearwise, "%Y-%m-%d")

            #     enddate = startdate.replace(year=startdate.year + 1, month=1, day=1) - timedelta(days=1)

            #     # Calculate the total days in the range
            #     total_days = (enddate - startdate).days + 1

            #     enddate_str = enddate.strftime('%Y-%m-%d')
    
            #     nex_enddate = enddate + timedelta(days=1)

            #     seconddate = startdate + timedelta(days=1)
            #     seconddate_str = seconddate.strftime('%Y-%m-%d')

            #     # Convert to string only for querying
            #     startdate_str = startdate.strftime('%Y-%m-%d')
            #     nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #     # Retrieve and store all data for the date range
            #     all_aggregated_data = ShiftProductiondata.objects.filter(
            #         Q(sp_date__gte=startdate_str, sp_date__lte=enddate_str),
            #         sp_plantname=Plantname,
            #         sp_machinename__in=MachinenamesArray
            #     ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
            
            #     all_breakdown_data = breakdown.objects.filter(
            #         Q(date=startdate_str, time__gte=firstday_start) |
            #         Q(date__range=[seconddate_str, enddate_str]) |
            #         Q(date=nex_enddate_str, time__lte=secondday_end),
            #         Machinename__in=MachinenamesArray,
            #         Plantname=Plantname
            #     ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')

            #     if select_wise == "Individual":

            #         for month_offset in range(12):
            #             # Start date of the current month
            #             month_startdate = startdate + relativedelta(months=month_offset)
            #             # End date of the current month (last day of the month)
            #             month_enddate = (month_startdate + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

            #             current_month_name = month_startdate.strftime('%B')

            #             total_days = (month_enddate - month_startdate).days + 1

            #             month_startdate_str = month_startdate.strftime('%Y-%m-%d')
            #             month_enddate_str = month_enddate.strftime('%Y-%m-%d')

            #             nex_enddate = month_enddate + timedelta(days=1)

            #             seconddate = month_startdate + timedelta(days=1)
            #             seconddate_str = seconddate.strftime('%Y-%m-%d')

            #             nex_enddate_str = nex_enddate.strftime('%Y-%m-%d')

            #             # Filter stored data for the current day and the shift boundaries specific to the machine
            #             aggregated_data = [
            #                     r for r in all_aggregated_data if 
            #                     r['sp_machinename'] == select_machine and 
            #                     month_startdate_str <= r['sp_date'] <= month_enddate_str
            #                 ]
                        
            #             time = 24 * total_days

            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             saw = [k for k in all_breakdown_data if
            #                k['Machinename'] == select_machine and
            #                ((k['date'] == month_startdate_str and firstday_start <= k['time']) or
            #                 (seconddate_str <= k['date'] <= month_enddate_str) or
            #                 (k['date'] == nex_enddate_str and k['time'] <= secondday_end))]

            #             #  .total_seconds()     # .seconds
            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_hours = mac_hours - total_idle_time_hours

            #             utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Month": current_month_name,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)

            #     elif select_wise == "All_Machines":

            #         for select_machine in MachinenamesArray:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             time = 24 * total_days

            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_hours = mac_hours - total_idle_time_hours

            #             utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)
                
            #     #--------------------------------
            #     elif select_wise == "selected_machines":
            #         for select_machine in selected_machines:

            #             aggregated_data = [r for r in all_aggregated_data if r['sp_machinename'] == select_machine]

            #             time = 24 * total_days

            #             mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

            #             saw = [k for k in all_breakdown_data if
            #                            k['Machinename'] == select_machine
            #                            ]

            #             total_idle_time = 0  # Initialize the sum

            #             last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

            #             # Iterate through the breakdown data and calculate time differences
            #             for last, bd in zip(saw, saw[1:]):
            #                 # If `MachineState = 0` for last, store its time but don't calculate yet
            #                 if last['MachineState'] == 0:
            #                     # Capture the first occurrence of MachineState = 0
            #                     if last_time_str is None:
            #                         last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                            
            #                 # Only calculate the time difference when transitioning from 0 to 1
            #                 if last_time_str and bd['MachineState'] == 1:
            #                     # Combine date and time for `bd`
            #                     bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

            #                     # Parse the combined date and time
            #                     last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
            #                     bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

            #                     # Calculate the time difference in seconds
            #                     time_difference = (bd_time - last_time).total_seconds()

            #                     # Print the intermediate values
            #                     # print(f"last time: {last_time}, bd time: {bd_time}, time difference (seconds): {time_difference}")

            #                     # Accumulate the total time in seconds
            #                     total_idle_time += time_difference

            #                     # Reset last_time_str to None after calculating for this transition
            #                     last_time_str = None
            #             # total_ProductionTimeActual_hour = ProductionTimeActual_hour - total_idle_time
            #             total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours

            #             total_hours = mac_hours - total_idle_time_hours

            #             utilization_rate = (total_hours / time) * 100 if total_hours != 0 else 0

            #             # Construct the response for the current date
            #             response_data.append({
            #                 "select_metrics": select_metrics,
            #                 "select_range": select_range,
            #                 "select_wise": select_wise,
            #                 "Machine": select_machine,
            #                 "Utilization_rate": round(utilization_rate, 2)
            #             })

            #         return JsonResponse(response_data, safe=False)


#--------------------------------------------------- Utilization_rate COMPLETED ---------------------------------------------------------#