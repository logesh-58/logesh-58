from django.http.response import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from productiontable.models import ProductionTable
from datetime import datetime, timedelta, time
from shiftmanagement.models import ShiftTimings, ShiftProductiondata
from django.db.models import Q, Sum, Max, Min, Count
from analysis.views import machineArray
from timeline.models import breakdown, badpart
import json
import pytz
from dashboard.models import Dashboard
from mouldmanagement.models import Mouldmodel
##########################################  Today  ##################################################

@csrf_exempt
def new_try(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        DateReq = json.loads(request.body)
        
        for_today = DateReq.get('for_today')
        for_yesterday = DateReq.get('for_yesterday')
        for_thisweek = DateReq.get('for_thisweek')
        for_thisyear = DateReq.get('for_thisyear')
        
        response_data = []

        MachinenamesArray = machineArray(Plantname)
        length_arr = len(MachinenamesArray)

        shift_starttime = ShiftTimings.objects.filter(Plantname=Plantname).values('shift1start', 'shift3end').last()
        
        # Extracting shift timings as strings (converted from time objects)
        firstday_start = shift_starttime['shift1start'].strftime('%H:%M:%S') if shift_starttime['shift1start'] else None
        secondday_end = shift_starttime['shift3end'].strftime('%H:%M:%S') if shift_starttime['shift3end'] else None

        # Get the current time in IST
        timenow_ist = datetime.now().time()

        time_start_A = time(0, 0, 0)
        time_end_A = shift_starttime['shift3end']

        if time_start_A <= timenow_ist <= time_end_A:
            today_date = (datetime.today()).date() - timedelta(days=1)
        else:
            today_date = (datetime.today()).date()

        startdate = today_date.replace(day=1)
        enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        pre_startdate_str = (startdate - timedelta(days=1)).strftime('%Y-%m-%d')

        nex_enddate_str = (enddate + timedelta(days=1)).strftime('%Y-%m-%d')

        all_aggregated_data = ShiftProductiondata.objects.filter(
                sp_date__range=[pre_startdate_str,nex_enddate_str],
                sp_plantname=Plantname,
                sp_machinename__in=MachinenamesArray
            ).values('sp_machinename', 'sp_date', 'sp_totalproductiontime', 'sp_shift', 'sp_totalproduction').order_by('sp_id')
        
        all_breakdown_data = breakdown.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Machinename__in=MachinenamesArray,
                Plantname=Plantname
            ).values('Machinename', 'MachineState', 'time', 'date').order_by('id')
        
        all_dashboard_value = ProductionTable.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Plantname=Plantname,
                Machinename__in=MachinenamesArray,
                ProductionCountActual__gt=0,
                MachineState=1
            ).values('Machinename', 'time', 'date', 'CycletimeActual', 'Mouldname_id', 'Cavity').order_by('id')
        
        all_RejectionParts_cal = badpart.objects.filter(
                date__range=[pre_startdate_str,nex_enddate_str],
                Plantname=Plantname,
                partcount__gt=0,
                Machinename__in=MachinenamesArray
            ).values('Machinename', 'date', 'time', 'Cavity').order_by('id')
        
        all_mould_value = Dashboard.objects.filter(
            Plantname=Plantname, Machinename__in=MachinenamesArray
        ).values('Machinename', 'Mouldname_id', 'ProductionCountActual', 'machinestatus').order_by('id')
        
        ########################################################

        # Function to calculate utilization rate
        def all_function(startdate, days):

            time = 24 * length_arr * days
            total_total_idle_time_hours = 0
            total_util_mac_hours = 0
            total_mac_counts = 0
            total_ProductionTimeActual_hour = 0
            total_ProductionCountActual = 0
            total_RejectionParts = 0
            total_uptime_mac_hours = 0

            for day_offset in range(days):

                current_date = startdate + timedelta(days=day_offset)
                current_date_str = current_date.strftime('%Y-%m-%d')

                next_day_str = (current_date + timedelta(days=1)).strftime('%Y-%m-%d')

                # Fetch production data for all machines in MachinenamesArray
                dashboard_value = [p for p in all_dashboard_value if
                                    ((p['date'] == current_date_str and firstday_start <= p['time']) or
                                        (p['date'] == next_day_str and p['time'] <= secondday_end))
                                ]

                ProductionTimeActual_hour = 0
                ProductionCountActual = 0
                # Process dashboard_value for each machine
                if dashboard_value:
                    
                    ProductionTimeActual_hour = sum(p['CycletimeActual'] for p in dashboard_value) / 3600  # Convert to hours
                    ProductionCountActual = sum(p['Cavity'] for p in dashboard_value) if dashboard_value else 0
                else:
                    ProductionTimeActual_hour = 0
                    ProductionCountActual = 0

                aggregated_data = [r for r in all_aggregated_data if
                        r['sp_date'] == current_date_str
                    ]
                util_mac_hours = sum(r['sp_totalproductiontime'] for r in aggregated_data) if aggregated_data else 0

                mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

                uptime_mac_hours = 0
                machine_shifts = {machine: max((r['sp_shift'] for r in aggregated_data if r['sp_machinename'] == machine), default=0) 
                                for machine in MachinenamesArray}
                
                for shift in machine_shifts.values():
                    if shift == 'A':
                        uptime_mac_hours += 8
                    elif shift == 'B':
                        uptime_mac_hours += 16
                    elif shift == 'C':
                        uptime_mac_hours += 24

                #######################

                RejectionParts_cal = [e for e in all_RejectionParts_cal if
                        # e['Machinename'] in MachinenamesArray and
                        ((e['date'] == current_date_str and firstday_start <= e['time']) or
                            (e['date'] == next_day_str and e['time'] <= secondday_end))
                    ]
                RejectionParts = sum(p['Cavity'] for p in RejectionParts_cal) if RejectionParts_cal else 0

                saw = [k for k in all_breakdown_data if
                                # k['Machinename'] in MachinenamesArray and
                                ((k['date'] == current_date_str and firstday_start <= k['time']) or
                                    (k['date'] == next_day_str and k['time'] <= secondday_end))
                            ]

                #  .total_seconds()     # .seconds
                total_idle_time = 0  # Initialize the sum

                last_time_str = None  # Keep track of the first occurrence of 'MachineState = 0'

                # Iterate through the breakdown data and calculate time differences
                for last, bd in zip(saw, saw[1:]):
                    # If `MachineState = 0` for last, store its time but don't calculate yet
                    if last['MachineState'] == 0:
                        # Capture the first occurrence of MachineState = 0
                        if last_time_str is None:
                            last_time_str = f"{last['date']} {last['time']}"  # 'YYYY-MM-DD HH:MM:SS'
                    
                    # Only calculate the time difference when transitioning from 0 to 1
                    if last_time_str and bd['MachineState'] == 1:
                        # Combine date and time for `bd`
                        bd_time_str = f"{bd['date']} {bd['time']}"  # 'YYYY-MM-DD HH:MM:SS'

                        # Parse the combined date and time
                        last_time = datetime.strptime(last_time_str, "%Y-%m-%d %H:%M:%S")
                        bd_time = datetime.strptime(bd_time_str, "%Y-%m-%d %H:%M:%S")

                        # Calculate the time difference in seconds
                        time_difference = (bd_time - last_time).total_seconds()

                        # Accumulate the total time in seconds
                        total_idle_time += time_difference

                        # Reset last_time_str to None after calculating for this transition
                        last_time_str = None

                total_idle_time_hours = total_idle_time / 3600  # Convert seconds to hours
                ########################

                total_total_idle_time_hours += total_idle_time_hours

                total_util_mac_hours += util_mac_hours

                total_uptime_mac_hours += uptime_mac_hours

                total_mac_counts += mac_counts

                total_ProductionTimeActual_hour += ProductionTimeActual_hour

                total_ProductionCountActual += ProductionCountActual

                total_RejectionParts += RejectionParts

            #calculate utilization
            utilization_total_hours = total_util_mac_hours - total_total_idle_time_hours
            utilization_rate = (utilization_total_hours / time) * 100

            #calculate uptime
            uptime_total_hours = total_uptime_mac_hours - total_total_idle_time_hours
            uptime = ((uptime_total_hours/(24 * days)) * 100)/length_arr

            #calculate availability
            oee_availability = (float(total_ProductionTimeActual_hour) / total_util_mac_hours) * 100 if total_util_mac_hours != 0 else 0

            #calculate oee
            oee_quality = (abs(total_ProductionCountActual - total_RejectionParts) / total_ProductionCountActual) * 100 if total_ProductionCountActual != 0 else 0
            oee_performance = (total_ProductionCountActual / total_mac_counts) * 100 if total_mac_counts != 0 else 0
            oee = (oee_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100 

            #calculate ooe
            ooe_availability = (float(total_ProductionTimeActual_hour) / total_uptime_mac_hours) * 100 if total_uptime_mac_hours != 0 else 0
            ooe = (ooe_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100

            #calculate teep
            teep_availability = (float(total_ProductionTimeActual_hour) / time) * 100 if time != 0 else 0
            teep = (teep_availability / 100) * (oee_performance / 100) * (oee_quality / 100) * 100

            return {
                "Utilization_Rate": round(utilization_rate, 2),
                "uptime": round(uptime, 2),
                "availability": round(oee_availability, 2),
                "OEE": round(oee, 2),
                "oee_availability": round(oee_availability, 2),
                "oee_quality": round(oee_quality, 2),
                "oee_performance": round(oee_performance, 2),
                "OOE": round(ooe, 2),
                "ooe_availability": round(ooe_availability, 2),
                "ooe_quality": round(oee_quality, 2),
                "ooe_performance": round(oee_performance, 2),
                "TEEP": round(teep, 2),
                "teep_availability": round(teep_availability, 2),
                "teep_quality": round(oee_quality, 2),
                "teep_performance": round(oee_performance, 2)
            }
     

        if for_today == "Today":

            main_function = all_function(today_date, 1)

            response_data.append({
                "parameter": "today",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_yesterday == "Yesterday":

            startdate = today_date - timedelta(days=1)

            main_function = all_function(startdate, 1)

            response_data.append({
                "parameter": "yesterday",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_thisweek == "This week":
            
            startdate = today_date - timedelta(days=today_date.weekday())

            main_function = all_function(startdate, 7)

            response_data.append({
                "parameter": "this week",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })

        if for_thisyear == "This month":
            
            startdate = today_date.replace(day=1)
            enddate = (today_date.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            total_days = (enddate - startdate).days + 1

            main_function = all_function(startdate, total_days)

            response_data.append({
                "parameter": "this month",
                "Utilization_Rate": main_function["Utilization_Rate"],
                "uptime": main_function["uptime"],
                "availability": main_function["oee_availability"],
                "OEE": main_function["OEE"],
                "oee_availability": main_function["oee_availability"],
                "oee_quality": main_function["oee_quality"],
                "oee_performance": main_function["oee_performance"],
                "OOE": main_function["OOE"],
                "ooe_availability": main_function["ooe_availability"],
                "ooe_quality": main_function["oee_quality"],
                "ooe_performance": main_function["oee_performance"],
                "TEEP": main_function["TEEP"],
                "teep_availability": main_function["teep_availability"],
                "teep_quality": main_function["oee_quality"],
                "teep_performance": main_function["oee_performance"]
            })


        current_date_str = today_date.strftime('%Y-%m-%d')
        next_day_str = (today_date + timedelta(days=1)).strftime('%Y-%m-%d')
        
        shift_starttime_on = shift_starttime['shift1start']
        shift_starttime_off = shift_starttime['shift3end']

        shift_start_datetime = datetime.strptime(current_date_str + ' ' + str(shift_starttime_on), '%Y-%m-%d %H:%M:%S')
        shift_end_datetime = datetime.strptime(next_day_str + ' ' + str(shift_starttime_off), '%Y-%m-%d %H:%M:%S') - timedelta(seconds=1)

        last_dashboard_value = [p for p in all_dashboard_value if
                                    ((p['date'] == current_date_str and firstday_start <= p['time']) or
                                        (p['date'] == next_day_str and p['time'] <= secondday_end))
                                ]
        
        rejection_data = [e for e in all_RejectionParts_cal if
                        ((e['date'] == current_date_str and firstday_start <= e['time']) or
                            (e['date'] == next_day_str and e['time'] <= secondday_end))
                    ]
        
        all_aggregated_data = [r for r in all_aggregated_data if
                        r['sp_date'] == current_date_str
                    ]

        current_hour_start = shift_start_datetime
        while current_hour_start < shift_end_datetime:
            next_hour_start = current_hour_start + timedelta(hours=1)
            hour_range_start_str = current_hour_start.strftime('%H:%M:%S')
            hour_range_end_str = (next_hour_start - timedelta(seconds=1)).strftime('%H:%M:%S')

            total_ProductionCountActual = 0
            total_RejectionParts = 0

            date = current_date_str if current_hour_start.time() >= shift_starttime_on else next_day_str

            # if "00:00:00" < hour_range_start_str < secondday_end:
            # if hour_range_start_str < secondday_end:
            if (hour_range_start_str < secondday_end) or ((hour_range_start_str and hour_range_end_str) > secondday_end):

                filtered_production = [p for p in last_dashboard_value if 
                                    p['date'] == date and 
                                    hour_range_start_str <= p['time'] <= hour_range_end_str]
            
                filtered_rejection = [r for r in rejection_data if 
                                    r['date'] == date and 
                                    hour_range_start_str <= r['time'] <= hour_range_end_str]
                                    
                # print("date1:", date, "hour_range_start_str1:", hour_range_start_str, "hour_range_end_str1:", hour_range_end_str)
            
            # elif "00:00:00" < hour_range_end_str < secondday_end:
            # elif hour_range_end_str < secondday_end:
            else:

                filtered_production = [k for k in last_dashboard_value if
                                ((k['date'] == current_date_str and hour_range_start_str <= k['time']) or
                                (k['date'] == next_day_str and k['time'] <= hour_range_end_str))
                                    ]
                
                filtered_rejection = [k for k in rejection_data if
                                ((k['date'] == current_date_str and hour_range_start_str <= k['time']) or
                                (k['date'] == next_day_str and k['time'] <= hour_range_end_str))
                                    ]
                
                # print("date2:", "rrrrrrrrrrrrrrrr", next_day_str, "hour_range_start_str2:", hour_range_start_str, "hour_range_end_str2:", hour_range_end_str)
            
            # else:
            #     filtered_production = [p for p in last_dashboard_value if 
            #                         p['date'] == date and 
            #                         hour_range_start_str <= p['time'] <= hour_range_end_str]
            
            #     filtered_rejection = [r for r in rejection_data if 
            #                         r['date'] == date and 
            #                         hour_range_start_str <= r['time'] <= hour_range_end_str]
            
            #     print("date3:", date, "hour_range_start_str3:", hour_range_start_str, "hour_range_end_str3:", hour_range_end_str)

            total_ProductionCountActual = sum(p['Cavity'] for p in filtered_production) if filtered_production else 0
            total_RejectionParts = sum(p['Cavity'] for p in filtered_rejection) if filtered_rejection else 0

            good_parts = total_ProductionCountActual - total_RejectionParts
            ########
            if good_parts < 0:
                parts = 0
            else:
                parts = good_parts
            ########
            response_data.append({
                "time": f"{hour_range_start_str} to {hour_range_end_str}",
                "total parts": total_ProductionCountActual,
                "good parts": parts,
                "bad parts": total_RejectionParts
            })

            current_hour_start = next_hour_start

        for machine_name in MachinenamesArray:

            if len([v for v in last_dashboard_value if v['date'] == current_date_str and v['Machinename'] == machine_name and v['time'] >= firstday_start]) != 0:

                dashboard_value = [r for r in all_mould_value if r['Machinename'] == machine_name]
                
                Mouldname_ids = dashboard_value[-1]['Mouldname_id'] if dashboard_value else 0

                Mouldname = Mouldmodel.objects.get(id=Mouldname_ids).Mouldname

                machine_status  = dashboard_value[-1]['machinestatus'] if dashboard_value else 0

            else:

                Mouldname = "No Data Found!"

                machine_status = "false"

            # Filter stored data for the current day and the shift boundaries specific to the machine
            dashboard_value = [p for p in last_dashboard_value if
                p['Machinename'] == machine_name
            ]

            aggregated_data = [r for r in all_aggregated_data if
                                r['sp_machinename'] == machine_name
                            ]

            mac_counts = sum(r['sp_totalproduction'] for r in aggregated_data) if aggregated_data else 0

            ProductionCountActual = 0
            mould_ProductionCountActual = 0

            if dashboard_value:
                mould_ProductionCountActual = sum(p['Cavity'] for p in dashboard_value if p['Mouldname_id'] == Mouldname_ids) if dashboard_value else 0
                ProductionCountActual = sum(p['Cavity'] for p in dashboard_value) if dashboard_value else 0
            else:
                ProductionCountActual = 0
                mould_ProductionCountActual = 0

            # Construct the response for the current date
            response_data.append({
                "Machine": machine_name,
                "mould_production_count": mould_ProductionCountActual,
                "Mouldname": Mouldname,
                "Machine_status": machine_status,
                "Current_production_count": ProductionCountActual,
                "Production_count_set": mac_counts
            })

        # If no valid keys are provided in the payload
        if not response_data:
            return JsonResponse("No valid input received", safe=False)

        return JsonResponse(response_data, safe=False)
    
######################################################################################################################################