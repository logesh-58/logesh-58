from django.urls import path, include
# from .Kpi_analysis import kpi_history
from .new_try import new_try 
from .kpi_new_method import kpi_history

urlpatterns = [

   path('kpi_history', kpi_history),
   path('new_try', new_try),
   
] 