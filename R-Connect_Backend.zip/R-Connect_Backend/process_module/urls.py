from django.urls import path, include
from .new_views import process_modulefd

urlpatterns = [
   path('Process_module', process_modulefd),  # Process_moduled
   
] 