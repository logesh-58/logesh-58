from timeline.models import timeline
from django.http.response import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from productiontable.models import ProductionTable
import json
import datetime
import time
from django.db.models.aggregates import Sum
from shiftmanagement.models import ShiftProductiondata, ShiftTimings
from machinemanagement.models import AddMachine
from mouldmanagement.models import Mouldmodel
from django.db.models import Q
from django.db.models import Sum as add
import pandas as pd

from django.utils.dateparse import parse_datetime

#------------------------------------------START of production analytics--------------------------------------------------
# def machineArray(Plantname):
#     mastermachineArray = []
#     getmachines = AddMachine.objects.filter(amPlantname = Plantname).values('amMachinename').order_by('amid')
#     for machines in getmachines:
#         Machinename = machines['amMachinename']
#         mastermachineArray.append(Machinename)
#     # print(mastermachineArray)
#     return mastermachineArray

def machineArray(Plantname):
    # Use values_list to fetch a list of machine names directly
    mastermachineArray = AddMachine.objects.filter(
        amPlantname=Plantname
    ).order_by('amid').values_list('amMachinename', flat=True)
    
    # Convert to list if necessary (depends on Django version)
    return list(mastermachineArray)

def checkwithConfigMachines(Plantname, machinedatas):
    configuredmachines = machineArray(Plantname)
    selecteddateMachine = []
    for i in (machinedatas):
        x = i['Machinename']
        if(x in configuredmachines):
            selecteddateMachine.append(i)
    return selecteddateMachine

@csrf_exempt
def daywisemachines(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        date = httpdata['date']
        date_ = datetime.datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.%fZ").date()
        Date = date_ + datetime.timedelta(days = 1)
        Date = datetime.datetime.strftime(Date, '%Y-%m-%d')
        # print(Date, Plantname)
        name = ProductionTable.objects.filter(date= Date, Plantname=Plantname).values('Machinename').distinct()
        names = list(name)
        selecteddateMachine = checkwithConfigMachines(Plantname, names)
        return JsonResponse(selecteddateMachine, safe=False)

def dayData(Plantname, Machinename, shiftstarttime, shiftendtime, Date, nextdate):
    # print(Machinename, Date, nextdate)
    print(shiftstarttime, shiftendtime)
    moldrow = ProductionTable.objects.filter(Q(date = Date, time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)
                                             |Q(date = nextdate, time__lte = shiftendtime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)).values('Mouldname_id').distinct()    
    data = []
    for i in moldrow:
        # print(i['Mouldname_id'])
        ProductionCountACTUALVALUE = ProductionTable.objects.filter(Q(date = Date, time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, Mouldname = i['Mouldname_id'], ProductionCountActual__gte = 0, MachineState = 1)
                                             |Q(date = nextdate, time__lte = shiftendtime, Machinename = Machinename, Plantname=Plantname, Mouldname = i['Mouldname_id'], ProductionCountActual__gte = 0, MachineState = 1)).count()
        ProductionCountSETVALUE    = ShiftProductiondata.objects.filter(Q(sp_date = Date, sp_machinename = Machinename, sp_mouldname_id = i['Mouldname_id'])
                                                                           | Q(sp_date = nextdate, sp_machinename = Machinename, sp_mouldname_id = i['Mouldname_id'])).aggregate(add('sp_totalproductionsetcount'))
        MouldName = Mouldmodel.objects.get(id = i['Mouldname_id']).Mouldname
        mydict = {'date':Date, 'Machinename':Machinename, 'Mouldname': MouldName, 'ProductionCountActual':ProductionCountACTUALVALUE, 'ProductionCountSet':ProductionCountSETVALUE['sp_totalproductionsetcount__sum']}
        data.append(mydict)
    return data
    # print(moldrow) 
    # print(moldrow)
    # print(moldrow_next)
    # print(moldrow)
    # print(moldrow_next)
    # for mold in moldrow:
    #     mold_name_id = mold['Mouldname_id']
    #     Mouldname_data = Mouldmodel.objects.filter(id = mold_name_id).values('Mouldname')
    #     mold_name = ''
    #     for i in Mouldname_data:
    #         mold_name = i['Mouldname']
    #     # print('Mouldname = ', mold_name)
    #     setval = 0
    #     ssetvalue1 = 0
    #     ssetvalue2 = 0
    #     ssetvalue3 = 0
    #     actualvalue = 0
    #     getrow = ProductionTable.objects.filter(date = Date, time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, Mouldname = mold_name_id, ProductionCountActual__gte = 1).count()
    #     #*******************************
    #     getrow_next = 0; 
    #     for m in moldrow_next:
    #         Mouldname_next_id = m['Mouldname_id']
    #         Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_next_id).values('Mouldname')
    #         Mouldname_next = ''
    #         for i in Mouldname_data:
    #             Mouldname_next = i['Mouldname']
    #         if(Mouldname_next == mold_name):
    #             try:
    #                 getrow_next = ProductionTable.objects.filter(date = nextdate, time__lte = shiftendtime, Machinename = Machinename, Plantname=Plantname, Mouldname = mold_name_id, ProductionCountActual__gte = 1).count()
    #             except:
    #                 getrow_next = 0
    #     actualvalue = getrow + getrow_next
    #     setvalue = ShiftProductiondata.objects.filter(Plantname = Plantname, sdate = Date, sMachinename = Machinename).values('sMouldname', 's1set', 's2set', 's3set')
    #     # print(setvalue)
    #     for value in setvalue:
    #         sMouldname = value['sMouldname']
    #         ssetvalue1 = value['s1set']
    #         ssetvalue2 = value['s2set']
    #         ssetvalue3 = value['s2set']
    #         # print(mold_name, len(mold_name), sMouldname, len(sMouldname))
    #         if((sMouldname.replace(" ", "")) == (mold_name.replace(" ", ""))):
    #             setval = ssetvalue1 + ssetvalue2 + ssetvalue3
    #     #*******************************
    #     # print('Daywise actual value = ', getrow, getrow_next, actualvalue)            
    #     # print('Daywise set value = ',setval)
    #     mydict = {'date':Date, 'Machinename':Machinename, 'Mouldname': mold_name, 'ProductionCountActual':int(actualvalue), 'ProductionCountSet':int(setval)}
    #     data.append(mydict)
    # return data

@csrf_exempt
def daywise(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']        
        httpdata = json.loads(request.body)
        date = httpdata['date']
        Machinename = httpdata['Machinename']
        Current_Date = datetime.datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.%fZ").date()
        # Current_Date = datetime.datetime.strptime(date, "%Y-%m-%dT%H:%M:%SZ").date()
        Next_Date = Current_Date + datetime.timedelta(days = 1)
        #--------------------------------------------------------------------------------
        shift_time = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift3end').last()
        shiftstarttime = shift_time['shift1start']
        shiftendtime   = shift_time['shift3end']
        #--------------------------------------------------------------------------------
        data = dayData(Plantname, Machinename, shiftstarttime, shiftendtime, Current_Date, Next_Date)
        return JsonResponse(data, safe=False)

@csrf_exempt
def weekwiseMachines(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        week = httpdata['week']
        # x = datetime.datetime.now()
        # currentday = x.weekday()
        today = datetime.datetime.now().date()
        today_day = datetime.datetime.now().weekday()
        currentweekstart = today - datetime.timedelta(days=today_day)
        lastweekstart = currentweekstart - datetime.timedelta(weeks=1)
        lastweekend = lastweekstart + datetime.timedelta(days=6)
        lastbfrweek_start = currentweekstart - datetime.timedelta(weeks=2)
        lastbfrweek_end = lastbfrweek_start + datetime.timedelta(days=6)        
       
        tw_ldate  = datetime.datetime.strftime(today,               '%Y-%m-%d')
        tw_fdate  = datetime.datetime.strftime(currentweekstart,    '%Y-%m-%d')
        lw_fdate  = datetime.datetime.strftime(lastweekstart,       '%Y-%m-%d')
        lw_ldate  = datetime.datetime.strftime(lastweekend,         '%Y-%m-%d')
        lbw_fdate = datetime.datetime.strftime(lastbfrweek_start,   '%Y-%m-%d')
        lbw_ldate = datetime.datetime.strftime(lastbfrweek_end,     '%Y-%m-%d')  
        
        # print(tw_fdate, tw_ldate, lw_fdate, lw_fdate, lbw_fdate, lbw_ldate)
        
        if(int(week) == 1): #this week
            machinedata = ProductionTable.objects.filter(date__range=(tw_fdate, tw_ldate), Plantname=Plantname, ProductionCountActual__gte = 1).values('Machinename').distinct()
            machinedatas = list(machinedata)
            selecteddateMachine = checkwithConfigMachines(Plantname, machinedatas)
            return JsonResponse(selecteddateMachine, safe=False)
        elif(int(week) == 0): #last week
            machinedata = ProductionTable.objects.filter(date__range=(lw_fdate, lw_ldate), Plantname=Plantname, ProductionCountActual__gte = 1).values('Machinename').distinct()
            machinedatas = list(machinedata)
            selecteddateMachine = checkwithConfigMachines(Plantname, machinedatas)
            return JsonResponse(selecteddateMachine, safe=False)
        elif(int(week) == (-1)): #last before week
            machinedata = ProductionTable.objects.filter(date__range=(lbw_fdate, lbw_ldate), Plantname=Plantname, ProductionCountActual__gte = 1).values('Machinename').distinct()
            machinedatas = list(machinedata)
            selecteddateMachine = checkwithConfigMachines(Plantname, machinedatas)
            return JsonResponse(selecteddateMachine, safe=False)

@csrf_exempt
def weekwise(request):
    # def weekwise(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        week = httpdata['week']
        Machinename = httpdata['Machinename']
        #--------------------------------------------------------------------------------
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        shift_endtime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift3end')
        shiftstarttime = datetime.datetime.now().time()
        shiftendtime = datetime.datetime.now().time()
        for i in shift_starttime:
            shiftstarttime = i['shift1start']
        for i in shift_endtime:
            shiftendtime = i['shift3end']
        #--------------------------------------------------------------------------------
        # today = datetime.datetime.now().date()
        # today_day = datetime.datetime.now().weekday()
        # currentweekstart = today - datetime.timedelta(days=today_day)
        # lastweekstart = currentweekstart - datetime.timedelta(weeks=1)
        # lastweekend = currentweekstart-datetime.timedelta(days=1)
        # FMT = '%Y-%m-%d'
        # tw_fdate = str(currentweekstart)
        # tw_ldate = str(today)
        # lw_fdate = str(lastweekstart)
        # lw_ldate = str(lastweekend)
        today = datetime.datetime.now().date()
        today_day = datetime.datetime.now().weekday()
        currentweekstart = today - datetime.timedelta(days=today_day)
        lastweekstart = currentweekstart - datetime.timedelta(weeks=1)
        lastweekend = lastweekstart + datetime.timedelta(days=6)       
       
        tw_ldate  = datetime.datetime.strftime(today,               '%Y-%m-%d')
        tw_fdate  = datetime.datetime.strftime(currentweekstart,    '%Y-%m-%d')
        lw_fdate  = datetime.datetime.strftime(lastweekstart,       '%Y-%m-%d')
        lw_ldate  = datetime.datetime.strftime(lastweekend,         '%Y-%m-%d')

        data = []
        if(int(week) == 1): # this week
            current_weekdates = pd.date_range(start = tw_fdate, end = tw_ldate)
            for i in current_weekdates:
                current_date = str(i.date())
                next_date = i.date() + datetime.timedelta(days = 1)
                moldrow = list(ProductionTable.objects.filter(Q(date = str(i.date()), time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)
                                             |Q(date = str(next_date), time__lte = shiftendtime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)).values('date', 'Mouldname_id').distinct())
                Production_Actual = 0
                if moldrow != []:
                    for mould in moldrow:
                        mould_name = Mouldmodel.objects.get(id = mould['Mouldname_id']).Mouldname
                        mouldid = mould['Mouldname_id']
                        Production_Actual = ProductionTable.objects.filter(Q(date = str(i.date()), time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, Mouldname = mouldid, MachineState = 1)
                                                |Q(date = str(next_date), time__lte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, Mouldname = mouldid, MachineState = 1)).count()
                        mydict = {'date':current_date, 'Machinename':Machinename, 'Mouldname':mould_name, 'ProductionCountActual':Production_Actual}
                        data.append(mydict)
                else:
                    mydict = {'date':current_date, 'Machinename':Machinename, 'Mouldname':None, 'ProductionCountActual':Production_Actual}
                    data.append(mydict)
            # print(data)
            return JsonResponse(data, safe=False)
        
        elif(int(week) == 0):
            # print(lw_fdate, lw_ldate)
            last_weekdates = pd.date_range(start = lw_fdate, end = lw_ldate)
            for i in last_weekdates:
                last_date = str(i.date())
                next_date = i.date() + datetime.timedelta(days = 1)
                moldrow = list(ProductionTable.objects.filter(Q(date = str(i.date()), time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)
                                             |Q(date = str(next_date), time__lte = shiftendtime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, MachineState = 1)).values('date', 'Mouldname_id').distinct())
                Production_Actual = 0
                if moldrow != []:
                    for mould in moldrow:
                        mould_name = Mouldmodel.objects.get(id = mould['Mouldname_id']).Mouldname
                        mouldid = mould['Mouldname_id']
                        Production_Actual = ProductionTable.objects.filter(Q(date = str(i.date()), time__gte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, Mouldname = mouldid, MachineState = 1)
                                                |Q(date = str(next_date), time__lte = shiftstarttime, Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 0, Mouldname = mouldid, MachineState = 1)).count()
                        mydict = {'date':last_date, 'Machinename':Machinename, 'Mouldname':mould_name, 'ProductionCountActual':Production_Actual}
                        data.append(mydict)
                else:
                    mydict = {'date':last_date, 'Machinename':Machinename, 'Mouldname':None, 'ProductionCountActual':Production_Actual}
                    data.append(mydict)
            return JsonResponse(data, safe=False)

@csrf_exempt
def weekdaychart(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        machinedatas = httpdata['datemachine']
        iDay = httpdata['daydata']
        iweek = machinedatas['week']
        Machinename = machinedatas['Machinename']
        Day = time.strptime(iDay, "%A").tm_wday
        x = datetime.datetime.now()
        currentday = x.weekday()
        # print(Day, iweek, Machinename)
        today = datetime.datetime.now().date()
        today_day = datetime.datetime.now().weekday()
        currentweekstart = today - datetime.timedelta(days=today_day)
        lastweekstart = currentweekstart - datetime.timedelta(weeks=1)
        lastweekend = currentweekstart-datetime.timedelta(days=1)

        #--------------------------------------------------------------------------------
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        shift_endtime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift3end')
        shiftstarttime = datetime.datetime.now().time()
        shiftendtime = datetime.datetime.now().time()
        for i in shift_starttime:
            shiftstarttime = i['shift1start']
        for i in shift_endtime:
            shiftendtime = i['shift3end']
        #--------------------------------------------------------------------------------
        if (int(iweek) == 0): #lastweek
            Day_date = lastweekstart + datetime.timedelta(days=Day)
            nextdate = lastweekstart + datetime.timedelta(days=Day+1)
            Day_date = datetime.datetime.strftime(Day_date, '%Y-%m-%d')
            nextdate = datetime.datetime.strftime(nextdate, '%Y-%m-%d')
            # print('0 = ',Day_date, nextdate, shift_starttime, shift_endtime)
            data = dayData(Plantname, Machinename, shiftstarttime, shiftendtime, Day_date, nextdate)
            return JsonResponse(data, safe=False)     
                                                                             
        if (int(iweek) == 1): #currentweek
            Day_date = currentweekstart + datetime.timedelta(days=Day)
            nextdate = currentweekstart + datetime.timedelta(days=Day+1)
            Day_date = datetime.datetime.strftime(Day_date, '%Y-%m-%d')
            nextdate = datetime.datetime.strftime(nextdate, '%Y-%m-%d')
            # print('1 = ',Day_date, nextdate, shift_starttime, shift_endtime)
            data = dayData(Plantname, Machinename, shiftstarttime, shiftendtime, Day_date, nextdate)
            return JsonResponse(data, safe=False)  
#------------------------------------------END of production analytics--------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------
#------------------------------------------START of efficiency analytics------------------------------------------------
def OEE(Date, parameters, Plantname, shiftstarttime, shiftendtime):
    now = datetime.datetime.now()
    names = checkwithConfigMachines(Plantname, list(ProductionTable.objects.filter(Plantname=Plantname, date=Date).values('Machinename').distinct()))
    previousdate = datetime.datetime.strftime(((datetime.datetime.strptime(Date, '%Y-%m-%d') - datetime.timedelta(days=1)).date()), '%Y-%m-%d')
    Data = []
    downtime = '00:00:00'
    moldchangetime = '00:00:00'
    print(names)
    for name in names:
        Machinename = name['Machinename']
        if(now.hour < shiftstarttime.hour):
            getlasttime = ProductionTable.objects.filter(date = Date, time_lte = shiftendtime, Machinename = Machinename, Plantname = Plantname, ProductionCountActual__gte = 1).values('time').last()
            getfirsttime = ProductionTable.objects.filter(date = previousdate, time__gte = shiftstarttime, Machinename = Machinename, Plantname = Plantname, ProductionCountActual__gte = 1).values('time').first()
        else:
            getfirsttime = ProductionTable.objects.filter(date = Date, time__gte = shiftstarttime, Machinename = Machinename, Plantname = Plantname, ProductionCountActual__gte = 1).values('time').first()
            getlasttime = ProductionTable.objects.filter(date = Date, time__lte = now.time(), Machinename = Machinename, Plantname = Plantname, ProductionCountActual__gte = 1).values('time').last()        
        try:
            getfirsttime = datetime.datetime.strptime((getfirsttime['time']), '%H:%M:%S')
            getlasttime = datetime.datetime.strptime((getlasttime['time']), '%H:%M:%S')
        except:
            continue
        getfirsttime_seconds    = (getfirsttime - datetime.datetime(1900, 1, 1)).total_seconds()
        getlasttime_seconds     = (getlasttime - datetime.datetime(1900, 1, 1)).total_seconds()
        # print('Get First and Last seconds = ', getfirsttime_seconds, getlasttime_seconds)
        if(getfirsttime > getlasttime):
            daylasttime = ((datetime.datetime.strptime('23:59:59', '%H:%M:%S')) - datetime.datetime(1900, 1, 1)).total_seconds()
            daystarttime= ((datetime.datetime.strptime('00:00:01', '%H:%M:%S')) - datetime.datetime(1900, 1, 1)).total_seconds()
            total_running_seconds = (int(daylasttime) - int(getfirsttime_seconds)) + (int(getlasttime_seconds) - int(daystarttime))
        else:
            total_running_seconds = int(getlasttime_seconds) - int(getfirsttime_seconds)
        # print('total_running_seconds = ', total_running_seconds)
        #--------------------Get Down Time and Mold CHange Time--------------------------------
        getrow = timeline.objects.filter(date = Date, Machinename = Machinename, Plantname = Plantname).values('nonproductionhour', 'moldchangetime')
        for i in getrow:
            downtime = i['nonproductionhour']
            moldchangetime = i['moldchangetime']
        #convert string time to datetime & datetime to seconds
        downtime_ = ((datetime.datetime.strptime(downtime, '%H:%M:%S')) - datetime.datetime(1900, 1, 1)).total_seconds()
        moldchangetime_ = ((datetime.datetime.strptime(moldchangetime, '%H:%M:%S')) - datetime.datetime(1900, 1, 1)).total_seconds()
        #check with parameters
        if (parameters == 'With mouldchange time'):
            nonrunning_seconds   = int(downtime_) + int(moldchangetime_)
            actual_running_seconds = (total_running_seconds) - nonrunning_seconds
            # print(total_running_seconds, nonrunning_seconds, actual_running_seconds)
            percentage = round((((total_running_seconds) / actual_running_seconds)*100), 2)
        else:
            actual_running_seconds = (total_running_seconds) - int(downtime_)
            # print(total_running_seconds, downtime_, actual_running_seconds)
            percentage = round((((total_running_seconds) / actual_running_seconds)*100), 2)
        # print(total_running_seconds, actual_running_seconds, percentage)
        my_dict = {'date': Date, 'Machinename':Machinename, 'efficiency': percentage}
        # print(my_dict)
        Data.append(my_dict)
        # print('OEE Data = ', Data)
    return Data

@csrf_exempt
def overallefficiencydata(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        parameters = httpdata['parameters']
        Date = datetime.datetime.strftime((datetime.datetime.strptime(httpdata['date'], "%Y-%m-%dT%H:%M:%S.%fZ")), '%Y-%m-%d')
        # print('Date = ', Date)
        currentdate = datetime.datetime.strftime((datetime.datetime.now()), '%Y-%m-%d')
        #--------------------------------------------------------------------------------
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start', 'shift3end')
        shiftstarttime = datetime.datetime.now().time()
        shiftendtime = datetime.datetime.now().time()
        for i in shift_starttime:
            shiftstarttime = i['shift1start']
            shiftendtime = i['shift3end']
        # print('Shift Start & End time = ', shiftstarttime, shiftendtime)
        #--------------------------------------------------------------------------------
        if(Date == currentdate):
            data = OEE(Date, parameters, Plantname, shiftstarttime, shiftendtime)
            # print(data)
            return JsonResponse(data, safe=False)
        else:
            # print(Date)
            name = ProductionTable.objects.filter(Plantname=Plantname, date= Date).values('Machinename').distinct()
            names = list(name)
            names = checkwithConfigMachines(Plantname, names)
            Data = []
            downtime = '00:00:00'
            moldchangetime = '00:00:00'
            for name in names:
                Machinename = name['Machinename']
                getrow = timeline.objects.filter(date = Date, Machinename = Machinename, Plantname = Plantname).values('nonproductionhour', 'moldchangetime')
                # print(Machinename, parameters, getrow)
                # print(Machinename, getrow)
                for i in getrow:
                    downtime = i['nonproductionhour']
                    moldchangetime = i['moldchangetime']
                downtime_ = datetime.datetime.strptime(downtime, '%H:%M:%S')
                downtime_ = downtime_ - datetime.datetime(1900, 1, 1)
                moldchangetime_ = datetime.datetime.strptime(moldchangetime, '%H:%M:%S')
                moldchangetime_ = moldchangetime_ - datetime.datetime(1900, 1, 1)
                # print(downtime_, moldchangetime_)
                if (parameters == 'With mouldchange time'):
                    downtime_       = downtime_.total_seconds()
                    moldchangetime_ = moldchangetime_.total_seconds()
                    total_seconds   = int(downtime_) + int(moldchangetime_)
                    working_sec = (24*60*60) - total_seconds
                    percentage = ((working_sec/(24*60*60))*100)
                    percentage = round(percentage, 2)
                else:
                    downtime_ = downtime_.total_seconds()
                    downtime_ = int(downtime_)
                    working_min = (24*60*60) - downtime_
                    percentage = ((working_min/(24*60*60))*100)
                    percentage = round(percentage, 2)
                # print(Machinename, percentage)
                my_dict = {'Machinename':Machinename, 'efficiency': percentage}
                Data.append(my_dict)
            return JsonResponse(Data, safe=False)

#########################

def todayMoldEfficiency(date, shiftstarttime, Plantname, Machinename):
    dateArray = []
    time_now = datetime.datetime.now().time()
    # print(time_now)
    time_now = time_now.strftime('%H:%M:%S')
    # print(time_now)
    dateArray.append(date)
    timeArray = [shiftstarttime, time_now]
    masterMouldname = []
    #From current day shiftstart time
    for i in range(0, len(dateArray)):
        ind = (i*i)+ i
        updated_date = dateArray[i]
        fromtime = timeArray[ind]
        totime   = timeArray[ind + 1]
        # print('Datetime = ', updated_date, fromtime, totime)
        if(ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 1).exists()):
            getMouldnames = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), 
                Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 1).values('Mouldname_id').distinct()
            for i in getMouldnames:
                Mouldname_id = i['Mouldname_id']
                Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
                Mouldname = ''
                for i in Mouldname_data:
                    Mouldname = i['Mouldname']
                if(Mouldname_id in masterMouldname):
                    print('Mouldname already present')
                else:
                    masterMouldname.append(Mouldname_id)
    eff_data = []
    for Mouldname in masterMouldname:
        totalseconds = 0
        actualseconds = 0
        estimatedtime = 0
        setcount = 0
        ssetvalue1 = 0
        ssetvalue2 = 0
        ssetvalue3 = 0
        Mould_Id = Mouldmodel.objects.get(Mouldname = Mouldname).id
        # print(Plantname, date, Machinename, Mouldname, len(Mouldname))
        setvalue = ShiftProductiondata.objects.filter(sp_plantname = Plantname, sp_date = date, sp_machinename = Machinename, sp_mouldname_id = Mould_Id).values('sp_shift', 'sp_totalproductionsetcount')
        for value in setvalue:
            if value['sp_shift'] == 'A':
                ssetvalue1 = value['sp_totalproductionsetcount']
            if value['sp_shift'] == 'B':
                ssetvalue2 = value['sp_totalproductionsetcount']
            if value['sp_shift'] == 'C':
                ssetvalue3 = value['sp_totalproductionsetcount']
            setcount = ssetvalue1 + ssetvalue2 + ssetvalue3
        for i in range(0, len(dateArray)):
            ind = (i*i)+ i
            updated_date = dateArray[i]
            fromtime = timeArray[ind]
            totime   = timeArray[ind + 1]
            # print(Mouldname, updated_date, fromtime, totime)
            if(ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1).exists()):
                getmolddata = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1).values('CycletimeSet').distinct()
                # print(Mouldname, getmolddata)
                for i in getmolddata:
                    settime = round((i['CycletimeSet'] / 1000000), 2)
                    # print(Mouldname, settime, setcount)
                    try:
                        estimatedtime = round((setcount / (3600 / settime)),2) #use this formula
                        # estimatedtime = round((setcount / settime), 2) # round(percentage, 3)
                        # print('estimatedtime = ', estimatedtime)
                    except:
                        estimatedtime = 0
                    # print(Mouldname, estimatedtime)
                    getfirsttime = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1).values('time').first()
                    firsttime = getfirsttime['time']
                    # print(Mouldname, firsttime)
                    getlasttime = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mouldname, ProductionCountActual__gte = 1).values('time').last()
                    lasttime = getlasttime['time']
                    # print(Mouldname, lasttime)
                    firsttime = datetime.datetime.strptime(firsttime, '%H:%M:%S')
                    lasttime  = datetime.datetime.strptime(lasttime, '%H:%M:%S')
                    actualtime = lasttime - firsttime
                    # print(Mouldname, actualtime, estimatedtime)
                    actualtime_s = int(actualtime.total_seconds())
                    estimatedtime_s = int(estimatedtime * 3600)
                    totalseconds = totalseconds + estimatedtime_s
                    actualseconds = actualseconds + actualtime_s
                    # print(Mouldname, actualseconds, totalseconds)
        efficiencyvalue = round((( totalseconds / actualseconds ) * 100), 2)    # Formula = (expected / actual) * 100
        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
        for i in Mouldname_data:
            Mouldname = i['Mouldname']
        mydict = {'Machinename':Machinename, 'Mouldname': Mouldname, 'efficiency': efficiencyvalue}
        # print(mydict)
        eff_data.append(mydict)
    return eff_data

@csrf_exempt
def daywisemouldeffdata(request):
    if request.method == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        # print(httpdata)
        Dateform = httpdata['date']
        Machinename = httpdata['Machinename']
        idate = Dateform['date']
        # print(idate)
        date_ = datetime.datetime.strptime(idate, "%Y-%m-%dT%H:%M:%S.%fZ")
        current_date = date_ + datetime.timedelta(days=1)
        current_date = current_date.strftime('%Y-%m-%d')
        # print('Current date = ',current_date)
        next_date = date_ + datetime.timedelta(days=2)
        Next_Date = datetime.datetime.strftime(next_date, '%Y-%m-%d')
        # print('Next_Date = ',Next_Date)
        today_date = datetime.datetime.now().date()
        today_date = datetime.datetime.strftime(today_date, '%Y-%m-%d')
        #--------------------------------------------------------------------------------
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        shift_endtime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift3end')
        shiftstarttime = datetime.datetime.now().time()
        shiftendtime = datetime.datetime.now().time()
        for i in shift_starttime:
            shiftstarttime = i['shift1start']
        for i in shift_endtime:
            shiftendtime = i['shift3end']
        nextdate = ''
        dateArray = []
        if(shiftendtime.hour > 0):
            dateArray.append(current_date)
            dateArray.append(Next_Date)
            timeArray = [str(shiftendtime), '23:59:59', '00:00:01', str(shiftendtime)]
            # print(timeArray)
        else:
            dateArray.append(current_date)
            timeArray = [str(shiftstarttime), str(shiftendtime)]
            # print(timeArray)
        #--------------------------------------------------------------------------------
        if(current_date == today_date):
            today_efficiency = todayMoldEfficiency(today_date, shiftstarttime, Plantname, Machinename)
            # print(today_efficiency)
            return JsonResponse(today_efficiency, safe=False)
        else:
            masterMouldname = []
            #From current day 6'o clock
            # print(dateArray, timeArray)
            for i in range(0, len(dateArray)):
                ind = (i*i)+ i
                updated_date = dateArray[i]
                fromtime = timeArray[ind]
                totime   = timeArray[ind + 1]
                # print(updated_date, fromtime, totime)
                if(ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 1).exists()):
                    getMouldnames = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Machinename = Machinename, Plantname=Plantname, ProductionCountActual__gte = 1).values('Mouldname_id').distinct()
                    for i in getMouldnames:
                        Mouldname_id = i['Mouldname_id']
                        Mouldname_data = Mouldmodel.objects.filter(id = Mouldname_id).values('Mouldname')
                        Mouldname =''
                        for i in Mouldname_data:
                            Mouldname = i['Mouldname']                        
                        if(Mouldname in masterMouldname):
                            print('Mouldname already present')
                        else:
                            masterMouldname.append(Mouldname)
                # print(masterMouldname)
            eff_data = []
            for Mouldname in masterMouldname:
                totalseconds = 0
                actualseconds = 0
                for i in range(0, len(dateArray)):
                    ind = (i*i)+ i
                    updated_date = dateArray[i]
                    fromtime = timeArray[ind]
                    totime   = timeArray[ind + 1]
                    # print(Mouldname, updated_date, fromtime, totime)
                    setcount = 0
                    ssetvalue1 = 0
                    ssetvalue2 = 0
                    ssetvalue3 = 0
                    Mould_Id = Mouldmodel.objects.get(Mouldname = Mouldname).id
                    setvalue = ShiftProductiondata.objects.filter(sp_plantname = Plantname, sp_date = current_date, sp_machinename = Machinename, sp_mouldname_id = Mould_Id).values('sp_shift', 'sp_totalproductionsetcount')
                    for value in setvalue:
                        if value['sp_shift'] == 'A':
                           ssetvalue1 = value['sp_totalproductionsetcount']
                        if value['sp_shift'] == 'B':
                           ssetvalue2 = value['sp_totalproductionsetcount']
                        if value['sp_shift'] == 'C':
                           ssetvalue3 = value['sp_totalproductionsetcount']
                        setcount = ssetvalue1 + ssetvalue2 + ssetvalue3
                    #--------------------------------------------------------------------------------
                    if(ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mould_Id, ProductionCountActual__gte = 1).exists()):
                        getmolddata = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mould_Id, ProductionCountActual__gte = 1).values('CycletimeSet').distinct()
                        # print(Mouldname, getmolddata)
                        for i in getmolddata:
                            settime = round((i['CycletimeSet'] / 1000000), 2)
                            # print(Mouldname, settime, setcount)
                            try:
                                estimatedtime = round((setcount / settime), 2) # round(percentage, 3)
                            except:
                                estimatedtime = 0
                            # print(Mouldname, estimatedtime)
                            getfirsttime = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mould_Id, ProductionCountActual__gte = 1).values('time').first()
                            firsttime = getfirsttime['time']
                            # print(Mouldname, firsttime)
                            getlasttime = ProductionTable.objects.filter(date = updated_date, time__range = (fromtime, totime), Plantname=Plantname, Machinename = Machinename, Mouldname= Mould_Id, ProductionCountActual__gte = 1).values('time').last()
                            lasttime = getlasttime['time']
                            # print(Mouldname, lasttime)
                            firsttime = datetime.datetime.strptime(firsttime, '%H:%M:%S')
                            lasttime  = datetime.datetime.strptime(lasttime, '%H:%M:%S')
                            actualtime = lasttime - firsttime
                            # print(Mouldname, actualtime, estimatedtime)
                            actualtime_s = int(actualtime.total_seconds())
                            estimatedtime_s = int(estimatedtime * 3600)
                            totalseconds = totalseconds + estimatedtime_s
                            actualseconds = actualseconds + actualtime_s
                # print(Mouldname, totalseconds, actualseconds)
                efficiencyvalue = round((( totalseconds / actualseconds ) * 100), 2)    # Formula = (expected / actual) * 100
                mydict = {'Machinename':Machinename, 'Mouldname': Mouldname, 'efficiency': efficiencyvalue}
                # print(mydict)
                eff_data.append(mydict)
            return JsonResponse(eff_data, safe=False)

@csrf_exempt
def weekwisemachineefficiency(request):
    if(request.method) == 'POST':
        Plantname = request.GET['Plantname']
        data = request.body
        httpdata = json.loads(data)
        week = httpdata['week']
        # print(week)
        Machinename = httpdata['Machinename']
        parameters = httpdata['parameters']
        # print(week, Machinename)
        today = datetime.datetime.now().date()
        today_day = datetime.datetime.now().weekday()
        currentweekstart = today - datetime.timedelta(days=today_day)
        lastweekstart = currentweekstart - datetime.timedelta(weeks=1)
        lastweekend = lastweekstart + datetime.timedelta(days=6)
        lastbfrweek_start = currentweekstart - datetime.timedelta(weeks=2)
        lastbfrweek_end = lastbfrweek_start + datetime.timedelta(days=6)
        weekdates = None
        # tw_fdate = str(currentweekstart)
        # tw_ldate = str(today)
        # lw_fdate = str(lastweekstart)
        # lw_ldate = str(lastweekend)
        # lbw_fdate = str(lastbfrweek_start)
        # lbw_ldate = str(lastbfrweek_end)
        tw_ldate  = datetime.datetime.strftime(today,               '%Y-%m-%d')
        tw_fdate  = datetime.datetime.strftime(currentweekstart,    '%Y-%m-%d')
        lw_fdate  = datetime.datetime.strftime(lastweekstart,       '%Y-%m-%d')
        lw_ldate  = datetime.datetime.strftime(lastweekend,         '%Y-%m-%d')
        lbw_fdate = datetime.datetime.strftime(lastbfrweek_start,   '%Y-%m-%d')
        lbw_ldate = datetime.datetime.strftime(lastbfrweek_end,     '%Y-%m-%d')  
        # print(lbw_fdate, lbw_ldate, lw_fdate, lw_ldate, tw_fdate, tw_ldate)
        #--------------------------------------------------------------------------------
        shift_starttime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift1start')
        shift_endtime = ShiftTimings.objects.filter(Plantname = Plantname).values('shift3end')
        shiftstarttime = datetime.datetime.now().time()
        shiftendtime = datetime.datetime.now().time()
        for i in shift_starttime:
            shiftstarttime = i['shift1start']
        for i in shift_endtime:
            shiftendtime = i['shift3end']
        #--------------------------------------------------------------------------------
        today = today.strftime('%Y-%m-%d')
        if(int(week) == 1):
            weekdates = pd.date_range(start = tw_fdate, end = tw_ldate)
        elif (int(week) == 0):
            weekdates  = pd.date_range(start = lw_fdate, end = lw_ldate)
            # print(weekdates)
        elif (int(week) == (-1)):
            weekdates  = pd.date_range(start = lbw_fdate, end = lbw_ldate)
        #---------------------------------------------------------------------------------
        downtime = '00:00:00'
        moldchangetime = '00:00:00'
        data = []
        for i in weekdates:
            getrow = list(timeline.objects.filter(date = str(i.date()), Machinename = Machinename, Plantname = Plantname).values('date', 'nonproductionhour', 'moldchangetime'))
            if getrow != []:
                for i in getrow:
                    downseconds = 0
                    moldcnhgsec = 0
                    date = i['date']
                    # print(date)
                    downtime = i['nonproductionhour']
                    moldchangetime = i['moldchangetime']
                    if(date == str(today)):
                        oeedata = OEE(date, parameters, Plantname, shiftstarttime, shiftendtime)
                        print("oeedata", oeedata)
                        for index, d in enumerate(oeedata):
                            oee_Machinename = d['Machinename']
                            if(oee_Machinename == Machinename):
                                temp_date = d['date']
                                temp_date = datetime.datetime.strptime(temp_date, '%Y-%m-%d')
                                temp_date = temp_date.strftime('%Y-%m-%d') 
                                d['date'] = temp_date
                                data.append(d)
                    else:
                        downtime = datetime.datetime.strptime(downtime, '%H:%M:%S')
                        moldchangetime = datetime.datetime.strptime(moldchangetime, '%H:%M:%S')
                        npd_timedelta = downtime - datetime.datetime(1900, 1, 1)
                        downseconds = int(npd_timedelta.total_seconds())
                        mldchng_timedelta = moldchangetime - datetime.datetime(1900, 1, 1)
                        moldcnhgsec = int(mldchng_timedelta.total_seconds())
                        if (parameters == 'With mouldchange time'):
                            nonpdseconds = downseconds + moldcnhgsec
                            fulldayseconds = 24*60*60
                            pdseconds = fulldayseconds - nonpdseconds
                            efficiency = round(((pdseconds / fulldayseconds) * 100),2)
                        elif (parameters == 'Without mouldchange time'):
                            nonpdseconds = downseconds
                            fulldayseconds = 24*60*60
                            pdseconds = fulldayseconds - nonpdseconds
                            efficiency = round(((pdseconds / fulldayseconds) * 100),2)
                        temp_date = date
                        temp_date = datetime.datetime.strptime(temp_date, '%Y-%m-%d')
                        temp_date = temp_date.strftime('%Y-%m-%d')                        
                        dict = {'date': temp_date, 'Machinename': Machinename, 'efficiency':efficiency}
                        data.append(dict)
            else:
                dict = {'date': i.date(), 'Machinename': Machinename, 'efficiency':0}
                data.append(dict)
        return JsonResponse(data, safe=False)
#------------------------------------------END of efficiency analytics--------------------------------------------------    
