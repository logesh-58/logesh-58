from django.db import models
from django.db.models.base import Model

# Create your models here.
class AddMachine(models.Model):
    amid =              models.AutoField(primary_key=True)
    amPlantname =       models.CharField(max_length=255,default=False,null=True)
    amMachinename =     models.CharField(max_length=255,default=False,null=True)
    ammachineimage =    models.CharField(max_length=255,default=False,null=True)
    ammachinecode =     models.CharField(max_length=255,default=False,null=True)
    ammachinelocation = models.CharField(max_length=255,default=False,null=True)
    amconsiderbool =    models.BooleanField(default=False, null=True)
    ammachineip = models.CharField(max_length=255,default=False,null=True)
    ambarelzonecount = models.CharField(max_length=255,default=False,null=True)
    amhrtczonecount = models.CharField(max_length=255,default=False,null=True)

